<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'block_sis';
$plugin->version   = 2025103101;
$plugin->requires  = 2022041900;
$plugin->maturity  = MATURITY_STABLE;
$plugin->release   = '1.0.0';
