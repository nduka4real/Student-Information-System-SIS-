CREATE TABLE `local_sis_promotions_log` (
  `id` int(10) UNSIGNED NOT NULL,
  `source_category` int(10) UNSIGNED NOT NULL,
  `target_category` int(10) UNSIGNED NOT NULL,
  `source_session` int(10) UNSIGNED NOT NULL,
  `target_session` int(10) UNSIGNED NOT NULL,
  `students_promoted` int(10) UNSIGNED NOT NULL,
  `promoted_by` int(10) UNSIGNED NOT NULL,
  `timecreated` int(10) UNSIGNED NOT NULL,
  `details` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Log of student promotions';

Table structure for table `mdi_local_sis_result`
CREATE TABLE `mdi_local_sis_result` (
  `userid` int(11) NOT NULL,
  `courseid` int(11) NOT NULL,
  `data` text NOT NULL,
  `total` decimal(10,2) DEFAULT 0.00,
  `weighted` decimal(10,2) DEFAULT 0.00,
  `grade` varchar(10) DEFAULT '',
  `points` decimal(5,2) DEFAULT 0.00,
  `timemodified` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- --------------------------------------------------------

--
-- Table structure for table `mdl_local_sis_ca`
--

CREATE TABLE `mdl_local_sis_ca` (
  `id` bigint(10) NOT NULL,
  `userid` bigint(10) NOT NULL DEFAULT 0,
  `courseid` bigint(10) NOT NULL DEFAULT 0,
  `ca_score` decimal(10,2) NOT NULL DEFAULT 0.00,
  `timemodified` bigint(10) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Continuous assessment records' ROW_FORMAT=COMPRESSED;

-- --------------------------------------------------------

--
-- Table structure for table `mdl_local_sis_ca_config`
--

CREATE TABLE `mdl_local_sis_ca_config` (
  `id` bigint(10) NOT NULL,
  `courseid` bigint(10) NOT NULL DEFAULT 0,
  `sessionid` bigint(10) NOT NULL DEFAULT 0,
  `termid` int(10) NOT NULL DEFAULT 0,
  `timemodified` bigint(10) NOT NULL DEFAULT 0,
  `components` longtext DEFAULT NULL,
  `grading_scale` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Continuous assessment configuration' ROW_FORMAT=COMPRESSED;

--
-- Dumping data for table `mdl_local_sis_ca_config`
--

INSERT INTO `mdl_local_sis_ca_config` (`id`, `courseid`, `sessionid`, `termid`, `timemodified`, `components`, `grading_scale`) VALUES
(28, 16, 3, 7, 1760044341, '[{\"name\":\"First CA\",\"weight\":20,\"max\":20},{\"name\":\"Second CA\",\"weight\":20,\"max\":20},{\"name\":\"Exam\",\"weight\":60,\"max\":60}]', '[{\"min\":70,\"grade\":\"A\",\"points\":5},{\"min\":65,\"grade\":\"B\",\"points\":4},{\"min\":60,\"grade\":\"C\",\"points\":3},{\"min\":55,\"grade\":\"D\",\"points\":2},{\"min\":50,\"grade\":\"E\",\"points\":1},{\"min\":45,\"grade\":\"E_\",\"points\":0.5},{\"min\":0,\"grade\":\"F\",\"points\":0}]'),
(29, 15, 3, 1, 1760045495, '[{\"name\":\"First CA\",\"weight\":20,\"max\":20},{\"name\":\"Second CA\",\"weight\":20,\"max\":20},{\"name\":\"Exam\",\"weight\":60,\"max\":60}]', '[{\"min\":70,\"grade\":\"A\",\"points\":5},{\"min\":65,\"grade\":\"B\",\"points\":4},{\"min\":60,\"grade\":\"C\",\"points\":3},{\"min\":55,\"grade\":\"D\",\"points\":2},{\"min\":50,\"grade\":\"E\",\"points\":1},{\"min\":45,\"grade\":\"P\",\"points\":0.5},{\"min\":0,\"grade\":\"F\",\"points\":0}]'),
(30, 3, 3, 1, 1760241567, '[{\"name\":\"First CA\",\"weight\":20,\"max\":20},{\"name\":\"Second CA\",\"weight\":20,\"max\":20},{\"name\":\"Exam\",\"weight\":60,\"max\":60}]', '[{\"min\":70,\"grade\":\"A\",\"points\":5},{\"min\":65,\"grade\":\"B\",\"points\":4},{\"min\":60,\"grade\":\"C\",\"points\":3},{\"min\":55,\"grade\":\"D\",\"points\":2},{\"min\":50,\"grade\":\"E\",\"points\":1},{\"min\":45,\"grade\":\"E_\",\"points\":0.5},{\"min\":0,\"grade\":\"F\",\"points\":0}]'),
(31, 3, 3, 7, 1760051315, '[{\"name\":\"First CA\",\"weight\":10,\"max\":10},{\"name\":\"Second CA\",\"weight\":20,\"max\":20},{\"name\":\"Exam\",\"weight\":70,\"max\":70}]', '[{\"min\":70,\"grade\":\"A\",\"points\":5},{\"min\":65,\"grade\":\"B\",\"points\":4},{\"min\":60,\"grade\":\"C\",\"points\":3},{\"min\":55,\"grade\":\"D\",\"points\":2},{\"min\":50,\"grade\":\"E\",\"points\":1},{\"min\":45,\"grade\":\"P\",\"points\":0.5},{\"min\":0,\"grade\":\"F\",\"points\":0}]'),
(32, 2, 3, 1, 1760241706, '[{\"name\":\"First CA\",\"weight\":20,\"max\":20},{\"name\":\"Second CA\",\"weight\":20,\"max\":20},{\"name\":\"Exam\",\"weight\":60,\"max\":60}]', '[{\"min\":70,\"grade\":\"A\",\"points\":5},{\"min\":65,\"grade\":\"B\",\"points\":4},{\"min\":60,\"grade\":\"C\",\"points\":3},{\"min\":55,\"grade\":\"D\",\"points\":2},{\"min\":50,\"grade\":\"E\",\"points\":1},{\"min\":45,\"grade\":\"E_\",\"points\":0.5},{\"min\":0,\"grade\":\"F\",\"points\":0}]'),
(33, 2, 3, 7, 1760052286, '[{\"name\":\"First CA\",\"weight\":10,\"max\":10},{\"name\":\"Second CA\",\"weight\":20,\"max\":20},{\"name\":\"Exam\",\"weight\":70,\"max\":70}]', '[{\"min\":70,\"grade\":\"A\",\"points\":5},{\"min\":65,\"grade\":\"B\",\"points\":4},{\"min\":60,\"grade\":\"C\",\"points\":3},{\"min\":55,\"grade\":\"D\",\"points\":2},{\"min\":50,\"grade\":\"E\",\"points\":1},{\"min\":45,\"grade\":\"E_\",\"points\":0.5},{\"min\":0,\"grade\":\"F\",\"points\":0}]'),
(34, 2, 3, 4, 1760050562, '[{\"name\":\"First CA\",\"weight\":15,\"max\":15},{\"name\":\"Second CA\",\"weight\":15,\"max\":15},{\"name\":\"Exam\",\"weight\":70,\"max\":70}]', '[{\"min\":70,\"grade\":\"A\",\"points\":5},{\"min\":65,\"grade\":\"B\",\"points\":4},{\"min\":60,\"grade\":\"C\",\"points\":3},{\"min\":55,\"grade\":\"D\",\"points\":2},{\"min\":50,\"grade\":\"E\",\"points\":1},{\"min\":45,\"grade\":\"E_\",\"points\":0.5},{\"min\":0,\"grade\":\"F\",\"points\":0}]'),
(35, 16, 3, 1, 1760238199, '[{\"name\":\"First CA\",\"weight\":20,\"max\":20},{\"name\":\"Second CA\",\"weight\":20,\"max\":20},{\"name\":\"Exam\",\"weight\":60,\"max\":60}]', '[{\"min\":70,\"grade\":\"A\",\"points\":5},{\"min\":60,\"grade\":\"B\",\"points\":4},{\"min\":50,\"grade\":\"C\",\"points\":3},{\"min\":45,\"grade\":\"D\",\"points\":2},{\"min\":40,\"grade\":\"E\",\"points\":1},{\"min\":0,\"grade\":\"F\",\"points\":0}]'),
(36, 8, 3, 1, 1760303384, '[{\"name\":\"First CA\",\"weight\":15,\"max\":15},{\"name\":\"Second CA\",\"weight\":15,\"max\":15},{\"name\":\"Exam\",\"weight\":70,\"max\":70}]', '[{\"min\":70,\"grade\":\"A\",\"points\":5},{\"min\":65,\"grade\":\"B\",\"points\":4},{\"min\":60,\"grade\":\"C\",\"points\":3},{\"min\":55,\"grade\":\"D\",\"points\":2},{\"min\":50,\"grade\":\"E\",\"points\":1},{\"min\":45,\"grade\":\"E_\",\"points\":0.5},{\"min\":0,\"grade\":\"F\",\"points\":0}]'),
(37, 8, 2, 1, 1760303399, '[{\"name\":\"First CA\",\"weight\":15,\"max\":15},{\"name\":\"Second CA\",\"weight\":15,\"max\":15},{\"name\":\"Exam\",\"weight\":70,\"max\":70}]', '[{\"min\":70,\"grade\":\"A\",\"points\":5},{\"min\":65,\"grade\":\"B\",\"points\":4},{\"min\":60,\"grade\":\"C\",\"points\":3},{\"min\":55,\"grade\":\"D\",\"points\":2},{\"min\":50,\"grade\":\"E\",\"points\":1},{\"min\":45,\"grade\":\"E_\",\"points\":0.5},{\"min\":0,\"grade\":\"F\",\"points\":0}]');

-- --------------------------------------------------------

--
-- Table structure for table `mdl_local_sis_comments`
--

CREATE TABLE `mdl_local_sis_comments` (
  `id` bigint(10) NOT NULL,
  `userid` bigint(10) NOT NULL,
  `categoryid` bigint(10) NOT NULL,
  `sessionid` bigint(10) NOT NULL DEFAULT 0,
  `termid` bigint(10) NOT NULL DEFAULT 0,
  `session` bigint(10) NOT NULL DEFAULT 0,
  `term` bigint(10) NOT NULL DEFAULT 0,
  `teachercomment` longtext DEFAULT NULL,
  `principalcomment` longtext DEFAULT NULL,
  `timemodified` bigint(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mdl_local_sis_comments`
--

INSERT INTO `mdl_local_sis_comments` (`id`, `userid`, `categoryid`, `sessionid`, `termid`, `session`, `term`, `teachercomment`, `principalcomment`, `timemodified`) VALUES
(1, 4, 1, 3, 7, 3, 7, 'Good work with a total of 77.75 marks and an average of 77.75%. With more effort, you can reach the top.', 'A commendable effort. Strive for more consistency and aim higher.', 1760298907),
(2, 3, 1, 3, 7, 3, 7, 'Good work with a total of 74.25 marks and an average of 74.25%. With more effort, you can reach the top.', 'A commendable effort. Strive for more consistency and aim higher.', 1760298907),
(3, 2, 1, 3, 7, 3, 7, 'Poor result (total marks: 0, average: 0.00%). Serious improvement and dedication are required.', 'Performance is below expectation. Strong commitment is needed to improve.', 1760298907);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_local_sis_exam_map`
--

CREATE TABLE `mdl_local_sis_exam_map` (
  `id` bigint(10) NOT NULL,
  `examid` bigint(10) NOT NULL,
  `courseid` bigint(10) NOT NULL,
  `categoryid` bigint(10) NOT NULL,
  `weight` decimal(10,2) NOT NULL DEFAULT 0.00,
  `timemodified` bigint(10) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Mapping of exams to courses or categories' ROW_FORMAT=COMPRESSED;

-- --------------------------------------------------------

--
-- Table structure for table `mdl_local_sis_fee`
--

CREATE TABLE `mdl_local_sis_fee` (
  `id` bigint(10) NOT NULL,
  `userid` bigint(10) NOT NULL,
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `session` bigint(10) NOT NULL DEFAULT 0,
  `term` bigint(10) NOT NULL DEFAULT 0,
  `timemodified` bigint(10) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Student fee tracking' ROW_FORMAT=COMPRESSED;

-- --------------------------------------------------------

--
-- Table structure for table `mdl_local_sis_promotions_log`
--

CREATE TABLE `mdl_local_sis_promotions_log` (
  `id` bigint(10) UNSIGNED NOT NULL,
  `source_category` bigint(10) UNSIGNED NOT NULL,
  `target_category` bigint(10) UNSIGNED NOT NULL,
  `source_session` bigint(10) UNSIGNED NOT NULL,
  `target_session` bigint(10) UNSIGNED NOT NULL,
  `students_promoted` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `promoted_by` bigint(10) UNSIGNED NOT NULL,
  `timecreated` bigint(10) UNSIGNED NOT NULL,
  `details` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mdl_local_sis_quizmap`
--

CREATE TABLE `mdl_local_sis_quizmap` (
  `id` bigint(10) NOT NULL,
  `quizid` bigint(10) NOT NULL,
  `courseid` bigint(10) NOT NULL,
  `categoryid` bigint(10) NOT NULL,
  `weight` decimal(10,2) NOT NULL DEFAULT 0.00,
  `timemodified` bigint(10) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Mapping between quizzes and courses' ROW_FORMAT=COMPRESSED;

-- --------------------------------------------------------

--
-- Table structure for table `mdl_local_sis_result`
--

CREATE TABLE `mdl_local_sis_result` (
  `id` bigint(10) NOT NULL,
  `courseid` bigint(10) NOT NULL,
  `userid` bigint(10) NOT NULL,
  `sessionid` bigint(10) NOT NULL,
  `termid` bigint(10) NOT NULL,
  `data` longtext DEFAULT NULL,
  `total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `grade` varchar(10) NOT NULL DEFAULT 'F',
  `points` decimal(5,2) NOT NULL DEFAULT 0.00,
  `timecreated` bigint(10) NOT NULL DEFAULT 0,
  `timemodified` bigint(10) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mdl_local_sis_result`
--

INSERT INTO `mdl_local_sis_result` (`id`, `courseid`, `userid`, `sessionid`, `termid`, `data`, `total`, `grade`, `points`, `timecreated`, `timemodified`) VALUES
(1, 3, 4, 3, 1, '[20,20,49.5]', 89.50, 'A', 5.00, 0, 1760241628),
(2, 3, 3, 3, 1, '[20,20,46.5]', 86.50, 'A', 5.00, 0, 1760241628),
(3, 3, 2, 3, 1, '[0,0,0]', 0.00, 'F', 0.00, 0, 1760241628),
(4, 1, 1, 1, 1, NULL, 0.00, 'A', 0.00, 1760235217, 1760235217),
(5, 3, 4, 3, 7, '[10,10,57.75]', 77.75, 'A', 5.00, 0, 1760240786),
(6, 3, 3, 3, 7, '[10,10,54.25]', 74.25, 'A', 5.00, 0, 1760240786),
(7, 3, 2, 3, 7, '[0,0,0]', 0.00, 'F', 0.00, 0, 1760240786),
(8, 16, 6, 3, 1, NULL, 0.00, 'F', 0.00, 0, 1760238216),
(9, 16, 13, 3, 1, NULL, 0.00, 'F', 0.00, 0, 1760238216),
(10, 16, 5, 3, 1, NULL, 0.00, 'F', 0.00, 0, 1760238216),
(11, 16, 8, 3, 1, NULL, 0.00, 'F', 0.00, 0, 1760238216),
(12, 16, 14, 3, 1, NULL, 0.00, 'F', 0.00, 0, 1760238216),
(13, 16, 12, 3, 1, NULL, 0.00, 'F', 0.00, 0, 1760238216),
(14, 16, 7, 3, 1, NULL, 0.00, 'F', 0.00, 0, 1760238216),
(15, 16, 10, 3, 1, NULL, 0.00, 'F', 0.00, 0, 1760238216),
(16, 16, 11, 3, 1, NULL, 0.00, 'F', 0.00, 0, 1760238216),
(17, 16, 9, 3, 1, NULL, 0.00, 'F', 0.00, 0, 1760238216);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_local_sis_school_settings`
--

CREATE TABLE `mdl_local_sis_school_settings` (
  `id` bigint(10) NOT NULL,
  `schoolname` varchar(255) NOT NULL DEFAULT '',
  `schooladdress` text DEFAULT NULL,
  `schoolmotto` varchar(255) DEFAULT '',
  `phone` varchar(50) DEFAULT '',
  `state` varchar(100) DEFAULT '',
  `country` varchar(100) DEFAULT '',
  `schoollogo` varchar(255) DEFAULT '',
  `principalsignature` varchar(255) DEFAULT '',
  `timemodified` bigint(10) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `mdl_local_sis_school_settings`
--

INSERT INTO `mdl_local_sis_school_settings` (`id`, `schoolname`, `schooladdress`, `schoolmotto`, `phone`, `state`, `country`, `schoollogo`, `principalsignature`, `timemodified`) VALUES
(1, 'NDUKS-TECH LAB', '10 iwrheko road, Ughelli, Delta State', 'As long as there are systems, there will always be need for system administrators and engineers', '+2347034602628', 'Delta', 'NG', 'schoollogo_1760037127.png', 'principalsignature_1760037127.png', 1760301295);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_local_sis_sessions`
--

CREATE TABLE `mdl_local_sis_sessions` (
  `id` bigint(10) NOT NULL,
  `sessionname` varchar(50) NOT NULL DEFAULT '',
  `isactive` tinyint(1) NOT NULL DEFAULT 0,
  `timemodified` bigint(10) NOT NULL DEFAULT 0,
  `isdefault` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Academic sessions and terms' ROW_FORMAT=COMPRESSED;

--
-- Dumping data for table `mdl_local_sis_sessions`
--

INSERT INTO `mdl_local_sis_sessions` (`id`, `sessionname`, `isactive`, `timemodified`, `isdefault`) VALUES
(1, '2023/2024', 0, 1760037681, 0),
(2, '2024/2025', 0, 1760037764, 0),
(3, '2025/2026', 0, 1760040271, 1);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_local_sis_student_access`
--

CREATE TABLE `mdl_local_sis_student_access` (
  `id` bigint(10) NOT NULL,
  `userid` bigint(10) NOT NULL,
  `categoryid` bigint(10) NOT NULL,
  `sessionid` bigint(10) NOT NULL,
  `termid` bigint(10) NOT NULL,
  `can_attempt_quiz` tinyint(1) NOT NULL DEFAULT 0,
  `can_view_results` tinyint(1) NOT NULL DEFAULT 0,
  `timecreated` bigint(10) NOT NULL,
  `timemodified` bigint(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci COMMENT='Student access control for quizzes and results';

--
-- Dumping data for table `mdl_local_sis_student_access`
--

INSERT INTO `mdl_local_sis_student_access` (`id`, `userid`, `categoryid`, `sessionid`, `termid`, `can_attempt_quiz`, `can_view_results`, `timecreated`, `timemodified`) VALUES
(4, 6, 6, 3, 7, 0, 0, 1760755004, 1760755004),
(5, 13, 6, 3, 7, 0, 0, 1760755004, 1760755004),
(6, 5, 6, 3, 7, 0, 0, 1760755004, 1760755004),
(7, 8, 6, 3, 7, 0, 0, 1760755004, 1760755004),
(8, 14, 6, 3, 7, 0, 0, 1760755004, 1760755004),
(9, 12, 6, 3, 7, 0, 0, 1760755004, 1760755004),
(10, 7, 6, 3, 7, 0, 0, 1760755004, 1760755004),
(11, 10, 6, 3, 7, 0, 0, 1760755004, 1760755004),
(12, 11, 6, 3, 7, 0, 0, 1760755004, 1760755004),
(13, 2, 6, 3, 7, 1, 1, 1760755004, 1760755004),
(14, 9, 6, 3, 7, 0, 0, 1760755004, 1760755004),
(21, 4, 1, 3, 7, 0, 0, 1760764087, 1760789822),
(22, 3, 1, 3, 7, 0, 0, 1760764087, 1760789822),
(23, 2, 1, 3, 7, 1, 1, 1760764087, 1760789822);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_local_sis_terms`
--

CREATE TABLE `mdl_local_sis_terms` (
  `id` bigint(10) NOT NULL,
  `sessionid` bigint(10) NOT NULL,
  `termname` varchar(255) NOT NULL DEFAULT '',
  `isdefault` tinyint(1) NOT NULL DEFAULT 0,
  `calculate_cumulative` tinyint(1) NOT NULL DEFAULT 0,
  `timecreated` bigint(10) NOT NULL,
  `timemodified` bigint(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=COMPRESSED;

--
-- Dumping data for table `mdl_local_sis_terms`
--

INSERT INTO `mdl_local_sis_terms` (`id`, `sessionid`, `termname`, `isdefault`, `calculate_cumulative`, `timecreated`, `timemodified`) VALUES
(1, 1, 'First Term', 0, 0, 1760037681, 1760037681),
(2, 1, 'Second Term', 0, 0, 1760037681, 1760037681),
(3, 1, 'Third Term', 0, 1, 1760037681, 1760037681),
(4, 2, 'First Term', 0, 0, 1760037764, 1760037764),
(5, 2, 'Second Term', 0, 0, 1760037764, 1760037764),
(6, 2, 'Third Term', 0, 1, 1760037764, 1760037764),
(7, 3, 'First Term', 0, 0, 1760040271, 1760040271),
(8, 3, 'Second Term', 0, 0, 1760040271, 1760040271),
(9, 3, 'Third Term', 0, 1, 1760040271, 1760040271);

-- AUTO_INCREMENT for table `mdl_local_sis_ca`
--
ALTER TABLE `mdl_local_sis_ca`
  MODIFY `id` bigint(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mdl_local_sis_ca_config`
--
ALTER TABLE `mdl_local_sis_ca_config`
  MODIFY `id` bigint(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `mdl_local_sis_comments`
--
ALTER TABLE `mdl_local_sis_comments`
  MODIFY `id` bigint(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `mdl_local_sis_exam_map`
--
ALTER TABLE `mdl_local_sis_exam_map`
  MODIFY `id` bigint(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mdl_local_sis_fee`
--
ALTER TABLE `mdl_local_sis_fee`
  MODIFY `id` bigint(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mdl_local_sis_promotions_log`
--
ALTER TABLE `mdl_local_sis_promotions_log`
  MODIFY `id` bigint(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mdl_local_sis_quizmap`
--
ALTER TABLE `mdl_local_sis_quizmap`
  MODIFY `id` bigint(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mdl_local_sis_result`
--
ALTER TABLE `mdl_local_sis_result`
  MODIFY `id` bigint(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `mdl_local_sis_school_settings`
--
ALTER TABLE `mdl_local_sis_school_settings`
  MODIFY `id` bigint(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `mdl_local_sis_sessions`
--
ALTER TABLE `mdl_local_sis_sessions`
  MODIFY `id` bigint(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `mdl_local_sis_student_access`
--
ALTER TABLE `mdl_local_sis_student_access`
  MODIFY `id` bigint(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `mdl_local_sis_terms`
--
ALTER TABLE `mdl_local_sis_terms`
  MODIFY `id` bigint(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

