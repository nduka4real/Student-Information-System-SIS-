<?php
// This file is part of the Student Information System plugin for Moodle.
// this file helps to manage courses/subjects
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version information for the Student Information System plugin
 *
 * @package    local_sis
 * @copyright  2025 NduksTech - https://facebook.com/ndukshub
 * @author     Nduka Akapti  (https://github.com/nduka4real)
 * @author     Ndukstech (https://www.youtube.com/@nduks-tech)
 * @author     https://www.linkedin.com/in/ndukaakpati/
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @details
 * Display Name: Student Information System
 * Description: A comprehensive system for managing student records, assessments, fees, and school operations.
 * Contact: https://github.com/nduka4real
 * Social: https://facebook.com/ndukshub
 */
// local/sis/course_manager.php
// Simple Course Manager: open built-in editor, create courses, delete courses
// Place in your local/sis plugin directory.

require_once(__DIR__ . '/../../config.php');
require_login();

global $DB, $PAGE, $OUTPUT, $USER;

require_once($CFG->dirroot . '/course/lib.php'); // create_course(), core_course_delete_courses()

$courseid    = optional_param('courseid', 0, PARAM_INT);
$categoryid  = optional_param('categoryid', 0, PARAM_INT);
$action      = optional_param('action', '', PARAM_ALPHA); // create, delete
$sesskey     = sesskey();

$PAGE->set_url(new moodle_url('/local/sis/course_manager.php', [
    'courseid' => $courseid,
    'categoryid' => $categoryid
]));
$PAGE->set_context(context_system::instance());
$PAGE->set_title(get_string('pluginname', 'local_sis') . ' - Course Manager');
$PAGE->set_heading('Course Manager');

echo $OUTPUT->header();

// ---------------------------------------------------
// Permission checks (viewing the page requires login).
// Additional capability checks are applied before create/delete actions.
// ---------------------------------------------------

// Fetch categories for selection
$categories = core_course_category::get_all(); // returns objects keyed by id
$categoryoptions = [0 => '-- Select category --'];
foreach ($categories as $cat) {
    $categoryoptions[$cat->id] = format_string($cat->name);
}

// Show top navigation / selection form
echo html_writer::start_tag('div', ['class' => 'mb-4']);
echo html_writer::start_tag('form', ['method' => 'get', 'class' => 'form-inline']);
echo html_writer::label('Category:', 'categoryid', false, ['class' => 'mr-2']);
echo html_writer::select($categoryoptions, 'categoryid', $categoryid, false, ['class' => 'form-control mr-2']);
echo html_writer::empty_tag('input', ['type' => 'submit', 'value' => 'Load', 'class' => 'btn btn-primary']);
echo html_writer::end_tag('form');
echo html_writer::end_tag('div');

// If category selected show built-in "Open course creation tool" link
if ($categoryid) {
    $openurl = new moodle_url('/course/edit.php', ['category' => $categoryid]);
    echo html_writer::start_tag('div', ['class' => 'mb-3']);
    echo html_writer::link($openurl, 'Open Moodle course creation tool for this category', ['class' => 'btn btn-secondary']);
    echo html_writer::end_tag('div');
}

// ---------------------------------------------------
// Handle create action: only allowed if user has create capability
// capability: moodle/course:create in system context
// ---------------------------------------------------
if ($action === 'create' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    require_sesskey();
    // Check capability to create courses
    if (!has_capability('moodle/course:create', context_system::instance())) {
        print_error('nopermissions', 'error', '', 'create course');
    }

    // Gather and sanitize POST fields
    $newfullname  = required_param('fullname', PARAM_TEXT);
    $newshortname = required_param('shortname', PARAM_TEXT);
    $newcategory  = required_param('category', PARAM_INT);
    $newsummary   = optional_param('summary', '', PARAM_TEXT);
    $visible      = optional_param('visible', 1, PARAM_INT);
    $format       = optional_param('format', 'topics', PARAM_ALPHA);

    // Validate category exists
    $cat = $DB->get_record('course_categories', ['id' => $newcategory], '*', IGNORE_MISSING);
    if (!$cat) {
        \core\notification::error('Selected category does not exist.');
        // Do not exit; allow page to display again
    } else {
        // Build course object for create_course()
        $courseinfo = new stdClass();
        $courseinfo->fullname  = $newfullname;
        $courseinfo->shortname = $newshortname;
        $courseinfo->category  = (int)$newcategory;
        $courseinfo->summary   = $newsummary;
        $courseinfo->format    = $format ?: 'topics';
        $courseinfo->visible   = (int)$visible;
        // optional: set default numsections etc.
        // Create course using Moodle API
        try {
            $newcourse = create_course($courseinfo);
            \core\notification::success('Course created successfully: ' . s($newcourse->fullname));
            // redirect back to manager with new course selected
            redirect(new moodle_url('/local/sis/course_manager.php', ['categoryid' => $newcategory]));
        } catch (Exception $e) {
            \core\notification::error('Failed to create course: ' . s($e->getMessage()));
        }
    }
}

// ---------------------------------------------------
// Handle delete action: must be POST, contain deletecourses[] array of ints
// Deleting requires capability 'moodle/course:delete' in each course's context.
// Uses core_course_delete_courses() which accepts array of course ids.
// ---------------------------------------------------
if ($action === 'delete' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    require_sesskey();

    // fetch array of course ids (use optional_param_array to avoid clean() array issue)
    $deletecourses = optional_param_array('deletecourses', [], PARAM_INT);

    if (empty($deletecourses)) {
        \core\notification::error('No courses selected for deletion.');
    } else {
        // Validate capability per course and build list of allowed deletions
        $to_delete = [];
        $not_allowed = [];

        foreach ($deletecourses as $cid) {
            $cid = (int)$cid;
            if ($cid <= 1) { // don't allow deleting frontpage (id 1)
                $not_allowed[] = $cid;
                continue;
            }
            $course = $DB->get_record('course', ['id' => $cid], '*', IGNORE_MISSING);
            if (!$course) {
                $not_allowed[] = $cid;
                continue;
            }
            $coursecontext = context_course::instance($cid);
            if (!has_capability('moodle/course:delete', $coursecontext)) {
                $not_allowed[] = $cid;
                continue;
            }
            $to_delete[] = $cid;
        }

        if (!empty($to_delete)) {
            try {
                core_course_delete_courses($to_delete);
                \core\notification::success('Deleted ' . count($to_delete) . ' course(s).');
            } catch (Exception $e) {
                \core\notification::error('Error deleting courses: ' . s($e->getMessage()));
            }
        }

        if (!empty($not_allowed)) {
            \core\notification::error('Some courses were not deleted due to missing permissions or invalid IDs: ' . implode(',', $not_allowed));
        }
        // redirect back to avoid re-post on refresh
        redirect(new moodle_url('/local/sis/course_manager.php', ['categoryid' => $categoryid]));
    }
}

// ---------------------------------------------------
// Display forms: Create course (if user has capability) and list courses with delete option
// ---------------------------------------------------

// Create-course form (only if user can create courses)
if (has_capability('moodle/course:create', context_system::instance())) {
    echo html_writer::start_tag('div', ['class' => 'card mb-4']);
    echo html_writer::start_tag('div', ['class' => 'card-header bg-info text-white']);
    echo html_writer::tag('h4', 'Create Course', ['class' => 'mb-0']);
    echo html_writer::end_tag('div');
    echo html_writer::start_tag('div', ['class' => 'card-body']);

    echo html_writer::start_tag('form', ['method' => 'post']);
    echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey()]);
    echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'action', 'value' => 'create']);

    // fullname
    echo html_writer::start_div('form-group');
    echo html_writer::label('Full name:', 'fullname');
    echo html_writer::empty_tag('input', [
        'type' => 'text', 'name' => 'fullname', 'class' => 'form-control', 'required' => true
    ]);
    echo html_writer::end_div();

    // shortname
    echo html_writer::start_div('form-group');
    echo html_writer::label('Short name:', 'shortname');
    echo html_writer::empty_tag('input', [
        'type' => 'text', 'name' => 'shortname', 'class' => 'form-control', 'required' => true
    ]);
    echo html_writer::end_div();

    // category select
    echo html_writer::start_div('form-group');
    echo html_writer::label('Category:', 'category');
    echo html_writer::select($categoryoptions, 'category', $categoryid, false, ['class' => 'form-control']);
    echo html_writer::end_div();

    // summary
    echo html_writer::start_div('form-group');
    echo html_writer::label('Summary (optional):', 'summary');
    echo html_writer::tag('textarea', '', ['name' => 'summary', 'class' => 'form-control', 'rows' => 3]);
    echo html_writer::end_div();

    // visible
    echo html_writer::start_div('form-group form-check');
    echo html_writer::empty_tag('input', [
        'type' => 'checkbox', 'name' => 'visible', 'value' => '1', 'id' => 'visible', 'class' => 'form-check-input', 'checked' => 'checked'
    ]);
    echo html_writer::label('Visible', 'visible', false, ['class' => 'form-check-label']);
    echo html_writer::end_div();

    // format
    echo html_writer::start_div('form-group');
    echo html_writer::label('Format:', 'format');
    echo html_writer::select(['topics' => 'Topics', 'weeks' => 'Weeks', 'singleactivity' => 'Single activity'], 'format', 'topics', false, ['class' => 'form-control']);
    echo html_writer::end_div();

    echo html_writer::empty_tag('input', ['type' => 'submit', 'value' => 'Create Course', 'class' => 'btn btn-success']);
    echo html_writer::end_tag('form');

    echo html_writer::end_tag('div'); // card-body
    echo html_writer::end_tag('div'); // card
}

// List courses in selected category and allow deletion (if permitted)
if ($categoryid) {
    $courses = $DB->get_records('course', ['category' => $categoryid], 'fullname ASC');

    echo html_writer::start_tag('div', ['class' => 'card']);
    echo html_writer::start_tag('div', ['class' => 'card-header']);
    echo html_writer::tag('h4', 'Courses in ' . s($categories[$categoryid]->name), ['class' => 'mb-0']);
    echo html_writer::end_tag('div');
    echo html_writer::start_tag('div', ['class' => 'card-body']);

    if (empty($courses)) {
        echo $OUTPUT->notification('No courses found in this category.', 'notifymessage');
    } else {
        echo html_writer::start_tag('form', ['method' => 'post']);
        echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey()]);
        echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'action', 'value' => 'delete']);
        echo html_writer::start_tag('table', ['class' => 'table table-striped']);
        echo html_writer::start_tag('thead');
        echo html_writer::start_tag('tr');
        echo html_writer::tag('th', 'Delete');
        echo html_writer::tag('th', 'ID');
        echo html_writer::tag('th', 'Full name');
        echo html_writer::tag('th', 'Short name');
        echo html_writer::tag('th', 'Visible');
        echo html_writer::end_tag('tr');
        echo html_writer::end_tag('thead');
        echo html_writer::start_tag('tbody');

        foreach ($courses as $c) {
            // don't show frontpage (id==1) and category courses special cases
            $deletecheckbox = '';
            if ($c->id > 1) {
                // show checkbox but actual deletion will check capability per course on submit
                $deletecheckbox = html_writer::empty_tag('input', [
                    'type' => 'checkbox',
                    'name' => 'deletecourses[]',
                    'value' => $c->id
                ]);
            }

            echo html_writer::start_tag('tr');
            echo html_writer::tag('td', $deletecheckbox);
            echo html_writer::tag('td', $c->id);
            echo html_writer::tag('td', html_writer::link(new moodle_url('/course/view.php', ['id' => $c->id]), format_string($c->fullname)));
            echo html_writer::tag('td', s($c->shortname));
            echo html_writer::tag('td', $c->visible ? 'Yes' : 'No');
            echo html_writer::end_tag('tr');
        }

        echo html_writer::end_tag('tbody');
        echo html_writer::end_tag('table');

        // Delete button
        echo html_writer::empty_tag('input', ['type' => 'submit', 'value' => 'Delete selected courses', 'class' => 'btn btn-danger', 'onclick' => 'return confirm("Are you sure you want to delete the selected courses? This cannot be undone.");']);
        echo html_writer::end_tag('form');
    }

    echo html_writer::end_tag('div'); // card-body
    echo html_writer::end_tag('div'); // card
}

// Footer
echo $OUTPUT->footer();