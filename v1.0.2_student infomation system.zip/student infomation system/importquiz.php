// This file is part of the Student Information System plugin for Moodle.
// this file is surposed to import quize in aiken format 
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version information for the Student Information System plugin
 *
 * @package    local_sis
 * @copyright  2025 NduksTech - https://facebook.com/ndukshub
 * @author     Nduka Akapti  (https://github.com/nduka4real)
 * @author     Ndukstech (https://www.youtube.com/@nduks-tech)
 * @author     https://www.linkedin.com/in/ndukaakpati/
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @details
 * Display Name: Student Information System
 * Description: A comprehensive system for managing student records, assessments, fees, and school operations.
 * Contact: https://github.com/nduka4real
 * Social: https://facebook.com/ndukshub
 */

$map = $DB->get_record('local_sis_quizmap', ['courseid' => $courseid]);

foreach ($students as $student) {
    $firstca = $secondca = $exam = 0;

    if ($map && $map->firstcaquiz) {
        $g = $DB->get_record('quiz_grades', ['quiz' => $map->firstcaquiz, 'userid' => $student->id]);
        if ($g) $firstca = $g->grade;
    }
    if ($map && $map->secondcaquiz) {
        $g = $DB->get_record('quiz_grades', ['quiz' => $map->secondcaquiz, 'userid' => $student->id]);
        if ($g) $secondca = $g->grade;
    }
    if ($map && $map->examquiz) {
        $g = $DB->get_record('quiz_grades', ['quiz' => $map->examquiz, 'userid' => $student->id]);
        if ($g) $exam = $g->grade;
    }

    $total = $firstca + $secondca + $exam;
    $grade = calculate_grade($total);

    if ($existing = $DB->get_record('local_sis_result', ['userid' => $student->id, 'courseid' => $courseid])) {
        $existing->firstca = $firstca;
        $existing->secondca = $secondca;
        $existing->exam = $exam;
        $existing->total = $total;
        $existing->grade = $grade;
        $DB->update_record('local_sis_result', $existing);
    } else {
        $record = (object)[
            'userid' => $student->id,
            'courseid' => $courseid,
            'firstca' => $firstca,
            'secondca' => $secondca,
            'exam' => $exam,
            'total' => $total,
            'grade' => $grade,
            'timemodified' => time()
        ];
        $DB->insert_record('local_sis_result', $record);
    }
}
