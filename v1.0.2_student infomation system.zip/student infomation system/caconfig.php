<?php
// This file is part of the Student Information System plugin for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version information for the Student Information System plugin
 *
 * @package    local_sis
 * @copyright  2025 NduksTech - https://facebook.com/ndukshub
 * @author     Nduka Akapti  (https://github.com/nduka4real)
 * @author     Ndukstech (https://www.youtube.com/@nduks-tech)
 * @author     https://www.linkedin.com/in/ndukaakpati/
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @details
 * Display Name: Student Information System
 * Description: A comprehensive system for managing student records, assessments, fees, and school operations.
 * Contact: https://github.com/nduka4real
 * Social: https://facebook.com/ndukshub
 */

// local/sis/caconfig.php
require_once(__DIR__ . '/../../config.php');
require_login();

$courseid = required_param('courseid', PARAM_INT);
$sessionid = optional_param('sessionid', 0, PARAM_INT);
$termid = optional_param('termid', 0, PARAM_INT);
$applyall = optional_param('applyall', 0, PARAM_BOOL);

$course = get_course($courseid);
$context = context_course::instance($course->id);
require_capability('moodle/course:update', $context);

$PAGE->set_url('/local/sis/caconfig.php', [
    'courseid' => $courseid,
    'sessionid' => $sessionid,
    'termid' => $termid
]);
$PAGE->set_context($context);
$PAGE->set_title("Configure CA Settings - " . format_string($course->fullname));

global $DB, $OUTPUT;

// Get available sessions
$sessions = $DB->get_records('local_sis_sessions', null, 'sessionname ASC');

// Set default session if not provided
if (!$sessionid && $sessions) {
    $default_session = $DB->get_record('local_sis_sessions', ['isdefault' => 1]);
    if ($default_session) {
        $sessionid = $default_session->id;
    } else {
        $sessionid = array_key_first($sessions);
    }
}

// Get terms for the selected session
$terms = [];
if ($sessionid) {
    $terms = $DB->get_records('local_sis_terms', ['sessionid' => $sessionid], 'termname ASC');
}

// Set default term if not provided
if (!$termid && $terms) {
    $default_term = $DB->get_record('local_sis_terms', ['sessionid' => $sessionid, 'isdefault' => 1]);
    if ($default_term) {
        $termid = $default_term->id;
    } else {
        $termid = array_key_first($terms);
    }
}

// Define default components and grading scale
$default_components = [
    ['name' => 'First CA', 'weight' => 15, 'max' => 15],
    ['name' => 'Second CA', 'weight' => 15, 'max' => 15],
    ['name' => 'Exam', 'weight' => 70, 'max' => 70]
];

$default_grading_scale = [
    ['min' => 70, 'grade' => 'A', 'points' => 5.0],
    ['min' => 65, 'grade' => 'B', 'points' => 4.0],
    ['min' => 60, 'grade' => 'C', 'points' => 3.0],
    ['min' => 55, 'grade' => 'D', 'points' => 2.0],
    ['min' => 50, 'grade' => 'E', 'points' => 1.0],
    ['min' => 45, 'grade' => 'E_', 'points' => 0.5],
    ['min' => 0, 'grade' => 'F', 'points' => 0.0]
];

// Get existing configuration
$ca_config = null;
if ($sessionid && $termid) {
    $ca_config = $DB->get_record('local_sis_ca_config', [
        'courseid' => $courseid,
        'sessionid' => $sessionid,
        'termid' => $termid
    ]);
}

// FIXED: Properly handle configuration loading - SAVED CONFIG TAKES PRECEDENCE
$components = $default_components;
$grading_scale = $default_grading_scale;

if ($ca_config) {
    // Check if we have the new structure with components field
    if (property_exists($ca_config, 'components') && !empty($ca_config->components)) {
        $decoded_components = json_decode($ca_config->components, true);
        if (is_array($decoded_components) && !empty($decoded_components)) {
            $components = $decoded_components;
        }
    }
    
    // Check if we have the new structure with grading_scale field
    if (property_exists($ca_config, 'grading_scale') && !empty($ca_config->grading_scale)) {
        $decoded_grading = json_decode($ca_config->grading_scale, true);
        if (is_array($decoded_grading) && !empty($decoded_grading)) {
            $grading_scale = $decoded_grading;
        }
    }
}

// Process form submission
$form_submitted = false;
if ($_SERVER['REQUEST_METHOD'] == 'POST' && confirm_sesskey()) {
    $form_submitted = true;
    
    // FIXED: Get applyall from POST data properly
    $applyall_post = optional_param('applyall', 0, PARAM_BOOL);
    
    if (!$sessionid || !$termid) {
        \core\notification::error('Please select both a session and term before saving configuration.');
    } else {
        // Process components
        $new_components = [];
        for ($i = 1; $i <= 3; $i++) {
            $name = trim(optional_param("component_name_$i", '', PARAM_TEXT));
            $weight = (float)optional_param("component_weight_$i", 0, PARAM_FLOAT);
            $max = (float)optional_param("component_max_$i", 0, PARAM_FLOAT);
            
            if (!empty($name) && $weight > 0) {
                $new_components[] = [
                    'name' => $name,
                    'weight' => $weight,
                    'max' => $max
                ];
            }
        }
        
        // Process grading scale
        $new_grading_scale = [];
        for ($i = 1; $i <= 7; $i++) {
            $min = (float)optional_param("grade_min_$i", 0, PARAM_FLOAT);
            $grade = trim(optional_param("grade_letter_$i", '', PARAM_TEXT));
            $points = (float)optional_param("grade_points_$i", 0, PARAM_FLOAT);
            
            if (!empty($grade)) {
                $new_grading_scale[] = [
                    'min' => $min,
                    'grade' => $grade,
                    'points' => $points
                ];
            }
        }
        
        // Validate data
        if (empty($new_components)) {
            \core\notification::error('At least one CA component is required.');
        } elseif (empty($new_grading_scale)) {
            \core\notification::error('At least one grading scale entry is required.');
        } else {
            // Prepare config data - FIXED: Ensure we have the correct table structure
            $config_data = new stdClass();
            $config_data->courseid = $courseid;
            $config_data->sessionid = $sessionid;
            $config_data->termid = $termid;
            $config_data->components = json_encode($new_components);
            $config_data->grading_scale = json_encode($new_grading_scale);
            $config_data->timemodified = time();
            
            try {
                $config_saved = false;
                $config_id = null;
                
                if ($ca_config) {
                    // Update existing configuration
                    $config_data->id = $ca_config->id;
                    $result = $DB->update_record('local_sis_ca_config', $config_data);
                    if ($result) {
                        $config_saved = true;
                        $config_id = $ca_config->id;
                        \core\notification::success('Configuration updated successfully.');
                        // Update the displayed configuration immediately
                        $components = $new_components;
                        $grading_scale = $new_grading_scale;
                        // Refresh the config object
                        $ca_config = $DB->get_record('local_sis_ca_config', ['id' => $ca_config->id]);
                    } else {
                        \core\notification::error('Failed to update configuration in database.');
                    }
                } else {
                    // Insert new configuration
                    $config_data->timecreated = time();
                    $config_id = $DB->insert_record('local_sis_ca_config', $config_data);
                    if ($config_id) {
                        $config_saved = true;
                        \core\notification::success('Configuration saved successfully.');
                        // Update the displayed configuration immediately
                        $components = $new_components;
                        $grading_scale = $new_grading_scale;
                        // Refresh the config object
                        $ca_config = $DB->get_record('local_sis_ca_config', ['id' => $config_id]);
                    } else {
                        \core\notification::error('Failed to save configuration to database.');
                    }
                }
                
                // FIXED: Apply to all courses if requested - Moved outside the if/else and fixed logic
                if ($applyall_post && $config_saved) {
                    // Get all courses in the same category
                    $courses = $DB->get_records('course', ['category' => $course->category]);
                    $applied_count = 0;
                    
                    foreach ($courses as $c) {
                        // Skip the current course
                        if ($c->id == $courseid) {
                            continue;
                        }
                        
                        // Check if configuration already exists for this course
                        $existing_config = $DB->get_record('local_sis_ca_config', [
                            'courseid' => $c->id,
                            'sessionid' => $sessionid,
                            'termid' => $termid
                        ]);
                        
                        if ($existing_config) {
                            // Update existing configuration
                            $existing_config->components = $config_data->components;
                            $existing_config->grading_scale = $config_data->grading_scale;
                            $existing_config->timemodified = time();
                            $DB->update_record('local_sis_ca_config', $existing_config);
                        } else {
                            // Create new configuration
                            $new_config = new stdClass();
                            $new_config->courseid = $c->id;
                            $new_config->sessionid = $sessionid;
                            $new_config->termid = $termid;
                            $new_config->components = $config_data->components;
                            $new_config->grading_scale = $config_data->grading_scale;
                            $new_config->timecreated = time();
                            $new_config->timemodified = time();
                            $DB->insert_record('local_sis_ca_config', $new_config);
                        }
                        $applied_count++;
                    }
                    
                    if ($applied_count > 0) {
                        \core\notification::success("Configuration applied to {$applied_count} additional courses in this category.");
                    } else {
                        \core\notification::info("No additional courses found in this category to apply the configuration to.");
                    }
                }
                
            } catch (Exception $e) {
                \core\notification::error('Database error: ' . $e->getMessage());
            }
        }
    }
}

// Display the page
echo $OUTPUT->header();
echo $OUTPUT->heading("Configure CA Settings for: " . format_string($course->fullname));

// Button to navigate back to Enter CA page
echo html_writer::start_div('mb-4');
echo html_writer::link(
    new moodle_url('/local/sis/enterca.php', [
        'courseid' => $courseid,
        'sessionid' => $sessionid,
        'termid' => $termid
    ]),
    'Back to Enter CA',
    ['class' => 'btn btn-primary mr-2']
);
echo html_writer::end_div();

// Session and term selection form
echo html_writer::start_tag('form', ['method' => 'get', 'class' => 'form-inline mb-4']);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'courseid', 'value' => $courseid]);

// Session dropdown
echo html_writer::label('Session:', 'sessionid', false, ['class' => 'mr-2']);
$session_options = [0 => '-- Select Session --'];
foreach ($sessions as $s) {
    $session_options[$s->id] = $s->sessionname;
}
echo html_writer::select($session_options, 'sessionid', $sessionid, false, ['class' => 'form-control mr-3']);

// Term dropdown - Only show terms for selected session
echo html_writer::label('Term:', 'termid', false, ['class' => 'mr-2']);
$term_options = [0 => '-- Select Term --'];
if ($sessionid && $terms) {
    foreach ($terms as $t) {
        $term_options[$t->id] = $t->termname;
    }
}
echo html_writer::select($term_options, 'termid', $termid, false, ['class' => 'form-control mr-3']);

echo html_writer::empty_tag('input', [
    'type' => 'submit',
    'value' => 'Load Configuration',
    'class' => 'btn btn-primary'
]);
echo html_writer::end_tag('form');

// Show warning if no session/term selected
if (!$sessionid || !$termid) {
    echo $OUTPUT->notification('Please select a session and term to configure CA settings.', 'notifywarning');
    echo $OUTPUT->footer();
    exit;
}

// Show current configuration status
if ($form_submitted) {
    if ($ca_config) {
        echo $OUTPUT->notification('Configuration saved successfully!', 'notifysuccess');
    }
} else {
    if ($ca_config) {
        echo $OUTPUT->notification('Loaded existing configuration for selected session and term.', 'notifysuccess');
    } else {
        echo $OUTPUT->notification('No configuration found for selected session and term. Using default template.', 'notifyinfo');
    }
}

// Display current configuration summary
echo html_writer::start_div('card mb-4');
echo html_writer::start_div('card-header bg-info text-white');
echo html_writer::tag('h5', 'Current Configuration Preview', ['class' => 'mb-0']);
echo html_writer::end_div();
echo html_writer::start_div('card-body');
echo html_writer::tag('h6', 'CA Components:', ['class' => 'font-weight-bold']);
echo html_writer::start_tag('ul', ['class' => 'list-unstyled']);
foreach ($components as $component) {
    echo html_writer::tag('li', 
        html_writer::tag('strong', s($component['name']) . ': ') . 
        'Max: ' . s($component['max']) . ', Weight: ' . s($component['weight']) . '%'
    );
}
echo html_writer::end_tag('ul');

echo html_writer::tag('h6', 'Grading Scale:', ['class' => 'font-weight-bold mt-3']);
echo html_writer::start_tag('ul', ['class' => 'list-unstyled']);
foreach ($grading_scale as $grade) {
    echo html_writer::tag('li', 
        html_writer::tag('strong', s($grade['grade']) . ': ') . 
        'Min: ' . s($grade['min']) . ', Points: ' . s($grade['points'])
    );
}
echo html_writer::end_tag('ul');
echo html_writer::end_div(); // card-body
echo html_writer::end_div(); // card

// CA configuration form
echo html_writer::start_tag('form', ['method' => 'post']);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey()]);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'courseid', 'value' => $courseid]);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sessionid', 'value' => $sessionid]);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'termid', 'value' => $termid]);

// CA Components section
echo html_writer::tag('h3', 'CA Components', ['class' => 'mt-4']);
echo html_writer::start_tag('div', ['class' => 'table-responsive']);
echo html_writer::start_tag('table', ['class' => 'table table-bordered']);
echo html_writer::start_tag('thead');
echo html_writer::start_tag('tr');
echo html_writer::tag('th', 'Component Name');
echo html_writer::tag('th', 'Weight (%)');
echo html_writer::tag('th', 'Maximum Score');
echo html_writer::end_tag('tr');
echo html_writer::end_tag('thead');
echo html_writer::start_tag('tbody');

for ($i = 0; $i < 3; $i++) {
    $component = isset($components[$i]) ? $components[$i] : ['name' => '', 'weight' => '', 'max' => ''];
    echo html_writer::start_tag('tr');
    echo html_writer::start_tag('td');
    echo html_writer::empty_tag('input', [
        'type' => 'text',
        'name' => 'component_name_' . ($i + 1),
        'value' => $component['name'],
        'class' => 'form-control',
        'placeholder' => 'Component Name',
        'required' => true
    ]);
    echo html_writer::end_tag('td');
    echo html_writer::start_tag('td');
    echo html_writer::empty_tag('input', [
        'type' => 'number',
        'name' => 'component_weight_' . ($i + 1),
        'value' => $component['weight'],
        'class' => 'form-control',
        'placeholder' => 'Weight',
        'step' => '0.1',
        'min' => '0',
        'max' => '100',
        'required' => true
    ]);
    echo html_writer::end_tag('td');
    echo html_writer::start_tag('td');
    echo html_writer::empty_tag('input', [
        'type' => 'number',
        'name' => 'component_max_' . ($i + 1),
        'value' => $component['max'],
        'class' => 'form-control',
        'placeholder' => 'Max Score',
        'step' => '0.1',
        'min' => '0',
        'required' => true
    ]);
    echo html_writer::end_tag('td');
    echo html_writer::end_tag('tr');
}

echo html_writer::end_tag('tbody');
echo html_writer::end_tag('table');
echo html_writer::end_tag('div');

// Grading Scale section
echo html_writer::tag('h3', 'Grading Scale', ['class' => 'mt-4']);
echo html_writer::start_tag('div', ['class' => 'table-responsive']);
echo html_writer::start_tag('table', ['class' => 'table table-bordered']);
echo html_writer::start_tag('thead');
echo html_writer::start_tag('tr');
echo html_writer::tag('th', 'Minimum Score');
echo html_writer::tag('th', 'Grade');
echo html_writer::tag('th', 'Points');
echo html_writer::end_tag('tr');
echo html_writer::end_tag('thead');
echo html_writer::start_tag('tbody');

for ($i = 0; $i < 7; $i++) {
    $grade = isset($grading_scale[$i]) ? $grading_scale[$i] : ['min' => '', 'grade' => '', 'points' => ''];
    echo html_writer::start_tag('tr');
    echo html_writer::start_tag('td');
    echo html_writer::empty_tag('input', [
        'type' => 'number',
        'name' => 'grade_min_' . ($i + 1),
        'value' => $grade['min'],
        'class' => 'form-control',
        'placeholder' => 'Min Score',
        'step' => '0.1',
        'min' => '0',
        'required' => $i < 5
    ]);
    echo html_writer::end_tag('td');
    echo html_writer::start_tag('td');
    echo html_writer::empty_tag('input', [
        'type' => 'text',
        'name' => 'grade_letter_' . ($i + 1),
        'value' => $grade['grade'],
        'class' => 'form-control',
        'placeholder' => 'Grade',
        'required' => $i < 5
    ]);
    echo html_writer::end_tag('td');
    echo html_writer::start_tag('td');
    echo html_writer::empty_tag('input', [
        'type' => 'number',
        'name' => 'grade_points_' . ($i + 1),
        'value' => $grade['points'],
        'class' => 'form-control',
        'placeholder' => 'Points',
        'step' => '0.1',
        'min' => '0',
        'required' => $i < 5
    ]);
    echo html_writer::end_tag('td');
    echo html_writer::end_tag('tr');
}

echo html_writer::end_tag('tbody');
echo html_writer::end_tag('table');
echo html_writer::end_tag('div');

// Apply to all courses checkbox
echo html_writer::start_tag('div', ['class' => 'form-check mt-3 mb-3']);
echo html_writer::empty_tag('input', [
    'type' => 'checkbox',
    'name' => 'applyall',
    'id' => 'applyall',
    'value' => '1',
    'class' => 'form-check-input'
]);
echo html_writer::label('Apply to all courses in this category', 'applyall', false, ['class' => 'form-check-label font-weight-bold text-primary']);
echo html_writer::end_tag('div');

// Submit button
echo html_writer::empty_tag('input', [
    'type' => 'submit',
    'value' => 'Save Configuration',
    'class' => 'btn btn-success btn-lg mt-3'
]);

echo html_writer::end_tag('form');

// Back link
echo html_writer::start_div('mt-4');
echo html_writer::link(new moodle_url('/course/view.php', ['id' => $courseid]), 'Back to Course', ['class' => 'btn btn-secondary']);
echo html_writer::end_div();

echo $OUTPUT->footer();