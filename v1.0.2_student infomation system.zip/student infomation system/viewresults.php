<?php
// This file is part of the Student Information System plugin for Moodle.
// This file is used by admin to view all results 
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version information for the Student Information System plugin
 *
 * @package    local_sis
 * @copyright  2025 NduksTech - https://facebook.com/ndukshub
 * @author     Nduka Akapti  (https://github.com/nduka4real)
 * @author     Ndukstech (https://www.youtube.com/@nduks-tech)
 * @author     https://www.linkedin.com/in/ndukaakpati/
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @details
 * Display Name: Student Information System
 * Description: A comprehensive system for managing student records, assessments, fees, and school operations.
 * Contact: https://github.com/nduka4real
 * Social: https://facebook.com/ndukshub
 */


// local/sis/viewresults.php
require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/pdflib.php');
require_login();

// ---------- PERMISSION CHECK: Only allow ADMIN USER and MANAGER roles ----------
$context = context_system::instance();
$current_user_roles = get_user_roles($context, $USER->id);

$has_permission = false;
$allowed_roles = ['adminuser', 'manager'];

foreach ($current_user_roles as $role) {
    if (in_array($role->shortname, $allowed_roles)) {
        $has_permission = true;
        break;
    }
}

if (is_siteadmin()) {
    $has_permission = true;
}

if (!$has_permission) {
    $nopermission_message = 'You do not have permission to access this page.';
    redirect(
        new moodle_url('/'),
        $nopermission_message,
        null,
        \core\output\notification::NOTIFY_ERROR
    );
    exit;
}

$categoryid = optional_param('categoryid', 0, PARAM_INT);
$userid     = optional_param('userid', 0, PARAM_INT);
$classresults = optional_param('classresults', 0, PARAM_BOOL);
$sessionid = optional_param('sessionid', 0, PARAM_INT);
$termid = optional_param('termid', 0, PARAM_INT);
$action = optional_param('action', '', PARAM_TEXT);

$PAGE->set_context($context);
$PAGE->set_url(new moodle_url('/local/sis/viewresults.php', [
    'categoryid' => $categoryid, 
    'userid' => $userid,
    'sessionid' => $sessionid,
    'termid' => $termid
]));

$page_title = 'SIS - Report Card';
$page_heading = 'Student Report Card';

$PAGE->set_title($page_title);
$PAGE->set_heading($page_heading);

$PAGE->requires->css(new moodle_url('/local/sis/styles.css'));

// ---------- Function to get school settings from database ----------
function local_sis_get_school_settings() {
    global $DB;
    
    $school_settings = $DB->get_record('local_sis_school_settings', array('id' => 1));
    
    if (!$school_settings) {
        return (object) [
            'schoolname' => 'NDUKS TECH',
            'schooladdress' => '',
            'schoolmotto' => '',
            'phone' => '',
            'state' => '',
            'country' => '',
            'schoollogo' => '',
            'principalsignature' => ''
        ];
    }
    
    return $school_settings;
}

// ---------- Function to get school logo URL using File API ----------
function local_sis_get_school_logo_url() {
    global $CFG;
    $fs = get_file_storage();
    $context = context_system::instance();
    
    if ($files = $fs->get_area_files($context->id, 'local_sis', 'schoollogo', 1, "filename", false)) {
        $file = reset($files);
        return moodle_url::make_pluginfile_url($file->get_contextid(), $file->get_component(), 
            $file->get_filearea(), $file->get_itemid(), $file->get_filepath(), 
            $file->get_filename(), false);
    }
    
    // Return empty string if no logo found instead of pix folder reference
    return '';
}

// ---------- Function to get principal signature URL using File API ----------
function local_sis_get_principal_signature_url() {
    global $CFG;
    $fs = get_file_storage();
    $context = context_system::instance();
    
    if ($files = $fs->get_area_files($context->id, 'local_sis', 'principalsignature', 1, "filename", false)) {
        $file = reset($files);
        return moodle_url::make_pluginfile_url($file->get_contextid(), $file->get_component(), 
            $file->get_filearea(), $file->get_itemid(), $file->get_filepath(), 
            $file->get_filename(), false);
    }
    
    // Return empty string if no signature found instead of pix folder reference
    return '';
}

// ---------- Function to get session and term information ----------
function local_sis_get_session_term_info($sessionid = 0, $termid = 0) {
    global $DB;
    
    $sessions = $DB->get_records('local_sis_sessions', [], 'sessionname ASC');
    
    if (!$sessionid) {
        $current_session = $DB->get_record('local_sis_sessions', ['isdefault' => 1]);
        if ($current_session) {
            $sessionid = $current_session->id;
            $sessionname = $current_session->sessionname;
        } else {
            $first_session = reset($sessions);
            $sessionid = $first_session ? $first_session->id : 0;
            $sessionname = $first_session ? $first_session->sessionname : 'No Session Available';
        }
    } else {
        $session = $DB->get_record('local_sis_sessions', ['id' => $sessionid]);
        $sessionname = $session ? $session->sessionname : 'Selected Session';
    }
    
    $terms = [];
    if ($sessionid) {
        $terms = $DB->get_records('local_sis_terms', ['sessionid' => $sessionid], 'termname ASC');
    }
    
    if (!$termid && $sessionid) {
        $current_term = $DB->get_record('local_sis_terms', ['sessionid' => $sessionid, 'isdefault' => 1]);
        if ($current_term) {
            $termid = $current_term->id;
            $termname = $current_term->termname;
        } else {
            $first_term = reset($terms);
            $termid = $first_term ? $first_term->id : 0;
            $termname = $first_term ? $first_term->termname : 'No Term Available';
        }
    } else if ($termid) {
        $term = $DB->get_record('local_sis_terms', ['id' => $termid]);
        $termname = $term ? $term->termname : 'Selected Term';
    } else {
        $termname = 'Select Term';
    }
    
    return [
        'sessionid' => $sessionid,
        'sessionname' => $sessionname,
        'termid' => $termid,
        'termname' => $termname,
        'sessions' => $sessions,
        'terms' => $terms
    ];
}

// ---------- Function to get all students in class with results ----------
function local_sis_get_class_students($categoryid, $sessionid, $termid) {
    global $DB;
    
    $sql = "SELECT DISTINCT u.*
             FROM {user} u
             JOIN {local_sis_result} r ON r.userid = u.id
             JOIN {course} c ON c.id = r.courseid
            WHERE c.category = :catid
              AND r.sessionid = :sessionid
              AND r.termid = :termid
          ORDER BY u.lastname, u.firstname";
    
    return $DB->get_records_sql($sql, [
        'catid' => $categoryid,
        'sessionid' => $sessionid,
        'termid' => $termid
    ]);
}

// ---------- Function to check if results exist for selected parameters ----------
function local_sis_check_results_exist($categoryid, $sessionid, $termid) {
    global $DB;
    
    $sql = "SELECT COUNT(*) as result_count
            FROM {local_sis_result} r
            JOIN {course} c ON c.id = r.courseid
            WHERE c.category = :catid
            AND r.sessionid = :sessionid
            AND r.termid = :termid";
    
    $result = $DB->get_record_sql($sql, [
        'catid' => $categoryid,
        'sessionid' => $sessionid,
        'termid' => $termid
    ]);
    
    return $result && $result->result_count > 0;
}

function local_sis_get_component_names($courseid, $sessionid, $termid) {
    global $DB;
    
    $ca_config = $DB->get_record('local_sis_ca_config', [
        'courseid' => $courseid,
        'sessionid' => $sessionid,
        'termid' => $termid
    ]);
    
    if (!$ca_config) {
        return ['CA1', 'CA2', 'Exam'];
    }
    
    $components = !empty($ca_config->components) ? json_decode($ca_config->components, true) : [];
    $component_names = [];
    foreach ($components as $component) {
        $component_names[] = $component['name'];
    }
    return $component_names;
}

// ---------- Function to get student comments ----------
function local_sis_get_student_comments($userid, $categoryid, $sessionid, $termid) {
    global $DB;
    
    $sql = "SELECT * FROM {local_sis_comments} 
            WHERE userid = :userid 
            AND categoryid = :categoryid 
            AND sessionid = :sessionid 
            AND termid = :termid 
            LIMIT 1";
    
    return $DB->get_record_sql($sql, [
        'userid' => $userid,
        'categoryid' => $categoryid,
        'sessionid' => $sessionid,
        'termid' => $termid
    ]);
}

// ---------- Function for ranking with ties ----------
function local_sis_rank_with_ties(array $useridtotals): array {
    arsort($useridtotals, SORT_NUMERIC);
    $positions = [];
    $rank = 0;
    $index = 0;
    $prev = null;
    foreach ($useridtotals as $uid => $score) {
        $index++;
        if ($prev === null || (string)$score !== (string)$prev) {
            $rank = $index;
            $prev = $score;
        }
        $positions[$uid] = $rank;
    }
    return $positions;
}

// ---------- OPTIMIZED: Bulk data fetching functions ----------
function local_sis_get_all_component_names($courseids, $sessionid, $termid) {
    global $DB;
    
    if (empty($courseids)) {
        return [];
    }
    
    list($insql, $inparams) = $DB->get_in_or_equal($courseids, SQL_PARAMS_NAMED);
    $params = array_merge($inparams, ['sessionid' => $sessionid, 'termid' => $termid]);
    
    $sql = "SELECT courseid, components 
            FROM {local_sis_ca_config} 
            WHERE courseid $insql 
            AND sessionid = :sessionid 
            AND termid = :termid";
    
    $ca_configs = $DB->get_records_sql($sql, $params);
    
    $component_names = [];
    foreach ($courseids as $courseid) {
        if (isset($ca_configs[$courseid]) && !empty($ca_configs[$courseid]->components)) {
            $components = json_decode($ca_configs[$courseid]->components, true);
            $names = [];
            foreach ($components as $component) {
                $names[] = $component['name'];
            }
            $component_names[$courseid] = $names;
        } else {
            $component_names[$courseid] = ['CA1', 'CA2', 'Exam'];
        }
    }
    
    return $component_names;
}

function local_sis_get_all_student_comments($userids, $categoryid, $sessionid, $termid) {
    global $DB;
    
    if (empty($userids)) {
        return [];
    }
    
    list($insql, $inparams) = $DB->get_in_or_equal($userids, SQL_PARAMS_NAMED);
    $params = array_merge($inparams, [
        'categoryid' => $categoryid,
        'sessionid' => $sessionid,
        'termid' => $termid
    ]);
    
    $sql = "SELECT * FROM {local_sis_comments} 
            WHERE userid $insql 
            AND categoryid = :categoryid 
            AND sessionid = :sessionid 
            AND termid = :termid";
    
    $comments = $DB->get_records_sql($sql, $params);
    
    $indexed_comments = [];
    foreach ($comments as $comment) {
        $indexed_comments[$comment->userid] = $comment;
    }
    
    return $indexed_comments;
}

function local_sis_get_all_student_results($userids, $courseids, $sessionid, $termid) {
    global $DB;
    
    if (empty($userids) || empty($courseids)) {
        return [];
    }
    
    list($userinsql, $userinparams) = $DB->get_in_or_equal($userids, SQL_PARAMS_NAMED);
    list($courseinsql, $courseinparams) = $DB->get_in_or_equal($courseids, SQL_PARAMS_NAMED);
    
    $params = array_merge($userinparams, $courseinparams, [
        'sessionid' => $sessionid,
        'termid' => $termid
    ]);
    
    $sql = "SELECT * FROM {local_sis_result} 
            WHERE userid $userinsql 
            AND courseid $courseinsql
            AND sessionid = :sessionid 
            AND termid = :termid";
    
    $results = $DB->get_records_sql($sql, $params);
    
    $organized_results = [];
    foreach ($results as $result) {
        if (!isset($organized_results[$result->userid])) {
            $organized_results[$result->userid] = [];
        }
        $organized_results[$result->userid][$result->courseid] = $result;
    }
    
    return $organized_results;
}

function local_sis_get_all_course_positions($courseids, $sessionid, $termid) {
    global $DB;
    
    if (empty($courseids)) {
        return [];
    }
    
    list($insql, $inparams) = $DB->get_in_or_equal($courseids, SQL_PARAMS_NAMED);
    $params = array_merge($inparams, ['sessionid' => $sessionid, 'termid' => $termid]);
    
    $sql = "SELECT r.id, r.courseid, r.userid, r.total
            FROM {local_sis_result} r
            WHERE r.courseid $insql 
            AND r.sessionid = :sessionid 
            AND r.termid = :termid 
            ORDER BY r.courseid, r.total DESC";
    
    $rs = $DB->get_recordset_sql($sql, $params);
    
    $course_positions = [];
    $current_course = null;
    $current_rank = 0;
    $current_index = 0;
    $prev_score = null;
    
    foreach ($rs as $record) {
        if ($record->courseid != $current_course) {
            $current_course = $record->courseid;
            $current_rank = 0;
            $current_index = 0;
            $prev_score = null;
            $course_positions[$current_course] = [];
        }
        
        $current_index++;
        
        if ($prev_score === null || (string)$record->total !== (string)$prev_score) {
            $current_rank = $current_index;
            $prev_score = $record->total;
        }
        
        $course_positions[$current_course][$record->userid] = $current_rank;
    }
    
    $rs->close();
    
    return $course_positions;
}

function local_sis_get_overall_rankings($userids, $courseids, $sessionid, $termid, $all_results) {
    $overall_scores = [];
    
    foreach ($userids as $userid) {
        $total_sum = 0;
        $count = 0;
        
        foreach ($courseids as $courseid) {
            if (isset($all_results[$userid][$courseid]) && is_numeric($all_results[$userid][$courseid]->total)) {
                $total_sum += (float)$all_results[$userid][$courseid]->total;
                $count++;
            }
        }
        
        if ($count > 0) {
            $overall_scores[$userid] = $total_sum / $count;
        }
    }
    
    return local_sis_rank_with_ties($overall_scores);
}

// ---------- Function to generate individual student report card HTML ----------
function local_sis_generate_student_report_card($student, $category, $courses, $has_new_structure, $school_settings, $overall_rank, $class_size, $session_term_info, $student_results = null, $component_names = null, $course_positions = null, $student_comments = null) {
    global $DB, $CFG;
    
    $logopathweb = local_sis_get_school_logo_url();
    $sigpathweb = local_sis_get_principal_signature_url();
    
    if ($student_comments === null) {
        $student_comments = local_sis_get_student_comments($student->id, $category->id, $session_term_info['sessionid'], $session_term_info['termid']);
    }
    
    $teachercomment = '';
    $principalcomment = '';
    if ($student_comments) {
        $teachercomment = $student_comments->teachercomment ?? '';
        $principalcomment = $student_comments->principalcomment ?? '';
    }
    
    ob_start();
    ?>
    <div class="sis-report-card-wrapper print-optimized" id="report-card-<?php echo $student->id; ?>">
        <!-- WATERMARK BACKGROUND -->
        <?php if (!empty($logopathweb)): ?>
        <div class="watermark-background">
            <img src="<?php echo s($logopathweb); ?>" alt="School Logo Watermark" class="watermark-logo">
        </div>
        <?php endif; ?>
        
        <div class="report-card printable-area" style="font-family: Arial, sans-serif; font-size: 11px; position: relative; z-index: 2;">
            <!-- Header: Logo and School Name on the same line -->
            <div class="report-header" style="text-align: center; margin-bottom: 15px; border-bottom: 2px solid #3f51b5; padding-bottom: 10px; position: relative; z-index: 3;">
                <div style="display: flex; align-items: center; justify-content: center; gap: 10px;">
                    <?php if (!empty($logopathweb)): ?>
                        <img src="<?php echo s($logopathweb); ?>" alt="School Logo" style="height: 70px; width: auto; position: relative; z-index: 3;">
                    <?php endif; ?>
                    <div style="position: relative; z-index: 3;">
                        <h2 style="margin: 0; font-size: 18px; color: #3f51b5;"><?php echo format_string($school_settings->schoolname ?: 'NDUKS TECH'); ?></h2>
                        <?php if (!empty($school_settings->schooladdress) || !empty($school_settings->schoolmotto)): ?>
                            <div style="margin-top: 5px; font-size: 11px; font-style: italic;">
                                <?php if (!empty($school_settings->schooladdress)): ?>
                                    <div><?php echo format_string($school_settings->schooladdress); ?></div>
                                <?php endif; ?>
                                <?php if (!empty($school_settings->schoolmotto)): ?>
                                    <div>Motto: "<?php echo format_string($school_settings->schoolmotto); ?>"</div>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                        <h3 style="margin: 10px 0 0 0; font-size: 14px; font-weight: normal;">Student Report Card</h3>
                    </div>
                </div>
            </div>
            
            <div class="report-student-info" style="margin-bottom: 15px; position: relative; z-index: 3;">
                <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
                    <div><strong>Student:</strong> <?php echo format_string(fullname($student)); ?></div>
                    <div><strong>Username:</strong> <?php echo s($student->username); ?></div>
                </div>
                <div style="display: flex; justify-content: space-between;">
                    <div><strong>Class:</strong> <?php echo format_string($category->name); ?></div>
                    <div><strong>Term/Session:</strong> <?php echo $session_term_info['termname'] . ', ' . $session_term_info['sessionname']; ?></div>
                </div>
                <div style="text-align: right; font-size: 10px; color: #666;"><?php echo date('F j, Y'); ?></div>
            </div>
            
            <div class="report-table-container" style="margin-bottom: 15px; position: relative; z-index: 3;">
                <table class="report-table" style="width: 100%; border-collapse: collapse; font-size: 11px;">
                    <thead>
                        <tr style="background-color: #3f51b5; color: white;">
                            <th style="border: 1px solid #ddd; padding: 5px; width: 35%;">Subject</th>
                            <?php
                            $first_course_id = reset($courses)->id;
                            if ($component_names !== null) {
                                $first_component_names = $component_names[$first_course_id] ?? ['CA1', 'CA2', 'Exam'];
                            } else {
                                $first_component_names = local_sis_get_component_names($first_course_id, $session_term_info['sessionid'], $session_term_info['termid']);
                            }
                            foreach ($first_component_names as $component_name) {
                                echo '<th style="border: 1px solid #ddd; padding: 5px; width: 6%;">' . $component_name . '</th>';
                            }
                            ?>
                            <th style="border: 1px solid #ddd; padding: 5px; width: 6%;">Total</th>
                            <th style="border: 1px solid #ddd; padding: 5px; width: 6%;">Grade</th>
                            <th style="border: 1px solid #ddd; padding: 5px; width: 6%;">Points</th>
                            <th style="border: 1px solid #ddd; padding: 5px; width: 10%;">Position</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    $course_count = 0;
                    foreach ($courses as $course) {
                        $course_count++;
                        if ($student_results !== null) {
                            $res = $student_results[$student->id][$course->id] ?? null;
                        } else {
                            $res = $DB->get_record('local_sis_result', [
                                'userid' => $student->id, 
                                'courseid' => $course->id,
                                'sessionid' => $session_term_info['sessionid'],
                                'termid' => $session_term_info['termid']
                            ]);
                        }
                        
                        $row_class = $course_count % 2 == 0 ? 'course-row-even print-force-colors' : 'course-row-odd print-force-colors';
                        
                        if (!$res) {
                            echo '<tr class="' . $row_class . '">';
                            echo '<td style="border: 1px solid #ddd; padding: 5px;">' . format_string($course->fullname) . '</td>';
                            if ($component_names !== null) {
                                $current_component_names = $component_names[$course->id] ?? ['CA1', 'CA2', 'Exam'];
                            } else {
                                $current_component_names = local_sis_get_component_names($course->id, $session_term_info['sessionid'], $session_term_info['termid']);
                            }
                            foreach ($current_component_names as $c) {
                                echo '<td style="border: 1px solid #ddd; padding: 5px; text-align: center;">-</td>';
                            }
                            echo '<td style="border: 1px solid #ddd; padding: 5px; text-align: center;">-</td>';
                            echo '<td style="border: 1px solid #ddd; padding: 5px; text-align: center;">-</td>';
                            echo '<td style="border: 1px solid #ddd; padding: 5px; text-align: center;">-</td>';
                            echo '<td style="border: 1px solid #ddd; padding: 5px; text-align: center;">-</td></tr>';
                            continue;
                        }
                        
                        if ($has_new_structure) {
                            $component_data = !empty($res->data) ? json_decode($res->data, true) : [];
                            $total = $res->total; 
                            $grade = $res->grade; 
                            $points = $res->points;
                        } else {
                            $component_data = [ $res->firstca ?? 0, $res->secondca ?? 0, $res->exam ?? 0 ];
                            $total = $res->total; 
                            $grade = $res->grade; 
                            $points = 0;
                        }
                        
                        if ($component_names !== null) {
                            $current_component_names = $component_names[$course->id] ?? ['CA1', 'CA2', 'Exam'];
                        } else {
                            $current_component_names = local_sis_get_component_names($course->id, $session_term_info['sessionid'], $session_term_info['termid']);
                        }

                        if ($course_positions !== null) {
                            $pos = $course_positions[$course->id][$student->id] ?? '-';
                            $classsize = count($course_positions[$course->id] ?? []);
                            $posdisplay = is_numeric($pos) ? (string)$pos : '-';
                            if (is_numeric($pos) && $classsize > 0) {
                                $position_counts = array_count_values($course_positions[$course->id] ?? []);
                                if ($position_counts[$pos] > 1) {
                                    $posdisplay .= ' (tie)';
                                }
                                $posdisplay .= ' of ' . $classsize;
                            } else {
                                $posdisplay = '-';
                            }
                        } else {
                            $all = $DB->get_records('local_sis_result', [
                                'courseid' => $course->id,
                                'sessionid' => $session_term_info['sessionid'],
                                'termid' => $session_term_info['termid']
                            ], '', 'userid, total');
                            
                            if (!empty($all)) {
                                $totals = [];
                                foreach ($all as $uid => $obj) $totals[$uid] = (float)$obj->total;
                                $positions = local_sis_rank_with_ties($totals);
                                $pos = $positions[$student->id] ?? '-';
                                $classsize = count($totals);
                                $countbypos = array_count_values($positions);
                                $posdisplay = is_numeric($pos) ? (string)$pos : '-';
                                if (is_numeric($pos) && $countbypos[$pos] > 1) $posdisplay .= ' (tie)';
                                $posdisplay .= ' of ' . $classsize;
                            } else {
                                $posdisplay = '-';
                            }
                        }

                        echo '<tr class="' . $row_class . '">';
                        echo '<td style="border: 1px solid #ddd; padding: 5px;">' . format_string($course->fullname) . '</td>';
                        foreach ($current_component_names as $index => $name) {
                            $score = $component_data[$index] ?? 0;
                            echo '<td style="border: 1px solid #ddd; padding: 5px; text-align: center;">' . ($score > 0 ? format_float($score, 1) : '-') . '</td>';
                        }
                        echo '<td style="border: 1px solid #ddd; padding: 5px; text-align: center; font-weight: bold;">' . format_float($total, 1) . '</td>';
                        echo '<td style="border: 1px solid #ddd; padding: 5px; text-align: center;">' . ($grade ?: '-') . '</td>';
                        echo '<td style="border: 1px solid #ddd; padding: 5px; text-align: center;">' . format_float($points, 1) . '</td>';
                        echo '<td style="border: 1px solid #ddd; padding: 5px; text-align: center;">' . $posdisplay . '</td>';
                        echo '</tr>';
                    }
                    ?>
                    </tbody>
                </table>
            </div>
            
            <?php
            $studentsubjecttotals = [];
            $total_score = 0;
            foreach ($courses as $course) {
                if ($student_results !== null) {
                    $res = $student_results[$student->id][$course->id] ?? null;
                } else {
                    $res = $DB->get_record('local_sis_result', [
                        'userid' => $student->id, 
                        'courseid' => $course->id,
                        'sessionid' => $session_term_info['sessionid'],
                        'termid' => $session_term_info['termid']
                    ]);
                }
                
                if ($res && is_numeric($res->total)) {
                    $studentsubjecttotals[] = (float)$res->total;
                    $total_score += (float)$res->total;
                }
            }
            $overall_avg = '-';
            $hi = '-';
            $lo = '-';
            $total_score_display = '-';
            if (!empty($studentsubjecttotals)) {
                $overall_avg = round(array_sum($studentsubjecttotals) / count($studentsubjecttotals), 1);
                $hi  = max($studentsubjecttotals);
                $lo  = min($studentsubjecttotals);
                $total_score_display = number_format($total_score, 1);
            }
            
            echo '<div class="report-summary" style="margin-bottom: 15px; padding: 10px; background-color: #f5f5f5; border-radius: 5px; position: relative; z-index: 3;">';
            echo '<h3 style="margin: 0 0 8px 0; font-size: 12px; color: #3f51b5;">Performance Summary</h3>';
            echo '<div style="display: flex; flex-wrap: wrap; gap: 15px; justify-content: space-between;">';
            echo '<div><strong>Total Score:</strong> ' . $total_score_display . '</div>';
            echo '<div><strong>Average Score:</strong> ' . ($overall_avg !== '-' ? format_float($overall_avg, 1) : '-') . '</div>';
            echo '<div><strong>Highest Score:</strong> ' . ($hi !== '-' ? format_float($hi, 1) : '-') . '</div>';
            echo '<div><strong>Class Position:</strong> ' . $overall_rank . ' of ' . $class_size . '</div>';
            echo '</div>';
            echo '<div style="display: flex; gap: 15px; margin-top: 5px;">';
            echo '<div><strong>Lowest Score:</strong> ' . ($lo !== '-' ? format_float($lo, 1) : '-') . '</div>';
            echo '</div>';
            echo '</div>';
            ?>

            <!-- Comments Section -->
            <div class="report-comments" style="margin: 15px 0; padding: 10px; border: 1px solid #e0e0e0; border-radius: 5px; background-color: #f9f9f9; position: relative; z-index: 3;">
                <h4 style="margin: 0 0 10px 0; padding-bottom:- 5px; border-bottom: 1px solid #3f51b5; color: #3f51b5; font-size: 12px;">Comments</h4>
                
                <div class="comment-section" style="display: flex; gap: 15px;">
                    <div class="comment-block" style="flex: 1; padding: 10px; background: white; border-radius: 5px; border-left: 3px solid #4caf50;">
                        <h5 style="margin: 0 0 8px 0; color: #4caf50; font-size: 11px;">Teacher's Comment:</h5>
                        <div class="comment-content" style="padding: 8px; background: #f8f9fa; border-radius: 3px; border: 1px solid #e9ecef; min-height: 60px; font-style: italic; font-size: 11px; line-height: 1.4;">
                            <?php echo !empty($teachercomment) ? format_text($teachercomment) : '<span style="color: #6c757d;">No comment provided</span>'; ?>
                        </div>
                    </div>
                    
                    <div class="comment-block" style="flex: 1; padding: 10px; background: white; border-radius: 5px; border-left: 3px solid #ff9800;">
                        <h5 style="margin: 0 0 8px 0; color: #ff9800; font-size: 11px;">Principal's Comment:</h5>
                        <div class="comment-content" style="padding: 8px; background: #f8f9fa; border-radius: 3px; border: 1px solid #e9ecef; min-height: 60px; font-style: italic; font-size: 11px; line-height: 1.4;">
                            <?php echo !empty($principalcomment) ? format_text($principalcomment) : '<span style="color: #6c757d;">No comment provided</span>'; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- CENTERED SIGNATURE SECTION -->
            <div class="report-footer" style="text-align: center; margin-top: 40px; padding-top: 20px; border-top: 1px solid #e0e0e0; position: relative; z-index: 3;">
                <div class="signature-block" style="display: inline-block; text-align: center; margin: 0 auto;">
                    <?php if (!empty($sigpathweb)): ?>
                        <img src="<?php echo s($sigpathweb); ?>" alt="Principal's Signature" style="height: 40px; width: auto; margin-bottom: 8px; display: block; margin-left: auto; margin-right: auto;">
                    <?php endif; ?>
                    <div style="font-size: 11px; font-weight: bold; text-align: center;">Principal's Signature</div>
                </div>
            </div>

            <!-- NEW: Plugin Footer -->
            <div class="plugin-footer" style="text-align: center; margin-top: 15px; padding-top: 10px; border-top: 1px solid #e0e0e0; font-size: 9px; color: #666; position: relative; z-index: 3;">
                ndukstech sis plugin   facebook.com/ndukshub
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

// Get school settings
$school_settings = local_sis_get_school_settings();

// Get session and term information
$session_term_info = local_sis_get_session_term_info($sessionid, $termid);

// Get all categories/classes
$categories = $DB->get_records('course_categories', [], 'name ASC');

$category = null;
if ($categoryid) {
    $category = $DB->get_record('course_categories', ['id' => $categoryid]);
}

// ---------- MAIN PAGE DISPLAY LOGIC ----------
echo $OUTPUT->header();

echo html_writer::div(
    html_writer::link(
        new moodle_url('/local/sis/index.php'),
        'Back to Main Dashboard',
        ['class' => 'btn btn-success mb-3 no-print']
    ),
    'text-center'
);

// Add CSS wrapper styles with PERFECT print styling for PDF
echo '
<style>
.sis-report-card-wrapper {
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    margin: 20px 0;
    padding: 20px;
    background: white;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    position: relative;
    overflow: hidden;
}

.sis-report-card-wrapper::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, #3f51b5, #2196f3, #00bcd4);
    border-radius: 8px 8px 0 0;
}

/* IMPROVED WATERMARK STYLES */
.watermark-background {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 1;
    pointer-events: none;
    opacity: 0.08;
    overflow: hidden;
}

.watermark-logo {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%) rotate(-30deg);
    width: 60%;
    max-width: 400px;
    height: auto;
    max-height: 400px;
    object-fit: contain;
    opacity: 0.15;
}

.report-card {
    position: relative;
    z-index: 2;
}

.course-row-odd {
    background-color: #f8f9fa !important;
}

.course-row-even {
    background-color: #ffffff !important;
}

.course-row-odd td,
.course-row-even td {
    border-bottom: 1px solid #dee2e6 !important;
    background-color: inherit !important;
}

/* PERFECT PRINT STYLES FOR PDF - EXACT MATCH TO WEB VIEW */
@media print {
    /* RESET EVERYTHING */
    * {
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
        color-adjust: exact !important;
    }
    
    @page {
        margin: 0.5cm;
        size: A4 portrait;
    }
    
    body {
        margin: 0 !important;
        padding: 0 !important;
        background: white !important;
        color: black !important;
        font-family: Arial, Helvetica, sans-serif !important;
        font-size: 11px !important;
        line-height: 1.2 !important;
        width: 100% !important;
    }
    
    /* HIDE NON-ESSENTIAL ELEMENTS */
    .no-print,
    .navbar,
    .breadcrumb,
    .sis-controls,
    .btn,
    .alert,
    #page-header,
    #page-footer,
    .moodle-header,
    .moodle-footer {
        display: none !important;
    }
    
    /* CRITICAL FIX: SHOW ALL REPORT CARDS WITHOUT BLANK PAGES */
    .sis-report-card-wrapper {
        display: block !important;
        visibility: visible !important;
        opacity: 1 !important;
        height: auto !important;
        overflow: visible !important;
        page-break-inside: avoid !important;
        margin: 0 !important;
        padding: 15px !important;
        border: 1px solid #e0e0e0 !important;
        border-radius: 8px !important;
        background: white !important;
        box-shadow: none !important;
        position: relative !important;
    }
    
    /* FIX: Remove problematic page-break-after that was causing blank pages */
    .sis-report-card-wrapper {
        page-break-after: auto !important;
    }
    
    /* Add page break after each report card except the last one */
    .sis-report-card-wrapper:not(:last-child) {
        page-break-after: always !important;
    }
    
    .sis-report-card-wrapper::before {
        content: "" !important;
        position: absolute !important;
        top: 0 !important;
        left: 0 !important;
        right: 0 !important;
        height: 4px !important;
        background: linear-gradient(90deg, #3f51b5, #2196f3, #00bcd4) !important;
        border-radius: 8px 8px 0 0 !important;
    }
    
    /* IMPROVED WATERMARK FOR PRINT */
    .watermark-background {
        display: block !important;
        opacity: 0.06 !important;
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
        position: absolute !important;
        top: 0 !important;
        left: 0 !important;
        right: 0 !important;
        bottom: 0 !important;
        z-index: 1 !important;
    }
    
    .watermark-logo {
        width: 70% !important;
        max-width: 450px !important;
        height: auto !important;
        max-height: 450px !important;
        opacity: 0.12 !important;
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
        transform: translate(-50%, -50%) rotate(-30deg) !important;
    }
    
    .report-card {
        margin: 0 !important;
        padding: 0 !important;
        background: white !important;
        font-family: Arial, sans-serif !important;
        font-size: 11px !important;
        position: relative !important;
        z-index: 2 !important;
    }
    
    /* HEADER STYLING - EXACT MATCH */
    .report-header {
        text-align: center !important;
        margin-bottom: 15px !important;
        border-bottom: 2px solid #3f51b5 !important;
        padding-bottom: 10px !important;
        background: white !important;
    }
    
    .report-header h2 {
        color: #3f51b5 !important;
        font-size: 18px !important;
        margin: 0 !important;
        background: white !important;
    }
    
    .report-header h3 {
        font-size: 14px !important;
        margin: 10px 0 0 0 !important;
        font-weight: normal !important;
        background: white !important;
    }
    
    /* FIXED: LOGO SIZE FOR PRINT - MATCHES WEB VIEW */
    .report-header img {
        height: 40px !important;
        width: auto !important;
        max-width: 100% !important;
    }
    
    /* STUDENT INFO */
    .report-student-info {
        margin-bottom: 15px !important;
        background: white !important;
    }
    
    /* TABLE STYLING - EXACT WEB MATCH */
    .report-table {
        width: 100% !important;
        border-collapse: collapse !important;
        border: 1px solid #ddd !important;
        font-size: 11px !important;
        page-break-inside: avoid;
        background: white !important;
    }
    
    .report-table th {
        background-color: #3f51b5 !important;
        color: white !important;
        font-weight: bold !important;
        border: 1px solid #ddd !important;
        padding: 5px !important;
        text-align: center !important;
    }
    
    .report-table td {
        border: 1px solid #ddd !important;
        padding: 5px !important;
        text-align: center !important;
        background-color: inherit !important;
    }
    
    /* FORCE ALTERNATING ROW COLORS TO PRINT */
    .course-row-odd {
        background-color: #f8f9fa !important;
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
        color-adjust: exact !important;
    }
    
    .course-row-even {
        background-color: #ffffff !important;
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
        color-adjust: exact !important;
    }
    
    .course-row-odd td,
    .course-row-even td {
        background-color: inherit !important;
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
        color-adjust: exact !important;
        border-bottom: 1px solid #dee2e6 !important;
    }
    
    /* SUMMARY SECTION */
    .report-summary {
        background-color: #f5f5f5 !important;
        margin-bottom: 15px !important;
        padding: 10px !important;
        border-radius: 5px !important;
        border: 1px solid #e0e0e0 !important;
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
        color-adjust: exact !important;
    }
    
    .report-summary h3 {
        color: #3f51b5 !important;
        font-size: 12px !important;
        margin: 0 0 8px 0 !important;
        background: transparent !important;
    }
    
    /* COMMENTS SECTION */
    .report-comments {
        background-color: #f9f9f9 !important;
        margin: 15px 0 !important;
        padding: 10px !important;
        border: 1px solid #e0e0e0 !important;
        border-radius: 5px !important;
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
        color-adjust: exact !important;
    }
    
    .report-comments h4 {
        color: #3f51b5 !important;
        font-size: 12px !important;
        margin: 0 0 10px 0 !important;
        padding-bottom: 5px !important;
        border-bottom: 1px solid #3f51b5 !important;
        background: transparent !important;
    }
    
    .comment-block {
        background: white !important;
        padding: 10px !important;
        border-radius: 5px !important;
        border-left: 3px solid !important;
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
        color-adjust: exact !important;
    }
    
    .comment-content {
        background: #f8f9fa !important;
        padding: 8px !important;
        border-radius: 3px !important;
        border: 1px solid #e9ecef !important;
        min-height: 60px !important;
        font-style: italic !important;
        font-size: 11px !important;
        line-height: 1.4 !important;
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
        color-adjust: exact !important;
    }
    
    /* FOOTER */
    .report-footer {
        text-align: center !important;
        margin-top: 40px !important;
        padding-top: 20px !important;
        border-top: 1px solid #e0e0e0 !important;
        background: white !important;
    }
    
    /* FIXED: SIGNATURE SIZE FOR PRINT */
    .report-footer img {
        height: 40px !important;
        width: auto !important;
        max-width: 100% !important;
    }
    
    .plugin-footer {
        text-align: center !important;
        margin-top: 15px !important;
        padding-top: 10px !important;
        border-top: 1px solid #e0e0e0 !important;
        font-size: 9px !important;
        color: #666 !important;
        background: white !important;
    }
    
    /* ENSURE IMAGES PRINT CORRECTLY */
    img {
        max-width: 100% !important;
        height: auto !important;
        display: inline-block !important;
    }
    
    /* PREVENT PAGE BREAKS INSIDE CRITICAL ELEMENTS */
    .report-table,
    .report-summary,
    .report-comments,
    .report-footer {
        page-break-inside: avoid !important;
    }
}

/* SCREEN-ONLY STYLES */
@media screen {
    .no-print {
        display: block;
    }
}

/* UTILITY CLASSES FOR PRINT PERFECTION */
.print-force-colors {
    -webkit-print-color-adjust: exact !important;
    print-color-adjust: exact !important;
    color-adjust: exact !important;
}
</style>
';

// Selection Controls - Hidden when results are displayed
if (!$categoryid || (!$userid && !$classresults)): ?>
<div class="sis-controls no-print" style="margin-bottom: 20px; padding: 15px; background-color: #f8f9fa; border-radius: 5px;">
    <!-- Main Selection Form -->
    <form method="get" action="" id="mainForm" class="form-inline">
        <input type="hidden" name="categoryid" id="categoryid" value="<?php echo $categoryid; ?>">
        <input type="hidden" name="userid" id="userid" value="<?php echo $userid; ?>">
        <input type="hidden" name="classresults" id="classresults" value="<?php echo $classresults; ?>">
        
        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr auto; gap: 10px; align-items: end;">
            <!-- Session Dropdown -->
            <div>
                <label for="sessionid" style="display: block; margin-bottom: 5px; font-weight: bold;">Session:</label>
                <select name="sessionid" id="sessionid" class="form-control" onchange="this.form.submit()">
                    <option value="">Select Session</option>
                    <?php foreach ($session_term_info['sessions'] as $s): ?>
                        <option value="<?php echo $s->id; ?>" 
                            <?php echo $session_term_info['sessionid'] == $s->id ? 'selected' : ''; ?>>
                            <?php echo format_string($s->sessionname); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <!-- Term Dropdown -->
            <div>
                <label for="termid" style="display: block; margin-bottom: 5px; font-weight: bold;">Term:</label>
                <select name="termid" id="termid" class="form-control" onchange="this.form.submit()">
                    <option value="">Select Term</option>
                    <?php foreach ($session_term_info['terms'] as $t): ?>
                        <option value="<?php echo $t->id; ?>" 
                            <?php echo $session_term_info['termid'] == $t->id ? 'selected' : ''; ?>>
                            <?php echo format_string($t->termname); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <!-- Category/Class Dropdown -->
            <div>
                <label for="category_select" style="display: block; margin-bottom: 5px; font-weight: bold;">Class/Category:</label>
                <select name="category_select" id="category_select" class="form-control" onchange="updateCategory()">
                    <option value="">Select Class</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?php echo $cat->id; ?>" <?php echo $categoryid == $cat->id ? 'selected' : ''; ?>>
                            <?php echo format_string($cat->name); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div>
                <button type="submit" class="btn btn-primary" name="apply" value="1" id="apply_btn">
                    Apply Selections
                </button>
            </div>
        </div>
    </form>

    <!-- Action Buttons (Shown when category is selected) -->
    <?php if ($categoryid): ?>
    <div id="action_buttons" style="display: block; margin-top: 15px;">
        <div style="display: flex; gap: 10px; align-items: center;">
            <div style="flex: 1;">
                <label for="student_select" style="display: block; margin-bottom: 5px; font-weight: bold;">Select Student (Optional):</label>
                <select name="student_select" id="student_select" class="form-control">
                    <option value="">All Students (Class Results)</option>
                    <?php 
                    $students = local_sis_get_class_students($categoryid, $session_term_info['sessionid'], $session_term_info['termid']);
                    foreach ($students as $student): ?>
                        <option value="<?php echo $student->id; ?>" <?php echo $userid == $student->id ? 'selected' : ''; ?>>
                            <?php echo fullname($student) . ' (' . $student->username . ')'; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div style="display: flex; gap: 10px; align-items: end;">
                <a href="<?php echo new moodle_url('/local/sis/viewresults.php', [
                    'categoryid' => $categoryid, 
                    'sessionid' => $sessionid, 
                    'termid' => $termid,
                    'classresults' => 1
                ]); ?>" class="btn btn-info">View Class Results</a>
                
                <button type="button" class="btn btn-success" onclick="viewStudentResult()" 
                        id="student_result_btn" <?php echo !$userid ? 'disabled' : ''; ?>>
                    View Student Result
                </button>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>
<?php else: ?>
<!-- Show minimal header when results are displayed -->
<div class="no-print" style="text-align: center; margin-bottom: 20px; padding: 15px; background-color: #e9f7ef; border-radius: 5px;">
    <h4>Viewing Results: <?php echo $session_term_info['sessionname'] . ' - ' . $session_term_info['termname']; ?></h4>
    <p>Class: <?php echo $category ? format_string($category->name) : 'Not selected'; ?></p>
    <a href="<?php echo new moodle_url('/local/sis/viewresults.php'); ?>" class="btn btn-secondary">Change Selections</a>
</div>
<?php endif; ?>

<!-- Print Button (shown when results are displayed) -->
<?php if ($categoryid && ($userid || $classresults)): ?>
<div style="text-align: center; margin: 20px 0;" class="no-print">
    <button class="btn btn-primary" onclick="printExactPDF()">
        <i class="fa fa-print"></i> Print Exact PDF Copy
    </button>
    <button class="btn btn-success" onclick="printAllReports()" style="margin-left: 10px;">
        <i class="fa fa-file-pdf"></i> Print All Reports
    </button>
</div>
<?php endif; ?>

<script>
function updateCategory() {
    var categoryId = document.getElementById('category_select').value;
    document.getElementById('categoryid').value = categoryId;
    
    if (categoryId) {
        document.getElementById('apply_btn').disabled = false;
    }
}

function viewStudentResult() {
    var studentId = document.getElementById('student_select').value;
    if (studentId) {
        window.location.href = '<?php echo $PAGE->url; ?>' + '&userid=' + studentId + '&classresults=0';
    } else {
        alert('Please select a student to view individual result.');
    }
}

// PERFECT PDF PRINT FUNCTION - FIXED TO PRINT ALL REPORTS WITHOUT BLANK PAGES
function printExactPDF() {
    // CRITICAL FIX: Remove any hiding styles and ensure all content is visible
    const allReportCards = document.querySelectorAll('.sis-report-card-wrapper');
    allReportCards.forEach((card, index) => {
        card.style.display = 'block';
        card.style.visibility = 'visible';
        card.style.opacity = '1';
        card.style.height = 'auto';
        card.style.overflow = 'visible';
        // Remove any inline styles that might be hiding content
        card.style.pageBreakBefore = 'auto';
        card.style.pageBreakAfter = index === allReportCards.length - 1 ? 'auto' : 'always';
    });
    
    // Force a reflow
    document.body.offsetHeight;
    
    // Print immediately
    window.print();
}

// Print all reports in sequence - FIXED FUNCTION
function printAllReports() {
    printExactPDF(); // Both buttons now use the same function to print all visible reports
}

// Enable/disable student result button based on student selection
document.getElementById('student_select').addEventListener('change', function() {
    var studentId = this.value;
    document.getElementById('student_result_btn').disabled = !studentId;
});

// Initialize Apply button state on page load
document.addEventListener('DOMContentLoaded', function() {
    var categoryId = document.getElementById('category_select').value;
    var applyBtn = document.getElementById('apply_btn');
    
    if (categoryId && applyBtn) {
        applyBtn.disabled = false;
    }
});
</script>

<?php
// Check if we have the necessary parameters
if (!$categoryid) {
    echo '<div class="alert alert-info" style="text-align: center;">';
    echo '<h4>Select Class to View Results</h4>';
    echo '<p>Please select a Session, Term, and Class from the dropdown menus above to view student results.</p>';
    echo '</div>';
    echo $OUTPUT->footer();
    exit;
}

// Check if results exist for the selected parameters
if (!local_sis_check_results_exist($categoryid, $session_term_info['sessionid'], $session_term_info['termid'])) {
    echo '<div class="alert alert-warning">No results found for the selected class, session, and term.</div>';
    echo $OUTPUT->footer();
    exit;
}

// Check DB structure
$columns = $DB->get_columns('local_sis_result');
$has_new_structure = array_key_exists('data', $columns);

if ($classresults || $userid) {
    $students = local_sis_get_class_students($categoryid, $session_term_info['sessionid'], $session_term_info['termid']);
    $courses = $DB->get_records('course', ['category' => $categoryid], 'fullname ASC', 'id, fullname');
    
    if (empty($students) || empty($courses)) {
        echo '<div class="alert alert-warning">No students or courses found for the selected criteria.</div>';
        echo $OUTPUT->footer();
        exit;
    }
    
    // Use optimized bulk fetching for better performance
    $student_ids = array_keys($students);
    $course_ids = array_keys($courses);
    
    // Bulk fetch all data
    $all_component_names = local_sis_get_all_component_names($course_ids, $session_term_info['sessionid'], $session_term_info['termid']);
    $all_student_comments = local_sis_get_all_student_comments($student_ids, $categoryid, $session_term_info['sessionid'], $session_term_info['termid']);
    $all_student_results = local_sis_get_all_student_results($student_ids, $course_ids, $session_term_info['sessionid'], $session_term_info['termid']);
    $all_course_positions = local_sis_get_all_course_positions($course_ids, $session_term_info['sessionid'], $session_term_info['termid']);
    $overall_rankings = local_sis_get_overall_rankings($student_ids, $course_ids, $session_term_info['sessionid'], $session_term_info['termid'], $all_student_results);
    
    $class_size = count($student_ids);
}

if ($classresults) {
    // Display class results using optimized data
    foreach ($students as $student) {
        $overall_rank = $overall_rankings[$student->id] ?? '-';
        
        $student_comment = isset($all_student_comments[$student->id]) ? $all_student_comments[$student->id] : null;
        
        // Generate report card using optimized data
        echo local_sis_generate_student_report_card(
            $student, 
            $category, 
            $courses, 
            $has_new_structure, 
            $school_settings, 
            $overall_rank, 
            $class_size, 
            $session_term_info,
            $all_student_results,
            $all_component_names,
            $all_course_positions,
            $student_comment
        );
    }
    
} else if ($userid) {
    // Display individual student results using optimized data
    $student = $DB->get_record('user', ['id' => $userid]);
    if (!$student) {
        echo '<div class="alert alert-danger">Student not found.</div>';
        echo $OUTPUT->footer();
        exit;
    }
    
    $overall_rank = $overall_rankings[$student->id] ?? '-';
    
    $student_comment = isset($all_student_comments[$student->id]) ? $all_student_comments[$student->id] : null;
    
    // Display report card using optimized data
    echo local_sis_generate_student_report_card(
        $student, 
        $category, 
        $courses, 
        $has_new_structure, 
        $school_settings, 
        $overall_rank, 
        $class_size, 
        $session_term_info,
        $all_student_results,
        $all_component_names,
        $all_course_positions,
        $student_comment
    );
}

echo html_writer::div(
    html_writer::link(
        new moodle_url('/local/sis/index.php'),
        'Back to Main Dashboard',
        ['class' => 'btn btn-success mb-3 no-print']
    ),
    'text-center'
);

echo $OUTPUT->footer();
?>