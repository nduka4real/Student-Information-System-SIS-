<?php
// This file is part of the Student Information System plugin for Moodle.
// this file manages fees
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version information for the Student Information System plugin
 *
 * @package    local_sis
 * @copyright  2025 NduksTech - https://facebook.com/ndukshub
 * @author     Nduka Akapti  (https://github.com/nduka4real)
 * @author     Ndukstech (https://www.youtube.com/@nduks-tech)
 * @author     https://www.linkedin.com/in/ndukaakpati/
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @details
 * Display Name: Student Information System
 * Description: A comprehensive system for managing student records, assessments, fees, and school operations.
 * Contact: https://github.com/nduka4real
 * Social: https://facebook.com/ndukshub
 */

require_once(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/../../course/lib.php');
require_login();

$categoryid = optional_param('categoryid', 0, PARAM_INT);
$sessionid = optional_param('sessionid', 0, PARAM_INT);
$termid = optional_param('termid', 0, PARAM_INT);
$action = optional_param('action', '', PARAM_TEXT);
$userid = optional_param('userid', 0, PARAM_INT);
$permission = optional_param('permission', '', PARAM_TEXT);

$context = context_system::instance();
require_capability('moodle/site:config', $context);

$PAGE->set_context($context);
$PAGE->set_url(new moodle_url('/local/sis/manage_fees.php'));
$PAGE->set_title('Student Access Management - Fee Control');
$PAGE->set_heading('Student Access Management');
$PAGE->set_pagelayout('admin');

// Add CSS
$PAGE->requires->css(new moodle_url('/local/sis/styles.css'));

echo $OUTPUT->header();

// Navigation buttons
echo html_writer::start_div('mb-4');
echo html_writer::link(new moodle_url('/local/sis/index.php'), 
    '? Back to SIS Dashboard', 
    ['class' => 'btn btn-secondary mr-2']
);
echo html_writer::end_div();

// Get session and term information
$session_term_info = get_session_term_info($sessionid, $termid);

// Handle single permission update via AJAX
if ($action == 'update_permission' && $userid && $permission && $categoryid && $sessionid && $termid) {
    require_sesskey();
    
    $value = optional_param('value', 0, PARAM_INT);
    $success = update_student_permission($userid, $categoryid, $sessionid, $termid, $permission, $value);
    
    if ($success) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Failed to update permission']);
    }
    exit;
}

// Handle bulk permission update
if ($action == 'bulk_update' && $categoryid && $sessionid && $termid) {
    require_sesskey();
    
    $user_permissions = optional_param_array('user_permissions', [], PARAM_INT);
    $quiz_access = optional_param_array('quiz_access', [], PARAM_INT);
    $results_access = optional_param_array('results_access', [], PARAM_INT);
    
    $updated = 0;
    foreach ($user_permissions as $userid) {
        $can_attempt_quiz = in_array($userid, $quiz_access) ? 1 : 0;
        $can_view_results = in_array($userid, $results_access) ? 1 : 0;
        
        update_student_permission($userid, $categoryid, $sessionid, $termid, 'all', null, $can_attempt_quiz, $can_view_results);
        $updated++;
    }
    
    \core\notification::success("Updated permissions for {$updated} students.");
    redirect(new moodle_url('/local/sis/manage_fees.php', [
        'categoryid' => $categoryid,
        'sessionid' => $sessionid,
        'termid' => $termid
    ]));
}

// === Helper functions ===

function get_session_term_info($sessionid = 0, $termid = 0) {
    global $DB;
    $sessions = $DB->get_records('local_sis_sessions', [], 'sessionname ASC');
    if (!$sessionid) {
        $current_session = $DB->get_record('local_sis_sessions', ['isdefault' => 1]);
        if ($current_session) {
            $sessionid = $current_session->id;
            $sessionname = $current_session->sessionname;
        } else {
            $first_session = reset($sessions);
            $sessionid = $first_session ? $first_session->id : 0;
            $sessionname = $first_session ? $first_session->sessionname : 'No Session Available';
        }
    } else {
        $session = $DB->get_record('local_sis_sessions', ['id' => $sessionid]);
        $sessionname = $session ? $session->sessionname : 'Selected Session';
    }
    $terms = [];
    if ($sessionid) {
        $terms = $DB->get_records('local_sis_terms', ['sessionid' => $sessionid], 'termname ASC');
    }
    if (!$termid && $sessionid) {
        $current_term = $DB->get_record('local_sis_terms', ['sessionid' => $sessionid, 'isdefault' => 1]);
        if ($current_term) {
            $termid = $current_term->id;
            $termname = $current_term->termname;
        } else {
            $first_term = reset($terms);
            $termid = $first_term ? $first_term->id : 0;
            $termname = $first_term ? $first_term->termname : 'No Term Available';
        }
    } else if ($termid) {
        $term = $DB->get_record('local_sis_terms', ['id' => $termid]);
        $termname = $term ? $term->termname : 'Selected Term';
    } else {
        $termname = 'Select Term';
    }
    return [
        'sessionid' => $sessionid,
        'sessionname' => $sessionname,
        'termid' => $termid,
        'termname' => $termname,
        'sessions' => $sessions,
        'terms' => $terms
    ];
}

function update_student_permission($userid, $categoryid, $sessionid, $termid, $permission, $value = null, $quiz_access = null, $results_access = null) {
    global $DB;
    $record = $DB->get_record('local_sis_student_access', [
        'userid' => $userid,
        'categoryid' => $categoryid,
        'sessionid' => $sessionid,
        'termid' => $termid
    ]);
    $time = time();
    if ($record) {
        if ($permission == 'all') {
            $record->can_attempt_quiz = $quiz_access;
            $record->can_view_results = $results_access;
        } else {
            $record->{$permission} = $value;
        }
        $record->timemodified = $time;
        return $DB->update_record('local_sis_student_access', $record);
    } else {
        $newrecord = new stdClass();
        $newrecord->userid = $userid;
        $newrecord->categoryid = $categoryid;
        $newrecord->sessionid = $sessionid;
        $newrecord->termid = $termid;
        $newrecord->timecreated = $time;
        $newrecord->timemodified = $time;
        if ($permission == 'all') {
            $newrecord->can_attempt_quiz = $quiz_access;
            $newrecord->can_view_results = $results_access;
        } else {
            $newrecord->can_attempt_quiz = ($permission == 'can_attempt_quiz') ? $value : 0;
            $newrecord->can_view_results = ($permission == 'can_view_results') ? $value : 0;
        }
        return $DB->insert_record('local_sis_student_access', $newrecord);
    }
}

function get_student_permissions($userid, $categoryid, $sessionid, $termid) {
    global $DB;
    return $DB->get_record('local_sis_student_access', [
        'userid' => $userid,
        'categoryid' => $categoryid,
        'sessionid' => $sessionid,
        'termid' => $termid
    ]);
}

function get_students_in_category($categoryid) {
    global $DB;
    $sql = "SELECT DISTINCT u.id, u.firstname, u.lastname, u.username, u.email,
                   u.firstnamephonetic, u.lastnamephonetic, u.middlename, u.alternatename
            FROM {user} u
            JOIN {user_enrolments} ue ON ue.userid = u.id
            JOIN {enrol} e ON e.id = ue.enrolid
            JOIN {course} c ON c.id = e.courseid
            WHERE c.category = ?
            AND u.deleted = 0
            AND u.suspended = 0
            ORDER BY u.lastname, u.firstname";
    return $DB->get_records_sql($sql, [$categoryid]);
}

function get_all_categories() {
    global $DB;
    return $DB->get_records('course_categories', [], 'name ASC');
}

// Main
if (!$categoryid || !$sessionid || !$termid) {
    display_selection_form($session_term_info);
} else {
    display_student_management($categoryid, $sessionid, $termid, $session_term_info);
}

echo $OUTPUT->footer();

// === Display functions ===
function display_selection_form($session_term_info) {
    $categories = get_all_categories();
    echo html_writer::start_div('card');
    echo html_writer::start_div('card-header');
    echo html_writer::tag('h4', 'Select Academic Period and Class', ['class' => 'mb-0']);
    echo html_writer::end_div();
    echo html_writer::start_div('card-body');
    echo html_writer::start_tag('form', ['method' => 'get', 'action' => new moodle_url('/local/sis/manage_fees.php')]);
    echo html_writer::start_div('row');
    // Session
    echo html_writer::start_div('col-md-4 mb-3');
    echo html_writer::label('Academic Session', 'sessionid', true, ['class' => 'form-label']);
    $session_options = ['' => 'Select Session'];
    foreach ($session_term_info['sessions'] as $s) {
        $session_options[$s->id] = format_string($s->sessionname);
    }
    echo html_writer::select($session_options, 'sessionid', $session_term_info['sessionid'], false, ['class' => 'form-control', 'required' => true]);
    echo html_writer::end_div();
    // Term
    echo html_writer::start_div('col-md-4 mb-3');
    echo html_writer::label('Term', 'termid', true, ['class' => 'form-label']);
    $term_options = ['' => 'Select Term'];
    foreach ($session_term_info['terms'] as $t) {
        $term_options[$t->id] = format_string($t->termname);
    }
    echo html_writer::select($term_options, 'termid', $session_term_info['termid'], false, ['class' => 'form-control', 'required' => true]);
    echo html_writer::end_div();
    // Category
    echo html_writer::start_div('col-md-4 mb-3');
    echo html_writer::label('Class/Category', 'categoryid', true, ['class' => 'form-label']);
    $category_options = ['' => 'Select Class'];
    foreach (get_all_categories() as $c) {
        $category_options[$c->id] = format_string($c->name);
    }
    echo html_writer::select($category_options, 'categoryid', optional_param('categoryid', 0, PARAM_INT), false, ['class' => 'form-control', 'required' => true]);
    echo html_writer::end_div();
    echo html_writer::end_div();
    echo html_writer::start_div('text-center');
    echo html_writer::tag('button', 'Manage Student Access', ['type' => 'submit', 'class' => 'btn btn-primary btn-lg']);
    echo html_writer::end_div();
    echo html_writer::end_tag('form');
    echo html_writer::end_div();
    echo html_writer::end_div();
}

function display_student_management($categoryid, $sessionid, $termid, $session_term_info) {
    global $DB, $PAGE;
    $category = $DB->get_record('course_categories', ['id' => $categoryid]);
    $students = get_students_in_category($categoryid);
    if (!$category) {
        \core\notification::error('Category not found.');
        redirect(new moodle_url('/local/sis/manage_fees.php'));
    }

    // === FIX STARTS HERE ===
    $PAGE->requires->js_init_code("
        document.addEventListener('DOMContentLoaded', function() {
            const quizMaster = document.getElementById('select_all_quiz');
            const quizBoxes = document.querySelectorAll('.can_attempt_quiz-checkbox');
            const resultsMaster = document.getElementById('select_all_results');
            const resultsBoxes = document.querySelectorAll('.can_view_results-checkbox');

            if (quizMaster) {
                quizMaster.addEventListener('change', function() {
                    quizBoxes.forEach(cb => { cb.checked = quizMaster.checked; cb.dispatchEvent(new Event('change')); });
                });
            }
            if (resultsMaster) {
                resultsMaster.addEventListener('change', function() {
                    resultsBoxes.forEach(cb => { cb.checked = resultsMaster.checked; cb.dispatchEvent(new Event('change')); });
                });
            }
        });
    ");
    // === FIX ENDS HERE ===

    echo html_writer::start_div('card');
    echo html_writer::start_div('card-header d-flex justify-content-between align-items-center');
    echo html_writer::tag('h4',
        'Manage Student Access: ' . format_string($category->name) .
        ' (' . $session_term_info['sessionname'] . ' - ' . $session_term_info['termname'] . ')',
        ['class' => 'mb-0']
    );
    echo html_writer::link(
        new moodle_url('/local/sis/manage_fees.php'),
        '? Change Selection',
        ['class' => 'btn btn-outline-secondary']
    );
    echo html_writer::end_div();
    echo html_writer::start_div('card-body');
    if (empty($students)) {
        echo html_writer::div(html_writer::tag('p', 'No students found.', ['class' => 'text-muted text-center']), 'alert alert-info');
    } else {
        echo html_writer::start_tag('form', [
            'method' => 'post',
            'action' => new moodle_url('/local/sis/manage_fees.php', [
                'categoryid' => $categoryid,
                'sessionid' => $sessionid,
                'termid' => $termid,
                'action' => 'bulk_update'
            ])
        ]);
        echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey()]);
        echo html_writer::start_div('table-responsive');
        echo html_writer::start_tag('table', ['class' => 'table table-striped table-bordered']);
        echo html_writer::start_tag('thead', ['class' => 'thead-dark']);
        echo html_writer::start_tag('tr');
        echo html_writer::tag('th', 'Student');
        echo html_writer::tag('th', 'Username');
        echo html_writer::tag('th',
            html_writer::checkbox('select_all_quiz', 1, false, 'Can Attempt Quiz', ['id' => 'select_all_quiz']) .
            '<br><small class=\"text-muted\">Allows taking quizzes/tests</small>',
            ['class' => 'text-center']
        );
        echo html_writer::tag('th',
            html_writer::checkbox('select_all_results', 1, false, 'Can View Results', ['id' => 'select_all_results']) .
            '<br><small class=\"text-muted\">Allows accessing myresult.php</small>',
            ['class' => 'text-center']
        );
        echo html_writer::end_tag('tr');
        echo html_writer::end_tag('thead');
        echo html_writer::start_tag('tbody');
        foreach ($students as $student) {
            $permissions = get_student_permissions($student->id, $categoryid, $sessionid, $termid);
            $can_quiz = $permissions ? $permissions->can_attempt_quiz : 0;
            $can_results = $permissions ? $permissions->can_view_results : 0;
            echo html_writer::start_tag('tr');
            echo html_writer::tag('td', fullname($student) . '<br><small>' . $student->email . '</small>');
            echo html_writer::tag('td', $student->username);
            echo html_writer::tag('td',
                html_writer::checkbox('quiz_access[]', $student->id, $can_quiz, '',
                    ['class' => 'can_attempt_quiz-checkbox', 'onchange' => 'updatePermission(' . $student->id . ', "can_attempt_quiz", this.checked)']
                ),
                ['class' => 'text-center']
            );
            echo html_writer::tag('td',
                html_writer::checkbox('results_access[]', $student->id, $can_results, '',
                    ['class' => 'can_view_results-checkbox', 'onchange' => 'updatePermission(' . $student->id . ', "can_view_results", this.checked)']
                ),
                ['class' => 'text-center']
            );
            echo html_writer::end_tag('tr');
            echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'user_permissions[]', 'value' => $student->id]);
        }
        echo html_writer::end_tag('tbody');
        echo html_writer::end_tag('table');
        echo html_writer::end_div();
        echo html_writer::tag('button', 'Save All Changes', ['type' => 'submit', 'class' => 'btn btn-success btn-lg mt-3']);
        echo html_writer::end_tag('form');
    }
    echo html_writer::end_div();
    echo html_writer::end_div();
}
?>