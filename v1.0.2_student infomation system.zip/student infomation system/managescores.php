<?php 
// This file is part of the Student Information System plugin for Moodle.
// This file is used to manage students scores 
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

require_once(__DIR__ . '/../../config.php');
require_login();

$systemcontext = context_system::instance();
require_capability('moodle/site:config', $systemcontext);

global $DB, $PAGE, $OUTPUT;

// Page setup
$PAGE->set_url(new moodle_url('/local/sis/managescores.php'));
$PAGE->set_context($systemcontext);
$PAGE->set_title('Manage Student Scores');
$PAGE->set_heading('Manage Student Scores');
$PAGE->set_pagelayout('admin');

// Get parameters with validation
$categoryid = optional_param('categoryid', 0, PARAM_INT);
$sessionid  = optional_param('sessionid', 0, PARAM_INT);
$termid     = optional_param('termid', 0, PARAM_INT);
$userid     = optional_param('userid', 0, PARAM_INT);
$delete     = optional_param('delete', 0, PARAM_BOOL);
$confirm    = optional_param('confirm', 0, PARAM_BOOL);
$selected_subjects = optional_param_array('selected_subjects', [], PARAM_INT);

// Handle bulk deletion after confirmation
if ($delete && $confirm && confirm_sesskey()) {
    if ($userid && $termid && $sessionid && !empty($selected_subjects)) {
        try {
            list($insql, $inparams) = $DB->get_in_or_equal($selected_subjects, SQL_PARAMS_NAMED);
            $params = array_merge([
                'userid' => $userid,
                'termid' => $termid,
                'sessionid' => $sessionid
            ], $inparams);
            
            $DB->delete_records_select('local_sis_result', 
                "userid = :userid AND termid = :termid AND sessionid = :sessionid AND courseid $insql", 
                $params);
            
            \core\notification::success('Selected scores deleted successfully.');
        } catch (Exception $e) {
            \core\notification::error('Error deleting scores: ' . $e->getMessage());
        }
        redirect(new moodle_url('/local/sis/managescores.php'));
    }
}

// Start output
echo $OUTPUT->header();
echo html_writer::start_tag('form', ['method' => 'get', 'class' => 'managescores-form', 'id' => 'mainForm']);
echo html_writer::tag('h3', 'Manage Student Scores - Bulk Delete');

try {
    // STEP 1: Select class/category
    $categories = $DB->get_records_menu('course_categories', null, 'name', 'id,name');
    if (empty($categories)) {
        echo $OUTPUT->notification('No course categories found.', 'notifyproblem');
    } else {
        echo html_writer::label('Select Class/Category:', 'categoryid');
        echo html_writer::select($categories, 'categoryid', $categoryid, ['0' => 'Select Class'], ['onchange' => 'this.form.submit()']);
        echo html_writer::empty_tag('br');
    }

    if ($categoryid) {
        // STEP 2: Select session
        $sessions = $DB->get_records_menu('local_sis_sessions', null, 'id DESC', 'id, sessionname');
        if (empty($sessions)) {
            echo $OUTPUT->notification('No sessions found.', 'notifyproblem');
        } else {
            echo html_writer::label('Select Session:', 'sessionid');
            echo html_writer::select($sessions, 'sessionid', $sessionid, ['0' => 'Select Session'], ['onchange' => 'this.form.submit()']);
            echo html_writer::empty_tag('br');
        }
    }

    if ($sessionid) {
        // STEP 3: Select term
        $terms = $DB->get_records_menu('local_sis_terms', ['sessionid' => $sessionid], 'id', 'id, termname');
        if (empty($terms)) {
            echo $OUTPUT->notification('No terms found for this session.', 'notifyproblem');
        } else {
            echo html_writer::label('Select Term:', 'termid');
            echo html_writer::select($terms, 'termid', $termid, ['0' => 'Select Term'], ['onchange' => 'this.form.submit()']);
            echo html_writer::empty_tag('br');
        }
    }

    // Close the main form and start a new one for student selection and subject management
    echo html_writer::end_tag('form');

    // Only show student selection and subjects if we have all three initial selections
    if ($categoryid && $sessionid && $termid) {
        echo html_writer::start_tag('form', ['method' => 'get', 'class' => 'student-form']);
        
        // Use individual hidden inputs instead of input_hidden_params
        echo html_writer::empty_tag('input', [
            'type' => 'hidden',
            'name' => 'categoryid',
            'value' => $categoryid
        ]);
        echo html_writer::empty_tag('input', [
            'type' => 'hidden',
            'name' => 'sessionid',
            'value' => $sessionid
        ]);
        echo html_writer::empty_tag('input', [
            'type' => 'hidden',
            'name' => 'termid',
            'value' => $termid
        ]);
        
        // STEP 4: Select student
        $studentsql = "SELECT u.id, CONCAT(u.firstname, ' ', u.lastname) AS name
                       FROM {user_enrolments} ue
                       JOIN {enrol} e ON e.id = ue.enrolid
                       JOIN {course} c ON c.id = e.courseid
                       JOIN {user} u ON u.id = ue.userid
                       WHERE c.category = :catid
                       GROUP BY u.id, u.firstname, u.lastname
                       ORDER BY u.lastname, u.firstname";
        $students = $DB->get_records_sql_menu($studentsql, ['catid' => $categoryid]);
        
        if (empty($students)) {
            echo $OUTPUT->notification('No students found in this category.', 'notifyproblem');
        } else {
            echo html_writer::label('Select Student:', 'userid');
            echo html_writer::select($students, 'userid', $userid, ['0' => 'Select Student'], ['onchange' => 'this.form.submit()']);
            echo html_writer::empty_tag('br');
        }
        echo html_writer::end_tag('form');

        // Show subjects with scores and checkboxes when student is selected
        if ($userid) {
            $student = $DB->get_record('user', ['id' => $userid]);
            $session = $DB->get_record('local_sis_sessions', ['id' => $sessionid]);
            $term = $DB->get_record('local_sis_terms', ['id' => $termid]);
            
            // Get all courses in the category
            $courses = $DB->get_records('course', ['category' => $categoryid], 'fullname');
            
            if ($courses) {
                echo html_writer::start_tag('form', ['method' => 'post', 'class' => 'subjects-form']);
                
                // Add hidden fields for parameters
                echo html_writer::empty_tag('input', [
                    'type' => 'hidden',
                    'name' => 'categoryid',
                    'value' => $categoryid
                ]);
                echo html_writer::empty_tag('input', [
                    'type' => 'hidden',
                    'name' => 'sessionid',
                    'value' => $sessionid
                ]);
                echo html_writer::empty_tag('input', [
                    'type' => 'hidden',
                    'name' => 'termid',
                    'value' => $termid
                ]);
                echo html_writer::empty_tag('input', [
                    'type' => 'hidden',
                    'name' => 'userid',
                    'value' => $userid
                ]);
                
                // Display context information
                echo html_writer::start_tag('div', ['class' => 'alert alert-info']);
                echo html_writer::tag('h4', 'Student: ' . fullname($student));
                echo html_writer::tag('p', 'Session: ' . $session->sessionname . ' | Term: ' . $term->termname);
                echo html_writer::end_tag('div');
                
                echo html_writer::tag('h4', 'Select Subjects to Delete Scores');
                
                $table = new html_table();
                $table->head = [
                    'Select', 
                    'Subject', 
                    'First CA', 
                    'Second CA', 
                    'Exam', 
                    'Total'
                ];
                $table->attributes['class'] = 'generaltable boxaligncenter';
                
                foreach ($courses as $course) {
                    // Get scores for this course, term, and session
                    $score = $DB->get_record('local_sis_result', [
                        'userid' => $userid,
                        'courseid' => $course->id,
                        'termid' => $termid,
                        'sessionid' => $sessionid
                    ]);
                    
                    // Decode scores from data field
                    $firstca = $secondca = $exam = $total = 0;
                    $hasScores = false;
                    
                    if ($score) {
                        $hasScores = true;
                        $data = json_decode($score->data, true);
                        if (is_array($data)) {
                            $firstca = $data[0] ?? 0;
                            $secondca = $data[1] ?? 0;
                            $exam = $data[2] ?? 0;
                        }
                        $total = $score->total ?? ($firstca + $secondca + $exam);
                    }
                    
                    $checkbox = html_writer::checkbox(
                        'selected_subjects[]', 
                        $course->id, 
                        false, 
                        '', 
                        ['class' => 'subject-checkbox']
                    );
                    
                    $table->data[] = [
                        $checkbox,
                        $course->fullname,
                        $hasScores ? number_format($firstca, 2) : 'No scores',
                        $hasScores ? number_format($secondca, 2) : 'No scores',
                        $hasScores ? number_format($exam, 2) : 'No scores',
                        $hasScores ? number_format($total, 2) : 'No scores'
                    ];
                }
                
                echo html_writer::table($table);
                
                // Show delete button
                echo html_writer::start_tag('div', ['class' => 'delete-button-container mt-3']);
                
                if (!$delete) {
                    echo html_writer::empty_tag('input', [
                        'type' => 'hidden',
                        'name' => 'delete',
                        'value' => 1
                    ]);
                    echo html_writer::empty_tag('input', [
                        'type' => 'hidden',
                        'name' => 'sesskey',
                        'value' => sesskey()
                    ]);
                    echo html_writer::tag('button', 'Delete Selected Scores', [
                        'type' => 'submit',
                        'class' => 'btn btn-danger',
                        'onclick' => 'return confirm(\'Are you sure you want to delete selected scores?\')'
                    ]);
                } else {
                    // Show confirmation page
                    echo html_writer::start_tag('div', ['class' => 'alert alert-warning']);
                    echo html_writer::tag('h4', 'Confirm Bulk Deletion');
                    echo html_writer::tag('p', 'You are about to delete scores for the selected subjects. This action cannot be undone!');
                    
                    if (!empty($selected_subjects)) {
                        echo html_writer::tag('p', 'Selected subjects:');
                        echo html_writer::start_tag('ul');
                        foreach ($selected_subjects as $courseid) {
                            $course = $DB->get_record('course', ['id' => $courseid]);
                            if ($course) {
                                echo html_writer::tag('li', $course->fullname);
                            }
                        }
                        echo html_writer::end_tag('ul');
                    }
                    echo html_writer::end_tag('div');

                    echo html_writer::empty_tag('input', [
                        'type' => 'hidden',
                        'name' => 'delete',
                        'value' => 1
                    ]);
                    echo html_writer::empty_tag('input', [
                        'type' => 'hidden',
                        'name' => 'confirm',
                        'value' => 1
                    ]);
                    echo html_writer::empty_tag('input', [
                        'type' => 'hidden',
                        'name' => 'sesskey',
                        'value' => sesskey()
                    ]);
                    
                    // Add hidden fields for selected subjects
                    foreach ($selected_subjects as $subject) {
                        echo html_writer::empty_tag('input', [
                            'type' => 'hidden',
                            'name' => 'selected_subjects[]',
                            'value' => $subject
                        ]);
                    }
                    
                    echo html_writer::tag('button', 'Yes, Delete Selected Scores Permanently', [
                        'type' => 'submit',
                        'class' => 'btn btn-danger mr-2'
                    ]);
                    
                    $cancelurl = new moodle_url('/local/sis/managescores.php', [
                        'categoryid' => $categoryid,
                        'sessionid' => $sessionid,
                        'termid' => $termid,
                        'userid' => $userid
                    ]);
                    echo html_writer::link($cancelurl, 'Cancel - Go Back', ['class' => 'btn btn-secondary']);
                }
                
                echo html_writer::end_tag('div');
                echo html_writer::end_tag('form');
            } else {
                echo $OUTPUT->notification('No courses found in this category.', 'notifyinfo');
            }
        }
    }

} catch (Exception $e) {
    echo $OUTPUT->notification('Error loading data: ' . $e->getMessage(), 'notifyproblem');
    debugging('Error in managescores.php: ' . $e->getMessage(), DEBUG_DEVELOPER);
}

echo $OUTPUT->footer();