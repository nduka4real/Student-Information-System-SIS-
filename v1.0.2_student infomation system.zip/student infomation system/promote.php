<?php
// This file is part of the Student Information System plugin for Moodle.
// this file promotes students from one class to another
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version information for the Student Information System plugin
 *
 * @package    local_sis
 * @copyright  2025 NduksTech - https://facebook.com/ndukshub
 * @author     Nduka Akapti  (https://github.com/nduka4real)
 * @author     Ndukstech (https://www.youtube.com/@nduks-tech)
 * @author     https://www.linkedin.com/in/ndukaakpati/
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @details
 * Display Name: Student Information System
 * Description: A comprehensive system for managing student records, assessments, fees, and school operations.
 * Contact: https://github.com/nduka4real
 * Social: https://facebook.com/ndukshub
 */

// local/sis/promote.php
require_once(__DIR__ . '/../../config.php');
require_login();

$context = context_system::instance();
require_capability('moodle/site:config', $context); // Only admins should manage promotions

$PAGE->set_context($context);
$PAGE->set_url(new moodle_url('/local/sis/promote.php'));
$PAGE->set_title('Student Promotion Management');
$PAGE->set_heading('Student Promotion');
$PAGE->requires->css(new moodle_url('/local/sis/styles.css'));

// Get parameters
$action = optional_param('action', '', PARAM_TEXT);
$source_category = optional_param('source_category', 0, PARAM_INT);
$target_category = optional_param('target_category', 0, PARAM_INT);
$source_session = optional_param('source_session', 0, PARAM_INT);
$target_session = optional_param('target_session', 0, PARAM_INT);
$confirm = optional_param('confirm', 0, PARAM_INT);
$selected_students = optional_param_array('selected_students', [], PARAM_INT);

echo $OUTPUT->header();
echo $OUTPUT->heading('Student Promotion Management');

// Function to get sessions
function get_sessions() {
    global $DB;
    return $DB->get_records('local_sis_sessions', [], 'sessionname ASC');
}

// Function to get categories/classes
function get_categories() {
    global $DB;
    return $DB->get_records('course_categories', ['visible' => 1], 'name ASC');
}

// Function to get students in a category for a specific session
function get_students_in_category($categoryid, $sessionid) {
    global $DB;
    
    $sql = "SELECT DISTINCT u.id, u.firstname, u.lastname, u.username, u.email, u.idnumber
            FROM {user} u
            JOIN {local_sis_result} r ON r.userid = u.id
            JOIN {course} c ON c.id = r.courseid
            WHERE c.category = :categoryid
            AND r.sessionid = :sessionid
            ORDER BY u.lastname, u.firstname";
    
    return $DB->get_records_sql($sql, [
        'categoryid' => $categoryid,
        'sessionid' => $sessionid
    ]);
}

// Function to check if student already exists in target category/session
function student_exists_in_target($student_id, $target_category, $target_session) {
    global $DB;
    
    $sql = "SELECT COUNT(*) as count
            FROM {local_sis_result} r
            JOIN {course} c ON c.id = r.courseid
            WHERE r.userid = :userid
            AND c.category = :categoryid
            AND r.sessionid = :sessionid";
    
    $result = $DB->get_record_sql($sql, [
        'userid' => $student_id,
        'categoryid' => $target_category,
        'sessionid' => $target_session
    ]);
    
    return $result->count > 0;
}

// Function to promote students (only register them in new class, no results copied)
function promote_students($student_ids, $source_category, $target_category, $source_session, $target_session) {
    global $DB, $USER;
    
    $results = [
        'success' => 0,
        'errors' => 0,
        'already_exists' => 0,
        'details' => []
    ];
    
    // Get courses in target category
    $target_courses = $DB->get_records('course', ['category' => $target_category], 'id ASC');
    
    if (empty($target_courses)) {
        $results['errors']++;
        $results['details'][] = "No courses found in target category.";
        return $results;
    }
    
    // Get terms for target session
    $terms = $DB->get_records('local_sis_terms', ['sessionid' => $target_session], 'termname ASC');
    
    if (empty($terms)) {
        $results['errors']++;
        $results['details'][] = "No terms found in target session.";
        return $results;
    }
    
    foreach ($student_ids as $student_id) {
        try {
            // Check if student already exists in target
            if (student_exists_in_target($student_id, $target_category, $target_session)) {
                $results['already_exists']++;
                $results['details'][] = "Student ID $student_id already exists in target class/session";
                continue;
            }
            
            $student = $DB->get_record('user', ['id' => $student_id]);
            if (!$student) {
                $results['errors']++;
                $results['details'][] = "Student ID $student_id not found";
                continue;
            }
            
            // Register student in each course in target category for each term
            foreach ($target_courses as $course) {
                foreach ($terms as $term) {
                    // Check if record already exists
                    $existing = $DB->get_record('local_sis_result', [
                        'userid' => $student_id,
                        'courseid' => $course->id,
                        'sessionid' => $target_session,
                        'termid' => $term->id
                    ]);
                    
                    if (!$existing) {
                        // Create empty result record (registration)
                        $new_record = new stdClass();
                        $new_record->userid = $student_id;
                        $new_record->courseid = $course->id;
                        $new_record->sessionid = $target_session;
                        $new_record->termid = $term->id;
                        $new_record->data = null;
                        $new_record->total = 0;
                        $new_record->grade = null;
                        $new_record->points = 0;
                        $new_record->timecreated = time();
                        $new_record->timemodified = time();
                        
                        $DB->insert_record('local_sis_result', $new_record);
                    }
                }
            }
            
            $results['success']++;
            $results['details'][] = "Successfully promoted student: " . fullname($student) . " ($student->username)";
            
        } catch (Exception $e) {
            $results['errors']++;
            $results['details'][] = "Error promoting student ID: $student_id - " . $e->getMessage();
        }
    }
    
    // Log the promotion activity
    if ($results['success'] > 0) {
        log_promotion($source_category, $target_category, $source_session, $target_session, 
                     $results['success'], $USER->id, "Promoted {$results['success']} students");
    }
    
    return $results;
}

// Function to log promotion activity
function log_promotion($source_category, $target_category, $source_session, $target_session, $students_count, $user_id, $details = '') {
    global $DB;
    
    // Create promotions log table if it doesn't exist
    $dbman = $DB->get_manager();
    $table = new xmldb_table('local_sis_promotions_log');
    
    if (!$dbman->table_exists($table)) {
        // Create the table
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('source_category', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL);
        $table->add_field('target_category', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL);
        $table->add_field('source_session', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL);
        $table->add_field('target_session', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL);
        $table->add_field('students_promoted', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL);
        $table->add_field('promoted_by', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL);
        $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL);
        $table->add_field('details', XMLDB_TYPE_TEXT, null, null, null);
        
        $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
        $dbman->create_table($table);
    }
    
    $log = new stdClass();
    $log->source_category = $source_category;
    $log->target_category = $target_category;
    $log->source_session = $source_session;
    $log->target_session = $target_session;
    $log->students_promoted = $students_count;
    $log->promoted_by = $user_id;
    $log->timecreated = time();
    $log->details = $details;
    
    $DB->insert_record('local_sis_promotions_log', $log);
}

// Handle form submissions
if ($action === 'promote' && $confirm) {
    require_sesskey();
    
    if (empty($selected_students)) {
        echo $OUTPUT->notification('No students selected for promotion.', 'notifyproblem');
    } else {
        $promotion_results = promote_students($selected_students, $source_category, $target_category, $source_session, $target_session);
        
        echo '<div class="alert alert-info">';
        echo '<h4>Promotion Results</h4>';
        echo "<p><strong>Successfully promoted:</strong> {$promotion_results['success']} students</p>";
        echo "<p><strong>Already in target class:</strong> {$promotion_results['already_exists']} students</p>";
        echo "<p><strong>Errors:</strong> {$promotion_results['errors']}</p>";
        
        if (!empty($promotion_results['details'])) {
            echo '<details><summary>View Details</summary><ul class="mt-2">';
            foreach ($promotion_results['details'] as $detail) {
                echo "<li>$detail</li>";
            }
            echo '</ul></details>';
        }
        echo '</div>';
        
        // Show continue button
        echo '<div class="text-center mt-3">';
        echo '<a href="' . new moodle_url('/local/sis/promote.php') . '" class="btn btn-primary">Continue Promoting Students</a>';
        echo '</div>';
        
        echo $OUTPUT->footer();
        exit;
    }
}

// Main promotion form
$sessions = get_sessions();
$categories = get_categories();

echo '<div class="sis-form-container">';
echo '<div class="card sis-card">';
echo '<div class="card-body">';

echo '<h3 class="card-title">Student Promotion Tool</h3>';
echo '<p class="text-muted">Use this tool to promote students from one class to another. This will register students in the new class without copying previous results.</p>';

echo '<form method="get" action="' . new moodle_url('/local/sis/promote.php') . '" id="promotionForm">';
echo '<input type="hidden" name="action" value="select_students">';

// Source selection
echo '<div class="row mb-4">';
echo '<div class="col-md-6">';
echo '<h5>Current Class/Session <small class="text-muted">(Where students are now)</small></h5>';
echo '<div class="form-group">';
echo '<label for="source_session">Current Session:</label>';
echo '<select name="source_session" id="source_session" class="form-control" required>';
echo '<option value="">Select Session</option>';
foreach ($sessions as $session) {
    $selected = ($source_session == $session->id) ? 'selected' : '';
    echo "<option value='{$session->id}' $selected>{$session->sessionname}</option>";
}
echo '</select>';
echo '</div>';

echo '<div class="form-group">';
echo '<label for="source_category">Current Class:</label>';
echo '<select name="source_category" id="source_category" class="form-control" required>';
echo '<option value="">Select Class</option>';
foreach ($categories as $category) {
    $selected = ($source_category == $category->id) ? 'selected' : '';
    echo "<option value='{$category->id}' $selected>{$category->name}</option>";
}
echo '</select>';
echo '</div>';
echo '</div>';

// Target selection
echo '<div class="col-md-6">';
echo '<h5>Next Class/Session <small class="text-muted">(Where students will be promoted)</small></h5>';
echo '<div class="form-group">';
echo '<label for="target_session">Next Session:</label>';
echo '<select name="target_session" id="target_session" class="form-control" required>';
echo '<option value="">Select Session</option>';
foreach ($sessions as $session) {
    $selected = ($target_session == $session->id) ? 'selected' : '';
    echo "<option value='{$session->id}' $selected>{$session->sessionname}</option>";
}
echo '</select>';
echo '</div>';

echo '<div class="form-group">';
echo '<label for="target_category">Next Class:</label>';
echo '<select name="target_category" id="target_category" class="form-control" required>';
echo '<option value="">Select Class</option>';
foreach ($categories as $category) {
    $selected = ($target_category == $category->id) ? 'selected' : '';
    echo "<option value='{$category->id}' $selected>{$category->name}</option>";
}
echo '</select>';
echo '</div>';
echo '</div>';
echo '</div>';

echo '<div class="form-group text-center">';
echo '<button type="submit" class="btn btn-primary">Load Students for Promotion</button>';


// START MODIFICATION: Add Back to SIS Dashboard button here
    echo html_writer::div(
        html_writer::link(
            new moodle_url('/local/sis/index.php'),
            'Back to Main Dashboard',
            ['class' => 'btn btn-success mb-3'] // Using success for prominent primary navigation
        ),
        'text-center'
    );
    // END MODIFICATION

echo '</div>';
echo '</form>';

// Display students if source is selected
if ($action === 'select_students' && $source_category && $source_session && $target_category && $target_session) {
    $students = get_students_in_category($source_category, $source_session);
    $source_category_name = $categories[$source_category]->name;
    $target_category_name = $categories[$target_category]->name;
    $source_session_name = $sessions[$source_session]->sessionname;
    $target_session_name = $sessions[$target_session]->sessionname;
    
    // Get target courses to show what subjects students will be registered for
    $target_courses = $DB->get_records('course', ['category' => $target_category], 'fullname ASC');
    $target_terms = $DB->get_records('local_sis_terms', ['sessionid' => $target_session], 'termname ASC');
    
    if (empty($students)) {
        echo $OUTPUT->notification('No students found in the selected current class and session.', 'notifyproblem');
    } else {
        echo '<hr>';
        echo '<h4>Students Ready for Promotion</h4>';
        echo '<div class="alert alert-info">';
        echo '<strong>Promotion Path:</strong> ' . $source_category_name . ' (' . $source_session_name . ') → ' . $target_category_name . ' (' . $target_session_name . ')';
        echo '<br><strong>Action:</strong> Students will be registered in ' . count($target_courses) . ' subjects for ' . count($target_terms) . ' terms';
        echo '</div>';
        
        echo '<form method="post" action="' . new moodle_url('/local/sis/promote.php') . '">';
        echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'action', 'value' => 'promote']);
        echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'source_category', 'value' => $source_category]);
        echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'target_category', 'value' => $target_category]);
        echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'source_session', 'value' => $source_session]);
        echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'target_session', 'value' => $target_session]);
        echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey()]);
        
        echo '<div class="table-responsive">';
        echo '<table class="table table-striped table-bordered">';
        echo '<thead class="thead-dark">';
        echo '<tr>';
        echo '<th width="5%"><input type="checkbox" id="selectAll"></th>';
        echo '<th width="25%">Student Name</th>';
        echo '<th width="15%">Username</th>';
        echo '<th width="20%">Student ID</th>';
        echo '<th width="15%">Current Results</th>';
        echo '<th width="20%">Status in Target Class</th>';
        echo '</tr>';
        echo '</thead>';
        echo '<tbody>';
        
        foreach ($students as $student) {
            $results_count = count_student_results($student->id, $source_category, $source_session);
            $already_in_target = student_exists_in_target($student->id, $target_category, $target_session);
            $status_class = $already_in_target ? 'text-warning' : 'text-success';
            $status_text = $already_in_target ? 'Already Registered' : 'Ready for Promotion';
            
            echo '<tr>';
            echo '<td>';
            if (!$already_in_target) {
                echo '<input type="checkbox" name="selected_students[]" value="' . $student->id . '" class="student-checkbox" checked>';
            } else {
                echo '<span class="text-muted">✓</span>';
            }
            echo '</td>';
            echo '<td>' . fullname($student) . '</td>';
            echo '<td>' . $student->username . '</td>';
            echo '<td>' . ($student->idnumber ?: 'N/A') . '</td>';
            echo '<td>' . $results_count . ' subjects</td>';
            echo '<td class="' . $status_class . '">' . $status_text . '</td>';
            echo '</tr>';
        }
        
        echo '</tbody>';
        echo '</table>';
        echo '</div>';
        
        // Show target course information
        if (!empty($target_courses)) {
            echo '<div class="alert alert-secondary">';
            echo '<h6>Subjects in Target Class:</h6>';
            $course_names = [];
            foreach ($target_courses as $course) {
                $course_names[] = $course->fullname;
            }
            echo implode(', ', $course_names);
            echo '</div>';
        }
        
        echo '<div class="alert alert-warning">';
        echo '<strong>Important:</strong> This action will register selected students in the next class. ';
        echo 'Their previous results will remain in the current class and will NOT be carried over. ';
        echo 'Students will start with empty records in the new class.';
        echo '</div>';
        
        echo '<div class="form-group text-center">';
        echo '<button type="submit" name="confirm" value="1" class="btn btn-success btn-lg">Confirm Student Promotion</button>';
        echo ' <a href="' . new moodle_url('/local/sis/promote.php') . '" class="btn btn-secondary">Cancel</a>';
        echo '</div>';
        
        echo '</form>';
        
        // JavaScript for select all functionality
        echo '<script>
        document.getElementById("selectAll").addEventListener("change", function() {
            var checkboxes = document.getElementsByClassName("student-checkbox");
            for (var i = 0; i < checkboxes.length; i++) {
                if (!checkboxes[i].disabled) {
                    checkboxes[i].checked = this.checked;
                }
            }
        });
        </script>';
    }
}

echo '</div>'; // card-body
echo '</div>'; // card

// Display recent promotions
echo '<div class="card mt-4">';
echo '<div class="card-body">';
echo '<h4>Recent Promotions</h4>';
display_recent_promotions();
echo '</div>';
echo '</div>';

echo '</div>'; // sis-form-container

echo $OUTPUT->footer();

// Function to count student results
function count_student_results($student_id, $category_id, $session_id) {
    global $DB;
    
    $sql = "SELECT COUNT(*) 
            FROM {local_sis_result} r
            JOIN {course} c ON c.id = r.courseid
            WHERE r.userid = :userid
            AND c.category = :categoryid
            AND r.sessionid = :sessionid";
    
    return $DB->count_records_sql($sql, [
        'userid' => $student_id,
        'categoryid' => $category_id,
        'sessionid' => $session_id
    ]);
}

// Function to display recent promotions
function display_recent_promotions() {
    global $DB, $USER;
    
    $dbman = $DB->get_manager();
    $table = new xmldb_table('local_sis_promotions_log');
    
    if (!$dbman->table_exists($table)) {
        echo '<p class="text-muted">No promotion history available.</p>';
        return;
    }
    
    $promotions = $DB->get_records('local_sis_promotions_log', [], 'timecreated DESC', '*', 0, 10);
    
    if (empty($promotions)) {
        echo '<p class="text-muted">No recent promotions found.</p>';
        return;
    }
    
    // Get category and session names for display
    $categories = $DB->get_records('course_categories', null, '', 'id, name');
    $sessions = $DB->get_records('local_sis_sessions', null, '', 'id, sessionname');
    
    echo '<div class="table-responsive">';
    echo '<table class="table table-sm table-hover">';
    echo '<thead>';
    echo '<tr><th>Date</th><th>From</th><th>To</th><th>Students</th><th>By</th></tr>';
    echo '</thead>';
    echo '<tbody>';
    
    foreach ($promotions as $promotion) {
        $source_cat_name = isset($categories[$promotion->source_category]) ? $categories[$promotion->source_category]->name : 'N/A';
        $target_cat_name = isset($categories[$promotion->target_category]) ? $categories[$promotion->target_category]->name : 'N/A';
        $source_sess_name = isset($sessions[$promotion->source_session]) ? $sessions[$promotion->source_session]->sessionname : 'N/A';
        $target_sess_name = isset($sessions[$promotion->target_session]) ? $sessions[$promotion->target_session]->sessionname : 'N/A';
        $promoter = $DB->get_record('user', ['id' => $promotion->promoted_by]);
        $promoter_name = $promoter ? fullname($promoter) : 'System';
        
        echo '<tr>';
        echo '<td>' . userdate($promotion->timecreated, '%d %b %Y %H:%M') . '</td>';
        echo '<td>' . $source_cat_name . '<br><small class="text-muted">' . $source_sess_name . '</small></td>';
        echo '<td>' . $target_cat_name . '<br><small class="text-muted">' . $target_sess_name . '</small></td>';
        echo '<td>' . $promotion->students_promoted . '</td>';
        echo '<td>' . $promoter_name . '</td>';
        echo '</tr>';
    }
    
    echo '</tbody>';
    echo '</table>';
    echo '</div>';
}