<?php
// This file is part of the Student Information System plugin for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version information for the Student Information System plugin
 *
 * @package    local_sis
 * @copyright  2025 NduksTech - https://facebook.com/ndukshub
 * @author     Nduka Akapti  (https://github.com/nduka4real)
 * @author     Ndukstech (https://www.youtube.com/@nduks-tech)
 * @author     https://www.linkedin.com/in/ndukaakpati/
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @details
 * Display Name: Student Information System
 * Description: A comprehensive system for managing student records, assessments, fees, and school operations.
 * Contact: https://github.com/nduka4real
 * Social: https://facebook.com/ndukshub
 */

require_once(__DIR__.'/../../config.php');
require_login();

$categoryid = required_param('categoryid', PARAM_INT);

// Load broadsheet logic
require_once(__DIR__.'/broadsheetlib.php');

$table = sis_generate_broadsheet($categoryid);

if (!$table) {
    print_error('No results available for this category');
}

$filename = "broadsheet_category_{$categoryid}.xlsx";

// Use Moodle Excel writer
$workbook = new \core\excel\writer($filename, 'Excel2007');
$sheet = $workbook->add_worksheet('Broadsheet');

// Define styles
$headerformat = $workbook->add_format([
    'bold' => 1,
    'bg_color' => '#D9E1F2',
    'align' => 'center',
    'border' => 1
]);

$cellformat = $workbook->add_format(['border' => 1]);

$numberformat = $workbook->add_format([
    'border' => 1,
    'num_format' => '0.00'
]);

$summaryformat = $workbook->add_format([
    'bold' => 1,
    'bg_color' => '#E2EFDA',
    'border' => 1
]);

$distheader = $workbook->add_format([
    'bold' => 1,
    'bg_color' => '#FCE4D6',
    'align' => 'center',
    'border' => 1
]);

// Header row
$col = 0;
foreach ($table->head as $heading) {
    $sheet->write_string(0, $col, $heading, $headerformat);
    $col++;
}

// Data rows
$rownum = 1;
$numcols = count($table->head);
$numericCols = [1, 2, 3, 4]; // First CA, Second CA, Exam, Total

// Store column data + grade distribution
$colData = [];
$gradeDist = [];
foreach ($numericCols as $c) {
    $colData[$c] = [];
}

foreach ($table->data as $row) {
    $col = 0;
    foreach ($row as $cell) {
        if (is_numeric($cell) && in_array($col, $numericCols)) {
            $sheet->write_number($rownum, $col, $cell, $numberformat);
            $colData[$col][] = $cell;
        } else {
            $sheet->write_string($rownum, $col, (string)$cell, $cellformat);

            if ($col == 5) { // grade column
                $grade = trim((string)$cell);
                if ($grade !== '') {
                    $gradeDist[$grade] = ($gradeDist[$grade] ?? 0) + 1;
                }
            }
        }
        $col++;
    }
    $rownum++;
}

// --- Add summary rows --- //
$labels = ['Average', 'Maximum', 'Minimum'];
$statFuncs = [
    'Average' => fn($arr) => array_sum($arr) / count($arr),
    'Maximum' => fn($arr) => max($arr),
    'Minimum' => fn($arr) => min($arr)
];

foreach ($labels as $label) {
    $sheet->write_string($rownum, 0, $label, $summaryformat);

    foreach ($numericCols as $c) {
        if (!empty($colData[$c])) {
            $value = $statFuncs[$label]($colData[$c]);
            $sheet->write_number($rownum, $c, $value, $summaryformat);
        }
    }
    $rownum++;
}

// --- Add Grade Distribution --- //
$rownum += 2; // leave gap
$sheet->write_string($rownum, 0, 'Grade Distribution', $distheader);
$rownum++;

$sheet->write_string($rownum, 0, 'Grade', $distheader);
$sheet->write_string($rownum, 1, 'Count', $distheader);
$rownum++;

ksort($gradeDist);
foreach ($gradeDist as $grade => $count) {
    $sheet->write_string($rownum, 0, $grade, $cellformat);
    $sheet->write_number($rownum, 1, $count, $cellformat);
    $rownum++;
}

// Auto-fit columns
for ($c = 0; $c < $numcols; $c++) {
    $sheet->set_column($c, $c, 22); // width 22
}
$sheet->set_column(0, 1, 15);

// Close and send file
$workbook->close();
exit;
