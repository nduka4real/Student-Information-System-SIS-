<?php
// This file is part of the Student Information System plugin for Moodle.
// This file is intended to create terms and sessions with active/default settings
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version information for the Student Information System plugin
 *
 * @package    local_sis
 * @copyright  2025 NduksTech - https://facebook.com/ndukshub
 * @author     Nduka Akapti  (https://github.com/nduka4real)
 * @author     Ndukstech (https://www.youtube.com/@nduks-tech)
 * @author     https://www.linkedin.com/in/ndukaakpati/
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @details
 * Display Name: Student Information System
 * Description: A comprehensive system for managing student records, assessments, fees, and school operations.
 * Contact: https://github.com/nduka4real
 * Social: https://facebook.com/ndukshub
 */

// local/sis/session_terms.php

require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/adminlib.php');
require_once($CFG->libdir . '/formslib.php');

require_login();
require_capability('moodle/site:config', context_system::instance());

// Define the form class for creating sessions
class session_terms_form extends moodleform {
    protected function definition() {
        $mform = $this->_form;

        // Session name
        $mform->addElement('text', 'sessionname', 'Session Name');
        $mform->setType('sessionname', PARAM_TEXT);
        $mform->addRule('sessionname', 'Required', 'required', null, 'client');

        // Is active session
        $mform->addElement('checkbox', 'isactive', 'Set as active session');
        $mform->addHelpButton('isactive', 'isactive', 'local_sis');

        // Is default session
        $mform->addElement('checkbox', 'isdefault', 'Set as default session');
        $mform->addHelpButton('isdefault', 'isdefault', 'local_sis');

        // Submit button
        $this->add_action_buttons(true, 'Create Session with Terms');
    }
}

// Define the form class for setting active/defaults
class active_defaults_form extends moodleform {
    protected function definition() {
        global $DB;
        
        $mform = $this->_form;

        // Get sessions and terms for dropdowns
        $sessions = $DB->get_records('local_sis_sessions', null, 'sessionname ASC');
        $terms = $DB->get_records_sql("
            SELECT t.*, s.sessionname 
            FROM {local_sis_terms} t 
            JOIN {local_sis_sessions} s ON t.sessionid = s.id 
            ORDER BY s.sessionname, t.termname
        ");

        // Active session dropdown
        $sessionoptions = [0 => 'Select active session...'];
        $activesessionid = $DB->get_field('local_sis_sessions', 'id', ['isactive' => 1]);
        
        foreach ($sessions as $session) {
            $sessionoptions[$session->id] = $session->sessionname . ($session->isactive ? ' (Currently Active)' : '');
        }
        
        $mform->addElement('select', 'activesession', 'Active Session', $sessionoptions);
        $mform->setDefault('activesession', $activesessionid);
        $mform->addHelpButton('activesession', 'activesession', 'local_sis');

        // Default session dropdown
        $defaultsessionid = $DB->get_field('local_sis_sessions', 'id', ['isdefault' => 1]);
        
        $mform->addElement('select', 'defaultsession', 'Default Session', $sessionoptions);
        $mform->setDefault('defaultsession', $defaultsessionid);
        $mform->addHelpButton('defaultsession', 'defaultsession', 'local_sis');

        // Active term dropdown
        $termoptions = [0 => 'Select active term...'];
        $activetermid = $DB->get_field('local_sis_terms', 'id', ['isactive' => 1]);
        
        foreach ($terms as $term) {
            $termoptions[$term->id] = $term->sessionname . ' - ' . $term->termname . ($term->isactive ? ' (Currently Active)' : '');
        }
        
        $mform->addElement('select', 'activeterm', 'Active Term', $termoptions);
        $mform->setDefault('activeterm', $activetermid);
        $mform->addHelpButton('activeterm', 'activeterm', 'local_sis');

        // Default term dropdown
        $defaulttermid = $DB->get_field('local_sis_terms', 'id', ['isdefault' => 1]);
        
        $mform->addElement('select', 'defaultterm', 'Default Term', $termoptions);
        $mform->setDefault('defaultterm', $defaulttermid);
        $mform->addHelpButton('defaultterm', 'defaultterm', 'local_sis');

        // Submit button
        $this->add_action_buttons(true, 'Save Active & Default Settings');
    }
}

$context = context_system::instance();
$PAGE->set_context($context);
$PAGE->set_url(new moodle_url('/local/sis/session_terms.php'));
$PAGE->set_title(' Session & Term Settings');
$PAGE->set_heading('Session & Term Settings');

global $DB;

// Ensure required tables exist
$dbman = $DB->get_manager();

// Define table structure for local_sis_sessions
$table = new xmldb_table('local_sis_sessions');
if (!$dbman->table_exists($table)) {
    $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
    $table->add_field('sessionname', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, null);
    $table->add_field('isactive', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0');
    $table->add_field('isdefault', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0');
    $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
    $dbman->create_table($table);
} else {
    // Ensure isactive exists
    $field = new xmldb_field('isactive', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0');
    if (!$dbman->field_exists($table, $field)) {
        $dbman->add_field($table, $field);
        $DB->execute("UPDATE {local_sis_sessions} SET isactive = 0 WHERE isactive IS NULL");
    }
    
    // Ensure isdefault exists
    $field = new xmldb_field('isdefault', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0');
    if (!$dbman->field_exists($table, $field)) {
        $dbman->add_field($table, $field);
        $DB->execute("UPDATE {local_sis_sessions} SET isdefault = 0 WHERE isdefault IS NULL");
    }
}

// Define table structure for local_sis_terms
$table = new xmldb_table('local_sis_terms');
if (!$dbman->table_exists($table)) {
    $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
    $table->add_field('sessionid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    $table->add_field('termname', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, null);
    $table->add_field('isactive', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0');
    $table->add_field('isdefault', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0');
    $table->add_field('calculate_cumulative', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0');
    $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
    $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
    $dbman->create_table($table);
} else {
    // Ensure isactive exists
    $field = new xmldb_field('isactive', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0');
    if (!$dbman->field_exists($table, $field)) {
        $dbman->add_field($table, $field);
        $DB->execute("UPDATE {local_sis_terms} SET isactive = 0 WHERE isactive IS NULL");
    }
    
    // Ensure isdefault exists
    $field = new xmldb_field('isdefault', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0');
    if (!$dbman->field_exists($table, $field)) {
        $dbman->add_field($table, $field);
        $DB->execute("UPDATE {local_sis_terms} SET isdefault = 0 WHERE isdefault IS NULL");
    }

    // Ensure calculate_cumulative exists
    $field = new xmldb_field('calculate_cumulative', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0');
    if (!$dbman->field_exists($table, $field)) {
        $dbman->add_field($table, $field);
        $DB->execute("UPDATE {local_sis_terms} SET calculate_cumulative = 0 WHERE calculate_cumulative IS NULL");
    }
}

// Load forms
$session_form = new session_terms_form();
$defaults_form = new active_defaults_form();

// Process session creation form
if ($session_form->is_cancelled()) {
    redirect(new moodle_url('/local/sis/session_terms.php'));
} else if ($data = $session_form->get_data()) {
    // Reset active session if new active session set
    if (!empty($data->isactive)) {
        $DB->set_field('local_sis_sessions', 'isactive', 0);
    }
    
    // Reset default session if new default session set
    if (!empty($data->isdefault)) {
        $DB->set_field('local_sis_sessions', 'isdefault', 0);
    }

    // Insert Session
    $session = new stdClass();
    $session->sessionname = $data->sessionname;
    $session->isactive   = !empty($data->isactive) ? 1 : 0;
    $session->isdefault  = !empty($data->isdefault) ? 1 : 0;
    $session->timecreated = time();
    $session->timemodified= time();
    $sessionid = $DB->insert_record('local_sis_sessions', $session);

    // Insert ALL three terms automatically
    $terms = ['First Term', 'Second Term', 'Third Term'];
    foreach ($terms as $t) {
        $term = new stdClass();
        $term->sessionid  = $sessionid;
        $term->termname   = $t;
        $term->isactive   = 0; // Admin can mark later
        $term->isdefault  = 0; // Admin can mark later
        $term->calculate_cumulative = ($t === 'Third Term') ? 1 : 0;
        $term->timecreated = time();
        $term->timemodified= time();
        $DB->insert_record('local_sis_terms', $term);
    }

    redirect(new moodle_url('/local/sis/session_terms.php'), 'Session with 3 terms created successfully.');
}

// Process active/defaults form
if ($defaults_form->is_cancelled()) {
    redirect(new moodle_url('/local/sis/session_terms.php'));
} else if ($data = $defaults_form->get_data()) {
    // Update active session
    $DB->set_field('local_sis_sessions', 'isactive', 0);
    if (!empty($data->activesession)) {
        $DB->set_field('local_sis_sessions', 'isactive', 1, ['id' => $data->activesession]);
    }

    // Update default session
    $DB->set_field('local_sis_sessions', 'isdefault', 0);
    if (!empty($data->defaultsession)) {
        $DB->set_field('local_sis_sessions', 'isdefault', 1, ['id' => $data->defaultsession]);
    }

    // Update active term
    $DB->set_field('local_sis_terms', 'isactive', 0);
    if (!empty($data->activeterm)) {
        $DB->set_field('local_sis_terms', 'isactive', 1, ['id' => $data->activeterm]);
    }

    // Update default term
    $DB->set_field('local_sis_terms', 'isdefault', 0);
    if (!empty($data->defaultterm)) {
        $DB->set_field('local_sis_terms', 'isdefault', 1, ['id' => $data->defaultterm]);
    }

    redirect(new moodle_url('/local/sis/session_terms.php'), 'Active and default settings updated successfully.');
}

// Handle delete request
$deleteid = optional_param('deleteid', 0, PARAM_INT);
$deletetype = optional_param('type', '', PARAM_ALPHA);

if ($deleteid && $deletetype && confirm_sesskey()) {
    if ($deletetype === 'session') {
        // Delete from all tables
        $DB->delete_records('local_sis_terms', ['sessionid' => $deleteid]);
        $DB->delete_records('local_sis_sessions', ['id' => $deleteid]);
    } elseif ($deletetype === 'term') {
        // Delete from terms
        $DB->delete_records('local_sis_terms', ['id' => $deleteid]);
    }
    redirect(new moodle_url('/local/sis/session_terms.php'), 'Deleted successfully.');
}

// Toggle cumulative calculation for a term
$toggletermid = optional_param('togglecumulative', 0, PARAM_INT);
if ($toggletermid && confirm_sesskey()) {
    $term = $DB->get_record('local_sis_terms', ['id' => $toggletermid]);
    if ($term) {
        $newvalue = ($term->calculate_cumulative ?? 0) ? 0 : 1;
        $DB->set_field('local_sis_terms', 'calculate_cumulative', $newvalue, ['id' => $toggletermid]);
        redirect(new moodle_url('/local/sis/session_terms.php'), 'Cumulative setting updated.');
    }
}

// Quick add missing terms to an existing session
$quickadd = optional_param('quickadd', 0, PARAM_INT);
if ($quickadd) {
    $session = $DB->get_record('local_sis_sessions', ['id' => $quickadd], '*', MUST_EXIST);

    $terms = ['First Term', 'Second Term', 'Third Term'];
    foreach ($terms as $t) {
        if (!$DB->record_exists('local_sis_terms', ['sessionid' => $session->id, 'termname' => $t])) {
            $term = new stdClass();
            $term->sessionid = $session->id;
            $term->termname  = $t;
            $term->isactive  = 0;
            $term->isdefault = 0;
            $term->calculate_cumulative = ($t === 'Third Term') ? 1 : 0;
            $term->timecreated = time();
            $term->timemodified= time();
            $DB->insert_record('local_sis_terms', $term);
        }
    }
    redirect(new moodle_url('/local/sis/session_terms.php'), 'Missing terms added.');
}

// Output
echo $OUTPUT->header();

echo html_writer::start_tag('div', ['class' => 'd-flex justify-content-between align-items-center mb-3']);
echo html_writer::tag('h2', 'Manage Sessions & Terms');
echo html_writer::link(
    new moodle_url('/local/sis/index.php'),
    'Back to SIS Home',
    ['class' => 'btn btn-secondary']
);
echo html_writer::end_tag('div');

// Display current active/default status
echo html_writer::start_tag('div', ['class' => 'card mb-4']);
echo html_writer::start_tag('div', ['class' => 'card-header bg-primary text-white']);
echo html_writer::tag('h4', 'Current Active & Default Settings');
echo html_writer::end_tag('div');
echo html_writer::start_tag('div', ['class' => 'card-body']);

$activesession = $DB->get_record('local_sis_sessions', ['isactive' => 1]);
$defaultsession = $DB->get_record('local_sis_sessions', ['isdefault' => 1]);
$activeterm = $DB->get_record_sql("
    SELECT t.*, s.sessionname 
    FROM {local_sis_terms} t 
    JOIN {local_sis_sessions} s ON t.sessionid = s.id 
    WHERE t.isactive = 1
");
$defaultterm = $DB->get_record_sql("
    SELECT t.*, s.sessionname 
    FROM {local_sis_terms} t 
    JOIN {local_sis_sessions} s ON t.sessionid = s.id 
    WHERE t.isdefault = 1
");

echo html_writer::start_tag('div', ['class' => 'row']);
echo html_writer::start_tag('div', ['class' => 'col-md-6']);
echo html_writer::tag('p', html_writer::tag('strong', 'Active Session: ') . 
    ($activesession ? $activesession->sessionname : 'Not set'));
echo html_writer::tag('p', html_writer::tag('strong', 'Default Session: ') . 
    ($defaultsession ? $defaultsession->sessionname : 'Not set'));
echo html_writer::end_tag('div');
echo html_writer::start_tag('div', ['class' => 'col-md-6']);
echo html_writer::tag('p', html_writer::tag('strong', 'Active Term: ') . 
    ($activeterm ? $activeterm->sessionname . ' - ' . $activeterm->termname : 'Not set'));
echo html_writer::tag('p', html_writer::tag('strong', 'Default Term: ') . 
    ($defaultterm ? $defaultterm->sessionname . ' - ' . $defaultterm->termname : 'Not set'));
echo html_writer::end_tag('div');
echo html_writer::end_tag('div');
echo html_writer::end_tag('div');
echo html_writer::end_tag('div');

// Display active/default settings form
echo html_writer::start_tag('div', ['class' => 'card mb-4']);
echo html_writer::start_tag('div', ['class' => 'card-header bg-info text-white']);
echo html_writer::tag('h4', 'Set Active & Default Session/Term');
echo html_writer::end_tag('div');
echo html_writer::start_tag('div', ['class' => 'card-body']);
$defaults_form->display();
echo html_writer::end_tag('div');
echo html_writer::end_tag('div');

// Display session creation form
echo html_writer::start_tag('div', ['class' => 'card mb-4']);
echo html_writer::start_tag('div', ['class' => 'card-header bg-success text-white']);
echo html_writer::tag('h4', 'Create New Session');
echo html_writer::end_tag('div');
echo html_writer::start_tag('div', ['class' => 'card-body']);
$session_form->display();
echo html_writer::end_tag('div');
echo html_writer::end_tag('div');

// List sessions & terms
$sessions = $DB->get_records('local_sis_sessions', null, 'id ASC');

if ($sessions) {
    // Add hidden form for modal submission
    echo html_writer::start_tag('form', ['id' => 'delete-form', 'method' => 'get', 'action' => 'session_terms.php']);
    echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'deleteid', 'id' => 'delete-id-input']);
    echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'type', 'id' => 'delete-type-input']);
    echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey()]);
    echo html_writer::end_tag('form');

    echo html_writer::start_tag('div', ['class' => 'card']);
    echo html_writer::start_tag('div', ['class' => 'card-header bg-secondary text-white']);
    echo html_writer::tag('h4', 'All Sessions & Terms');
    echo html_writer::end_tag('div');
    echo html_writer::start_tag('div', ['class' => 'card-body']);
    
    echo html_writer::start_tag('table', ['class' => 'table table-bordered table-striped']);
    echo html_writer::start_tag('thead');
    echo html_writer::start_tag('tr');
    echo html_writer::tag('th', 'Session');
    echo html_writer::tag('th', 'Status');
    echo html_writer::tag('th', 'Term');
    echo html_writer::tag('th', 'Term Status');
    echo html_writer::tag('th', 'Cumulative');
    echo html_writer::tag('th', 'Actions');
    echo html_writer::end_tag('tr');
    echo html_writer::end_tag('thead');
    echo html_writer::start_tag('tbody');

    foreach ($sessions as $session) {
        $terms = $DB->get_records('local_sis_terms', ['sessionid' => $session->id], 'id ASC');
        $sessionrowspan = count($terms);
        $firstterm = true;
        
        foreach ($terms as $term) {
            echo html_writer::start_tag('tr');

            if ($firstterm) {
                echo html_writer::start_tag('td', ['rowspan' => $sessionrowspan]);
                echo s($session->sessionname);
                if ($session->isactive) {
                    echo html_writer::tag('span', ' Active', ['class' => 'badge badge-success ml-1']);
                }
                if ($session->isdefault) {
                    echo html_writer::tag('span', ' Default', ['class' => 'badge badge-primary ml-1']);
                }
                echo html_writer::end_tag('td');
                
                echo html_writer::start_tag('td', ['rowspan' => $sessionrowspan]);
                $actions = html_writer::link(
                    '#',
                    'Delete Session',
                    [
                        'class' => 'btn btn-sm btn-warning delete-link',
                        'data-id' => $session->id,
                        'data-type' => 'session',
                        'data-name' => s($session->sessionname)
                    ]
                );
                echo $actions;
                echo html_writer::end_tag('td');
                
                $firstterm = false;
            }

            echo html_writer::start_tag('td');
            echo s($term->termname);
            echo html_writer::end_tag('td');

            echo html_writer::start_tag('td');
            if ($term->isactive) {
                echo html_writer::tag('span', 'Active', ['class' => 'badge badge-success']);
            }
            if ($term->isdefault) {
                echo html_writer::tag('span', 'Default', ['class' => 'badge badge-primary ml-1']);
            }
            echo html_writer::end_tag('td');

            // Cumulative setting with toggle link
            echo html_writer::start_tag('td');
            echo ($term->calculate_cumulative ?? 0) ? 'Yes' : 'No';
            echo ' ';
            echo html_writer::link(
                new moodle_url('/local/sis/session_terms.php', [
                    'togglecumulative' => $term->id, 
                    'sesskey' => sesskey()
                ]),
                ($term->calculate_cumulative ?? 0) ? '(Set Termly)' : '(Set Cumulative)',
                ['class' => 'small']
            );
            echo html_writer::end_tag('td');

            // Actions
            echo html_writer::start_tag('td');
            echo html_writer::link(
                '#',
                'Delete Term',
                [
                    'class' => 'btn btn-sm btn-danger delete-link',
                    'data-id' => $term->id,
                    'data-type' => 'term',
                    'data-name' => s($term->termname)
                ]
            );
            echo html_writer::end_tag('td');

            echo html_writer::end_tag('tr');
        }
    }

    echo html_writer::end_tag('tbody');
    echo html_writer::end_tag('table');
    echo html_writer::end_tag('div');
    echo html_writer::end_tag('div');
    
    // Quick add terms button for each session
    echo html_writer::start_tag('div', ['class' => 'mt-3']);
    echo html_writer::tag('h5', 'Add Missing Terms to Sessions:');
    foreach ($sessions as $session) {
        echo html_writer::link(
            new moodle_url('/local/sis/session_terms.php', ['quickadd' => $session->id, 'sesskey' => sesskey()]),
            'Add Terms to ' . s($session->sessionname),
            ['class' => 'btn btn-sm btn-info mr-2 mb-2']
        );
    }
    echo html_writer::end_tag('div');
} else {
    echo html_writer::div('No sessions or terms found.', 'alert alert-info mt-3');
}

// Delete Confirmation Modal
echo html_writer::start_tag('div', ['id' => 'delete-modal', 'class' => 'modal', 'style' => 'display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0,0,0,0.4); justify-content: center; align-items: center;']);
echo html_writer::start_tag('div', ['class' => 'modal-content bg-white p-4 rounded-lg shadow-lg w-1/3']);
echo html_writer::tag('h3', 'Confirm Deletion', ['class' => 'text-xl font-bold mb-4']);
echo html_writer::tag('p', '', ['id' => 'modal-message', 'class' => 'mb-4']);
echo html_writer::start_tag('div', ['class' => 'd-flex justify-content-end']);
echo html_writer::tag('button', 'Cancel', ['id' => 'cancel-button', 'class' => 'btn btn-secondary mr-2']);
echo html_writer::tag('button', 'Delete', ['id' => 'confirm-button', 'class' => 'btn btn-danger']);
echo html_writer::end_tag('div');
echo html_writer::end_tag('div');
echo html_writer::end_tag('div');

echo $OUTPUT->footer();
?>
<script>
    document.addEventListener('DOMContentLoaded', () => {
        const modal = document.getElementById('delete-modal');
        const modalMessage = document.getElementById('modal-message');
        const confirmButton = document.getElementById('confirm-button');
        const cancelButton = document.getElementById('cancel-button');
        const deleteForm = document.getElementById('delete-form');
        const deleteIdInput = document.getElementById('delete-id-input');
        const deleteTypeInput = document.getElementById('delete-type-input');

        document.querySelectorAll('.delete-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const id = link.getAttribute('data-id');
                const type = link.getAttribute('data-type');
                const name = link.getAttribute('data-name');
                modalMessage.textContent = `Are you sure you want to delete the ${type} "${name}"? This action cannot be undone.`;
                deleteIdInput.value = id;
                deleteTypeInput.value = type;
                modal.style.display = 'flex';
            });
        });

        cancelButton.addEventListener('click', () => {
            modal.style.display = 'none';
        });
        
        confirmButton.addEventListener('click', () => {
            deleteForm.submit();
        });
    });
</script>