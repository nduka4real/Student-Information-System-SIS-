<?php
// This file is part of the Student Information System plugin for Moodle.
// this file is used to call paystack processor
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version information for the Student Information System plugin
 *
 * @package    local_sis
 * @copyright  2025 NduksTech - https://facebook.com/ndukshub
 * @author     Nduka Akapti  (https://github.com/nduka4real)
 * @author     Ndukstech (https://www.youtube.com/@nduks-tech)
 * @author     https://www.linkedin.com/in/ndukaakpati/
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @details
 * Display Name: Student Information System
 * Description: A comprehensive system for managing student records, assessments, fees, and school operations.
 * Contact: https://github.com/nduka4real
 * Social: https://facebook.com/ndukshub
 */

require_once(__DIR__ . '/../../../config.php');
require_once($CFG->dirroot . '/local/sis/classes/payment_manager.php');

require_login();
global $USER, $DB, $PAGE, $OUTPUT;

$reference = required_param('reference', PARAM_TEXT);
$payment = local_sis_payment_manager::get_payment_by_reference($reference);

if (!$payment || $payment->userid != $USER->id) {
    throw new moodle_exception('invalidpayment', 'local_sis');
}

$PAGE->set_url(new moodle_url('/local/sis/pay/payment_paystack.php', ['reference' => $reference]));
$PAGE->set_context(context_system::instance());
$PAGE->set_pagelayout('standard');
$PAGE->set_title("Paystack Payment");
$PAGE->set_heading("Complete Payment");

echo $OUTPUT->header();

/* --- Fetch Paystack Keys & Currency --- */
$public_key = $DB->get_field('local_sis_payment_config', 'config_value', ['gateway'=>'paystack','config_key'=>'public_key']);
$currency   = $DB->get_field('local_sis_payment_config', 'config_value', ['gateway'=>'paystack','config_key'=>'currency'], IGNORE_MISSING) ?? 'NGN';

/* --- Fetch Additional Payment Email (optional) --- */
$extra_email = $DB->get_field('local_sis_payment_config', 'config_value', ['gateway'=>'paystack','config_key'=>'payment_email2'], IGNORE_MISSING);

/* --- Get School Logo --- */
$schoollogo = $DB->get_field('local_sis_school_settings', 'schoollogo', ['id'=>1], IGNORE_MISSING);

/* If no custom logo, fallback to Moodle theme logo */
if (empty($schoollogo)) {
    $schoollogo = $CFG->wwwroot . "/theme/image.php?theme={$CFG->theme}&component=core&image=logo";
}
// If stored as relative path, convert to full URL
if (substr($schoollogo,0,4) !== "http") {
    $schoollogo = $CFG->wwwroot . '/' . ltrim($schoollogo,'/');
}

if (empty($public_key)) {
    echo $OUTPUT->notification('Paystack public key not configured. Contact admin.', 'error');
    echo $OUTPUT->footer();
    exit;
}

/* --- Verification Redirect URL --- */
$verifyurl = new moodle_url('/local/sis/pay/payment_verify.php', [
    'gateway' => 'paystack',
    'reference' => $payment->reference
]);

// Get currency symbol
function get_paystack_currency_symbol($currency) {
    $symbols = [
        'NGN' => '&#8358;',
        'USD' => '$',
        'EUR' => '�',
        'GBP' => '�'
    ];
    return $symbols[$currency] ?? $currency;
}
?>

<div class="container mt-4 text-center">
    <h4>Amount: <b><?php echo get_paystack_currency_symbol($currency) . ' ' . number_format($payment->amount, 2); ?></b></h4>
    <p>Reference: <b><?php echo $payment->reference; ?></b></p>
    <p class="text-muted">You will be redirected to Paystack to complete your payment securely.</p>

    <?php if ($extra_email) { ?>
        <p><small>Notification Email: <?php echo $extra_email; ?></small></p>
    <?php } ?>

    <button id="paystackPay" class="btn btn-success btn-lg">
        <i class="fa fa-credit-card"></i> Pay Now with Paystack
    </button>
    
    <div class="mt-3">
        <a href="<?php echo new moodle_url('/local/sis/pay/make_payment.php'); ?>" 
           class="btn btn-secondary">
            Cancel Payment
        </a>
    </div>
    
    <div id="paymentResponse" class="mt-3"></div>
</div>

<script src="https://js.paystack.co/v1/inline.js"></script>
<script>
document.getElementById("paystackPay").onclick = function() {
    const payBtn = this;
    const messageDiv = document.getElementById("paymentResponse");
    payBtn.disabled = true;
    payBtn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Processing...';
    messageDiv.innerHTML = '';

    var handler = PaystackPop.setup({
        key: '<?php echo $public_key; ?>',
        email: '<?php echo clean_param($USER->email, PARAM_EMAIL); ?>',
        amount: <?php echo intval($payment->amount * 100); ?>, // Paystack expects kobo/cents
        currency: '<?php echo $currency; ?>',
        ref: '<?php echo $payment->reference; ?>',
        metadata: {
            custom_fields: [
                {
                    display_name: "Student Name",
                    variable_name: "student_name",
                    value: "<?php echo addslashes(fullname($USER)); ?>"
                },
                {
                    display_name: "Student Email",
                    variable_name: "student_email", 
                    value: "<?php echo clean_param($USER->email, PARAM_EMAIL); ?>"
                },
                {
                    display_name: "Additional Email",
                    variable_name: "school_email2",
                    value: "<?php echo $extra_email ?: ''; ?>"
                }
            ]
        },
        callback: function(response) {
            // Redirect to verification page with transaction reference
            window.location.href = '<?php echo $verifyurl->out(false); ?>' + '&transaction_id=' + response.reference;
        },
        onClose: function() {
            payBtn.disabled = false;
            payBtn.innerHTML = '<i class="fa fa-credit-card"></i> Pay Now with Paystack';
            messageDiv.innerHTML = 
                '<div class="alert alert-warning">Payment window was closed. If you have completed the payment, wait for confirmation.</div>';
        }
    });
    handler.openIframe();
};
</script>

<?php echo $OUTPUT->footer();