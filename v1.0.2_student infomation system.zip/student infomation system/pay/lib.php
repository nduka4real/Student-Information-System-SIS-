<?php
// This file is part of the Student Information System plugin for Moodle.
// this file is the library file of payment
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version information for the Student Information System plugin
 *
 * @package    local_sis
 * @copyright  2025 NduksTech - https://facebook.com/ndukshub
 * @author     Nduka Akapti  (https://github.com/nduka4real)
 * @author     Ndukstech (https://www.youtube.com/@nduks-tech)
 * @author     https://www.linkedin.com/in/ndukaakpati/
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @details
 * Display Name: Student Information System
 * Description: A comprehensive system for managing student records, assessments, fees, and school operations.
 * Contact: https://github.com/nduka4real
 * Social: https://facebook.com/ndukshub
 */

// local/sis/pay/lib.php

defined('MOODLE_INTERNAL') || die();

class local_sis_payment_manager {
    
    public static function get_available_gateways() {
        global $DB;
        
        $gateways = ['flutterwave', 'paystack', 'paypal'];
        $available = [];
        
        foreach ($gateways as $gateway) {
            $enabled = $DB->get_record('local_sis_payment_config', [
                'gateway' => $gateway,
                'config_key' => 'enabled'
            ]);
            
            if ($enabled && !empty($enabled->config_value)) {
                $available[] = $gateway;
            }
        }
        
        return $available;
    }

    public static function get_payment_by_id($paymentid) {
        global $DB;
        return $DB->get_record('local_sis_payments', ['id' => $paymentid]);
    }

    public static function create_payment($userid, $amount, $currency, $gateway, $courseid = null, $metadata = []) {
        global $DB, $USER;
        
        $payment = new stdClass();
        $payment->userid = $userid;
        $payment->courseid = $courseid;
        $payment->amount = $amount;
        $payment->currency = $currency;
        $payment->gateway = $gateway;
        $payment->reference = self::generate_reference();
        $payment->status = 'pending';
        $payment->created_at = time();
        $payment->updated_at = time();
        $payment->metadata = !empty($metadata) ? json_encode($metadata) : null;
        
        try {
            $paymentid = $DB->insert_record('local_sis_payments', $payment);
            return $paymentid;
        } catch (Exception $e) {
            error_log("Payment creation failed: " . $e->getMessage());
            return false;
        }
    }
    
    public static function generate_reference() {
        return 'SIS_' . time() . '_' . rand(1000, 9999);
    }
    
    public static function get_payment_by_reference($reference) {
        global $DB;
        return $DB->get_record('local_sis_payments', ['reference' => $reference]);
    }
    
    public static function update_payment_status($reference, $status, $transaction_id = null, $payment_data = null) {
        global $DB;
        
        $payment = self::get_payment_by_reference($reference);
        if ($payment) {
            $payment->status = $status;
            $payment->updated_at = time();
            
            if ($transaction_id) {
                $payment->transaction_id = $transaction_id;
            }
            
            if ($payment_data) {
                $payment->payment_data = json_encode($payment_data);
            }
            
            $DB->update_record('local_sis_payments', $payment);
            
            // Trigger payment completion events
            if ($status === 'completed') {
                self::handle_successful_payment($payment);
            }
            
            return true;
        }
        
        return false;
    }
    
    public static function handle_successful_payment($payment) {
        // Handle post-payment actions (enroll in course, etc.)
        if ($payment->courseid) {
            self::enroll_user_in_course($payment->userid, $payment->courseid);
        }
        
        // Send confirmation email
        self::send_payment_confirmation($payment);
        
        // Trigger Moodle event
        self::trigger_payment_completed_event($payment);
    }
    
    public static function enroll_user_in_course($userid, $courseid) {
        global $DB, $CFG;
        
        // Check if enrollment function exists in main lib
        $main_lib_path = __DIR__ . '/../lib.php';
        if (file_exists($main_lib_path)) {
            require_once($main_lib_path);
            if (function_exists('enroll_student_in_course')) {
                return enroll_student_in_course($userid, $courseid);
            }
        }
        
        // Fallback to manual enrollment
        require_once($CFG->dirroot . '/enrol/manual/lib.php');
        
        $enrol = enrol_get_plugin('manual');
        if ($enrol) {
            $instance = $DB->get_record('enrol', [
                'courseid' => $courseid, 
                'enrol' => 'manual'
            ], '*', IGNORE_MULTIPLE);
            
            if ($instance) {
                $enrol->enrol_user($instance, $userid, 5); // 5 = student role
                return true;
            }
        }
        
        return false;
    }
    
    public static function send_payment_confirmation($payment) {
        global $DB, $CFG;
        
        $user = $DB->get_record('user', ['id' => $payment->userid]);
        if (!$user) {
            return false;
        }
        
        $course = $payment->courseid ? $DB->get_record('course', ['id' => $payment->courseid]) : null;
        
        $subject = get_string('paymentconfirmationsubject', 'local_sis');
        $message = get_string('paymentconfirmationmessage', 'local_sis', [
            'amount' => $payment->amount,
            'currency' => $payment->currency,
            'reference' => $payment->reference,
            'coursename' => $course ? format_string($course->fullname) : get_string('generalfee', 'local_sis')
        ]);
        
        return email_to_user($user, core_user::get_noreply_user(), $subject, $message);
    }
    
    public static function trigger_payment_completed_event($payment) {
        $event = \local_sis\event\payment_completed::create([
            'objectid' => $payment->id,
            'context' => context_system::instance(),
            'other' => [
                'amount' => $payment->amount,
                'currency' => $payment->currency,
                'gateway' => $payment->gateway
            ]
        ]);
        $event->trigger();
    }
    
    public static function get_gateway_config($gateway) {
        global $DB;
        
        $config = [];
        $records = $DB->get_records('local_sis_payment_config', ['gateway' => $gateway]);
        
        foreach ($records as $record) {
            $config[$record->config_key] = $record->config_value;
        }
        
        return $config;
    }
    
    public static function is_gateway_enabled($gateway) {
        $config = self::get_gateway_config($gateway);
        return !empty($config['enabled']);
    }
    
    public static function get_payment_categories() {
        global $DB;
        return $DB->get_records('local_sis_payment_categories', [], 'name ASC');
    }
    
    public static function get_payment_category($id) {
        global $DB;
        return $DB->get_record('local_sis_payment_categories', ['id' => $id]);
    }
}