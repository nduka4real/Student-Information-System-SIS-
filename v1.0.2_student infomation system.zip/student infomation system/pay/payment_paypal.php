<?php
// This file is part of the Student Information System plugin for Moodle.
// this file is used to manage payment via paypal
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version information for the Student Information System plugin
 *
 * @package    local_sis
 * @copyright  2025 NduksTech - https://facebook.com/ndukshub
 * @author     Nduka Akapti  (https://github.com/nduka4real)
 * @author     Ndukstech (https://www.youtube.com/@nduks-tech)
 * @author     https://www.linkedin.com/in/ndukaakpati/
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @details
 * Display Name: Student Information System
 * Description: A comprehensive system for managing student records, assessments, fees, and school operations.
 * Contact: https://github.com/nduka4real
 * Social: https://facebook.com/ndukshub
 */

require_once('../../config.php');
require_once(__DIR__ . '/classes/payment_manager.php');

require_login();

$reference = required_param('reference', PARAM_TEXT);
$payment = local_sis_pay_payment_manager::get_payment_by_reference($reference);

if (!$payment || $payment->userid != $USER->id) {
    throw new moodle_exception('invalidpayment', 'local_sis');
}

$PAGE->set_url(new moodle_url('/local/sis/pay/payment_paypal.php', ['reference' => $reference]));
$PAGE->set_context(context_system::instance());
$PAGE->set_title(get_string('paymentprocessing', 'local_sis'));

echo $OUTPUT->header();

$client_id = get_payment_config('paypal', 'client_id');
$currency = get_payment_config('paypal', 'currency') ?: 'USD';
$test_mode = get_payment_config('paypal', 'test_mode');

?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0"><?php echo get_string('paymentviapaypal', 'local_sis'); ?></h4>
                </div>
                <div class="card-body text-center">
                    <p><?php echo get_string('paymentamount', 'local_sis') . ': ' . $payment->amount . ' ' . $currency; ?></p>
                    <p><?php echo get_string('paymentreference', 'local_sis') . ': ' . $payment->reference; ?></p>
                    
                    <div id="paypal-button-container"></div>
                    <div id="paymentResponse" class="mt-3"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://www.paypal.com/sdk/js?client-id=<?php echo $client_id; ?>&currency=<?php echo $currency; ?>"></script>
<script>
paypal.Buttons({
    createOrder: function(data, actions) {
        return actions.order.create({
            purchase_units: [{
                amount: {
                    value: '<?php echo $payment->amount; ?>'
                },
                description: 'Course Enrollment Payment',
                custom_id: '<?php echo $payment->reference; ?>'
            }]
        });
    },
    onApprove: function(data, actions) {
        return actions.order.capture().then(function(details) {
            // Redirect to verification page
            window.location.href = '<?php echo new moodle_url('/local/sis/pay/payment_verify.php', ['gateway' => 'paypal', 'reference' => $payment->reference, 'transaction_id' => '']); ?>' + details.id;
        });
    },
    onError: function(err) {
        document.getElementById('paymentResponse').innerHTML = 
            '<div class="alert alert-danger">Payment failed: ' + err + '</div>';
    },
    onCancel: function(data) {
        document.getElementById('paymentResponse').innerHTML = 
            '<div class="alert alert-warning">Payment cancelled.</div>';
    }
}).render('#paypal-button-container');
</script>

<?php
echo $OUTPUT->footer();