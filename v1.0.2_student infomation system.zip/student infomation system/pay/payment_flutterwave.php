<?php
// This file is part of the Student Information System plugin for Moodle.
// this file is used to call flutterwave processors
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version information for the Student Information System plugin
 *
 * @package    local_sis
 * @copyright  2025 NduksTech - https://facebook.com/ndukshub
 * @author     Nduka Akapti  (https://github.com/nduka4real)
 * @author     Ndukstech (https://www.youtube.com/@nduks-tech)
 * @author     https://www.linkedin.com/in/ndukaakpati/
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @details
 * Display Name: Student Information System
 * Description: A comprehensive system for managing student records, assessments, fees, and school operations.
 * Contact: https://github.com/nduka4real
 * Social: https://facebook.com/ndukshub
 */require_once(__DIR__ . '/../../../config.php');
require_once($CFG->dirroot . '/local/sis/classes/payment_manager.php');

require_login();
global $USER, $DB, $PAGE, $OUTPUT;

$reference = required_param('reference', PARAM_TEXT);
$payment = local_sis_payment_manager::get_payment_by_reference($reference);

if (!$payment || $payment->userid != $USER->id) {
    throw new moodle_exception('invalidpayment', 'local_sis');
}

$PAGE->set_url(new moodle_url('/local/sis/pay/payment_flutterwave.php', ['reference' => $reference]));
$PAGE->set_context(context_system::instance());
$PAGE->set_pagelayout('standard');
$PAGE->set_title("Flutterwave Payment");
$PAGE->set_heading("Complete Payment");

echo $OUTPUT->header();

/* --- Fetch Flutterwave Keys & Currency --- */
$public_key = $DB->get_field('local_sis_payment_config', 'config_value', ['gateway'=>'flutterwave','config_key'=>'public_key']);
$currency   = $DB->get_field('local_sis_payment_config', 'config_value', ['gateway'=>'flutterwave','config_key'=>'currency'], IGNORE_MISSING) ?? 'NGN';

/* --- Fetch Additional Payment Email (optional) --- */
$extra_email = $DB->get_field('local_sis_payment_config', 'config_value', ['gateway'=>'flutterwave','config_key'=>'payment_email2'], IGNORE_MISSING);

/* --- Get School Logo --- */
$schoollogo = $DB->get_field('local_sis_school_settings', 'schoollogo', ['id'=>1], IGNORE_MISSING);

/* If no custom logo, fallback to Moodle theme logo */
if (empty($schoollogo)) {
    $schoollogo = $CFG->wwwroot . "/theme/image.php?theme={$CFG->theme}&component=core&image=logo";
}
// If stored as relative path, convert to full URL
if (substr($schoollogo,0,4) !== "http") {
    $schoollogo = $CFG->wwwroot . '/' . ltrim($schoollogo,'/');
}

if (empty($public_key)) {
    echo $OUTPUT->notification('Flutterwave public key not configured. Contact admin.', 'error');
    echo $OUTPUT->footer();
    exit;
}

/* --- Verification Redirect URL --- */
$verifyurl = new moodle_url('/local/sis/pay/payment_verify.php', [
    'gateway' => 'flutterwave',
    'reference' => $payment->reference
]);
?>

<div class="container mt-4 text-center">
    <h4>Amount: <b><?php echo $payment->amount . ' ' . $currency; ?></b></h4>
    <p>Reference: <b><?php echo $payment->reference; ?></b></p>

    <?php if ($extra_email) { ?>
        <p><small>Notification Email: <?php echo $extra_email; ?></small></p>
    <?php } ?>

    <button id="payBtn" class="btn btn-success btn-lg">
        <i class="fa fa-credit-card"></i> Pay Now
    </button>
    
    <div class="mt-3">
        <a href="<?php echo new moodle_url('/local/sis/pay/make_payment.php'); ?>" 
           class="btn btn-secondary">
            Cancel Payment
        </a>
    </div>
    
    <div id="msg" class="mt-3"></div>
</div>

<script src="https://checkout.flutterwave.com/v3.js"></script>
<script>
document.getElementById("payBtn").onclick = function() {
    const payBtn = this;
    const messageDiv = document.getElementById("msg");
    payBtn.disabled = true;
    payBtn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Processing...';
    messageDiv.innerHTML = '';

    FlutterwaveCheckout({
        public_key: "<?php echo $public_key; ?>",
        tx_ref: "<?php echo $payment->reference; ?>",
        amount: <?php echo $payment->amount; ?>,
        currency: "<?php echo $currency; ?>",
        payment_options: "card, banktransfer, ussd, mobilemoney",
        redirect_url: "<?php echo $verifyurl->out(false); ?>",
        customer: {
            email: "<?php echo clean_param($USER->email, PARAM_EMAIL); ?>",
            name: "<?php echo addslashes(fullname($USER)); ?>"
        },
        meta: {
            student_email: "<?php echo clean_param($USER->email, PARAM_EMAIL); ?>",
            school_email2: "<?php echo $extra_email ?: ''; ?>",
        },
        customizations: {
            title: "School Fees Payment",
            description: "Payment for school services - Ref: <?php echo $payment->reference; ?>",
            logo: "<?php echo $schoollogo; ?>"
        },
        onclose: function() {
            payBtn.disabled = false;
            payBtn.innerHTML = '<i class="fa fa-credit-card"></i> Pay Now';
            messageDiv.innerHTML =
                '<div class="alert alert-warning">Payment window closed. Click Pay Now to try again.</div>';
        }
    });
};
</script>

<?php echo $OUTPUT->footer(); ?>