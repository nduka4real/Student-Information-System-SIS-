<?php
defined('MOODLE_INTERNAL') || die();

class local_sis_observer {

    public static function quiz_submitted(\mod_quiz\event\attempt_submitted $event) {
        global $DB;

        $quizid   = $event->other['quizid'];
        $userid   = $event->relateduserid;
        $courseid = $event->courseid;

        // Check if this quiz is mapped in local_sis_quizmap
        $map = $DB->get_record('local_sis_quizmap', ['courseid' => $courseid]);
        if (!$map) {
            return true;
        }

        $firstca = $secondca = $exam = 0;

        // Get student’s quiz grade
        $grade = $DB->get_record('quiz_grades', ['quiz' => $quizid, 'userid' => $userid]);

        if (!$grade) {
            return true; // No grade yet
        }

        // Determine where this quiz should go
        if ($map->firstcaquiz == $quizid) {
            $firstca = $grade->grade;
        }
        if ($map->secondcaquiz == $quizid) {
            $secondca = $grade->grade;
        }
        if ($map->examquiz == $quizid) {
            $exam = $grade->grade;
        }

        // Get existing record or create new
        $record = $DB->get_record('local_sis_result', [
            'userid' => $userid,
            'courseid' => $courseid
        ]);

        if ($record) {
            if ($map->firstcaquiz == $quizid) $record->firstca = $firstca;
            if ($map->secondcaquiz == $quizid) $record->secondca = $secondca;
            if ($map->examquiz == $quizid) $record->exam = $exam;

            $record->total = ($record->firstca ?? 0) + ($record->secondca ?? 0) + ($record->exam ?? 0);
            $record->grade = calculate_grade($record->total);
            $record->timemodified = time();

            $DB->update_record('local_sis_result', $record);

        } else {
            $new = (object)[
                'userid' => $userid,
                'courseid' => $courseid,
                'firstca' => $firstca,
                'secondca' => $secondca,
                'exam' => $exam,
                'total' => $firstca + $secondca + $exam,
                'grade' => calculate_grade($firstca + $secondca + $exam),
                'timemodified' => time()
            ];
            $DB->insert_record('local_sis_result', $new);
        }

        return true;
    }
}


function calculate_grade($total) {
    if ($total >= 70) return 'A';
    if ($total >= 60) return 'B';
    if ($total >= 50) return 'C';
    if ($total >= 45) return 'D';
    if ($total >= 40) return 'E';
    return 'F';
}

