<?php
// This file is part of the Student Information System plugin for Moodle.
// this file is used to delete scores from data base
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version information for the Student Information System plugin
 *
 * @package    local_sis
 * @copyright  2025 NduksTech - https://facebook.com/ndukshub
 * @author     Nduka Akapti  (https://github.com/nduka4real)
 * @author     Ndukstech (https://www.youtube.com/@nduks-tech)
 * @author     https://www.linkedin.com/in/ndukaakpati/
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @details
 * Display Name: Student Information System
 * Description: A comprehensive system for managing student records, assessments, fees, and school operations.
 * Contact: https://github.com/nduka4real
 * Social: https://facebook.com/ndukshub
 */

require_once('../../config.php');
require_once($CFG->libdir.'/adminlib.php');

require_login();
require_capability('moodle/site:config', context_system::instance());

$PAGE->set_context(context_system::instance());
$PAGE->set_url(new moodle_url('/local/sis/delete_scores.php'));
$PAGE->set_title('Delete Student Scores');
$PAGE->set_heading('Delete Student Scores');

// Check if table exists
global $DB;
if (!$DB->get_manager()->table_exists('local_sis_result')) {
    echo $OUTPUT->header();
    echo $OUTPUT->error_text('The local_sis_result table does not exist.');
    echo $OUTPUT->footer();
    die();
}

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm'])) {
    $studentid = required_param('student', PARAM_INT);
    $courseid = required_param('courseid', PARAM_INT);
    
    $conditions = ['userid' => $studentid, 'courseid' => $courseid];
    $deleted = $DB->delete_records('local_sis_result', $conditions);
    
    if ($deleted) {
        \core\notification::success("Successfully deleted {$deleted} score records.");
    } else {
        \core\notification::error("No scores found to delete.");
    }
}

// Get available students with scores
$students = $DB->get_records_sql("
    SELECT DISTINCT u.id, u.firstname, u.lastname 
    FROM {local_sis_result} lsr
    JOIN {user} u ON u.id = lsr.userid
    ORDER BY u.lastname, u.firstname
");

// Get available courses with scores
$courses = $DB->get_records_sql("
    SELECT DISTINCT c.id, c.fullname 
    FROM {local_sis_result} lsr
    JOIN {course} c ON c.id = lsr.courseid
    ORDER BY c.fullname
");

echo $OUTPUT->header();
echo $OUTPUT->heading('Delete Student Scores');

// Show table structure for debugging
if (has_capability('moodle/site:config', context_system::instance())) {
    $columns = $DB->get_columns('local_sis_result');
    echo "<div class='alert alert-info'>";
    echo "<h4>Table Structure - local_sis_result:</h4>";
    echo "<ul>";
    foreach ($columns as $column => $info) {
        echo "<li><strong>{$column}</strong> - Type: {$info->meta_type}</li>";
    }
    echo "</ul>";
    
    // Show sample data
    $sample = $DB->get_records('local_sis_result', null, '', '*', 0, 3);
    if ($sample) {
        echo "<h4>Sample Data (first 3 records):</h4>";
        echo "<pre>";
        foreach ($sample as $record) {
            print_r($record);
        }
        echo "</pre>";
    }
    echo "</div>";
}
?>

<form method="post" action="">
    <div class="form-group">
        <label for="student">Student:</label>
        <select name="student" id="student" class="form-control" required>
            <option value="">Select Student</option>
            <?php foreach ($students as $student): ?>
                <option value="<?php echo $student->id; ?>">
                    <?php echo fullname($student); ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>
    
    <div class="form-group">
        <label for="courseid">Course:</label>
        <select name="courseid" id="courseid" class="form-control" required>
            <option value="">Select Course</option>
            <?php foreach ($courses as $course): ?>
                <option value="<?php echo $course->id; ?>">
                    <?php echo format_string($course->fullname); ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>
    
    <div class="form-group">
        <div class="form-check">
            <input type="checkbox" name="confirm" id="confirm" class="form-check-input" required>
            <label for="confirm" class="form-check-label">
                I confirm that I want to delete these scores permanently
            </label>
        </div>
    </div>
    
    <button type="submit" class="btn btn-danger">Delete Scores</button>
    <a href="<?php echo new moodle_url('/admin/index.php'); ?>" class="btn btn-secondary">Cancel</a>
</form>

<?php
echo $OUTPUT->footer();