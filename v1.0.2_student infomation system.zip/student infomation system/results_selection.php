<?php
// This file is part of the Student Information System plugin for Moodle.
// this file is used to select result
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version information for the Student Information System plugin
 *
 * @package    local_sis
 * @copyright  2025 NduksTech - https://facebook.com/ndukshub
 * @author     Nduka Akapti  (https://github.com/nduka4real)
 * @author     Ndukstech (https://www.youtube.com/@nduks-tech)
 * @author     https://www.linkedin.com/in/ndukaakpati/
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @details
 * Display Name: Student Information System
 * Description: A comprehensive system for managing student records, assessments, fees, and school operations.
 * Contact: https://github.com/nduka4real
 * Social: https://facebook.com/ndukshub
 */

// local/sis/results_selection.php
require_once(__DIR__ . '/../../config.php');
require_login();

$context = context_system::instance();
$PAGE->set_context($context);
$PAGE->set_url(new moodle_url('/local/sis/results_selection.php'));
$PAGE->set_title('Select Results Parameters');
$PAGE->set_heading('Select Results Parameters');

// Check if user has permission to view results
if (!has_capability('local/sis:view', $context)) {
    throw new moodle_exception('nopermission', 'local_sis');
}

echo $OUTPUT->header();

// Navigation buttons
echo html_writer::div(
    html_writer::link(
        new moodle_url('/local/sis/index.php'),
        'Back to Main Dashboard',
        ['class' => 'btn btn-success mb-3']
    ),
    'text-center'
);

// Get available sessions and terms
function get_session_term_info($sessionid = 0, $termid = 0) {
    global $DB;
    
    $sessions = $DB->get_records('local_sis_sessions', [], 'sessionname ASC');
    
    if (!$sessionid) {
        $current_session = $DB->get_record('local_sis_sessions', ['iscurrent' => 1]);
        if ($current_session) {
            $sessionid = $current_session->id;
        } else {
            $first_session = reset($sessions);
            $sessionid = $first_session ? $first_session->id : 0;
        }
    }
    
    $terms = [];
    if ($sessionid) {
        $terms = $DB->get_records('local_sis_terms', ['sessionid' => $sessionid], 'termname ASC');
    }
    
    if (!$termid && $sessionid) {
        $current_term = $DB->get_record('local_sis_terms', ['sessionid' => $sessionid, 'iscurrent' => 1]);
        if ($current_term) {
            $termid = $current_term->id;
        } else {
            $first_term = reset($terms);
            $termid = $first_term ? $first_term->id : 0;
        }
    }
    
    return [
        'sessionid' => $sessionid,
        'sessions' => $sessions,
        'termid' => $termid,
        'terms' => $terms
    ];
}

$sessionid = optional_param('sessionid', 0, PARAM_INT);
$termid = optional_param('termid', 0, PARAM_INT);
$categoryid = optional_param('categoryid', 0, PARAM_INT);

$session_term_info = get_session_term_info($sessionid, $termid);
$categories = $DB->get_records('course_categories', [], 'name ASC');

// Check if user is a student
$is_student = false;
$current_user_id = $USER->id;
$roles = get_user_roles($context, $current_user_id);
foreach ($roles as $role) {
    if (strpos($role->shortname, 'student') !== false) {
        $is_student = true;
        break;
    }
}

// For students, automatically get their category
if ($is_student && !$categoryid) {
    $student_category = get_student_category($current_user_id);
    if ($student_category) {
        $categoryid = $student_category->id;
    }
}

?>
<div class="sis-results-selection-container">
    <div class="card">
        <div class="card-body">
            <h3 class="card-title">Select Results Parameters</h3>
            <p class="text-muted">Choose the session, term, and class to view results.</p>
            
            <form method="get" action="viewresults.php" id="selectionForm">
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="sessionid" class="form-label">Session:</label>
                        <select name="sessionid" id="sessionid" class="form-control" required>
                            <option value="">Select Session</option>
                            <?php foreach ($session_term_info['sessions'] as $s): ?>
                                <option value="<?php echo $s->id; ?>" 
                                    <?php echo $session_term_info['sessionid'] == $s->id ? 'selected' : ''; ?>>
                                    <?php echo format_string($s->sessionname); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="col-md-4">
                        <label for="termid" class="form-label">Term:</label>
                        <select name="termid" id="termid" class="form-control" required>
                            <option value="">Select Term</option>
                            <?php foreach ($session_term_info['terms'] as $t): ?>
                                <option value="<?php echo $t->id; ?>" 
                                    <?php echo $session_term_info['termid'] == $t->id ? 'selected' : ''; ?>>
                                    <?php echo format_string($t->termname); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="col-md-4">
                        <label for="categoryid" class="form-label">Class:</label>
                        <select name="categoryid" id="categoryid" class="form-control" 
                            <?php echo $is_student ? 'disabled' : 'required'; ?>>
                            <option value="">Select Class</option>
                            <?php foreach ($categories as $cat): ?>
                                <option value="<?php echo $cat->id; ?>" 
                                    <?php echo $categoryid == $cat->id ? 'selected' : ''; ?>>
                                    <?php echo format_string($cat->name); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <?php if ($is_student): ?>
                            <input type="hidden" name="categoryid" value="<?php echo $categoryid; ?>">
                            <small class="text-muted">Your class is automatically selected</small>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="text-center">
                    <button type="submit" class="btn btn-primary btn-lg">
                        View Results
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.getElementById('sessionid').addEventListener('change', function() {
    // Reload page with new session to update terms
    var form = document.getElementById('selectionForm');
    form.action = 'results_selection.php';
    form.submit();
});
</script>

<?php
echo $OUTPUT->footer();

// Helper function to get student's category
function get_student_category($userid) {
    global $DB;
    
    // Get the most recent category from student's results
    $sql = "SELECT c.id, c.name
            FROM {local_sis_result} r
            JOIN {course} c ON c.id = r.courseid
            WHERE r.userid = :userid
            ORDER BY r.timecreated DESC
            LIMIT 1";
    
    return $DB->get_record_sql($sql, ['userid' => $userid]);
}