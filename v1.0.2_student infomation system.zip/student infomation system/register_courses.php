<?php
// This file is part of the Student Information System plugin for Moodle.
// this file is used for bulk . course registration
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version information for the Student Information System plugin
 *
 * @package    local_sis
 * @copyright  2025 NduksTech - https://facebook.com/ndukshub
 * @author     Nduka Akapti  (https://github.com/nduka4real)
 * @author     Ndukstech (https://www.youtube.com/@nduks-tech)
 * @author     https://www.linkedin.com/in/ndukaakpati/
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @details
 * Display Name: Student Information System
 * Description: A comprehensive system for managing student records, assessments, fees, and school operations.
 * Contact: https://github.com/nduka4real
 * Social: https://facebook.com/ndukshub
 */

// this is added here to prevent email sending error as a  temporary measure
define('NO_DEBUG_DISPLAY', true);
@ini_set('display_errors', '0');
@ini_set('log_errors', '1');

// Force UTF-8 output
header('Content-Type: text/html; charset=utf-8');

require_once('../../config.php');
require_once($CFG->libdir . '/formslib.php');
require_once($CFG->dirroot . '/enrol/manual/lib.php');

$categoryid = optional_param('categoryid', 0, PARAM_INT);
$action     = optional_param('action', '', PARAM_ALPHA);

require_login();

$context = context_system::instance();

// Capability check
if (!has_capability('moodle/site:config', $context) &&
    !has_capability('moodle/course:update', $context)) {
    throw new required_capability_exception($context, 'moodle/course:update', 'nopermissions', '');
}

// Page setup
$PAGE->set_url(new moodle_url('/local/sis/register_courses.php'));
$PAGE->set_context($context);
$PAGE->set_title('Course Registration');
$PAGE->set_heading('Course Registration');
$PAGE->set_pagelayout('admin');

// Process registration
if ($action === 'register' && confirm_sesskey()) {
    process_course_registration();
}

// Output
echo $OUTPUT->header();

// Back to SIS Dashboard button
echo html_writer::start_div('mb-3');
echo html_writer::link(
    new moodle_url('/local/sis/index.php'),
    ' Back to SIS Dashboard',
    ['class' => 'btn btn-outline-primary btn-sm']
);
echo html_writer::end_div();

echo $OUTPUT->heading('Course Registration');
display_registration_interface($categoryid);
echo $OUTPUT->footer();

/* ========================================================================= */
/* PROCESS COURSE REGISTRATION                                               */
/* ========================================================================= */

function process_course_registration() {
    global $DB, $CFG;

    $categoryid    = required_param('categoryid', PARAM_INT);
    $registrations = optional_param_array('registrations', [], PARAM_TEXT);

    if (empty($registrations)) {
        \core\notification::error('No course registrations selected');
        return false;
    }

    $enrolled = 0;
    $errors   = 0;

    foreach ($registrations as $registration) {
        list($studentid, $courseid) = explode('-', $registration);

        $student = $DB->get_record('user', ['id' => $studentid, 'deleted' => 0]);
        $course  = $DB->get_record('course', ['id' => $courseid, 'category' => $categoryid]);

        if (!$student || !$course) {
            $errors++;
            continue;
        }

        if (is_enrolled(context_course::instance($courseid), $studentid)) {
            continue;
        }

        // Get manual enrol instance
        $instances      = enrol_get_instances($courseid, true);
        $manualinstance = null;

        foreach ($instances as $instance) {
            if ($instance->enrol === 'manual') {
                $manualinstance = $instance;
                break;
            }
        }

        if (!$manualinstance) {
            $coursecontext = context_course::instance($courseid);
            if (has_capability('enrol/manual:config', $coursecontext)) {
                $enrolplugin = enrol_get_plugin('manual');
                $id = $enrolplugin->add_instance($course);
                $manualinstance = $DB->get_record('enrol', ['id' => $id]);
            } else {
                $errors++;
                continue;
            }
        }

        try {
            // METHOD 1: Direct database insertion (completely bypasses email)
            $result = enrol_user_direct($manualinstance->id, $studentid, 5);
            
            if ($result) {
                $enrolled++;
            } else {
                $errors++;
            }
            
        } catch (Exception $e) {
            $errors++;
            error_log("Enrolment error for student $studentid in course $courseid: " . $e->getMessage());
        }
    }

    // Display results
    if ($enrolled > 0) {
        \core\notification::success("Successfully enrolled $enrolled students");
    }
    if ($errors > 0) {
        \core\notification::warning("Failed to complete $errors enrolments");
    }

    return true;
}

/**
 * Direct user enrolment without triggering email notifications
 */
function enrol_user_direct($enrolid, $userid, $roleid = 5) {
    global $DB, $USER;

    // Check if already enrolled
    $existing = $DB->get_record('user_enrolments', [
        'enrolid' => $enrolid,
        'userid' => $userid
    ]);

    if ($existing) {
        return true; // Already enrolled
    }

    // Create enrolment record
    $enrolment = new stdClass();
    $enrolment->enrolid = $enrolid;
    $enrolment->userid = $userid;
    $enrolment->status = 0; // Active
    $enrolment->timestart = time();
    $enrolment->timeend = 0;
    $enrolment->modifierid = $USER->id;
    $enrolment->timecreated = time();
    $enrolment->timemodified = time();

    $enrolmentid = $DB->insert_record('user_enrolments', $enrolment);

    if (!$enrolmentid) {
        return false;
    }

    // Assign role in course context
    $enrol = $DB->get_record('enrol', ['id' => $enrolid]);
    $context = context_course::instance($enrol->courseid);
    
    role_assign($roleid, $userid, $context->id, 'enrol_manual', $enrolid);

    // Trigger event for logging (but not email)
    $event = \core\event\user_enrolment_created::create([
        'objectid' => $enrolmentid,
        'courseid' => $enrol->courseid,
        'context' => $context,
        'relateduserid' => $userid,
        'other' => ['enrol' => 'manual']
    ]);
    $event->trigger();

    return true;
}

/**
 * Alternative method using core function with email disabled via config
 */
function enrol_user_safe($enrolinstance, $userid, $roleid = 5) {
    global $CFG;

    // Temporarily disable all email
    $original_noemail = isset($CFG->noemailever) ? $CFG->noemailever : false;
    set_config('noemailever', 1);

    try {
        $enrolplugin = enrol_get_plugin('manual');
        
        // Store original welcome message setting
        $original_welcome = null;
        if (isset($enrolinstance->customint4)) {
            $original_welcome = $enrolinstance->customint4;
            // Temporarily disable welcome message
            $DB->set_field('enrol', 'customint4', 0, ['id' => $enrolinstance->id]);
        }

        // Enrol user
        $enrolplugin->enrol_user($enrolinstance, $userid, $roleid);
        $result = true;

        // Restore welcome message setting
        if ($original_welcome !== null) {
            $DB->set_field('enrol', 'customint4', $original_welcome, ['id' => $enrolinstance->id]);
        }

    } catch (Exception $e) {
        $result = false;
        error_log("Safe enrolment failed: " . $e->getMessage());
    }

    // Restore email setting
    if ($original_noemail === false) {
        unset_config('noemailever');
    } else {
        set_config('noemailever', $original_noemail);
    }

    return $result;
}

/* ========================================================================= */
/* INTERFACE                                                                 */
/* ========================================================================= */

function display_registration_interface($categoryid) {
    global $OUTPUT;

    display_category_selector($categoryid);

    if (!$categoryid) {
        return;
    }

    $students = get_students_for_category($categoryid);
    $courses  = get_courses_for_category($categoryid);

    if (empty($students)) {
        echo $OUTPUT->notification('No students found in this category', 'warning');
        return;
    }

    if (empty($courses)) {
        echo $OUTPUT->notification('No courses found in this category', 'warning');
        return;
    }

    display_registration_matrix($categoryid, $students, $courses);
}

/* ========================================================================= */
/* CATEGORY SELECTOR                                                         */
/* ========================================================================= */

function display_category_selector($selected_category = 0) {
    global $DB;

    $categories = $DB->get_records('course_categories', null, 'name', 'id,name,parent');

    echo html_writer::start_div('card mb-4');
    echo html_writer::start_div('card-body');
    echo html_writer::tag('h5', 'Select Category', ['class' => 'card-title']);

    echo html_writer::start_tag('form', ['method' => 'get', 'class' => 'form-inline']);

    $options = [0 => 'Choose a category...'];
    foreach ($categories as $cat) {
        $indent = $cat->parent ? '� ' : '';
        $options[$cat->id] = $indent . $cat->name;
    }

    echo html_writer::select($options, 'categoryid', $selected_category, false, ['class' => 'form-control mr-2']);

    echo html_writer::empty_tag('input', [
        'type'  => 'submit',
        'value' => 'Load',
        'class' => 'btn btn-primary'
    ]);

    echo html_writer::end_tag('form');
    echo html_writer::end_div();
    echo html_writer::end_div();
}

/* ========================================================================= */
/* REGISTRATION MATRIX                                                       */
/* ========================================================================= */

function display_registration_matrix($categoryid, $students, $courses) {
    global $DB, $OUTPUT;

    $category   = $DB->get_record('course_categories', ['id' => $categoryid]);
    $enrolments = get_current_enrolments($students, $courses, $categoryid);

    echo html_writer::start_div('card');

    echo html_writer::div(
        html_writer::tag('h4', 'Course Registration: ' . $category->name),
        'card-header bg-primary text-white'
    );

    echo html_writer::start_tag('form', [
        'method' => 'post',
        'action' => new moodle_url('/local/sis/register_courses.php', [
            'action'  => 'register',
            'sesskey' => sesskey()
        ])
    ]);

    echo html_writer::start_div('card-body');

    echo html_writer::empty_tag('input', [
        'type'  => 'hidden',
        'name'  => 'categoryid',
        'value' => $categoryid
    ]);

    // Summary and master controls
    echo html_writer::start_div('alert alert-info mb-4');
    echo html_writer::tag('p', 'Students: ' . count($students) . ' | Courses: ' . count($courses));
    echo html_writer::tag('p', 'Check the boxes to register students for specific courses.');
    
    // Email notification
    echo html_writer::start_div('alert alert-warning mt-2');
    echo html_writer::tag('p', '<strong>Note:</strong> Welcome emails are disabled during bulk enrolment.');
    echo html_writer::end_div();
    
    // Master controls
    echo html_writer::start_div('mt-3');
    echo html_writer::tag('button', 'Select All Students', [
        'type'    => 'button',
        'class'   => 'btn btn-sm btn-outline-primary mr-2',
        'onclick' => 'selectAllStudents(true)'
    ]);
    echo html_writer::tag('button', 'Deselect All Students', [
        'type'    => 'button',
        'class'   => 'btn btn-sm btn-outline-secondary mr-2',
        'onclick' => 'selectAllStudents(false)'
    ]);
    echo html_writer::tag('button', 'Select All Courses', [
        'type'    => 'button',
        'class'   => 'btn btn-sm btn-outline-info mr-2',
        'onclick' => 'selectAllCourses(true)'
    ]);
    echo html_writer::tag('button', 'Deselect All Courses', [
        'type'    => 'button',
        'class'   => 'btn btn-sm btn-outline-warning',
        'onclick' => 'selectAllCourses(false)'
    ]);
    echo html_writer::end_div();
    
    echo html_writer::end_div(); // alert

    echo html_writer::start_div('table-responsive');
    echo html_writer::start_tag('table', ['class' => 'table table-bordered table-sm', 'id' => 'registration-matrix']);

    /* HEADER */
    echo html_writer::start_tag('thead');
    
    // Master checkbox row
    echo html_writer::start_tag('tr');
    echo html_writer::tag('th', 
        html_writer::tag('small', 'Select All', ['class' => 'd-block']) .
        html_writer::empty_tag('input', [
            'type' => 'checkbox',
            'id' => 'master-student-checkbox',
            'class' => 'master-checkbox',
            'onchange' => 'toggleAllStudents(this.checked)'
        ]),
        ['class' => 'bg-light sticky-left text-center', 'style' => 'width: 200px;']
    );
    
    $courseIndex = 0;
    foreach ($courses as $course) {
        echo html_writer::tag('th', 
            html_writer::tag('small', $course->shortname, ['class' => 'd-block']) .
            html_writer::empty_tag('input', [
                'type' => 'checkbox',
                'id' => 'master-course-' . $courseIndex,
                'class' => 'master-course-checkbox',
                'data-course-index' => $courseIndex,
                'onchange' => 'toggleAllCourses(' . $courseIndex . ', this.checked)'
            ]),
            ['class' => 'text-center', 'style' => 'min-width: 100px;', 'title' => $course->fullname]
        );
        $courseIndex++;
    }
    echo html_writer::end_tag('tr');
    
    // Column headers row
    echo html_writer::start_tag('tr');
    echo html_writer::tag('th', 'Student', ['class' => 'bg-light sticky-left']);
    foreach ($courses as $course) {
        echo html_writer::tag('th', $course->shortname, [
            'class' => 'text-center',
            'title' => $course->fullname
        ]);
    }
    echo html_writer::end_tag('tr');
    echo html_writer::end_tag('thead');

    /* BODY */
    echo html_writer::start_tag('tbody');
    $studentIndex = 0;
    foreach ($students as $student) {
        $user = get_complete_user_data('id', $student->id);

        echo html_writer::start_tag('tr');

        echo html_writer::tag('td',
            html_writer::empty_tag('input', [
                'type' => 'checkbox',
                'class' => 'student-row-checkbox',
                'data-student-index' => $studentIndex,
                'onchange' => 'toggleStudentRow(' . $studentIndex . ', this.checked)'
            ]) . ' ' .
            fullname($user) . '<br><span class="text-muted small">' . $student->email . '</span>',
            ['class' => 'bg-light sticky-left']
        );

        $courseIndex = 0;
        foreach ($courses as $course) {
            $is_enrolled = isset($enrolments[$student->id]) &&
                           in_array($course->id, $enrolments[$student->id]);

            if ($is_enrolled) {
                $cell = '<span class="text-success font-weight-bold" title="Already enrolled">&#10003;</span>';
            } else {
                $cell = html_writer::empty_tag('input', [
                    'type'  => 'checkbox',
                    'name'  => 'registrations[]',
                    'value' => "{$student->id}-{$course->id}",
                    'class' => 'registration-checkbox course-col-' . $courseIndex . ' student-row-' . $studentIndex,
                    'data-student-index' => $studentIndex,
                    'data-course-index' => $courseIndex
                ]);
            }

            echo html_writer::tag('td', $cell, ['class' => 'text-center align-middle']);
            $courseIndex++;
        }

        echo html_writer::end_tag('tr');
        $studentIndex++;
    }
    echo html_writer::end_tag('tbody');
    echo html_writer::end_tag('table');
    echo html_writer::end_div();

    echo html_writer::end_div(); // card-body

    echo html_writer::start_div('card-footer');
    echo html_writer::empty_tag('input', [
        'type'  => 'submit',
        'value' => 'Register Selected Courses',
        'class' => 'btn btn-success btn-lg'
    ]);
    echo html_writer::link(
        new moodle_url('/local/sis/index.php'),
        'Back to Dashboard',
        ['class' => 'btn btn-secondary ml-2']
    );
    echo html_writer::end_div();

    echo html_writer::end_tag('form');
    echo html_writer::end_div();

    // JavaScript for master checkboxes
    echo "
    <script>
    function toggleAllStudents(checked) {
        var checkboxes = document.querySelectorAll('.student-row-checkbox');
        checkboxes.forEach(function(checkbox) {
            checkbox.checked = checked;
            var studentIndex = checkbox.getAttribute('data-student-index');
            toggleStudentRow(studentIndex, checked);
        });
    }
    
    function toggleStudentRow(studentIndex, checked) {
        var checkboxes = document.querySelectorAll('.student-row-' + studentIndex);
        checkboxes.forEach(function(checkbox) {
            if (!checkbox.disabled) {
                checkbox.checked = checked;
            }
        });
        updateMasterCheckboxes();
    }
    
    function toggleAllCourses(courseIndex, checked) {
        var checkboxes = document.querySelectorAll('.course-col-' + courseIndex);
        checkboxes.forEach(function(checkbox) {
            if (!checkbox.disabled) {
                checkbox.checked = checked;
            }
        });
        updateMasterCheckboxes();
    }
    
    function updateMasterCheckboxes() {
        // Update master student checkbox
        var studentCheckboxes = document.querySelectorAll('.student-row-checkbox');
        var allStudentsChecked = studentCheckboxes.length > 0;
        var someStudentsChecked = false;
        
        studentCheckboxes.forEach(function(checkbox) {
            if (!checkbox.checked) {
                allStudentsChecked = false;
            } else {
                someStudentsChecked = true;
            }
        });
        
        var masterStudent = document.getElementById('master-student-checkbox');
        masterStudent.checked = allStudentsChecked;
        masterStudent.indeterminate = !allStudentsChecked && someStudentsChecked;
        
        // Update master course checkboxes
        var courseCheckboxes = document.querySelectorAll('.master-course-checkbox');
        courseCheckboxes.forEach(function(masterCourse) {
            var courseIndex = masterCourse.getAttribute('data-course-index');
            var courseBoxes = document.querySelectorAll('.course-col-' + courseIndex);
            var allCourseChecked = courseBoxes.length > 0;
            var someCourseChecked = false;
            
            courseBoxes.forEach(function(checkbox) {
                if (!checkbox.checked) {
                    allCourseChecked = false;
                } else {
                    someCourseChecked = true;
                }
            });
            
            masterCourse.checked = allCourseChecked;
            masterCourse.indeterminate = !allCourseChecked && someCourseChecked;
        });
    }
    
    function selectAllStudents(select) {
        toggleAllStudents(select);
    }
    
    function selectAllCourses(select) {
        var courseCheckboxes = document.querySelectorAll('.master-course-checkbox');
        courseCheckboxes.forEach(function(checkbox) {
            var courseIndex = checkbox.getAttribute('data-course-index');
            toggleAllCourses(courseIndex, select);
        });
    }
    
    // Initialize master checkboxes
    document.addEventListener('DOMContentLoaded', function() {
        updateMasterCheckboxes();
        
        // Add change listeners to individual checkboxes
        var individualCheckboxes = document.querySelectorAll('.registration-checkbox');
        individualCheckboxes.forEach(function(checkbox) {
            checkbox.addEventListener('change', updateMasterCheckboxes);
        });
    });
    </script>
    
    <style>
    .sticky-left {
        position: sticky;
        left: 0;
        background: #f8f9fa;
        z-index: 10;
    }
    .table th {
        vertical-align: middle !important;
    }
    .master-checkbox {
        transform: scale(1.2);
        margin: 5px;
    }
    .student-row-checkbox {
        transform: scale(1.1);
        margin-right: 8px;
    }
    </style>
    ";
}

/* ========================================================================= */
/* DATA HELPERS                                                              */
/* ========================================================================= */

function get_current_enrolments($students, $courses, $categoryid) {
    global $DB;

    if (empty($students) || empty($courses)) {
        return [];
    }

    $student_ids = array_keys($students);
    $course_ids  = array_keys($courses);

    list($ssql, $sparams) = $DB->get_in_or_equal($student_ids, SQL_PARAMS_NAMED, 's');
    list($csql, $cparams) = $DB->get_in_or_equal($course_ids, SQL_PARAMS_NAMED, 'c');

    $sql = "
        SELECT ue.userid, c.id AS courseid
        FROM {user_enrolments} ue
        JOIN {enrol} e ON e.id = ue.enrolid
        JOIN {course} c ON c.id = e.courseid
        WHERE ue.userid $ssql
          AND c.id $csql
          AND c.category = :categoryid
    ";

    $params = array_merge($sparams, $cparams, ['categoryid' => $categoryid]);
    $records = $DB->get_recordset_sql($sql, $params);

    $enrolments = [];
    foreach ($records as $r) {
        $enrolments[$r->userid][] = $r->courseid;
    }
    $records->close();

    return $enrolments;
}

function get_students_for_category($categoryid) {
    global $DB;

    $sql = "
        SELECT DISTINCT u.id, u.firstname, u.lastname, u.email
        FROM {user} u
        JOIN {role_assignments} ra ON ra.userid = u.id
        JOIN {context} ctx ON ctx.id = ra.contextid AND ctx.contextlevel = 50
        JOIN {role} r ON r.id = ra.roleid
        JOIN {course} c ON c.id = ctx.instanceid
        WHERE c.category = :categoryid
          AND r.shortname = 'student'
          AND u.deleted = 0
          AND u.suspended = 0
    ";

    return $DB->get_records_sql($sql, ['categoryid' => $categoryid]);
}

function get_courses_for_category($categoryid) {
    global $DB;
    return $DB->get_records('course', ['category' => $categoryid, 'visible' => 1], 'fullname');
}