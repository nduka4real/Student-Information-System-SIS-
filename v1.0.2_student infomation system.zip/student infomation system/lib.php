<?php
// This file is part of the Student Information System plugin for Moodle.
// this files contains the library of this plugin
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version information for the Student Information System plugin
 *
 * @package    local_sis
 * @copyright  2025 NduksTech - https://facebook.com/ndukshub
 * @author     Nduka Akapti  (https://github.com/nduka4real)
 * @author     Ndukstech (https://www.youtube.com/@nduks-tech)
 * @author     https://www.linkedin.com/in/ndukaakpati/
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @details
 * Display Name: Student Information System
 * Description: A comprehensive system for managing student records, assessments, fees, and school operations.
 * Contact: https://github.com/nduka4real
 * Social: https://facebook.com/ndukshub
 */

defined('MOODLE_INTERNAL') || die();

// Include required Moodle files
require_once($CFG->libdir . '/externallib.php');
require_once($CFG->dirroot . '/user/profile/lib.php');

/**
 * COURSE REGISTRATION FUNCTIONS
 */

/**
 * Display the course registration form
 *
 * @param int $categoryid Category ID
 * @param int $studentid Student ID
 */
function local_sis_display_registration_form($categoryid = 0, $studentid = 0) {
    global $DB, $OUTPUT;

    // Get all categories and convert to proper options array
    $categories = $DB->get_records('course_categories', null, 'name', 'id, name');
    $categoryoptions = [0 => get_string('selectcategory', 'local_sis')];
    
    foreach ($categories as $category) {
        $categoryoptions[$category->id] = format_string($category->name);
    }
    
    echo html_writer::start_div('category-selector');
    echo html_writer::label(get_string('selectcategory', 'local_sis'), 'categoryid');
    echo html_writer::select($categoryoptions, 'categoryid', $categoryid, 
        ['' => get_string('choosecategory', 'local_sis')], 
        ['id' => 'categoryid', 'class' => 'category-selector']
    );
    echo html_writer::end_div();

    if ($categoryid) {
        local_sis_display_students_and_courses($categoryid, $studentid);
    }
}

/**
 * Display students and courses for registration
 *
 * @param int $categoryid Category ID
 * @param int $studentid Student ID
 */
function local_sis_display_students_and_courses($categoryid, $studentid = 0) {
    global $DB, $OUTPUT;

    // Get students in this category
    $students = local_sis_get_students_by_category($categoryid);
    
    // Get courses in this category
    $categorycourses = local_sis_get_courses_by_category($categoryid);
    
    // Get all other categories for carry-over courses
    $othercategories = $DB->get_records_sql("
        SELECT cc.id, cc.name 
        FROM {course_categories} cc 
        WHERE cc.id != ? 
        ORDER BY cc.name
    ", [$categoryid]);

    if (empty($students)) {
        echo $OUTPUT->notification(get_string('nostudentsincategory', 'local_sis'));
        return;
    }

    echo html_writer::start_tag('form', [
        'method' => 'post',
        'action' => new moodle_url('/local/sis/register_courses.php', [
            'categoryid' => $categoryid,
            'action' => 'register'
        ]),
        'id' => 'registrationform'
    ]);
    echo html_writer::empty_tag('input', [
        'type' => 'hidden',
        'name' => 'sesskey',
        'value' => sesskey()
    ]);

    echo html_writer::start_div('registration-container');
    
    foreach ($students as $student) {
        echo local_sis_render_student_registration_section($student, $categorycourses, $othercategories);
    }

    echo html_writer::end_div();
    
    echo html_writer::start_div('form-actions');
    echo html_writer::tag('button', get_string('registercourses', 'local_sis'), [
        'type' => 'submit',
        'class' => 'btn btn-primary'
    ]);
    echo html_writer::end_div();
    
    echo html_writer::end_tag('form');
}

/**
 * Render student registration section with courses
 *
 * @param stdClass $student Student object
 * @param array $categorycourses Courses in current category
 * @param array $othercategories Other categories for carry-over
 * @return string HTML content
 */
function local_sis_render_student_registration_section($student, $categorycourses, $othercategories) {
    global $OUTPUT, $DB;

    $html = html_writer::start_div('student-registration-section', [
        'data-studentid' => $student->id
    ]);
    
    // Student header
    $html .= html_writer::start_div('student-header card-header');
    $html .= html_writer::tag('h4', fullname($student));
    $html .= html_writer::tag('span', $student->email, ['class' => 'student-email']);
    $html .= html_writer::end_div();
    
    $html .= html_writer::start_div('student-courses card-body');
    
    // Current category courses
    if (!empty($categorycourses)) {
        $html .= html_writer::tag('h5', get_string('categorycourses', 'local_sis'));
        $html .= html_writer::start_div('category-courses');
        
        foreach ($categorycourses as $course) {
            $isregistered = local_sis_is_student_registered($student->id, $course->id);
            
            $html .= html_writer::start_div('course-checkbox form-check');
            $html .= html_writer::checkbox(
                "courses[{$student->id}][{$course->id}]",
                1,
                $isregistered,
                format_string($course->fullname),
                ['class' => 'form-check-input', 'id' => "course_{$student->id}_{$course->id}"]
            );
            $html .= html_writer::end_div();
        }
        $html .= html_writer::end_div();
    }

    // Carry-over courses from other categories
    $html .= local_sis_render_carryover_courses($student->id, $othercategories);
    
    $html .= html_writer::end_div(); // .student-courses
    $html .= html_writer::end_div(); // .student-registration-section
    
    return $html;
}

/**
 * Render carry-over courses from other categories
 *
 * @param int $studentid Student ID
 * @param array $othercategories Other categories
 * @return string HTML content
 */
function local_sis_render_carryover_courses($studentid, $othercategories) {
    global $DB;

    $html = html_writer::start_div('carryover-courses');
    $html .= html_writer::tag('h5', get_string('carryovercourses', 'local_sis'));
    
    foreach ($othercategories as $category) {
        $courses = local_sis_get_courses_by_category($category->id);
        
        if (empty($courses)) {
            continue;
        }

        $html .= html_writer::start_div('category-section accordion-item');
        $html .= html_writer::tag('h6', 
            html_writer::link('#', format_string($category->name), [
                'class' => 'accordion-toggle',
                'data-bs-toggle' => 'collapse',
                'data-bs-target' => "#category_{$category->id}_{$studentid}"
            ]),
            ['class' => 'accordion-header']
        );
        
        $html .= html_writer::start_div('accordion-collapse collapse', [
            'id' => "category_{$category->id}_{$studentid}"
        ]);
        $html .= html_writer::start_div('accordion-body');
        
        foreach ($courses as $course) {
            $isregistered = local_sis_is_student_registered($studentid, $course->id);
            
            $html .= html_writer::start_div('course-checkbox form-check');
            $html .= html_writer::checkbox(
                "courses[{$studentid}][{$course->id}]",
                1,
                $isregistered,
                format_string($course->fullname),
                ['class' => 'form-check-input carryover-course']
            );
            $html .= html_writer::end_div();
        }
        
        $html .= html_writer::end_div(); // .accordion-body
        $html .= html_writer::end_div(); // .accordion-collapse
        $html .= html_writer::end_div(); // .category-section
    }
    
    $html .= html_writer::end_div(); // .carryover-courses
    
    return $html;
}

/**
 * Process course registration form
 */
function local_sis_process_registration() {
    global $DB;

    $courses = optional_param_array('courses', [], PARAM_INT);
    $registered = 0;
    $errors = 0;

    foreach ($courses as $studentid => $studentcourses) {
        foreach ($studentcourses as $courseid => $value) {
            if ($value) {
                // Register student to course
                if (local_sis_register_student_to_course($studentid, $courseid)) {
                    $registered++;
                } else {
                    $errors++;
                }
            } else {
                // Unregister student from course
                local_sis_unregister_student_from_course($studentid, $courseid);
            }
        }
    }

    if ($registered > 0) {
        \core\notification::success(get_string('registrationsuccess', 'local_sis', $registered));
    }
    if ($errors > 0) {
        \core\notification::error(get_string('registrationerrors', 'local_sis', $errors));
    }
}

/**
 * Get students by category
 *
 * @param int $categoryid Category ID
 * @return array Student records
 */
function local_sis_get_students_by_category($categoryid) {
    global $DB;
    
    $sql = "SELECT u.id, u.firstname, u.lastname, u.email
            FROM {user} u
            JOIN {user_info_data} uid ON u.id = uid.userid
            JOIN {user_info_field} uif ON uid.fieldid = uif.id
            WHERE uif.shortname = 'category'
            AND uid.data = ?
            AND u.deleted = 0
            ORDER BY u.lastname, u.firstname";
    
    return $DB->get_records_sql($sql, [$categoryid]);
}

/**
 * Get courses by category
 *
 * @param int $categoryid Category ID
 * @return array Course records
 */
function local_sis_get_courses_by_category($categoryid) {
    global $DB;
    
    return $DB->get_records('course', ['category' => $categoryid, 'visible' => 1], 'fullname');
}

/**
 * Check if student is registered to a course
 *
 * @param int $studentid Student ID
 * @param int $courseid Course ID
 * @return bool
 */
function local_sis_is_student_registered($studentid, $courseid) {
    global $DB;
    
    // Check if student is enrolled in the course
    $context = context_course::instance($courseid);
    return is_enrolled($context, $studentid);
}

/**
 * Register student to course
 *
 * @param int $studentid Student ID
 * @param int $courseid Course ID
 * @return bool Success status
 */
function local_sis_register_student_to_course($studentid, $courseid) {
    global $DB;
    
    if (!local_sis_is_student_registered($studentid, $courseid)) {
        $plugin = enrol_get_plugin('manual');
        if ($instances = $DB->get_records('enrol', ['courseid' => $courseid, 'enrol' => 'manual'], 'id')) {
            $instance = reset($instances);
            $plugin->enrol_user($instance, $studentid, 5); // Student role typically has id 5
            return true;
        }
    }
    return false;
}

/**
 * Unregister student from course
 *
 * @param int $studentid Student ID
 * @param int $courseid Course ID
 */
function local_sis_unregister_student_from_course($studentid, $courseid) {
    global $DB;
    
    if ($instances = $DB->get_records('enrol', ['courseid' => $courseid, 'enrol' => 'manual'], 'id')) {
        $instance = reset($instances);
        $plugin = enrol_get_plugin('manual');
        $plugin->unenrol_user($instance, $studentid);
    }
}

/**
 * END COURSE REGISTRATION FUNCTIONS
 */

/**
 * Extends the Moodle navigation for the SIS plugin.
 *
 * @param global_navigation $navigation The global navigation object.
 */
function local_sis_extend_navigation(global_navigation $navigation) {
    global $USER, $PAGE;
    
    // Check if user is logged in and not a guest
    if (!isloggedin() || isguestuser()) {
        return;
    }
    
    // Check capability in system context
    $context = context_system::instance();
    if (!has_capability('local/sis:view', $context)) {
        return;
    }
    
    try {
        // NEW: Role-based navigation
        // Check if user is a student
        if (local_sis_is_student_user()) {
            // Create the main student portal node
            $studentnode = $navigation->add(
                get_string('studentportal', 'local_sis'),
                null,
                navigation_node::TYPE_CONTAINER,
                null,
                'studentportal',
                new pix_icon('i/dashboard', '')
            );
            
            // Add "My Results" link
            $studentnode->add(
                get_string('myresults', 'local_sis'),
                new moodle_url('/local/sis/viewresults.php'),
                navigation_node::TYPE_SETTING,
                null,
                'myresults',
                new pix_icon('i/report', '')
            );
            
            // Make student portal visible in flat navigation (dashboard)
            $studentnode->showinflatnavigation = true;
        }

        // Add admin links for teachers/admins
        if (has_capability('moodle/site:config', context_system::instance()) || 
            has_capability('moodle/course:update', context_system::instance())) {
            
            $sisnode = $navigation->add(
                get_string('sisadmin', 'local_sis'),
                null,
                navigation_node::TYPE_CONTAINER,
                null,
                'sisadmin',
                new pix_icon('i/admin', '')
            );
            
            $sisnode->add(
                get_string('sisdashboard', 'local_sis'),
                new moodle_url('/local/sis/index.php'),
                navigation_node::TYPE_SETTING,
                null,
                'sisdashboard',
                new pix_icon('i/dashboard', '')
            );
            
            $sisnode->add(
                get_string('schoolsettings', 'local_sis'),
                new moodle_url('/local/sis/resultsettings.php'),
                navigation_node::TYPE_SETTING,
                null,
                'schoolsettings',
                new pix_icon('i/settings', '')
            );
            
            $sisnode->add(
                get_string('sessionterms', 'local_sis'),
                new moodle_url('/local/sis/session_terms.php'),
                navigation_node::TYPE_SETTING,
                null,
                'sessionterms',
                new pix_icon('i/calendar', '')
            );

            // ADD COURSE REGISTRATION LINK
            $sisnode->add(
                get_string('courseregistration', 'local_sis'),
                new moodle_url('/local/sis/register_courses.php'),
                navigation_node::TYPE_SETTING,
                null,
                'courseregistration',
                new pix_icon('i/cohort', '')
            );
            
            // Make SIS admin visible in flat navigation
            $sisnode->showinflatnavigation = true;
        }
        
        // KEEP EXISTING: Add the main SIS node for users who don't fit the above categories but have the capability
        if (!local_sis_is_student_user() && 
            !has_capability('moodle/site:config', context_system::instance()) && 
            !has_capability('moodle/course:update', context_system::instance())) {
            
            $node = $navigation->add(
                get_string('pluginname', 'local_sis'),
                new moodle_url('/local/sis/index.php'),
                navigation_node::TYPE_CUSTOM,
                null,
                'local_sis_root',
                new pix_icon('i/course', '')
            );
            $node->showinflatnavigation = true;
        }
        
    } catch (Exception $e) {
        debugging('Error adding SIS navigation node: ' . $e->getMessage(), DEBUG_DEVELOPER);
    }
}

/**
 * Extends the flat navigation for the dashboard
 *
 * @param flat_navigation $navigation The flat navigation object
 */
function local_sis_extend_flat_navigation(flat_navigation $navigation) {
    global $USER, $PAGE;
    
    // Only extend on dashboard pages
    if ($PAGE->pagetype !== 'my-index') {
        return;
    }
    
    // Check if user is logged in and not a guest
    if (!isloggedin() || isguestuser()) {
        return;
    }
    
    // Check capability in system context
    $context = context_system::instance();
    if (!has_capability('local/sis:view', $context)) {
        return;
    }
    
    try {
        // Get all existing navigation nodes
        $nodes = $navigation->get_children_key_list();
        
        // Check if user is a student
        if (local_sis_is_student_user()) {
            // Check if student portal already exists
            if (!in_array('studentportal', $nodes)) {
                // Create student portal node for dashboard
                $studentnode = $navigation->add(
                    get_string('studentportal', 'local_sis'),
                    null,
                    navigation_node::TYPE_CONTAINER,
                    null,
                    'studentportal',
                    new pix_icon('i/dashboard', '')
                );
                
                // Add "My Results" link
                $studentnode->add(
                    get_string('myresults', 'local_sis'),
                    new moodle_url('/local/sis/viewresults.php'),
                    navigation_node::TYPE_SETTING,
                    null,
                    'myresults',
                    new pix_icon('i/report', '')
                );
            }
        }

        // Add admin links for teachers/admins on dashboard
        if ((has_capability('moodle/site:config', context_system::instance()) || 
             has_capability('moodle/course:update', context_system::instance())) &&
            !in_array('sisadmin', $nodes)) {
            
            $sisnode = $navigation->add(
                get_string('sisadmin', 'local_sis'),
                null,
                navigation_node::TYPE_CONTAINER,
                null,
                'sisadmin',
                new pix_icon('i/admin', '')
            );
            
            $sisnode->add(
                get_string('sisdashboard', 'local_sis'),
                new moodle_url('/local/sis/index.php'),
                navigation_node::TYPE_SETTING,
                null,
                'sisdashboard',
                new pix_icon('i/dashboard', '')
            );
        }
        
    } catch (Exception $e) {
        debugging('Error adding SIS flat navigation: ' . $e->getMessage(), DEBUG_DEVELOPER);
    }
}

/**
 * Check if current user is a student
 *
 * @return bool
 */
function local_sis_is_student_user() {
    global $USER;

    // If user has teacher/admin capabilities, they're not a student
    $context = context_system::instance();
    if (has_capability('moodle/course:update', $context) || 
        has_capability('moodle/site:config', $context)) {
        return false;
    }

    // Check user roles in system context
    $roles = get_user_roles($context, $USER->id);
    foreach ($roles as $role) {
        if (strpos($role->shortname, 'student') !== false || 
            strpos($role->shortname, 'learner') !== false) {
            return true;
        }
    }

    // Check if enrolled as student in any course
    $enrolled_courses = enrol_get_all_users_courses($USER->id);
    foreach ($enrolled_courses as $course) {
        $context = context_course::instance($course->id);
        $roles = get_user_roles($context, $USER->id);
        foreach ($roles as $role) {
            if (strpos($role->shortname, 'student') !== false || 
                strpos($role->shortname, 'learner') !== false) {
                return true;
            }
        }
    }

    return false;
}

/**
 * Extends the user's profile navigation.
 *
 * @param \core_user\output\myprofile\tree $tree
 * @param stdClass $user
 * @param bool $iscurrentuser
 * @param stdClass|null $course
 */
function local_sis_myprofile_navigation(core_user\output\myprofile\tree $tree, $user, $iscurrentuser, $course) {
    // Check if we should show the node
    if (!$iscurrentuser) {
        return;
    }
    
    $context = context_system::instance();
    if (!has_capability('local/sis:view', $context)) {
        return;
    }
    
    try {
        $url = new moodle_url('/local/sis/viewresults.php', ['id' => $user->id]);
        
        // FIX: Use string for icon instead of pix_icon object for myprofile
        $node = new core_user\output\myprofile\node(
            'reports',
            'myresults',
            get_string('myresults', 'local_sis'),
            null,
            $url,
            'i/report'  // Changed from new pix_icon('i/report', '') to string
        );
        $tree->add_node($node);
    } catch (Exception $e) {
        debugging('Error adding SIS myprofile node: ' . $e->getMessage(), DEBUG_DEVELOPER);
    }
}

/**
 * Serves the files from the local_sis file areas
 *
 * @param stdClass $course the course object
 * @param stdClass $cm the course module object
 * @param stdClass $context the context
 * @param string $filearea the name of the file area
 * @param array $args extra arguments (itemid, path)
 * @param bool $forcedownload whether or not force download
 * @param array $options additional options affecting the file serving
 * @return bool false if the file not found, just send the file otherwise
 */
function local_sis_pluginfile($course, $cm, $context, $filearea, $args, $forcedownload, array $options = array()) {
    
    // Check the contextlevel is as expected - for system level files
    if ($context->contextlevel != CONTEXT_SYSTEM) {
        return false;
    }
    
    // Make sure the filearea is one of those used by the plugin
    $allowedfileareas = ['schoollogo', 'principalsignature'];
    if (!in_array($filearea, $allowedfileareas)) {
        return false;
    }
    
    // Make sure the user is logged in
    require_login();
    
    // Check the relevant capabilities - only admins can view these files
    if (!has_capability('moodle/site:config', $context)) {
        return false;
    }
    
    // Extract the itemid and filename from the $args array
    $itemid = array_shift($args);
    $filename = array_pop($args);
    
    if (!$args) {
        $filepath = '/';
    } else {
        $filepath = '/' . implode('/', $args) . '/';
    }
    
    // Retrieve the file from the Files API
    $fs = get_file_storage();
    $file = $fs->get_file($context->id, 'local_sis', $filearea, $itemid, $filepath, $filename);
    
    if (!$file) {
        return false;
    }
    
    // We can now send the file back to the browser
    send_stored_file($file, 86400, 0, $forcedownload, $options);
}

/**
 * Extends course settings navigation.
 *
 * @param settings_navigation $settingsnav
 * @param context $context
 */
function local_sis_extend_settings_navigation(settings_navigation $settingsnav, $context) {
    global $PAGE;
    
    // Only proceed in course context
    if ($context->contextlevel != CONTEXT_COURSE) {
        return;
    }
    
    // Check capability
    if (!has_capability('local/sis:manage', $context)) {
        return;
    }
    
    try {
        $courseadminnode = $settingsnav->find('courseadmin', navigation_node::TYPE_COURSE);
        if (!$courseadminnode) {
            return;
        }
        
        $url = new moodle_url('/local/sis/course_settings.php', ['id' => $context->instanceid]);
        $sisnode = $courseadminnode->add(
            get_string('coursesis', 'local_sis'),
            $url,
            navigation_node::NODETYPE_LEAF,
            null,
            'local_sis_course',
            new pix_icon('i/settings', '')
        );
        
        // Make active if we're on the SIS course settings page
        if ($PAGE->url->compare($url, URL_MATCH_BASE)) {
            $sisnode->make_active();
        }
        
    } catch (Exception $e) {
        debugging('Error adding SIS settings navigation: ' . $e->getMessage(), DEBUG_DEVELOPER);
    }
}

/**
 * Get SIS information for a user.
 *
 * @param int $userid User ID
 * @return stdClass|bool SIS data or false if not found
 */
function local_sis_get_user_data($userid) {
    global $DB;
    
    if (!is_numeric($userid) || $userid <= 0) {
        return false;
    }
    
    try {
        // Example: Get user SIS data from your custom table
        // Replace 'local_sis_users' with your actual table name
        return $DB->get_record('local_sis_users', ['userid' => $userid]);
    } catch (Exception $e) {
        debugging('Error getting SIS user data: ' . $e->getMessage(), DEBUG_DEVELOPER);
        return false;
    }
}

/**
 * Check if SIS features are available for a user.
 *
 * @param int $userid User ID
 * @return bool
 */
function local_sis_is_available($userid = null) {
    global $USER;
    
    if (!$userid) {
        $userid = $USER->id;
    }
    
    if (!isloggedin() || isguestuser()) {
        return false;
    }
    
    $context = context_system::instance();
    return has_capability('local/sis:view', $context, $userid);
}