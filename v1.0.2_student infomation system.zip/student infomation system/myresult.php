<?php
// This file is part of the Student Information System plugin for Moodle.
// This file enables users who have permission to view their results.
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle. If not, see <http://www.gnu.org/licenses/>.

/**
 * Version information for the Student Information System plugin
 *
 * @package local_sis
 * @copyright 2025 NduksTech - https://facebook.com/ndukshub
 * @author Nduka Akapti (https://github.com/nduka4real)
 * @author Ndukstech (https://www.youtube.com/@nduks-tech)
 * @author https://www.linkedin.com/in/ndukaakpati/
 * @license http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @details
 * Display Name: Student Information System
 * Description: A comprehensive system for managing student records, assessments, fees, and school operations.
 * Contact: https://github.com/nduka4real
 * Social: https://facebook.com/ndukshub
 */

// local/sis/myresult.php
require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/pdflib.php');
require_login();

// Force the userid to be the currently logged in student
$userid = $USER->id;
$sessionid = optional_param('sessionid', 0, PARAM_INT);
$termid = optional_param('termid', 0, PARAM_INT);

$context = context_system::instance();
$PAGE->set_context($context);
$PAGE->set_url(new moodle_url('/local/sis/myresult.php', [
    'sessionid' => $sessionid,
    'termid' => $termid
]));
$PAGE->set_title('My Results');
$PAGE->set_heading('My Academic Results');

// Add custom CSS
$PAGE->requires->css(new moodle_url('/local/sis/styles.css'));

// ========== HELPER FUNCTIONS ==========

// ---------- Function to get school settings from database ----------
function local_sis_get_school_settings() {
    global $DB;
    
    $school_settings = $DB->get_record('local_sis_school_settings', array('id' => 1));
    
    if (!$school_settings) {
        return (object) [
            'schoolname' => 'NDUKS TECH',
            'schooladdress' => '',
            'schoolmotto' => '',
            'phone' => '',
            'state' => '',
            'country' => '',
            'schoollogo' => '', 
            'principalsignature' => ''
        ];
    }
    
    return $school_settings;
}

// ---------- Function to get school logo URL using File API ----------
function local_sis_get_school_logo_url() {
    global $CFG;
    $fs = get_file_storage();
    $context = context_system::instance();
    
    // Try to get logo from File API first
    if ($files = $fs->get_area_files($context->id, 'local_sis', 'schoollogo', 1, "filename", false)) {
        $file = reset($files);
        return (string)moodle_url::make_pluginfile_url(
            $file->get_contextid(), 
            $file->get_component(), 
            $file->get_filearea(), 
            $file->get_itemid(), 
            $file->get_filepath(), 
            $file->get_filename(), 
            true
        );
    }
    
    // Fallback to old file system path
    $school_settings = local_sis_get_school_settings();
    if (!empty($school_settings->schoollogo)) {
        $logopath = $CFG->wwwroot . '/local/sis/pix/' . $school_settings->schoollogo;
        if (file_exists($CFG->dirroot . '/local/sis/pix/' . $school_settings->schoollogo)) {
            return $logopath . '?v=' . filemtime($CFG->dirroot . '/local/sis/pix/' . $school_settings->schoollogo);
        }
    }
    
    // Default logo
    $default_logo = $CFG->wwwroot . '/local/sis/pix/schoollogo.png';
    if (file_exists($CFG->dirroot . '/local/sis/pix/schoollogo.png')) {
        return $default_logo . '?v=' . filemtime($CFG->dirroot . '/local/sis/pix/schoollogo.png');
    }
    
    return $default_logo;
}

// ---------- Function to get principal signature URL using File API ----------
function local_sis_get_principal_signature_url() {
    global $CFG;
    $fs = get_file_storage();
    $context = context_system::instance();
    
    // Try to get signature from File API first
    if ($files = $fs->get_area_files($context->id, 'local_sis', 'principalsignature', 1, "filename", false)) {
        $file = reset($files);
        return (string)moodle_url::make_pluginfile_url(
            $file->get_contextid(), 
            $file->get_component(), 
            $file->get_filearea(), 
            $file->get_itemid(), 
            $file->get_filepath(), 
            $file->get_filename(), 
            true
        );
    }
    
    // Fallback to old file system path
    $school_settings = local_sis_get_school_settings();
    if (!empty($school_settings->principalsignature)) {
        $sigpath = $CFG->wwwroot . '/local/sis/pix/' . $school_settings->principalsignature;
        if (file_exists($CFG->dirroot . '/local/sis/pix/' . $school_settings->principalsignature)) {
            return $sigpath . '?v=' . filemtime($CFG->dirroot . '/local/sis/pix/' . $school_settings->principalsignature);
        }
    }
    
    // Default signature
    $default_sig = $CFG->wwwroot . '/local/sis/pix/principal_signature.png';
    if (file_exists($CFG->dirroot . '/local/sis/pix/principal_signature.png')) {
        return $default_sig . '?v=' . filemtime($CFG->dirroot . '/local/sis/pix/principal_signature.png');
    }
    
    return $default_sig;
}

// ---------- Function to get session and term information ----------
function local_sis_get_session_term_info($sessionid = 0, $termid = 0) {
    global $DB;
    
    // Get all sessions ordered by name
    $sessions = $DB->get_records('local_sis_sessions', [], 'sessionname ASC');
    
    // If no session ID provided, get default session
    if (!$sessionid) {
        $current_session = $DB->get_record('local_sis_sessions', ['isdefault' => 1]);
        if ($current_session) {
            $sessionid = $current_session->id;
            $sessionname = $current_session->sessionname;
        } else {
            // Fallback to first session if no default found
            $first_session = reset($sessions);
            $sessionid = $first_session ? $first_session->id : 0;
            $sessionname = $first_session ? $first_session->sessionname : 'No Session Available';
        }
    } else {
        // Get the specific session
        $session = $DB->get_record('local_sis_sessions', ['id' => $sessionid]);
        $sessionname = $session ? $session->sessionname : 'Selected Session';
    }
    
    // Get terms for the selected session
    $terms = [];
    if ($sessionid) {
        $terms = $DB->get_records('local_sis_terms', ['sessionid' => $sessionid], 'termname ASC');
    }
    
    // If no term ID provided, get default term for the session
    if (!$termid && $sessionid) {
        $current_term = $DB->get_record('local_sis_terms', ['sessionid' => $sessionid, 'isdefault' => 1]);
        if ($current_term) {
            $termid = $current_term->id;
            $termname = $current_term->termname;
        } else {
            // Fallback to first term if no default found
            $first_term = reset($terms);
            $termid = $first_term ? $first_term->id : 0;
            $termname = $first_term ? $first_term->termname : 'No Term Available';
        }
    } else if ($termid) {
        // Get the specific term
        $term = $DB->get_record('local_sis_terms', ['id' => $termid]);
        $termname = $term ? $term->termname : 'Selected Term';
    } else {
        $termname = 'Select Term';
    }
    
    return [
        'sessionid' => $sessionid,
        'sessionname' => $sessionname,
        'termid' => $termid,
        'termname' => $termname,
        'sessions' => $sessions,
        'terms' => $terms
    ];
}

// ---------- Check if student has permission to view results for specific term/session ----------
function can_student_view_results($userid, $categoryid, $sessionid, $termid) {
    global $DB;
    
    return $DB->record_exists('local_sis_student_access', [
        'userid' => $userid,
        'categoryid' => $categoryid,
        'sessionid' => $sessionid,
        'termid' => $termid,
        'can_view_results' => 1
    ]);
}

// ---------- Function to get student's class/category from results ----------
function get_student_class($userid, $sessionid, $termid) {
    global $DB;
    
    $sql = "SELECT DISTINCT c.category as id, cat.name as name
            FROM {local_sis_result} r
            JOIN {course} c ON c.id = r.courseid
            JOIN {course_categories} cat ON cat.id = c.category
            WHERE r.userid = :userid
            AND r.sessionid = :sessionid
            AND r.termid = :termid
            LIMIT 1";
    
    return $DB->get_record_sql($sql, [
        'userid' => $userid,
        'sessionid' => $sessionid,
        'termid' => $termid
    ]);
}

// ---------- Function to get student's courses with results ----------
function get_student_courses($userid, $sessionid, $termid) {
    global $DB;
    
    $sql = "SELECT c.id, c.fullname
            FROM {local_sis_result} r
            JOIN {course} c ON c.id = r.courseid
            WHERE r.userid = :userid
            AND r.sessionid = :sessionid
            AND r.termid = :termid
            ORDER BY c.fullname ASC";
    
    return $DB->get_records_sql($sql, [
        'userid' => $userid,
        'sessionid' => $sessionid,
        'termid' => $termid
    ]);
}

// ---------- Function to get component names ----------
function local_sis_get_component_names($courseid, $sessionid, $termid) {
    global $DB;
    
    $ca_config = $DB->get_record('local_sis_ca_config', [
        'courseid' => $courseid,
        'sessionid' => $sessionid,
        'termid' => $termid
    ]);
    
    if (!$ca_config) {
        // Default components if config not found
        return ['CA1', 'CA2', 'Exam'];
    }
    
    $components = !empty($ca_config->components) ? json_decode($ca_config->components, true) : [];
    $component_names = [];
    foreach ($components as $component) {
        $component_names[] = $component['name'];
    }
    return $component_names;
}

// ---------- Function to get student comments ----------
function local_sis_get_student_comments($userid, $categoryid, $sessionid, $termid) {
    global $DB;
    
    $sql = "SELECT * FROM {local_sis_comments} 
            WHERE userid = :userid 
            AND categoryid = :categoryid 
            AND sessionid = :sessionid 
            AND termid = :termid 
            LIMIT 1";
    
    return $DB->get_record_sql($sql, [
        'userid' => $userid,
        'categoryid' => $categoryid,
        'sessionid' => $sessionid,
        'termid' => $termid
    ]);
}

// ---------- Function for ranking with ties ----------
function local_sis_rank_with_ties(array $useridtotals): array {
    arsort($useridtotals, SORT_NUMERIC);
    $positions = [];
    $rank = 0;
    $index = 0;
    $prev = null;
    foreach ($useridtotals as $uid => $score) {
        $index++;
        if ($prev === null || (string)$score !== (string)$prev) {
            $rank = $index;
            $prev = $score;
        }
        $positions[$uid] = $rank;
    }
    return $positions;
}

// ---------- Function to get class size for ranking ----------
function get_class_size($categoryid, $sessionid, $termid) {
    global $DB;
    
    $sql = "SELECT COUNT(DISTINCT r.userid) as total_students
            FROM {local_sis_result} r
            JOIN {course} c ON c.id = r.courseid
            WHERE c.category = :categoryid
            AND r.sessionid = :sessionid
            AND r.termid = :termid";
    
    $result = $DB->get_record_sql($sql, [
        'categoryid' => $categoryid,
        'sessionid' => $sessionid,
        'termid' => $termid
    ]);
    
    return $result ? $result->total_students : 0;
}

// ---------- Helper function to get all class average scores for ranking ----------
function get_class_average_totals($categoryid, $sessionid, $termid): array {
    global $DB;
    
    $sql = "SELECT r.userid, AVG(r.total) as average_score
            FROM {local_sis_result} r
            JOIN {course} c ON c.id = r.courseid
            WHERE c.category = :categoryid
            AND r.sessionid = :sessionid
            AND r.termid = :termid
            GROUP BY r.userid";
    
    $student_averages = $DB->get_records_sql($sql, [
        'categoryid' => $categoryid,
        'sessionid' => $sessionid,
        'termid' => $termid
    ]);
    
    $averages = [];
    foreach ($student_averages as $student) {
        $averages[$student->userid] = (float)$student->average_score;
    }
    return $averages;
}

// ---------- Function to get overall ranking ----------
function get_overall_ranking($userid, $categoryid, $sessionid, $termid) {
    
    $averages = get_class_average_totals($categoryid, $sessionid, $termid);
    
    if (empty($averages)) {
        return '-';
    }
    
    // Rank students
    $positions = local_sis_rank_with_ties($averages);
    return $positions[$userid] ?? '-';
}

// ---------- Function to generate individual student report card HTML ----------
function generate_student_report_card($student, $category, $courses, $has_new_structure, $school_settings, $overall_rank, $class_size, $session_term_info) {
    global $DB, $CFG;
    
    // Get image URLs
    $logopathweb = local_sis_get_school_logo_url();
    $sigpathweb = local_sis_get_principal_signature_url();
    
    // Get student comments
    $student_comments = local_sis_get_student_comments($student->id, $category->id, $session_term_info['sessionid'], $session_term_info['termid']);
    
    $teachercomment = $student_comments->teachercomment ?? '';
    $principalcomment = $student_comments->principalcomment ?? '';
    
    ob_start();
    ?>
    <div class="sis-report-card-wrapper">
        <div class="report-card printable-area" style="page-break-after: always; margin-bottom: 30px; font-family: Arial, Helvetica, sans-serif; font-size: 11px; line-height: 1.3;">
            <div class="report-header" style="text-align: center; margin-bottom: 15px; border-bottom: 2px solid #3f51b5; padding-bottom: 10px;">
                <div style="display: flex; align-items: center; justify-content: center; gap: 10px; flex-wrap: wrap;">
                    <!-- Logo -->
                    <div style="flex-shrink: 0;">
                        <img src="<?php echo s($logopathweb); ?>" 
                             alt="School Logo" 
                             style="height: 60px; max-width: 100px; display: block; border: 1px solid #ddd; background: white;"
                             onerror="this.style.display='none';">
                    </div>
                    <div style="flex: 1; min-width: 200px;">
                        <h2 style="margin: 0; font-size: 18px; color: #3f51b5; font-family: Arial, Helvetica, sans-serif;"><?php echo format_string($school_settings->schoolname ?: 'NDUKS TECH'); ?></h2>
                        <?php if (!empty($school_settings->schooladdress) || !empty($school_settings->schoolmotto)): ?>
                            <div style="margin-top: 5px; font-size: 11px; font-style: italic; font-family: Arial, Helvetica, sans-serif;">
                                <?php if (!empty($school_settings->schooladdress)): ?>
                                    <div><?php echo format_string($school_settings->schooladdress); ?></div>
                                <?php endif; ?>
                                <?php if (!empty($school_settings->schoolmotto)): ?>
                                    <div>Motto: "<?php echo format_string($school_settings->schoolmotto); ?>"</div>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                        <h3 style="margin: 10px 0 0 0; font-size: 14px; font-weight: normal; font-family: Arial, Helvetica, sans-serif;">Student Report Card</h3>
                    </div>
                </div>
            </div>
            
            <div class="report-student-info" style="margin-bottom: 15px; font-family: Arial, Helvetica, sans-serif;">
                <div style="display: flex; justify-content: space-between; margin-bottom: 8px; flex-wrap: wrap; gap: 10px;">
                    <div><strong>Student:</strong> <?php echo format_string(fullname($student)); ?></div>
                    <div><strong>Username:</strong> <?php echo s($student->username); ?></div>
                </div>
                <div style="display: flex; justify-content: space-between; flex-wrap: wrap; gap: 10px;">
                    <div><strong>Class:</strong> <?php echo format_string($category->name); ?></div>
                    <div><strong>Term/Session:</strong> <?php echo $session_term_info['termname'] . ', ' . $session_term_info['sessionname']; ?></div>
                </div>
                <div style="text-align: right; font-size: 10px; color: #666; margin-top: 5px;"><?php echo date('F j, Y'); ?></div>
            </div>
            
            <div class="report-table-container" style="margin-bottom: 15px; overflow-x: auto;">
                <table class="report-table" style="width: 100%; border-collapse: collapse; font-size: 11px; font-family: Arial, Helvetica, sans-serif; table-layout: fixed;">
                    <thead>
                        <tr style="background-color: #3f51b5; color: white;">
                            <th style="border: 1px solid #ddd; padding: 5px; width: 35%; word-wrap: break-word;">Subject</th>
                            <?php
                            // Component names are dynamic based on the first available course
                            if (!empty($courses)) {
                                $first_course_id = reset($courses)->id;
                                $component_names = local_sis_get_component_names($first_course_id, $session_term_info['sessionid'], $session_term_info['termid']);
                            } else {
                                $component_names = ['CA1', 'CA2', 'Exam'];
                            }

                            foreach ($component_names as $component_name) {
                                echo '<th style="border: 1px solid #ddd; padding: 5px; width: 6%; word-wrap: break-word;">' . $component_name . '</th>';
                            }
                            ?>
                            <th style="border: 1px solid #ddd; padding: 5px; width: 6%; word-wrap: break-word;">Total</th>
                            <th style="border: 1px solid #ddd; padding: 5px; width: 6%; word-wrap: break-word;">Grade</th>
                            <th style="border: 1px solid #ddd; padding: 5px; width: 6%; word-wrap: break-word;">Points</th>
                            <th style="border: 1px solid #ddd; padding: 5px; width: 10%; word-wrap: break-word;">Position</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    foreach ($courses as $course) {
                        $res = $DB->get_record('local_sis_result', [
                            'userid' => $student->id, 
                            'courseid' => $course->id,
                            'sessionid' => $session_term_info['sessionid'],
                            'termid' => $session_term_info['termid']
                        ]);
                        
                        // Handle missing result for a course gracefully
                        if (!$res) {
                            echo '<tr><td style="border: 1px solid #ddd; padding: 5px; word-wrap: break-word;">' . format_string($course->fullname) . '</td>';
                            $course_component_names = local_sis_get_component_names($course->id, $session_term_info['sessionid'], $session_term_info['termid']);
                            foreach ($course_component_names as $c) echo '<td style="border: 1px solid #ddd; padding: 5px; text-align: center;">-</td>';
                            echo '<td style="border: 1px solid #ddd; padding: 5px; text-align: center;">-</td>';
                            echo '<td style="border: 1px solid #ddd; padding: 5px; text-align: center;">-</td>';
                            echo '<td style="border: 1px solid #ddd; padding: 5px; text-align: center;">-</td>';
                            echo '<td style="border: 1px solid #ddd; padding: 5px; text-align: center;">-</td></tr>';
                            continue;
                        }
                        
                        $component_names = local_sis_get_component_names($course->id, $session_term_info['sessionid'], $session_term_info['termid']);

                        if ($has_new_structure) {
                            $component_data = !empty($res->data) ? json_decode($res->data, true) : [];
                            $total = $res->total; 
                            $grade = $res->grade; 
                            $points = $res->points;
                        } else {
                            $component_data = [ $res->firstca ?? 0, $res->secondca ?? 0, $res->exam ?? 0 ];
                            $total = $res->total; 
                            $grade = $res->grade; 
                            $points = 0;
                        }
                        
                        // ranking logic for single student view
                        $all = $DB->get_records('local_sis_result', [
                            'courseid' => $course->id,
                            'sessionid' => $session_term_info['sessionid'],
                            'termid' => $session_term_info['termid']
                        ], '', 'userid, total');
                        
                        $posdisplay = '-';
                        if (!empty($all)) {
                            $totals = [];
                            foreach ($all as $uid => $obj) $totals[$uid] = (float)$obj->total;
                            $positions = local_sis_rank_with_ties($totals);
                            $pos = $positions[$student->id] ?? '-';
                            $classsize_subject = count($totals);
                            $countbypos = array_count_values($positions);
                            
                            $posdisplay = is_numeric($pos) ? (string)$pos : '-';
                            if (is_numeric($pos) && $countbypos[$pos] > 1) $posdisplay .= ' (tie)';
                            $posdisplay .= ' of ' . $classsize_subject;
                        }

                        echo '<tr>';
                        echo '<td style="border: 1px solid #ddd; padding: 5px; word-wrap: break-word;">' . format_string($course->fullname) . '</td>';
                        // Display scores for components
                        foreach ($component_names as $index => $name) {
                            $score = 0;
                            if (!$has_new_structure) {
                                if ($index == 0) $score = $res->firstca ?? 0;
                                else if ($index == 1) $score = $res->secondca ?? 0;
                                else if ($index == 2) $score = $res->exam ?? 0;
                            } else {
                                $score = $component_data[$index] ?? 0;
                            }
                            
                            echo '<td style="border: 1px solid #ddd; padding: 5px; text-align: center;">' . (is_numeric($score) && $score > 0 ? format_float($score, 1) : '-') . '</td>';
                        }
                        echo '<td style="border: 1px solid #ddd; padding: 5px; text-align: center; font-weight: bold;">' . format_float($total, 1) . '</td>';
                        echo '<td style="border: 1px solid #ddd; padding: 5px; text-align: center;">' . ($grade ?: '-') . '</td>';
                        echo '<td style="border: 1px solid #ddd; padding: 5px; text-align: center;">' . format_float($points, 1) . '</td>';
                        echo '<td style="border: 1px solid #ddd; padding: 5px; text-align: center;">' . $posdisplay . '</td>';
                        echo '</tr>';
                    }
                    ?>
                    </tbody>
                </table>
            </div>
            
            <?php
            // overall stats
            $studentsubjecttotals = [];
            $total_score = 0;
            foreach ($courses as $course) {
                $res = $DB->get_record('local_sis_result', [
                    'userid' => $student->id, 
                    'courseid' => $course->id,
                    'sessionid' => $session_term_info['sessionid'],
                    'termid' => $session_term_info['termid']
                ]);
                if ($res && is_numeric($res->total)) {
                    $studentsubjecttotals[] = (float)$res->total;
                    $total_score += (float)$res->total;
                }
            }
            $overall_avg = '-';
            $hi = '-';
            $lo = '-';
            $total_score_display = '-';
            if (!empty($studentsubjecttotals)) {
                $overall_avg = array_sum($studentsubjecttotals) / count($studentsubjecttotals);
                $hi  = max($studentsubjecttotals);
                $lo  = min($studentsubjecttotals);
                $total_score_display = number_format($total_score, 1);
            }
            
            echo '<div class="report-summary" style="margin-bottom: 15px; padding: 10px; background-color: #f5f5f5; border-radius: 5px; font-family: Arial, Helvetica, sans-serif;">';
            echo '<h4 style="margin: 0 0 8px 0; font-size: 12px; color: #3f51b5; font-family: Arial, Helvetica, sans-serif;">Performance Summary</h4>';
            echo '<div style="display: flex; flex-wrap: wrap; gap: 15px; justify-content: space-between;">';
            echo '<div><strong>Total Score:</strong> ' . $total_score_display . '</div>';
            echo '<div><strong>Average Score:</strong> ' . format_float($overall_avg, 1) . '</div>';
            echo '<div><strong>Highest Score:</strong> ' . format_float($hi, 1) . '</div>';
            
            // Overall class rank
            $rank_text = is_numeric($overall_rank) ? (string)$overall_rank : '-';
            if (is_numeric($overall_rank)) {
                $class_averages = get_class_average_totals($category->id, $session_term_info['sessionid'], $session_term_info['termid']);
                $positions = local_sis_rank_with_ties($class_averages);
                $countbypos = array_count_values($positions);
                if (!empty($countbypos[$overall_rank]) && $countbypos[$overall_rank] > 1) $rank_text .= ' (tie)';
            }
            
            echo '<div><strong>Class Position:</strong> ' . $rank_text . ' of ' . $class_size . '</div>';
            echo '</div>';
            echo '<div style="display: flex; gap: 15px; margin-top: 5px;">';
            echo '<div><strong>Lowest Score:</strong> ' . format_float($lo, 1) . '</div>';
            echo '</div>';
            echo '</div>';
            ?>

            <div class="report-comments" style="margin: 15px 0; padding: 10px; border: 1px solid #e0e0e0; border-radius: 5px; background-color: #f9f9f9; font-family: Arial, Helvetica, sans-serif;">
                <h4 style="margin: 0 0 10px 0; padding-bottom: 5px; border-bottom: 1px solid #3f51b5; color: #3f51b5; font-size: 12px; font-family: Arial, Helvetica, sans-serif;">Comments</h4>
                
                <div class="comment-section" style="display: flex; gap: 15px; flex-wrap: wrap;">
                    <div class="comment-block" style="flex: 1; min-width: 250px; padding: 10px; background: white; border-radius: 5px; border-left: 3px solid #4caf50;">
                        <h5 style="margin: 0 0 8px 0; color: #4caf50; font-size: 11px; font-family: Arial, Helvetica, sans-serif;">Teacher's Comment:</h5>
                        <div class="comment-content" style="padding: 8px; background: #f8f9fa; border-radius: 3px; border: 1px solid #e9ecef; min-height: 60px; font-style: italic; font-size: 11px; line-height: 1.4; font-family: Arial, Helvetica, sans-serif;">
                            <?php echo !empty($teachercomment) ? format_text($teachercomment) : '<span style="color: #6c757d;">No comment provided</span>'; ?>
                        </div>
                    </div>
                    
                    <div class="comment-block" style="flex: 1; min-width: 250px; padding: 10px; background: white; border-radius: 5px; border-left: 3px solid #ff9800;">
                        <h5 style="margin: 0 0 8px 0; color: #ff9800; font-size: 11px; font-family: Arial, Helvetica, sans-serif;">Principal's Comment:</h5>
                        <div class="comment-content" style="padding: 8px; background: #f8f9fa; border-radius: 3px; border: 1px solid #e9ecef; min-height: 60px; font-style: italic; font-size: 11px; line-height: 1.4; font-family: Arial, Helvetica, sans-serif;">
                            <?php echo !empty($principalcomment) ? format_text($principalcomment) : '<span style="color: #6c757d;">No comment provided</span>'; ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="report-footer" style="text-align: center; margin-top: 40px; padding-top: 20px; border-top: 1px solid #e0e0e0; font-family: Arial, Helvetica, sans-serif;">
                <div class="signature-block" style="display: inline-block; text-align: center; margin: 0 auto;">
                    <img src="<?php echo s($sigpathweb); ?>" 
                         alt="Principal's Signature" 
                         style="height: 50px; margin-bottom: 8px; display: block; margin-left: auto; margin-right: auto; border: 1px solid #ddd; background: white;"
                         onerror="this.style.display='none';">
                    <div style="font-size: 11px; font-weight: bold; text-align: center;">Principal's Signature</div>
                </div>
            </div>

            <div class="plugin-footer" style="text-align: center; margin-top: 15px; padding-top: 10px; border-top: 1px solid #e0e0e0; font-size: 9px; color: #666; font-family: Arial, Helvetica, sans-serif;">
                ndukstech sis plugin    facebook.com/ndukshub
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

// ========== MAIN EXECUTION ==========

// Get school settings
$school_settings = local_sis_get_school_settings();

// Get session and term information
$session_term_info = local_sis_get_session_term_info($sessionid, $termid);

echo $OUTPUT->header();
?>

<div class="sis-report-card-container">
    <div class="sis-controls no-print" style="margin-bottom: 20px; padding: 15px; background-color: #f8f9fa; border-radius: 5px;">
        <h4>View My Results</h4>
        <p>Select the academic session and term to view your results.</p>
        
        <form method="get" action="" class="form-inline">
            <div style="display: grid; grid-template-columns: 1fr 1fr auto; gap: 10px; align-items: end;">
                <div>
                    <label for="sessionid" style="display: block; margin-bottom: 5px; font-weight: bold;">Session:</label>
                    <select name="sessionid" id="sessionid" class="form-control">
                        <option value="">Select Session</option>
                        <?php foreach ($session_term_info['sessions'] as $s): ?>
                            <option value="<?php echo $s->id; ?>" 
                                <?php echo $session_term_info['sessionid'] == $s->id ? 'selected' : ''; ?>>
                                <?php echo format_string($s->sessionname); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div>
                    <label for="termid" style="display: block; margin-bottom: 5px; font-weight: bold;">Term:</label>
                    <select name="termid" id="termid" class="form-control">
                        <option value="">Select Term</option>
                        <?php foreach ($session_term_info['terms'] as $t): ?>
                            <option value="<?php echo $t->id; ?>" 
                                <?php echo $session_term_info['termid'] == $t->id ? 'selected' : ''; ?>>
                                <?php echo format_string($t->termname); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div>
                    <button type="submit" class="btn btn-primary">View My Results</button>
                </div>
            </div>
        </form>
    </div>

<?php
// Check if session and term are selected
if ($sessionid && $termid) {
    // Get student's class and courses
    $student_class = get_student_class($userid, $sessionid, $termid);
    $courses = get_student_courses($userid, $sessionid, $termid);
    
    if (!$student_class || empty($courses)) {
        echo '<div class="alert alert-warning">No results found for the selected session and term.</div>';
    } else {
        // Check if student has permission to view results
        $has_permission = can_student_view_results($userid, $student_class->id, $sessionid, $termid);
        
        if (!$has_permission) {
            echo '<div class="alert alert-danger" style="text-align: center;">';
            echo '<h4>Access Denied</h4>';
            echo '<p>You do not have permission to view results for ' . $session_term_info['termname'] . ', ' . $session_term_info['sessionname'] . '.</p>';
            echo '<p>Please contact your administrator if you believe this is an error.</p>';
            echo '</div>';
        } else {
            // Get class size and overall ranking
            $class_size = get_class_size($student_class->id, $sessionid, $termid);
            $overall_rank = get_overall_ranking($userid, $student_class->id, $sessionid, $termid);
            
            // Check DB structure
            $columns = $DB->get_columns('local_sis_result');
            $has_new_structure = array_key_exists('data', $columns);
            
            // Get current user
            $student = $USER;
            
            // Display the report card
            echo generate_student_report_card($student, $student_class, $courses, $has_new_structure, $school_settings, $overall_rank, $class_size, $session_term_info);
            
            // Print button
            echo '<div style="text-align: center; margin: 20px 0;" class="no-print">';
            echo '<button class="btn btn-primary" onclick="window.print()">';
            echo '<i class="fa fa-print"></i> Print Result';
            echo '</button>';
            echo '</div>';
        }
    }
} else {
    echo '<div class="alert alert-info" style="text-align: center;">';
    echo '<h4>Select Session and Term</h4>';
    echo '<p>Please select a Session and Term from the dropdown menus above to view your results.</p>';
    echo '</div>';
}
?>

</div>

<style>
.sis-report-card-wrapper {
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    margin: 20px 0;
    padding: 20px;
    background: white;
    font-family: Arial, Helvetica, sans-serif;
}

/* Print styles */
@media print {
    body * {
        visibility: hidden;
    }
    .printable-area, .printable-area * {
        visibility: visible;
        margin: 0;
        padding: 0;
    }
    .printable-area {
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
        font-family: Arial, Helvetica, sans-serif !important;
    }
    .no-print {
        display: none !important;
    }
    .report-table {
        page-break-inside: avoid;
    }
    .report-card {
        page-break-after: always;
    }
}

/* Browser compatibility fixes */
.report-table {
    border-collapse: collapse;
    width: 100%;
}

.report-table th,
.report-table td {
    border: 1px solid #ddd;
    padding: 5px;
    vertical-align: top;
}

/* Ensure images don't break layout */
img {
    max-width: 100%;
    height: auto;
}
</style>

<script>
// Additional browser compatibility
document.addEventListener('DOMContentLoaded', function() {
    // Handle image loading errors
    var images = document.querySelectorAll('img');
    images.forEach(function(img) {
        img.addEventListener('error', function() {
            this.style.display = 'none';
        });
    });
});
</script>

<?php
echo $OUTPUT->footer();