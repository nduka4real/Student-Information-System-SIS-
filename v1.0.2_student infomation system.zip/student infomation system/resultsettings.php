<?php
// This file is part of the Student Information System plugin for Moodle.
// this is used to set up the result card settings
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version information for the Student Information System plugin
 *
 * @package    local_sis
 * @copyright  2025 NduksTech - https://facebook.com/ndukshub
 * @author     Nduka Akapti  (https://github.com/nduka4real)
 * @author     Ndukstech (https://www.youtube.com/@nduks-tech)
 * @author     https://www.linkedin.com/in/ndukaakpati/
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @details
 * Display Name: Student Information System
 * Description: A comprehensive system for managing student records, assessments, fees, and school operations.
 * Contact: https://github.com/nduka4real
 * Social: https://facebook.com/ndukshub
 */

require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/formslib.php');
require_login();

$context = context_system::instance();
$PAGE->set_context($context);
$PAGE->set_url(new moodle_url('/local/sis/resultsettings.php'));
$PAGE->set_title("School Settings");
$PAGE->set_heading("School Settings");

// Only admins
require_capability('moodle/site:config', $context);

global $DB, $CFG;

// Define file areas
$filearea_logo = 'schoollogo';
$filearea_signature = 'principalsignature';

// 1. Check if our table exists
$dbman = $DB->get_manager();
$table = new xmldb_table('local_sis_school_settings');
if (!$dbman->table_exists($table)) {
    debugging('Table local_sis_school_settings does not exist.', DEBUG_DEVELOPER);
}

// 2. Fetch current settings from the new table.
$settings = $DB->get_record('local_sis_school_settings', array('id' => 1));
if (!$settings) {
    $settings = (object) [
        'id' => null,
        'schoolname' => '',
        'schooladdress' => '',
        'schoolmotto' => '',
        'phone' => '',
        'state' => '',
        'country' => 'US',
        'timemodified' => time()
    ];
}

/**
 * School settings form class
 */
class local_sis_school_settings_form extends moodleform {
    
    protected function definition() {
        global $settings;
        
        $mform = $this->_form;
        
        // School name
        $mform->addElement('text', 'schoolname', 'School Name');
        $mform->setType('schoolname', PARAM_TEXT);
        $mform->setDefault('schoolname', $settings->schoolname);
        $mform->addRule('schoolname', 'This field is required', 'required', null, 'client');
        
        // School Address
        $mform->addElement('textarea', 'schooladdress', 'School Address');
        $mform->setType('schooladdress', PARAM_TEXT);
        $mform->setDefault('schooladdress', $settings->schooladdress);
        
        // School Motto
        $mform->addElement('textarea', 'schoolmotto', 'School Motto');
        $mform->setType('schoolmotto', PARAM_TEXT);
        $mform->setDefault('schoolmotto', $settings->schoolmotto);
        
        // Phone Number
        $mform->addElement('text', 'phone', 'Phone Number');
        $mform->setType('phone', PARAM_TEXT);
        $mform->setDefault('phone', $settings->phone);
        
        // State
        $mform->addElement('text', 'state', 'State/Province');
        $mform->setType('state', PARAM_TEXT);
        $mform->setDefault('state', $settings->state);
        
        // Country with Dropdown
        $countries = get_string_manager()->get_list_of_countries();
        $mform->addElement('select', 'country', 'Country', $countries);
        $mform->setDefault('country', $settings->country);
        
        // Logo file manager
        $mform->addElement('filemanager', 'schoollogo_filemanager', 'School Logo', 
            null, array(
                'subdirs' => 0,
                'maxfiles' => 1,
                'accepted_types' => array('png', 'jpg', 'jpeg', 'gif')
            ));
        
        // Signature file manager
        $mform->addElement('filemanager', 'principalsignature_filemanager', 'Principal Signature', 
            null, array(
                'subdirs' => 0,
                'maxfiles' => 1,
                'accepted_types' => array('png', 'jpg', 'jpeg', 'gif')
            ));
        
        $this->add_action_buttons();
    }
}

// Create form instance
$mform = new local_sis_school_settings_form();

// Handle form submission
if ($mform->is_cancelled()) {
    redirect(new moodle_url('/local/sis/index.php'));
} else if ($data = $mform->get_data()) {
    
    // Prepare settings object - ONLY text fields
    $updatedsettings = new stdClass();
    $updatedsettings->schoolname = $data->schoolname;
    $updatedsettings->schooladdress = $data->schooladdress;
    $updatedsettings->schoolmotto = $data->schoolmotto;
    $updatedsettings->phone = $data->phone;
    $updatedsettings->state = $data->state;
    $updatedsettings->country = $data->country;
    $updatedsettings->timemodified = time();

    try {
        // Check if record exists
        $existing = $DB->get_record('local_sis_school_settings', array('id' => 1));
        
        if ($existing) {
            // Update existing record
            $updatedsettings->id = 1;
            $result = $DB->update_record('local_sis_school_settings', $updatedsettings);
            \core\notification::success('Settings updated successfully.');
        } else {
            // Insert new record - let auto_increment handle the ID
            $result = $DB->insert_record('local_sis_school_settings', $updatedsettings);
            \core\notification::success('Settings created successfully.');
        }

        // Save files using File API - always use itemid = 1
        if ($result) {
            file_save_draft_area_files($data->schoollogo_filemanager, $context->id, 'local_sis', 
                $filearea_logo, 1, array(
                    'subdirs' => 0,
                    'maxfiles' => 1,
                    'accepted_types' => array('png', 'jpg', 'jpeg', 'gif')
                ));
            
            file_save_draft_area_files($data->principalsignature_filemanager, $context->id, 'local_sis', 
                $filearea_signature, 1, array(
                    'subdirs' => 0,
                    'maxfiles' => 1,
                    'accepted_types' => array('png', 'jpg', 'jpeg', 'gif')
                ));
            
        } else {
            \core\notification::error('Failed to save settings to database.');
        }
        
    } catch (Exception $e) {
        \core\notification::error('Error saving settings: ' . $e->getMessage());
    }
    
    redirect($PAGE->url);
}

// Prepare file manager data before displaying form
$draftitemid_logo = file_get_submitted_draft_itemid('schoollogo_filemanager');
$draftitemid_signature = file_get_submitted_draft_itemid('principalsignature_filemanager');

file_prepare_draft_area($draftitemid_logo, $context->id, 'local_sis', $filearea_logo, 
    1, array(
        'subdirs' => 0,
        'maxfiles' => 1,
        'accepted_types' => array('png', 'jpg', 'jpeg', 'gif')
    ));

file_prepare_draft_area($draftitemid_signature, $context->id, 'local_sis', $filearea_signature, 
    1, array(
        'subdirs' => 0,
        'maxfiles' => 1,
        'accepted_types' => array('png', 'jpg', 'jpeg', 'gif')
    ));

// Set draft item IDs for the form
$settings->schoollogo_filemanager = $draftitemid_logo;
$settings->principalsignature_filemanager = $draftitemid_signature;

$mform->set_data($settings);

// ---- Output page ----
echo $OUTPUT->header();
echo $OUTPUT->heading("School Settings");

// Current values card
echo html_writer::start_div('card p-3 mb-3 bg-light');
echo html_writer::tag('h5', 'Current Settings', ['class' => 'text-primary mb-3']);

echo html_writer::div('School Name: <b>' . s($settings->schoolname) . '</b>', 'mb-2');
echo html_writer::div('School Address: <b>' . s($settings->schooladdress) . '</b>', 'mb-2');
echo html_writer::div('School Motto: <i>"' . s($settings->schoolmotto) . '"</i>', 'mb-2');
echo html_writer::div('Phone: <b>' . s($settings->phone) . '</b>', 'mb-2');
echo html_writer::div('State: <b>' . s($settings->state) . '</b>', 'mb-2');
echo html_writer::div('Country: <b>' . s($settings->country) . '</b>', 'mb-3');

// Display current logo and signature from File API
$fs = get_file_storage();

// Display current logo
if ($files = $fs->get_area_files($context->id, 'local_sis', $filearea_logo, 1, "filename", false)) {
    $file = reset($files);
    $url = moodle_url::make_pluginfile_url($file->get_contextid(), $file->get_component(), 
        $file->get_filearea(), $file->get_itemid(), $file->get_filepath(), 
        $file->get_filename(), false);
    echo html_writer::div('Current School Logo:', 'mt-2 mb-1');
    echo html_writer::empty_tag('img', [
        'src' => $url,
        'class' => 'img-thumbnail d-block mb-2',
        'style' => 'max-width:200px; max-height:100px;',
        'alt' => 'School Logo'
    ]);
} else {
    echo html_writer::div('No school logo uploaded', 'text-muted mb-2');
}

// Display current signature
if ($files = $fs->get_area_files($context->id, 'local_sis', $filearea_signature, 1, "filename", false)) {
    $file = reset($files);
    $url = moodle_url::make_pluginfile_url($file->get_contextid(), $file->get_component(), 
        $file->get_filearea(), $file->get_itemid(), $file->get_filepath(), 
        $file->get_filename(), false);
    echo html_writer::div('Current Principal Signature:', 'mt-2 mb-1');
    echo html_writer::empty_tag('img', [
        'src' => $url,
        'class' => 'img-thumbnail d-block mb-2',
        'style' => 'max-width:200px; max-height:100px;',
        'alt' => 'Principal Signature'
    ]);
} else {
    echo html_writer::div('No principal signature uploaded', 'text-muted mb-2');
}
echo html_writer::end_div();

// Display form
$mform->display();

// Back to Dashboard button
echo html_writer::div(
    html_writer::link(
        new moodle_url('/local/sis/index.php'),
        'Back to Main Dashboard',
        ['class' => 'btn btn-success mb-3']
    ),
    'text-center mt-3'
);

echo $OUTPUT->footer();