<?php
// This file is part of the Student Information System plugin for Moodle.
// this file is used to manage admissin forms
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version information for the Student Information System plugin
 *
 * @package    local_sis
 * @copyright  2025 NduksTech - https://facebook.com/ndukshub
 * @author     Nduka Akapti  (https://github.com/nduka4real)
 * @author     Ndukstech (https://www.youtube.com/@nduks-tech)
 * @author     https://www.linkedin.com/in/ndukaakpati/
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @details
 * Display Name: Student Information System
 * Description: A comprehensive system for managing student records, assessments, fees, and school operations.
 * Contact: https://github.com/nduka4real
 * Social: https://facebook.com/ndukshub
 */

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir . '/formslib.php');

class local_sis_admission_form extends moodleform {
    
    protected function definition() {
        global $DB, $CFG;
        
        $mform = $this->_form;
        
        // Personal Information
        $mform->addElement('header', 'personalinfo', get_string('personalinformation', 'local_sis'));
        
        $mform->addElement('text', 'firstname', get_string('firstname'), 'maxlength="100" size="30"');
        $mform->setType('firstname', PARAM_TEXT);
        $mform->addRule('firstname', get_string('required'), 'required', null, 'client');
        
        $mform->addElement('text', 'lastname', get_string('lastname'), 'maxlength="100" size="30"');
        $mform->setType('lastname', PARAM_TEXT);
        $mform->addRule('lastname', get_string('required'), 'required', null, 'client');
        
        $mform->addElement('text', 'email', get_string('email'), 'maxlength="100" size="30"');
        $mform->setType('email', PARAM_EMAIL);
        $mform->addRule('email', get_string('required'), 'required', null, 'client');
        
        $mform->addElement('text', 'phone', get_string('phone'), 'maxlength="20" size="20"');
        $mform->setType('phone', PARAM_TEXT);
        
        // Academic Information
        $mform->addElement('header', 'academicinfo', get_string('academicinformation', 'local_sis'));
        
        $programs = $this->get_programs();
        $mform->addElement('select', 'program', get_string('program', 'local_sis'), $programs);
        $mform->setType('program', PARAM_TEXT);
        $mform->addRule('program', get_string('required'), 'required', null, 'client');
        
        $departments = $this->get_departments();
        $mform->addElement('select', 'department', get_string('department', 'local_sis'), $departments);
        $mform->setType('department', PARAM_TEXT);
        
        $mform->addElement('date_selector', 'expected_graduation', get_string('expectedgraduation', 'local_sis'));
        
        // Emergency Contact
        $mform->addElement('header', 'emergencyinfo', get_string('emergencycontact', 'local_sis'));
        
        $mform->addElement('text', 'emergency_name', get_string('emergencyname', 'local_sis'), 'maxlength="100" size="30"');
        $mform->setType('emergency_name', PARAM_TEXT);
        
        $mform->addElement('text', 'emergency_relationship', get_string('relationship', 'local_sis'), 'maxlength="50" size="20"');
        $mform->setType('emergency_relationship', PARAM_TEXT);
        
        $mform->addElement('text', 'emergency_phone', get_string('emergencyphone', 'local_sis'), 'maxlength="20" size="20"');
        $mform->setType('emergency_phone', PARAM_TEXT);
        
        // Medical Information
        $mform->addElement('header', 'medicalinfo', get_string('medicalinformation', 'local_sis'));
        
        $mform->addElement('textarea', 'medical_info', get_string('medicalinfo', 'local_sis'), 'rows="3" cols="50"');
        $mform->setType('medical_info', PARAM_TEXT);
        
        // Course Enrollment
        $mform->addElement('header', 'enrollmentinfo', get_string('courseenrollment', 'local_sis'));
        
        $courses = $this->get_available_courses();
        $mform->addElement('select', 'enroll_courses', get_string('selectcourses', 'local_sis'), $courses);
        $mform->setType('enroll_courses', PARAM_INT);
        $mform->getElement('enroll_courses')->setMultiple(true);
        $mform->getElement('enroll_courses')->setSize(8);
        
        // Submit buttons
        $this->add_action_buttons(true, get_string('admitstudent', 'local_sis'));
    }
    
    public function validation($data, $files) {
        $errors = parent::validation($data, $files);
        
        // Validate email format
        if (!validate_email($data['email'])) {
            $errors['email'] = get_string('invalidemail');
        }
        
        // Check if email already exists
        if ($this->email_exists($data['email'])) {
            $errors['email'] = get_string('emailexists', 'local_sis');
        }
        
        // Validate expected graduation date
        if ($data['expected_graduation'] < time()) {
            $errors['expected_graduation'] = get_string('invalidgraduationdate', 'local_sis');
        }
        
        return $errors;
    }
    
    private function get_programs() {
        // You can replace this with actual program data from your system
        return [
            'bs_computer_science' => 'Bachelor of Science in Computer Science',
            'bs_business_admin' => 'Bachelor of Science in Business Administration',
            'ba_psychology' => 'Bachelor of Arts in Psychology',
            'bs_engineering' => 'Bachelor of Science in Engineering'
        ];
    }
    
    private function get_departments() {
        // You can replace this with actual department data from your system
        return [
            'computer_science' => 'Computer Science',
            'business' => 'Business Administration',
            'psychology' => 'Psychology',
            'engineering' => 'Engineering',
            'mathematics' => 'Mathematics'
        ];
    }
    
    private function get_available_courses() {
        global $DB;
        
        $courses = $DB->get_records('course', ['visible' => 1], 'fullname', 'id, fullname, shortname');
        $courseoptions = [];
        
        foreach ($courses as $course) {
            $courseoptions[$course->id] = $course->fullname . ' (' . $course->shortname . ')';
        }
        
        return $courseoptions;
    }
    
    private function email_exists($email) {
        global $DB;
        return $DB->record_exists('user', ['email' => $email, 'deleted' => 0]);
    }
}