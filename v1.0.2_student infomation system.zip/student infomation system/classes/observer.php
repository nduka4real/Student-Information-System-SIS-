<?php
// This file is part of the Student Information System plugin for Moodle.
// This file is used to observer events changes
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version information for the Student Information System plugin
 *
 * @package    local_sis
 * @copyright  2025 NduksTech - https://facebook.com/ndukshub
 * @author     Nduka Akapti  (https://github.com/nduka4real)
 * @author     Ndukstech (https://www.youtube.com/@nduks-tech)
 * @author     https://www.linkedin.com/in/ndukaakpati/
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @details
 * Display Name: Student Information System
 * Description: A comprehensive system for managing student records, assessments, fees, and school operations.
 * Contact: https://github.com/nduka4real
 * Social: https://facebook.com/ndukshub
 */

defined('MOODLE_INTERNAL') || die();

class local_sis_observer {

    /**
     * Handle quiz submission events
     *
     * @param \mod_quiz\event\attempt_submitted $event
     * @return bool
     */
    public static function quiz_submitted(\mod_quiz\event\attempt_submitted $event) {
        global $DB;

        $quizid   = $event->other['quizid'];
        $userid   = $event->relateduserid;
        $courseid = $event->courseid;

        // Check if this quiz is mapped in local_sis_quizmap
        $map = $DB->get_record('local_sis_quizmap', ['courseid' => $courseid]);
        if (!$map) {
            return true;
        }

        $firstca = $secondca = $exam = 0;

        // Get student's quiz grade
        $grade = $DB->get_record('quiz_grades', ['quiz' => $quizid, 'userid' => $userid]);

        if (!$grade) {
            return true; // No grade yet
        }

        // Determine where this quiz should go
        if ($map->firstcaquiz == $quizid) {
            $firstca = $grade->grade;
        }
        if ($map->secondcaquiz == $quizid) {
            $secondca = $grade->grade;
        }
        if ($map->examquiz == $quizid) {
            $exam = $grade->grade;
        }

        // Get existing record or create new
        $record = $DB->get_record('local_sis_result', [
            'userid' => $userid,
            'courseid' => $courseid
        ]);

        if ($record) {
            if ($map->firstcaquiz == $quizid) $record->firstca = $firstca;
            if ($map->secondcaquiz == $quizid) $record->secondca = $secondca;
            if ($map->examquiz == $quizid) $record->exam = $exam;

            $record->total = ($record->firstca ?? 0) + ($record->secondca ?? 0) + ($record->exam ?? 0);
            $record->grade = local_sis_calculate_grade($record->total);
            $record->timemodified = time();

            $DB->update_record('local_sis_result', $record);

        } else {
            $new = (object)[
                'userid' => $userid,
                'courseid' => $courseid,
                'firstca' => $firstca,
                'secondca' => $secondca,
                'exam' => $exam,
                'total' => $firstca + $secondca + $exam,
                'grade' => local_sis_calculate_grade($firstca + $secondca + $exam),
                'timemodified' => time()
            ];
            $DB->insert_record('local_sis_result', $new);
        }

        return true;
    }

    /**
     * Handle quiz grading events - unified handler for both submission and grading
     *
     * @param \mod_quiz\event\attempt_submitted|\mod_quiz\event\attempt_graded $event
     * @return bool
     */
    public static function quiz_updated($event) {
        global $DB, $USER;

        try {
            // Get event data
            $eventdata = $event->get_data();
            
            // Log the event for debugging
            debugging("SIS Observer: Quiz event triggered - " . $event->eventname, DEBUG_DEVELOPER);

            // Get the quiz attempt
            $attemptid = $eventdata['objectid'];
            $attempt = $DB->get_record('quiz_attempts', ['id' => $attemptid]);
            
            if (!$attempt) {
                return false;
            }

            // Get the quiz
            $quiz = $DB->get_record('quiz', ['id' => $attempt->quiz]);
            
            if (!$quiz) {
                return false;
            }

            // Get the course module
            $cm = get_coursemodule_from_instance('quiz', $quiz->id, $quiz->course);
            
            if (!$cm) {
                return false;
            }

            // Call your existing quiz submission logic
            self::quiz_submitted_integrated($attempt, $quiz, $cm, $event);
            
            // Additional functionality: Update assessment records
            self::update_assessment_record($attempt, $quiz, $cm);
            
            // Additional functionality: Log activity
            self::log_assessment_activity($attempt->userid, $quiz->course, $quiz->id, $event->eventname);

            return true;

        } catch (\Exception $e) {
            // Log any errors
            debugging("SIS Observer Error: " . $e->getMessage(), DEBUG_NORMAL);
            return false;
        }
    }

    /**
     * Integrated version of quiz_submitted that works with attempt data
     *
     * @param object $attempt Quiz attempt record
     * @param object $quiz Quiz record
     * @param object $cm Course module record
     * @param object $event Event object
     */
    private static function quiz_submitted_integrated($attempt, $quiz, $cm, $event) {
        global $DB;

        $quizid   = $quiz->id;
        $userid   = $attempt->userid;
        $courseid = $quiz->course;

        // Check if this quiz is mapped in local_sis_quizmap
        $map = $DB->get_record('local_sis_quizmap', ['courseid' => $courseid]);
        if (!$map) {
            return true;
        }

        $firstca = $secondca = $exam = 0;

        // Get student's quiz grade - use the attempt data
        $grade = $DB->get_record('quiz_grades', ['quiz' => $quizid, 'userid' => $userid]);

        if (!$grade) {
            // If no grade record exists yet, we might need to calculate from attempt
            if ($attempt->state === 'finished') {
                // For immediate grading, we can use the sumgrades
                $calculated_grade = quiz_rescale_grade($attempt->sumgrades, $quiz, false);
                if ($calculated_grade !== null) {
                    $firstca = $secondca = $exam = 0;
                    
                    // Determine where this quiz should go
                    if ($map->firstcaquiz == $quizid) {
                        $firstca = $calculated_grade;
                    }
                    if ($map->secondcaquiz == $quizid) {
                        $secondca = $calculated_grade;
                    }
                    if ($map->examquiz == $quizid) {
                        $exam = $calculated_grade;
                    }
                }
            }
            return true; // No grade yet or couldn't calculate
        } else {
            // Use the actual grade from quiz_grades table
            if ($map->firstcaquiz == $quizid) {
                $firstca = $grade->grade;
            }
            if ($map->secondcaquiz == $quizid) {
                $secondca = $grade->grade;
            }
            if ($map->examquiz == $quizid) {
                $exam = $grade->grade;
            }
        }

        // Get existing record or create new
        $record = $DB->get_record('local_sis_result', [
            'userid' => $userid,
            'courseid' => $courseid
        ]);

        if ($record) {
            if ($map->firstcaquiz == $quizid) $record->firstca = $firstca;
            if ($map->secondcaquiz == $quizid) $record->secondca = $secondca;
            if ($map->examquiz == $quizid) $record->exam = $exam;

            $record->total = ($record->firstca ?? 0) + ($record->secondca ?? 0) + ($record->exam ?? 0);
            $record->grade = local_sis_calculate_grade($record->total);
            $record->timemodified = time();

            $DB->update_record('local_sis_result', $record);

        } else {
            $new = (object)[
                'userid' => $userid,
                'courseid' => $courseid,
                'firstca' => $firstca,
                'secondca' => $secondca,
                'exam' => $exam,
                'total' => $firstca + $secondca + $exam,
                'grade' => local_sis_calculate_grade($firstca + $secondca + $exam),
                'timecreated' => time(),
                'timemodified' => time()
            ];
            $DB->insert_record('local_sis_result', $new);
        }

        return true;
    }

    /**
     * Update assessment record in SIS
     *
     * @param object $attempt Quiz attempt record
     * @param object $quiz Quiz record
     * @param object $cm Course module record
     */
    private static function update_assessment_record($attempt, $quiz, $cm) {
        global $DB, $USER;
        
        // Your custom table for storing assessment data
        $assessment_data = [
            'userid' => $attempt->userid,
            'courseid' => $quiz->course,
            'quizid' => $quiz->id,
            'attemptid' => $attempt->id,
            'grade' => $attempt->sumgrades,
            'maxgrade' => $quiz->sumgrades, // Use quiz sumgrades or grade field
            'timecompleted' => $attempt->timefinish,
            'timemodified' => time(),
            'modifiedby' => $USER->id
        ];

        // Check if record exists
        $existing = $DB->get_record('local_sis_assessments', [
            'userid' => $attempt->userid,
            'quizid' => $quiz->id,
            'attemptid' => $attempt->id
        ]);

        if ($existing) {
            $assessment_data['id'] = $existing->id;
            $DB->update_record('local_sis_assessments', $assessment_data);
        } else {
            $assessment_data['timecreated'] = time();
            $DB->insert_record('local_sis_assessments', $assessment_data);
        }
    }

    /**
     * Log assessment activity for reporting
     *
     * @param int $userid User ID
     * @param int $courseid Course ID
     * @param int $quizid Quiz ID
     * @param string $eventname Event name
     */
    private static function log_assessment_activity($userid, $courseid, $quizid, $eventname) {
        global $DB, $USER;

        $log_data = [
            'userid' => $userid,
            'courseid' => $courseid,
            'quizid' => $quizid,
            'eventname' => $eventname,
            'ip' => getremoteaddr(),
            'timecreated' => time(),
            'createdby' => $USER->id
        ];

        $DB->insert_record('local_sis_activity_log', $log_data);
    }

    /**
     * Handle user enrolment events
     *
     * @param \core\event\user_enrolment_created $event
     * @return bool
     */
    public static function user_enrolled(\core\event\user_enrolment_created $event) {
        global $DB;
        
        $userid = $event->relateduserid;
        $courseid = $event->courseid;
        
        // Log enrolment activity
        self::log_assessment_activity($userid, $courseid, 0, 'user_enrolled');
        
        return true;
    }

    /**
     * Handle course completion events
     *
     * @param \core\event\course_completed $event
     * @return bool
     */
    public static function course_completed(\core\event\course_completed $event) {
        global $DB;
        
        $userid = $event->relateduserid;
        $courseid = $event->courseid;
        
        // Log course completion
        self::log_assessment_activity($userid, $courseid, 0, 'course_completed');
        
        return true;
    }
}


/**
 * Calculate grade based on total score
 *
 * @param float $total The total score
 * @return string The grade letter
 */
function local_sis_calculate_grade($total) {
    if ($total >= 70) return 'A';
    if ($total >= 60) return 'B';
    if ($total >= 50) return 'C';
    if ($total >= 45) return 'D';
    if ($total >= 40) return 'E';
    return 'F';
}