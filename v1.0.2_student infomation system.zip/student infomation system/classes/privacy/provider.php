<?php
// This file is part of the Student Information System (SIS) plugin for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle. If not, see <https://www.gnu.org/licenses/>.
/**
 * Version information for the Student Information System plugin
 *
 * @package    local_sis
 * @copyright  2025 NduksTech - https://facebook.com/ndukshub
 * @author     Nduka Akapti  (https://github.com/nduka4real)
 * @author     Ndukstech (https://www.youtube.com/@nduks-tech)
 * @author     https://www.linkedin.com/in/ndukaakpati/
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @details
 * Display Name: Student Information System
 * Description: A comprehensive system for managing student records, assessments, fees, and school operations.
 * Contact: https://github.com/nduka4real
 * Social: https://facebook.com/ndukshub
 */

namespace local_sis\privacy;

use core_privacy\local\metadata\collection;
use core_privacy\local\request\writer;
use core_privacy\local\request\contextlist;
use core_privacy\local\request\approved_contextlist;
use core_privacy\local\request\userlist;
use core_privacy\local\request\approved_userlist;

/**
 * Privacy provider for the local_sis plugin.
 *
 * @package    local_sis
 * @category   privacy
 * @copyright  2025 NduksTech
 * @author     Nduka Akapti
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class provider implements
    \core_privacy\local\metadata\provider,
    \core_privacy\local\request\plugin\provider,
    \core_privacy\local\request\core_userlist_provider
{
    /**
     * Database tables used by this plugin.
     */
    private const DATABASE_TABLES = [
        'local_sis_comments',
        'local_sis_fee',
        'local_sis_payments',
        'local_sis_payment_categories',
        'local_sis_payment_config',
        'local_sis_promotions_log',
        'local_sis_quizmap',
        'local_sis_result',
        'local_sis_school_settings',
        'local_sis_sessions',
        'local_sis_student_access',
        'local_sis_terms',
        'local_sis_ca_config',
    ];

    /**
     * Describe all the places where this plugin stores personal data.
     *
     * @param collection $collection
     * @return collection
     */
    public static function get_metadata(collection $collection): collection {
        // Student comments and remarks
        $collection->add_database_table('local_sis_comments', [
            'userid' => 'privacy:metadata:local_sis_comments:userid',
            'comment_by' => 'privacy:metadata:local_sis_comments:comment_by',
            'comment_text' => 'privacy:metadata:local_sis_comments:comment_text',
            'comment_type' => 'privacy:metadata:local_sis_comments:comment_type',
            'context_id' => 'privacy:metadata:local_sis_comments:context_id',
            'timecreated' => 'privacy:metadata:local_sis_comments:timecreated',
            'timemodified' => 'privacy:metadata:local_sis_comments:timemodified'
        ], 'privacy:metadata:local_sis_comments');

        // Fee structure and assessments
        $collection->add_database_table('local_sis_fee', [
            'userid' => 'privacy:metadata:local_sis_fee:userid',
            'fee_type' => 'privacy:metadata:local_sis_fee:fee_type',
            'amount' => 'privacy:metadata:local_sis_fee:amount',
            'academic_year' => 'privacy:metadata:local_sis_fee:academic_year',
            'term_id' => 'privacy:metadata:local_sis_fee:term_id',
            'due_date' => 'privacy:metadata:local_sis_fee:due_date',
            'status' => 'privacy:metadata:local_sis_fee:status',
            'assessed_by' => 'privacy:metadata:local_sis_fee:assessed_by',
            'timecreated' => 'privacy:metadata:local_sis_fee:timecreated',
            'timemodified' => 'privacy:metadata:local_sis_fee:timemodified'
        ], 'privacy:metadata:local_sis_fee');

        // Payment transactions
        $collection->add_database_table('local_sis_payments', [
            'userid' => 'privacy:metadata:local_sis_payments:userid',
            'payment_category_id' => 'privacy:metadata:local_sis_payments:payment_category_id',
            'amount_paid' => 'privacy:metadata:local_sis_payments:amount_paid',
            'payment_method' => 'privacy:metadata:local_sis_payments:payment_method',
            'transaction_id' => 'privacy:metadata:local_sis_payments:transaction_id',
            'receipt_number' => 'privacy:metadata:local_sis_payments:receipt_number',
            'payment_date' => 'privacy:metadata:local_sis_payments:payment_date',
            'processed_by' => 'privacy:metadata:local_sis_payments:processed_by',
            'timecreated' => 'privacy:metadata:local_sis_payments:timecreated',
            'timemodified' => 'privacy:metadata:local_sis_payments:timemodified'
        ], 'privacy:metadata:local_sis_payments');

        // Payment categories
        $collection->add_database_table('local_sis_payment_categories', [
            'category_name' => 'privacy:metadata:local_sis_payment_categories:category_name',
            'description' => 'privacy:metadata:local_sis_payment_categories:description',
            'default_amount' => 'privacy:metadata:local_sis_payment_categories:default_amount',
            'created_by' => 'privacy:metadata:local_sis_payment_categories:created_by',
            'timecreated' => 'privacy:metadata:local_sis_payment_categories:timecreated',
            'timemodified' => 'privacy:metadata:local_sis_payment_categories:timemodified'
        ], 'privacy:metadata:local_sis_payment_categories');

        // Payment configuration
        $collection->add_database_table('local_sis_payment_config', [
            'config_name' => 'privacy:metadata:local_sis_payment_config:config_name',
            'config_value' => 'privacy:metadata:local_sis_payment_config:config_value',
            'config_description' => 'privacy:metadata:local_sis_payment_config:config_description',
            'updated_by' => 'privacy:metadata:local_sis_payment_config:updated_by',
            'timecreated' => 'privacy:metadata:local_sis_payment_config:timecreated',
            'timemodified' => 'privacy:metadata:local_sis_payment_config:timemodified'
        ], 'privacy:metadata:local_sis_payment_config');

        // Student promotion history
        $collection->add_database_table('local_sis_promotions_log', [
            'userid' => 'privacy:metadata:local_sis_promotions_log:userid',
            'from_class' => 'privacy:metadata:local_sis_promotions_log:from_class',
            'to_class' => 'privacy:metadata:local_sis_promotions_log:to_class',
            'academic_year' => 'privacy:metadata:local_sis_promotions_log:academic_year',
            'promoted_by' => 'privacy:metadata:local_sis_promotions_log:promoted_by',
            'promotion_date' => 'privacy:metadata:local_sis_promotions_log:promotion_date',
            'remarks' => 'privacy:metadata:local_sis_promotions_log:remarks',
            'timecreated' => 'privacy:metadata:local_sis_promotions_log:timecreated'
        ], 'privacy:metadata:local_sis_promotions_log');

        // Quiz mapping and assessments
        $collection->add_database_table('local_sis_quizmap', [
            'userid' => 'privacy:metadata:local_sis_quizmap:userid',
            'quiz_id' => 'privacy:metadata:local_sis_quizmap:quiz_id',
            'course_id' => 'privacy:metadata:local_sis_quizmap:course_id',
            'term_id' => 'privacy:metadata:local_sis_quizmap:term_id',
            'assessment_type' => 'privacy:metadata:local_sis_quizmap:assessment_type',
            'maximum_score' => 'privacy:metadata:local_sis_quizmap:maximum_score',
            'weightage' => 'privacy:metadata:local_sis_quizmap:weightage',
            'mapped_by' => 'privacy:metadata:local_sis_quizmap:mapped_by',
            'timecreated' => 'privacy:metadata:local_sis_quizmap:timecreated',
            'timemodified' => 'privacy:metadata:local_sis_quizmap:timemodified'
        ], 'privacy:metadata:local_sis_quizmap');

        // Student results and grades
        $collection->add_database_table('local_sis_result', [
            'userid' => 'privacy:metadata:local_sis_result:userid',
            'courseid' => 'privacy:metadata:local_sis_result:courseid',
            'termid' => 'privacy:metadata:local_sis_result:termid',
            'assessment_type' => 'privacy:metadata:local_sis_result:assessment_type',
            'score' => 'privacy:metadata:local_sis_result:score',
            'grade' => 'privacy:metadata:local_sis_result:grade',
            'grade_points' => 'privacy:metadata:local_sis_result:grade_points',
            'comments' => 'privacy:metadata:local_sis_result:comments',
            'graded_by' => 'privacy:metadata:local_sis_result:graded_by',
            'timecreated' => 'privacy:metadata:local_sis_result:timecreated',
            'timemodified' => 'privacy:metadata:local_sis_result:timemodified'
        ], 'privacy:metadata:local_sis_result');

        // School settings (minimal personal data)
        $collection->add_database_table('local_sis_school_settings', [
            'setting_name' => 'privacy:metadata:local_sis_school_settings:setting_name',
            'setting_value' => 'privacy:metadata:local_sis_school_settings:setting_value',
            'setting_description' => 'privacy:metadata:local_sis_school_settings:setting_description',
            'updated_by' => 'privacy:metadata:local_sis_school_settings:updated_by',
            'timecreated' => 'privacy:metadata:local_sis_school_settings:timecreated',
            'timemodified' => 'privacy:metadata:local_sis_school_settings:timemodified'
        ], 'privacy:metadata:local_sis_school_settings');

        // Academic sessions
        $collection->add_database_table('local_sis_sessions', [
            'session_name' => 'privacy:metadata:local_sis_sessions:session_name',
            'session_year' => 'privacy:metadata:local_sis_sessions:session_year',
            'start_date' => 'privacy:metadata:local_sis_sessions:start_date',
            'end_date' => 'privacy:metadata:local_sis_sessions:end_date',
            'is_current' => 'privacy:metadata:local_sis_sessions:is_current',
            'created_by' => 'privacy:metadata:local_sis_sessions:created_by',
            'timecreated' => 'privacy:metadata:local_sis_sessions:timecreated',
            'timemodified' => 'privacy:metadata:local_sis_sessions:timemodified'
        ], 'privacy:metadata:local_sis_sessions');

        // Student access logs and permissions
        $collection->add_database_table('local_sis_student_access', [
            'userid' => 'privacy:metadata:local_sis_student_access:userid',
            'access_type' => 'privacy:metadata:local_sis_student_access:access_type',
            'access_point' => 'privacy:metadata:local_sis_student_access:access_point',
            'ip_address' => 'privacy:metadata:local_sis_student_access:ip_address',
            'user_agent' => 'privacy:metadata:local_sis_student_access:user_agent',
            'access_time' => 'privacy:metadata:local_sis_student_access:access_time',
            'session_id' => 'privacy:metadata:local_sis_student_access:session_id',
            'timecreated' => 'privacy:metadata:local_sis_student_access:timecreated'
        ], 'privacy:metadata:local_sis_student_access');

        // Academic terms
        $collection->add_database_table('local_sis_terms', [
            'term_name' => 'privacy:metadata:local_sis_terms:term_name',
            'term_code' => 'privacy:metadata:local_sis_terms:term_code',
            'start_date' => 'privacy:metadata:local_sis_terms:start_date',
            'end_date' => 'privacy:metadata:local_sis_terms:end_date',
            'academic_year' => 'privacy:metadata:local_sis_terms:academic_year',
            'is_current' => 'privacy:metadata:local_sis_terms:is_current',
            'created_by' => 'privacy:metadata:local_sis_terms:created_by',
            'timecreated' => 'privacy:metadata:local_sis_terms:timecreated',
            'timemodified' => 'privacy:metadata:local_sis_terms:timemodified'
        ], 'privacy:metadata:local_sis_terms');

        // Continuous assessment configuration
        $collection->add_database_table('local_sis_ca_config', [
            'course_id' => 'privacy:metadata:local_sis_ca_config:course_id',
            'assessment_type' => 'privacy:metadata:local_sis_ca_config:assessment_type',
            'maximum_score' => 'privacy:metadata:local_sis_ca_config:maximum_score',
            'weightage' => 'privacy:metadata:local_sis_ca_config:weightage',
            'is_active' => 'privacy:metadata:local_sis_ca_config:is_active',
            'configured_by' => 'privacy:metadata:local_sis_ca_config:configured_by',
            'timecreated' => 'privacy:metadata:local_sis_ca_config:timecreated',
            'timemodified' => 'privacy:metadata:local_sis_ca_config:timemodified'
        ], 'privacy:metadata:local_sis_ca_config');

        return $collection;
    }

    /**
     * Get the list of contexts that contain user information for the given user.
     *
     * @param int $userid
     * @return contextlist
     */
    public static function get_contexts_for_userid(int $userid): contextlist {
        global $DB;

        $contextlist = new contextlist();
        $params = ['userid' => $userid];

        // Check all SIS tables for user data
        foreach (self::DATABASE_TABLES as $table) {
            $sql = "SELECT DISTINCT contextid 
                    FROM {context} 
                    WHERE contextlevel = :contextlevel 
                    AND EXISTS (
                        SELECT 1 FROM {{$table}} WHERE userid = :userid
                    )";
            
            if ($DB->record_exists_sql($sql, ['contextlevel' => CONTEXT_SYSTEM, 'userid' => $userid])) {
                $contextlist->add_system_context();
                break; // Only need to add system context once
            }
        }

        return $contextlist;
    }

    /**
     * Get the list of users who have data within a context.
     *
     * @param userlist $userlist The userlist containing the list of users who have data in this context/plugin combination.
     */
    public static function get_users_in_context(userlist $userlist) {
        $context = $userlist->get_context();

        if ($context->contextlevel !== CONTEXT_SYSTEM) {
            return;
        }

        foreach (self::DATABASE_TABLES as $table) {
            $sql = "SELECT userid FROM {{$table}}";
            $userlist->add_from_sql('userid', $sql, []);
        }
    }

    /**
     * Export all user data for the specified user, in the specified contexts.
     *
     * @param approved_contextlist $contextlist The approved contexts to export information for.
     */
    public static function export_user_data(approved_contextlist $contextlist) {
        global $DB;

        $userid = $contextlist->get_user()->id;

        // Only export system context data
        if (!in_array(\context_system::instance()->id, $contextlist->get_contextids())) {
            return;
        }

        $writer = writer::with_context(\context_system::instance());
        $exportdata = [];

        // Export comments data
        $comments = $DB->get_records('local_sis_comments', ['userid' => $userid]);
        if (!empty($comments)) {
            foreach ($comments as $comment) {
                $exportdata['comments'][] = [
                    'comment_by' => self::get_username_or_anonymous($comment->comment_by ?? 0),
                    'comment_text' => $comment->comment_text ?? '',
                    'comment_type' => $comment->comment_type ?? '',
                    'context_id' => $comment->context_id ?? '',
                    'time_created' => self::format_date($comment->timecreated),
                    'time_modified' => self::format_date($comment->timemodified)
                ];
            }
        }

        // Export fee data
        $fees = $DB->get_records('local_sis_fee', ['userid' => $userid]);
        if (!empty($fees)) {
            foreach ($fees as $fee) {
                $exportdata['fees'][] = [
                    'fee_type' => $fee->fee_type ?? '',
                    'amount' => format_float($fee->amount, 2),
                    'academic_year' => $fee->academic_year ?? '',
                    'term_id' => $fee->term_id ?? '',
                    'due_date' => self::format_date($fee->due_date),
                    'status' => $fee->status ?? '',
                    'assessed_by' => self::get_username_or_anonymous($fee->assessed_by ?? 0),
                    'time_created' => self::format_date($fee->timecreated),
                    'time_modified' => self::format_date($fee->timemodified)
                ];
            }
        }

        // Export payments data
        $payments = $DB->get_records('local_sis_payments', ['userid' => $userid]);
        if (!empty($payments)) {
            foreach ($payments as $payment) {
                $exportdata['payments'][] = [
                    'payment_category_id' => $payment->payment_category_id ?? '',
                    'amount_paid' => format_float($payment->amount_paid, 2),
                    'payment_method' => $payment->payment_method ?? '',
                    'transaction_id' => $payment->transaction_id ?? '',
                    'receipt_number' => $payment->receipt_number ?? '',
                    'payment_date' => self::format_date($payment->payment_date),
                    'processed_by' => self::get_username_or_anonymous($payment->processed_by ?? 0),
                    'time_created' => self::format_date($payment->timecreated),
                    'time_modified' => self::format_date($payment->timemodified)
                ];
            }
        }

        // Export promotion history
        $promotions = $DB->get_records('local_sis_promotions_log', ['userid' => $userid]);
        if (!empty($promotions)) {
            foreach ($promotions as $promotion) {
                $exportdata['promotions'][] = [
                    'from_class' => $promotion->from_class ?? '',
                    'to_class' => $promotion->to_class ?? '',
                    'academic_year' => $promotion->academic_year ?? '',
                    'promoted_by' => self::get_username_or_anonymous($promotion->promoted_by ?? 0),
                    'promotion_date' => self::format_date($promotion->promotion_date),
                    'remarks' => $promotion->remarks ?? '',
                    'time_created' => self::format_date($promotion->timecreated)
                ];
            }
        }

        // Export quiz mappings
        $quizmaps = $DB->get_records('local_sis_quizmap', ['userid' => $userid]);
        if (!empty($quizmaps)) {
            foreach ($quizmaps as $quizmap) {
                $exportdata['quiz_mappings'][] = [
                    'quiz_id' => $quizmap->quiz_id ?? '',
                    'course_id' => $quizmap->course_id ?? '',
                    'term_id' => $quizmap->term_id ?? '',
                    'assessment_type' => $quizmap->assessment_type ?? '',
                    'maximum_score' => $quizmap->maximum_score ?? '',
                    'weightage' => $quizmap->weightage ?? '',
                    'mapped_by' => self::get_username_or_anonymous($quizmap->mapped_by ?? 0),
                    'time_created' => self::format_date($quizmap->timecreated),
                    'time_modified' => self::format_date($quizmap->timemodified)
                ];
            }
        }

        // Export results data
        $results = $DB->get_records('local_sis_result', ['userid' => $userid]);
        if (!empty($results)) {
            foreach ($results as $result) {
                $exportdata['results'][] = [
                    'course_id' => $result->courseid,
                    'term_id' => $result->termid,
                    'assessment_type' => $result->assessment_type ?? 'General',
                    'score' => $result->score,
                    'grade' => $result->grade,
                    'grade_points' => $result->grade_points ?? '',
                    'comments' => $result->comments ?? '',
                    'graded_by' => self::get_username_or_anonymous($result->graded_by ?? 0),
                    'time_created' => self::format_date($result->timecreated),
                    'time_modified' => self::format_date($result->timemodified)
                ];
            }
        }

        // Export student access logs
        $accesslogs = $DB->get_records('local_sis_student_access', ['userid' => $userid]);
        if (!empty($accesslogs)) {
            foreach ($accesslogs as $log) {
                $exportdata['access_logs'][] = [
                    'access_type' => $log->access_type ?? '',
                    'access_point' => $log->access_point ?? '',
                    'ip_address' => $log->ip_address ?? '',
                    'user_agent' => $log->user_agent ?? '',
                    'access_time' => self::format_date($log->access_time),
                    'session_id' => $log->session_id ?? '',
                    'time_created' => self::format_date($log->timecreated)
                ];
            }
        }

        // Write the exported data
        if (!empty($exportdata)) {
            $writer->export_data(
                [get_string('privacy:path:sis_data', 'local_sis')],
                (object)$exportdata
            );
        }
    }

    /**
     * Delete all user data for the specified user, in the specified contexts.
     *
     * @param approved_contextlist $contextlist The approved contexts and user information to delete information for.
     */
    public static function delete_data_for_user(approved_contextlist $contextlist) {
        global $DB;

        $userid = $contextlist->get_user()->id;

        // Only delete system context data
        if (!in_array(\context_system::instance()->id, $contextlist->get_contextids())) {
            return;
        }

        foreach (self::DATABASE_TABLES as $table) {
            $DB->delete_records($table, ['userid' => $userid]);
        }

        // Log the deletion for audit purposes
        self::log_privacy_action($userid, 'delete_data_for_user', 
            "All SIS data deleted for user {$userid} per privacy request");
    }

    /**
     * Delete all users' data within the given context.
     *
     * @param \context $context The specific context to delete data for.
     */
    public static function delete_data_for_all_users_in_context(\context $context) {
        global $DB;

        if ($context->contextlevel !== CONTEXT_SYSTEM) {
            return;
        }

        foreach (self::DATABASE_TABLES as $table) {
            $DB->delete_records($table);
        }

        // Log the deletion for audit purposes
        self::log_privacy_action(0, 'delete_data_for_all_users', 
            "All SIS data deleted for all users in system context");
    }

    /**
     * Delete multiple users within a single context.
     *
     * @param approved_userlist $userlist The approved context and user information to delete information for.
     */
    public static function delete_data_for_users(approved_userlist $userlist) {
        global $DB;

        $context = $userlist->get_context();
        $userids = $userlist->get_userids();

        if ($context->contextlevel !== CONTEXT_SYSTEM) {
            return;
        }

        if (empty($userids)) {
            return;
        }

        list($insql, $inparams) = $DB->get_in_or_equal($userids, SQL_PARAMS_NAMED);

        foreach (self::DATABASE_TABLES as $table) {
            $DB->delete_records_select($table, "userid {$insql}", $inparams);
        }

        // Log the deletion for audit purposes
        $userliststr = implode(', ', $userids);
        self::log_privacy_action(0, 'delete_data_for_users', 
            "SIS data deleted for users: {$userliststr}");
    }

    /**
     * Format timestamp for export.
     *
     * @param int $timestamp
     * @return string
     */
    private static function format_date(int $timestamp): string {
        if (empty($timestamp)) {
            return '';
        }
        return userdate($timestamp, get_string('strftimedatetimeaccurate', 'core_langconfig'));
    }

    /**
     * Get username or return anonymous identifier.
     *
     * @param int $userid
     * @return string
     */
    private static function get_username_or_anonymous(int $userid): string {
        global $DB;
        
        if ($userid <= 0) {
            return get_string('privacy:anonymous_user', 'local_sis');
        }
        
        $user = $DB->get_record('user', ['id' => $userid], 'username, firstname, lastname');
        if ($user) {
            return fullname($user) . " ({$user->username})";
        }
        
        return get_string('privacy:unknown_user', 'local_sis');
    }

    /**
     * Log privacy-related actions for audit trail.
     *
     * @param int $userid
     * @param string $action
     * @param string $description
     */
    private static function log_privacy_action(int $userid, string $action, string $description) {
        global $DB, $USER;
        
        $log = new \stdClass();
        $log->userid = $USER->id;
        $log->action = $action;
        $log->component = 'local_sis';
        $log->target_userid = $userid;
        $log->ip_address = getremoteaddr();
        $log->user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        $log->description = $description;
        $log->timecreated = time();
        
        $DB->insert_record('local_sis_user_logs', $log);
    }
}