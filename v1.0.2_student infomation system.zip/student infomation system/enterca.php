<?php
// This file is part of the Student Information System plugin for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version information for the Student Information System plugin
 *
 * @package    local_sis
 * @copyright  2025 NduksTech - https://facebook.com/ndukshub
 * @author     Nduka Akapti  (https://github.com/nduka4real)
 * @author     Ndukstech (https://www.youtube.com/@nduks-tech)
 * @author     https://www.linkedin.com/in/ndukaakpati/
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @details
 * Display Name: Student Information System
 * Description: A comprehensive system for managing student records, assessments, fees, and school operations.
 * Contact: https://github.com/nduka4real
 * Social: https://facebook.com/ndukshub
 */

// local/sis/enterca.php
// Fixed version - CA Management System with Database Saving

require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/weblib.php');

require_login();

global $DB, $USER, $PAGE, $OUTPUT;

// === Parameters ===
$courseid       = optional_param('courseid', 0, PARAM_INT);
$categoryid     = optional_param('categoryid', 0, PARAM_INT);
$quizid         = optional_param('quizid', 0, PARAM_INT);
$search_query   = optional_param('search', '', PARAM_TEXT);
$bulk_action    = optional_param('bulk_action', '', PARAM_TEXT);
$import_quiz    = optional_param('import_quiz', 0, PARAM_INT);
$override_score = optional_param('override_score', 0, PARAM_INT);
$sessionid      = optional_param('sessionid', 0, PARAM_INT);
$termid         = optional_param('termid', 0, PARAM_INT);
$action         = optional_param('action', '', PARAM_ALPHA);

// === Helper Functions ===
function render_category_selection($selected_categoryid = 0) {
    global $DB;
    
    // Get ALL visible categories
    $sql = "SELECT c.id, c.name, c.parent, c.depth
            FROM {course_categories} c
            WHERE c.visible = 1
            ORDER BY c.depth, c.name ASC";
    
    $categories = $DB->get_records_sql($sql);
    
    if (empty($categories)) {
        return html_writer::div('No categories available.', 'alert alert-warning');
    }
    
    $output = html_writer::start_tag('form', ['method' => 'get', 'class' => 'form-inline mb-4']);
    $output .= html_writer::label('Select Category:', 'categoryid', false, ['class' => 'mr-2']);
    
    $options = [0 => '-- Select Category --'];
    foreach ($categories as $cat) {
        // Create indented names based on category depth
        $indent = str_repeat('&nbsp;&nbsp;&nbsp;', $cat->depth);
        $options[$cat->id] = $indent . format_string($cat->name);
    }
    
    $output .= html_writer::select($options, 'categoryid', $selected_categoryid, false, [
        'class' => 'form-control mr-2',
        'onchange' => 'this.form.submit()'
    ]);
    
    $output .= html_writer::end_tag('form');
    return $output;
}

function get_user_courses_by_category($userid, $categoryid = 0) {
    global $DB;
    
    $params = [];
    $sql = "SELECT c.id, c.fullname, c.shortname, c.category
            FROM {course} c
            WHERE c.visible = 1";
    
    // If category is specified, filter by category
    if ($categoryid) {
        $sql .= " AND c.category = ?";
        $params[] = $categoryid;
    }
    
    // Only check enrollment if we're not an admin and we want user-specific courses
    // For admin users or when we want to see all courses in category, don't check enrollment
    if (!is_siteadmin($userid)) {
        $sql .= " AND EXISTS (
            SELECT 1 FROM {enrol} e 
            JOIN {user_enrolments} ue ON ue.enrolid = e.id 
            WHERE e.courseid = c.id AND ue.userid = ?
        )";
        $params[] = $userid;
    }
    
    $sql .= " ORDER BY c.fullname ASC";
    
    return $DB->get_records_sql($sql, $params);
}

function clean_component_name($name) {
    return preg_replace('/[^a-z0-9]/', '', strtolower($name));
}

function filter_admin_users($users) {
    $filtered = [];
    foreach ($users as $user) {
        if (!is_siteadmin($user->id)) {
            $filtered[$user->id] = $user;
        }
    }
    return $filtered;
}

// === Category and Course selection UI ===
if (!$courseid) {
    $PAGE->set_url(new moodle_url('/local/sis/enterca.php'));
    $PAGE->set_context(context_system::instance());
    $PAGE->set_title("Select Course - Enter CA");
    echo $OUTPUT->header();
    echo $OUTPUT->heading("Select a course to Enter Student Scores");

    echo render_category_selection($categoryid);
    
    $courses = get_user_courses_by_category($USER->id, $categoryid);
    
    if ($categoryid && empty($courses)) {
        echo $OUTPUT->notification("No courses found in the selected category.", 'notifyproblem');
        echo $OUTPUT->footer();
        exit;
    }
    
    if (!$categoryid && !empty($courses)) {
        echo $OUTPUT->notification("Please select a category first to view courses.", 'notifyinfo');
        echo $OUTPUT->footer();
        exit;
    }

    if ($categoryid && !empty($courses)) {
        echo html_writer::start_tag('form', ['method' => 'get', 'class' => 'form-inline mb-3']);
        echo html_writer::empty_tag('input', [
            'type' => 'hidden',
            'name' => 'categoryid', 
            'value' => $categoryid
        ]);
        echo html_writer::empty_tag('input', [
            'type' => 'text',
            'name' => 'search',
            'value' => $search_query,
            'placeholder' => 'Search courses...',
            'class' => 'form-control mr-2',
            'style' => 'max-width:400px;'
        ]);
        echo html_writer::empty_tag('input', [
            'type' => 'submit',
            'value' => 'Search',
            'class' => 'btn btn-primary'
        ]);
        echo html_writer::end_tag('form');

        if (!empty($search_query)) {
            $courses = array_filter($courses, function($c) use ($search_query) {
                return stripos($c->fullname, $search_query) !== false || stripos($c->shortname, $search_query) !== false;
            });
        }

        if (!empty($courses)) {
            echo html_writer::start_tag('ul', ['class' => 'list-group']);
            foreach ($courses as $c) {
                $url = new moodle_url('/local/sis/enterca.php', ['courseid' => $c->id]);
                echo html_writer::tag('li',
                    html_writer::link($url, format_string($c->fullname) . ' (' . format_string($c->shortname) . ')'),
                    ['class' => 'list-group-item']
                );
            }
            echo html_writer::end_tag('ul');
        } else {
            echo $OUTPUT->notification("No courses found matching your search.", 'notifyproblem');
        }
    }

    echo '<div class="text-center mt-4">';
    echo html_writer::link(
        new moodle_url('/local/sis/index.php'),
        'Back to Main Dashboard',
        ['class' => 'btn btn-success']
    );
    echo '</div>';

    echo $OUTPUT->footer();
    exit;
}

// === Course context & permissions ===
$course = get_course($courseid);
$context = context_course::instance($course->id);
require_capability('moodle/course:update', $context);

$PAGE->set_url(new moodle_url('/local/sis/enterca.php', ['courseid' => $courseid]));
$PAGE->set_context($context);
$PAGE->set_title("Enter CA for " . format_string($course->fullname));

// Get available sessions
$sessions = $DB->get_records('local_sis_sessions', null, 'sessionname ASC');

// Set default session if not provided
if (!$sessionid && $sessions) {
    $default_session = $DB->get_record('local_sis_sessions', ['isdefault' => 1]);
    if ($default_session) {
        $sessionid = $default_session->id;
    } else {
        $sessionid = reset($sessions)->id;
    }
}

// Get terms for the selected session
$terms = [];
if ($sessionid) {
    $terms = $DB->get_records('local_sis_terms', ['sessionid' => $sessionid], 'termname ASC');
}

// Set default term if not provided
if (!$termid && $terms) {
    $default_term = $DB->get_record('local_sis_terms', ['isdefault' => 1, 'sessionid' => $sessionid]);
    if ($default_term) {
        $termid = $default_term->id;
    } else {
        $termid = reset($terms)->id;
    }
}

// Reset termid if it doesn't belong to the selected session
if ($termid && $sessionid) {
    $term_check = $DB->get_record('local_sis_terms', ['id' => $termid, 'sessionid' => $sessionid]);
    if (!$term_check) {
        $termid = 0;
        // Set default term again after reset
        if ($terms) {
            $default_term = $DB->get_record('local_sis_terms', ['isdefault' => 1, 'sessionid' => $sessionid]);
            if ($default_term) {
                $termid = $default_term->id;
            } else {
                $termid = reset($terms)->id;
            }
        }
    }
}

// === Load CA config or create default ===
$ca_config = $DB->get_record('local_sis_ca_config', [
    'courseid' => $courseid,
    'sessionid' => $sessionid,
    'termid' => $termid
]);

if (!$ca_config) {
    $default_config = new stdClass();
    $default_config->courseid = $courseid;
    $default_config->sessionid = $sessionid;
    $default_config->termid = $termid;
    $default_config->components = json_encode([
        ['name' => 'First CA', 'weight' => 15, 'max' => 15],
        ['name' => 'Second CA', 'weight' => 15, 'max' => 15],
        ['name' => 'Exam', 'weight' => 70, 'max' => 70]
    ]);
    $default_config->grading_scale = json_encode([
        ['min' => 70, 'grade' => 'A', 'points' => 5.0],
        ['min' => 65, 'grade' => 'B', 'points' => 4.0],
        ['min' => 60, 'grade' => 'C', 'points' => 3.0],
        ['min' => 55, 'grade' => 'D', 'points' => 2.0],
        ['min' => 50, 'grade' => 'E', 'points' => 1.0],
        ['min' => 45, 'grade' => 'E_', 'points' => 0.5],
        ['min' => 0, 'grade' => 'F', 'points' => 0.0]
    ]);
    $default_config->timecreated = time();
    $default_config->timemodified = time();

    $config_id = $DB->insert_record('local_sis_ca_config', $default_config);
    $ca_config = $DB->get_record('local_sis_ca_config', ['id' => $config_id]);
}

$components = json_decode($ca_config->components, true);
$grading_scale = json_decode($ca_config->grading_scale, true);

// Ensure grading scale sorted by min descending
usort($grading_scale, function($a, $b) {
    return ($b['min'] <=> $a['min']);
});

// === Helper: map existing results keyed by userid for fast lookup ===
$existing_records = $DB->get_records('local_sis_result', [
    'courseid' => $courseid,
    'sessionid' => $sessionid,
    'termid' => $termid
]);

$existing_by_user = [];
foreach ($existing_records as $rec) {
    $existing_by_user[$rec->userid] = $rec;
}

// === Handle manual CA entry form submission ===
if ($action === 'saveca' && confirm_sesskey()) {
    // Get all POST data safely
    $ca_data = array();
    
    if (isset($_POST['ca']) && is_array($_POST['ca'])) {
        foreach ($_POST['ca'] as $userid => $components_data) {
            $clean_userid = clean_param($userid, PARAM_INT);
            $clean_components = array();
            
            if (is_array($components_data)) {
                foreach ($components_data as $key => $value) {
                    $clean_key = clean_param($key, PARAM_TEXT);
                    $clean_value = clean_param($value, PARAM_FLOAT);
                    $clean_components[$clean_key] = $clean_value;
                }
            }
            
            $ca_data[$clean_userid] = $clean_components;
        }
    }
    
    $saved_count = 0;
    $errors = array();
    
    // Get enrolled students for validation
    $students = get_enrolled_users($context, 'mod/assign:submit', '', 'u.id, u.idnumber, u.firstname, u.lastname, u.firstnamephonetic, u.lastnamephonetic, u.middlename, u.alternatename');
    $students = filter_admin_users($students);
    
    foreach ($ca_data as $userid => $components_data) {
        // Validate user is enrolled and not admin
        if (!isset($students[$userid]) || is_siteadmin($userid)) {
            continue;
        }
        
        $scores = array();
        $total = 0.0;
        
        // Process each component score
        foreach ($components as $index => $component) {
            $score_key = "ca{$index}";
            $score = 0.0;
            
            if (isset($components_data[$score_key])) {
                $raw_score = $components_data[$score_key];
                // Handle empty values
                if ($raw_score === '' || $raw_score === null) {
                    $score = 0.0;
                } else {
                    $score = (float)$raw_score;
                }
                
                // Validate score is within bounds
                $max = (float)$component['max'];
                if ($score < 0) $score = 0.0;
                if ($score > $max) $score = $max;
            }
            
            $scores[] = $score;
            $total += $score;
        }
        
        // Calculate grade and points based on total
        $grade = 'F';
        $points = 0.0;
        foreach ($grading_scale as $gs) {
            if ($total >= $gs['min']) {
                $grade = $gs['grade'];
                $points = (float)$gs['points'];
                break;
            }
        }
        
        // Prepare record for database
        $record = new stdClass();
        $record->courseid = $courseid;
        $record->userid = $userid;
        $record->sessionid = $sessionid;
        $record->termid = $termid;
        $record->data = json_encode($scores);
        $record->total = $total;
        $record->grade = $grade;
        $record->points = $points;
        $record->timemodified = time();
        
        try {
            if (isset($existing_by_user[$userid])) {
                // Update existing record
                $record->id = $existing_by_user[$userid]->id;
                $DB->update_record('local_sis_result', $record);
            } else {
                // Insert new record
                $record->timecreated = time();
                $DB->insert_record('local_sis_result', $record);
            }
            $saved_count++;
        } catch (Exception $e) {
            $student_name = fullname($students[$userid]);
            $errors[] = "Failed to save data for student {$student_name}: " . $e->getMessage();
        }
    }
    
    // Show success/error messages
    if ($saved_count > 0) {
        \core\notification::success("Successfully saved CA data for {$saved_count} students.");
    }
    
    if (!empty($errors)) {
        foreach ($errors as $error) {
            \core\notification::error($error);
        }
    }
    
    // Redirect to avoid form resubmission
    redirect(new moodle_url('/local/sis/enterca.php', [
        'courseid' => $courseid,
        'sessionid' => $sessionid,
        'termid' => $termid,
        'categoryid' => $course->category
    ]));
}

// === Handle CSV bulk upload ===
if ($bulk_action === 'upload' && !empty($_FILES['bulk_file']['tmp_name'])) {
    $filetmp = $_FILES['bulk_file']['tmp_name'];

    $handle = fopen($filetmp, 'r');
    if ($handle === false) {
        echo $OUTPUT->header();
        echo $OUTPUT->notification("Failed to open uploaded CSV file.", 'notifyproblem');
        echo $OUTPUT->footer();
        exit;
    }

    $header = fgetcsv($handle);
    if ($header === false) {
        echo $OUTPUT->header();
        echo $OUTPUT->notification("CSV file is empty or unreadable.", 'notifyproblem');
        echo $OUTPUT->footer();
        fclose($handle);
        exit;
    }

    // Determine column indexes for components using cleaned names
    $component_cols = array();
    $cleanHeader = array_map('clean_component_name', $header);
    foreach ($components as $index => $component) {
        $key = clean_component_name($component['name']);
        $col_index = array_search($key, $cleanHeader);
        if ($col_index !== false) {
            $component_cols[$index] = $col_index;
        }
    }

    // Build idnumber => userid map for enrolled students (excluding admins)
    $students_map = get_enrolled_users($context, 'mod/assign:submit', '', 'u.id, u.idnumber, u.firstname, u.lastname, u.firstnamephonetic, u.lastnamephonetic, u.middlename, u.alternatename');
    $students_map = filter_admin_users($students_map);
    $idnumber_map = array();
    foreach ($students_map as $s) {
        if (!empty($s->idnumber)) {
            $idnumber_map[$s->idnumber] = $s->id;
        }
    }

    $success_count = 0;
    $error_messages = array();

    while (($row = fgetcsv($handle)) !== false) {
        $student_idnumber = isset($row[0]) ? trim($row[0]) : '';
        if ($student_idnumber === '' || !isset($idnumber_map[$student_idnumber])) {
            $error_messages[] = "Skipping row for student ID '{$student_idnumber}' - not found or blank.";
            continue;
        }
        $userid = $idnumber_map[$student_idnumber];

        // Collect component scores
        $scores = array_fill(0, count($components), 0.0);
        $total = 0.0;
        foreach ($component_cols as $ca_index => $col_index) {
            $score = isset($row[$col_index]) ? (float)str_replace(',', '.', $row[$col_index]) : 0.0;
            if ($score < 0) $score = 0.0;
            $max = $components[$ca_index]['max'] ?? null;
            if ($max !== null && $score > $max) $score = (float)$max;
            
            $scores[$ca_index] = $score;
            $total += $score;
        }

    // Determine grade/points
        $grade = 'F';
        $points = 0.0;
        foreach ($grading_scale as $gs) {
            if ($total >= $gs['min']) {
                $grade = $gs['grade'];
                $points = (float)$gs['points'];
                break;
            }
        }

        $record = new stdClass();
        $record->courseid = $courseid;
        $record->userid = $userid;
        $record->sessionid = $sessionid;
        $record->termid = $termid;
        $record->data = json_encode($scores);
        $record->total = $total;
        $record->grade = $grade;
        $record->points = $points;
        $record->timemodified = time();

        if (isset($existing_by_user[$userid])) {
            $record->id = $existing_by_user[$userid]->id;
            $DB->update_record('local_sis_result', $record);
        } else {
            $record->timecreated = time();
            $DB->insert_record('local_sis_result', $record);
        }
        $success_count++;
    }

    fclose($handle);

    echo $OUTPUT->header();
    echo $OUTPUT->heading("Bulk Upload Results");
    echo $OUTPUT->notification("Successfully processed {$success_count} rows.", 'notifysuccess');
    if (!empty($error_messages)) {
        echo $OUTPUT->notification("Some rows could not be processed:", 'notifyproblem');
        $error_list = '';
        foreach ($error_messages as $message) {
            $error_list .= html_writer::tag('li', s($message));
        }
        echo html_writer::tag('ul', $error_list);
    }
    echo html_writer::tag('a', 'Back to CA Entry', ['href' => new moodle_url('/local/sis/enterca.php', [
        'courseid' => $courseid,
        'sessionid' => $sessionid,
        'termid' => $termid
    ])]);
    echo $OUTPUT->footer();
    exit;
}

// === Quiz import handling ===
if ($import_quiz && confirm_sesskey()) {
    // find the index of Exam component
    $exam_index = null;
    foreach ($components as $idx => $comp) {
        if (strtolower(trim($comp['name'])) === 'exam') {
            $exam_index = $idx;
            break;
        }
    }

    if ($exam_index === null) {
        redirect(new moodle_url('/local/sis/enterca.php', [
            'courseid' => $courseid,
            'sessionid' => $sessionid,
            'termid' => $termid
        ]), "No 'Exam' component found in CA configuration.", null, \core\output\notification::NOTIFY_ERROR);
    }

    // Determine which quiz to import
    $selected_quizid = $quizid ?: 0;
    if (!$selected_quizid) {
        $quizzes = $DB->get_records('quiz', ['course' => $courseid], 'timeopen DESC');
        if (!empty($quizzes)) {
            $first = reset($quizzes);
            $selected_quizid = $first->id;
        }
    }

    if (!$selected_quizid) {
        redirect(new moodle_url('/local/sis/enterca.php', [
            'courseid' => $courseid,
            'sessionid' => $sessionid,
            'termid' => $termid
        ]), "No quizzes found for this course.", null, \core\output\notification::NOTIFY_ERROR);
    }

    // Load quiz
    $quiz = $DB->get_record('quiz', ['id' => $selected_quizid], '*', MUST_EXIST);
    $quiz_max = (float)($quiz->grade ?: 0.0);

    // get quiz grades
    $quiz_grades = $DB->get_records('quiz_grades', ['quiz' => $selected_quizid]);
    $grades_by_user = array();
    foreach ($quiz_grades as $qg) {
        $grades_by_user[$qg->userid] = (float)$qg->grade;
    }

    // get enrolled students (excluding admins)
    $enrolled_students = get_enrolled_users($context, 'mod/assign:submit', '', 'u.id, u.idnumber, u.firstname, u.lastname, u.firstnamephonetic, u.lastnamephonetic, u.middlename, u.alternatename');
    $enrolled_students = filter_admin_users($enrolled_students);
    
    if (empty($enrolled_students)) {
        redirect(new moodle_url('/local/sis/enterca.php', [
            'courseid' => $courseid,
            'sessionid' => $sessionid,
            'termid' => $termid
        ]), "No students are enrolled in this course.", null, \core\output\notification::NOTIFY_ERROR);
    }

    $updated_count = 0;
    $created_count = 0;

    foreach ($enrolled_students as $student) {
        $uid = $student->id;
        $raw_grade = isset($grades_by_user[$uid]) ? $grades_by_user[$uid] : 0.0;

        // scale to exam max
        $exam_max = (float)$components[$exam_index]['max'];
        $scaled_grade = ($quiz_max > 0) ? ($raw_grade / $quiz_max) * $exam_max : (float)$raw_grade;
        if ($scaled_grade < 0) $scaled_grade = 0.0;
        if ($scaled_grade > $exam_max) $scaled_grade = $exam_max;

        // existing record?
        $existing = $existing_by_user[$uid] ?? null;
        if ($existing) {
            $data = array();
            if (!empty($existing->data)) {
                $data = json_decode($existing->data, true);
                if (!is_array($data)) $data = array();
            } else {
                $data = array_fill(0, count($components), 0.0);
            }

            $current_value = isset($data[$exam_index]) ? (float)$data[$exam_index] : 0.0;
            $should_update = ($override_score == 1) || ($current_value == 0.0 || $current_value === '' || $current_value === null);

            if ($should_update) {
                $data[$exam_index] = $scaled_grade;

                // recalc total
                $total = 0.0;
                foreach ($data as $v) {
                    if (is_numeric($v)) $total += (float)$v;
                }

                // compute grade & points
                $grade_val = 'F';
                $points = 0.0;
                foreach ($grading_scale as $gs) {
                    if ($total >= $gs['min']) {
                        $grade_val = $gs['grade'];
                        $points = (float)$gs['points'];
                        break;
                    }
                }

                $existing->data = json_encode($data);
                $existing->total = $total;
                $existing->grade = $grade_val;
                $existing->points = $points;
                $existing->timemodified = time();

                $DB->update_record('local_sis_result', $existing);
                $updated_count++;
            }
        } else {
            // create new record
            $data = array_fill(0, count($components), 0.0);
            $data[$exam_index] = $scaled_grade;
            $total = 0.0;
            foreach ($data as $v) {
                if (is_numeric($v)) $total += (float)$v;
            }

            $grade_val = 'F';
            $points = 0.0;
            foreach ($grading_scale as $gs) {
                if ($total >= $gs['min']) {
                    $grade_val = $gs['grade'];
                    $points = (float)$gs['points'];
                    break;
                }
            }

            $record = new stdClass();
            $record->courseid = $courseid;
            $record->userid = $uid;
            $record->sessionid = $sessionid;
            $record->termid = $termid;
            $record->data = json_encode($data);
            $record->total = $total;
            $record->grade = $grade_val;
            $record->points = $points;
            $record->timecreated = time();
            $record->timemodified = time();

            $DB->insert_record('local_sis_result', $record);
            $created_count++;
        }
    }

    $msg = "Quiz import completed: updated {$updated_count} existing records, created {$created_count} new records.";
    redirect(new moodle_url('/local/sis/enterca.php', [
        'courseid' => $courseid,
        'sessionid' => $sessionid,
        'termid' => $termid
    ]), $msg, null, \core\output\notification::NOTIFY_SUCCESS);
}

// === Display Page ===
echo $OUTPUT->header();

// Back link
$course_category = $DB->get_field('course', 'category', ['id' => $courseid]);
echo html_writer::div(
    html_writer::link(
        new moodle_url('/local/sis/enterca.php', ['categoryid' => $course_category]),
        'Back to Course Selection',
        ['class' => 'btn btn-secondary mb-3']
    ),
    'text-left'
);

// Button to navigate to CA Configuration
echo html_writer::div(
    html_writer::link(
        new moodle_url('/local/sis/caconfig.php', [
            'courseid' => $courseid,
            'sessionid' => $sessionid,
            'termid' => $termid
        ]),
        'Configure CA Settings',
        ['class' => 'btn btn-info mb-3']
    ),
    'text-left'
);

// Session and term selection form
echo html_writer::start_tag('form', ['method' => 'get', 'class' => 'form-inline mb-4']);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'courseid', 'value' => $courseid]);

// Session dropdown
echo html_writer::label('Session:', 'sessionid', false, ['class' => 'mr-2']);
$session_options = [0 => '-- Select Session --'];
foreach ($sessions as $s) {
    $session_options[$s->id] = $s->sessionname;
}
echo html_writer::select($session_options, 'sessionid', $sessionid, false, ['class' => 'form-control mr-3']);

// Term dropdown
echo html_writer::label('Term:', 'termid', false, ['class' => 'mr-2']);
$term_options = [0 => '-- Select Term --'];
if ($sessionid && $terms) {
    foreach ($terms as $t) {
        $term_options[$t->id] = $t->termname;
    }
} else {
    $term_options = [0 => '-- Select Session First --'];
}
echo html_writer::select($term_options, 'termid', $termid, false, ['class' => 'form-control mr-3']);

echo html_writer::empty_tag('input', [
    'type' => 'submit',
    'value' => 'Apply Filters',
    'class' => 'btn btn-primary'
]);
echo html_writer::end_tag('form');

// Page heading
echo $OUTPUT->heading("Enter Continuous Assessment (CA) for: " . format_string($course->fullname));

// Show warning if no terms available for selected session
if ($sessionid && empty($terms)) {
    echo $OUTPUT->notification("No terms found for the selected session. Please configure terms for this session first.", 'notifyproblem');
    echo $OUTPUT->footer();
    exit;
}

// Quiz selector (preview)
$quizzes = $DB->get_records('quiz', ['course' => $courseid], 'name ASC');
if (!empty($quizzes)) {
    echo html_writer::start_tag('form', ['method' => 'get', 'class' => 'form-inline mb-3']);
    echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'courseid', 'value' => $courseid]);
    echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sessionid', 'value' => $sessionid]);
    echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'termid', 'value' => $termid]);
    $options = [0 => '--- Select quiz to import (or choose none) ---'];
    foreach ($quizzes as $q) {
        $options[$q->id] = format_string($q->name);
    }
    echo html_writer::label('Import Exam scores from quiz:', 'quizid', false, ['class' => 'mr-2']);
    echo html_writer::select($options, 'quizid', $quizid, false, ['class' => 'form-control mr-2']);
    echo html_writer::empty_tag('input', ['type' => 'submit', 'value' => 'Apply', 'class' => 'btn btn-primary']);
    echo html_writer::end_tag('form');
}

// If a quiz was chosen, fetch its grades to preview
$quiz_scores = array();
if ($quizid) {
    $quizrec = $DB->get_record('quiz', ['id' => $quizid], '*', IGNORE_MISSING);
    if ($quizrec) {
        $qgrades = $DB->get_records('quiz_grades', ['quiz' => $quizid]);
        foreach ($qgrades as $g) {
            $quiz_scores[$g->userid] = (float)$g->grade;
        }
    }
}

// Import form (POST)
echo $OUTPUT->heading("Import Quiz Scores", 3);
echo html_writer::start_tag('form', ['method' => 'post', 'class' => 'mb-4']);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'import_quiz', 'value' => '1']);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey()]);
if ($quizid) {
    echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'quizid', 'value' => (int)$quizid]);
}
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sessionid', 'value' => (int)$sessionid]);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'termid', 'value' => (int)$termid]);

echo html_writer::start_div('form-check mb-2');
echo html_writer::empty_tag('input', ['type' => 'checkbox', 'name' => 'override_score', 'value' => '1', 'id' => 'override_score', 'class' => 'form-check-input']);
echo html_writer::tag('label', 'Override manually entered exam scores', ['for' => 'override_score', 'class' => 'form-check-label']);
echo html_writer::end_div();

echo html_writer::empty_tag('input', ['type' => 'submit', 'value' => 'Import Quiz Scores', 'class' => 'btn btn-primary']);
echo html_writer::end_tag('form');

// Bulk upload UI
echo $OUTPUT->heading("Bulk Upload CA Scores", 3);
echo html_writer::start_tag('form', ['method' => 'post', 'enctype' => 'multipart/form-data']);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'bulk_action', 'value' => 'upload']);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey()]);
echo html_writer::empty_tag('input', ['type' => 'file', 'name' => 'bulk_file', 'required' => 'required', 'class' => 'form-control-file mb-2']);
echo html_writer::empty_tag('input', ['type' => 'submit', 'value' => 'Upload CSV', 'class' => 'btn btn-secondary']);
echo html_writer::end_tag('form');

// Manual entry table
echo $OUTPUT->heading("Manual CA Entry", 3);

// fetch enrolled students with all name fields (excluding admins)
$students = get_enrolled_users($context, 'mod/assign:submit', '', 'u.id, u.idnumber, u.firstname, u.lastname, u.firstnamephonetic, u.lastnamephonetic, u.middlename, u.alternatename');
$students = filter_admin_users($students);

if (empty($students)) {
    echo $OUTPUT->notification("No students enrolled in this course.", 'notifyproblem');
    echo $OUTPUT->footer();
    exit;
}

// Build manual entry form
echo html_writer::start_tag('form', ['method' => 'post']);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'action', 'value' => 'saveca']);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey()]);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'courseid', 'value' => $courseid]);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sessionid', 'value' => $sessionid]);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'termid', 'value' => $termid]);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'categoryid', 'value' => $course->category]);

$table = new html_table();
$header = ['Student ID', 'Student'];
foreach ($components as $component) {
    $header[] = format_string($component['name']) . ' (Max: ' . $component['max'] . ')';
}
$header[] = 'Total';
$header[] = 'Grade';
$header[] = 'Points';
$table->head = $header;

foreach ($students as $s) {
    $uid = $s->id;
    $existing_data = array_fill(0, count($components), 0.0);
    $existing_total = '';
    $existing_grade = '';
    $existing_points = '';

    if (!empty($existing_by_user[$uid])) {
        $rec = $existing_by_user[$uid];
        if (!empty($rec->data)) {
            $decoded = json_decode($rec->data, true);
            if (is_array($decoded)) {
                for ($i = 0; $i < count($components); $i++) {
                    if (isset($decoded[$i]) && is_numeric($decoded[$i])) {
                        $existing_data[$i] = (float)$decoded[$i];
                    }
                }
            }
        }
        $existing_total = isset($rec->total) ? (float)$rec->total : '';
        $existing_grade = $rec->grade ?? '';
        $existing_points = isset($rec->points) ? (float)$rec->points : '';
    }

    $row = array();
    $row[] = html_writer::tag('span', $s->idnumber);
    $row[] = fullname($s);

    foreach ($components as $index => $component) {
        $value = $existing_data[$index];

        // If a quiz was chosen and this is the Exam component and existing value is empty/0,
        // preview the quiz score
        if ($quizid && strtolower(trim($component['name'])) === 'exam') {
            $preview_quiz_score = null;
            if (isset($quiz_scores[$uid])) {
                $quizrec = $DB->get_record('quiz', ['id' => $quizid], '*', IGNORE_MISSING);
                $quiz_max = $quizrec ? (float)($quizrec->grade ?: 0.0) : 0.0;
                $exam_max = (float)$component['max'];
                if ($quiz_max > 0) {
                    $preview_quiz_score = ($quiz_scores[$uid] / $quiz_max) * $exam_max;
                } else {
                    $preview_quiz_score = (float)$quiz_scores[$uid];
                }
            }
            if (($value === 0.0 || $value === null || $value === '') && $preview_quiz_score !== null) {
                $value = round($preview_quiz_score, 2);
            }
        }

        $row[] = html_writer::empty_tag('input', [
            'type' => 'number',
            'step' => '0.01',
            'min' => '0',
            'max' => $component['max'],
            'name' => "ca[{$uid}][ca{$index}]",
            'value' => $value === '' ? '' : $value,
            'style' => 'width: 80px;'
        ]);
    }

    $row[] = html_writer::tag('span', $existing_total === '' ? '&mdash;' : round($existing_total, 2), ['class' => 'total-value']);
    $row[] = html_writer::tag('span', $existing_grade === '' ? '&mdash;' : $existing_grade, ['class' => 'grade-value']);
    $row[] = html_writer::tag('span', $existing_points === '' ? '&mdash;' : round($existing_points, 1), ['class' => 'points-value']);

    $table->data[] = $row;
}

echo html_writer::table($table);
echo html_writer::empty_tag('input', ['type' => 'submit', 'value' => 'Save CA', 'class' => 'btn btn-primary']);
echo html_writer::end_tag('form');

// Add Back to SIS Dashboard button
echo '<div class="text-center mt-4">';
echo html_writer::link(
    new moodle_url('/local/sis/index.php'),
    'Back to Main Dashboard',
    ['class' => 'btn btn-success']
);
echo '</div>';

echo $OUTPUT->footer();
?>