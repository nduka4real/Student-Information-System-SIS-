<?php
// This file is part of the Student Information System plugin for Moodle.
// this file is used to manage upgrades
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version information for the Student Information System plugin
 *
 * @package    local_sis
 * @copyright  2025 NduksTech - https://facebook.com/ndukshub
 * @author     Nduka Akapti  (https://github.com/nduka4real)
 * @author     Ndukstech (https://www.youtube.com/@nduks-tech)
 * @author     https://www.linkedin.com/in/ndukaakpati/
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @details
 * Display Name: Student Information System
 * Description: A comprehensive system for managing student records, assessments, fees, and school operations.
 * Contact: https://github.com/nduka4real
 * Social: https://facebook.com/ndukshub
 */


defined('MOODLE_INTERNAL') || die();

/**
 * Execute local_sis upgrade from the given old version
 *
 * @param int $oldversion
 * @return bool
 */
function xmldb_local_sis_upgrade($oldversion) {
    global $DB;
    $dbman = $DB->get_manager();

    // ========== VERSION 2024100100 - INITIAL INSTALLATION ==========
    if ($oldversion < 2024100100) {

        // Create table: local_sis_ca_config
        $table = new xmldb_table('local_sis_ca_config');
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('courseid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('sessionid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('termid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('components', XMLDB_TYPE_TEXT, null, null, null, null, null);
        $table->add_field('grading_scale', XMLDB_TYPE_TEXT, null, null, null, null, null);
        $table->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));
        $table->add_key('course_session_term', XMLDB_KEY_UNIQUE, array('courseid', 'sessionid', 'termid'));
        $table->add_index('courseid_idx', XMLDB_INDEX_NOTUNIQUE, array('courseid'));
        $table->add_index('sessionid_idx', XMLDB_INDEX_NOTUNIQUE, array('sessionid'));
        $table->add_index('termid_idx', XMLDB_INDEX_NOTUNIQUE, array('termid'));
        
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        // Create table: local_sis_comments
        $table = new xmldb_table('local_sis_comments');
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('categoryid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('sessionid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('termid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('session', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('term', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('teachercomment', XMLDB_TYPE_TEXT, null, null, null, null, null);
        $table->add_field('principalcomment', XMLDB_TYPE_TEXT, null, null, null, null, null);
        $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));
        $table->add_index('userid_idx', XMLDB_INDEX_NOTUNIQUE, array('userid'));
        $table->add_index('categoryid_idx', XMLDB_INDEX_NOTUNIQUE, array('categoryid'));
        $table->add_index('session_term_idx', XMLDB_INDEX_NOTUNIQUE, array('sessionid', 'termid'));
        
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        // Create table: local_sis_fee
        $table = new xmldb_table('local_sis_fee');
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('amount', XMLDB_TYPE_NUMBER, '10,2', null, XMLDB_NOTNULL, null, '0.00');
        $table->add_field('status', XMLDB_TYPE_CHAR, '20', null, XMLDB_NOTNULL, null, 'pending');
        $table->add_field('session', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('term', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));
        $table->add_index('userid_idx', XMLDB_INDEX_NOTUNIQUE, array('userid'));
        $table->add_index('status_idx', XMLDB_INDEX_NOTUNIQUE, array('status'));
        $table->add_index('session_term_idx', XMLDB_INDEX_NOTUNIQUE, array('session', 'term'));
        
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        // Create table: local_sis_payments
        $table = new xmldb_table('local_sis_payments');
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('courseid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('amount', XMLDB_TYPE_NUMBER, '10,2', null, XMLDB_NOTNULL, null, null);
        $table->add_field('currency', XMLDB_TYPE_CHAR, '10', null, XMLDB_NOTNULL, null, 'USD');
        $table->add_field('gateway', XMLDB_TYPE_CHAR, '50', null, XMLDB_NOTNULL, null, null);
        $table->add_field('transaction_id', XMLDB_TYPE_CHAR, '255', null, null, null, null);
        $table->add_field('reference', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, null);
        $table->add_field('status', XMLDB_TYPE_CHAR, '50', null, XMLDB_NOTNULL, null, 'pending');
        $table->add_field('payment_data', XMLDB_TYPE_TEXT, null, null, null, null, null);
        $table->add_field('created_at', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('updated_at', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('metadata', XMLDB_TYPE_TEXT, null, null, null, null, null);
        $table->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));
        $table->add_index('userid_idx', XMLDB_INDEX_NOTUNIQUE, array('userid'));
        $table->add_index('reference_idx', XMLDB_INDEX_UNIQUE, array('reference'));
        $table->add_index('status_idx', XMLDB_INDEX_NOTUNIQUE, array('status'));
        $table->add_index('gateway_idx', XMLDB_INDEX_NOTUNIQUE, array('gateway'));
        
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        // Create table: local_sis_payment_categories
        $table = new xmldb_table('local_sis_payment_categories');
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('categoryid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('course_fee', XMLDB_TYPE_NUMBER, '10,2', null, XMLDB_NOTNULL, null, '0.00');
        $table->add_field('registration_fee', XMLDB_TYPE_NUMBER, '10,2', null, XMLDB_NOTNULL, null, '0.00');
        $table->add_field('exam_fee', XMLDB_TYPE_NUMBER, '10,2', null, XMLDB_NOTNULL, null, '0.00');
        $table->add_field('library_fee', XMLDB_TYPE_NUMBER, '10,2', null, XMLDB_NOTNULL, null, '0.00');
        $table->add_field('other_fee', XMLDB_TYPE_NUMBER, '10,2', null, XMLDB_NOTNULL, null, '0.00');
        $table->add_field('currency', XMLDB_TYPE_CHAR, '3', null, XMLDB_NOTNULL, null, 'USD');
        $table->add_field('enabled', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '1');
        $table->add_field('payallfees', XMLDB_TYPE_INTEGER, '1', null, null, null, '0');
        $table->add_field('created_at', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('updated_at', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));
        $table->add_key('categoryid_unique', XMLDB_KEY_UNIQUE, array('categoryid'));
        
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        // Create table: local_sis_payment_config
        $table = new xmldb_table('local_sis_payment_config');
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('gateway', XMLDB_TYPE_CHAR, '50', null, XMLDB_NOTNULL, null, null);
        $table->add_field('config_key', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, null);
        $table->add_field('config_value', XMLDB_TYPE_TEXT, null, null, XMLDB_NOTNULL, null, null);
        $table->add_field('is_secret', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0');
        $table->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));
        $table->add_key('gateway_key', XMLDB_KEY_UNIQUE, array('gateway', 'config_key'));
        
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        // Create table: local_sis_promotions_log
        $table = new xmldb_table('local_sis_promotions_log');
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('source_category', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('target_category', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('source_session', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('target_session', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('students_promoted', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('promoted_by', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('details', XMLDB_TYPE_TEXT, null, null, null, null, null);
        $table->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));
        $table->add_index('source_category_idx', XMLDB_INDEX_NOTUNIQUE, array('source_category'));
        $table->add_index('target_category_idx', XMLDB_INDEX_NOTUNIQUE, array('target_category'));
        $table->add_index('promoted_by_idx', XMLDB_INDEX_NOTUNIQUE, array('promoted_by'));
        
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        // Create table: local_sis_quizmap
        $table = new xmldb_table('local_sis_quizmap');
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('quizid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('courseid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('categoryid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('weight', XMLDB_TYPE_NUMBER, '10,2', null, XMLDB_NOTNULL, null, '0.00');
        $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));
        $table->add_key('quiz_unique', XMLDB_KEY_UNIQUE, array('quizid'));
        $table->add_index('courseid_idx', XMLDB_INDEX_NOTUNIQUE, array('courseid'));
        $table->add_index('categoryid_idx', XMLDB_INDEX_NOTUNIQUE, array('categoryid'));
        
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        // Create table: local_sis_result
        $table = new xmldb_table('local_sis_result');
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('courseid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('sessionid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('termid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('data', XMLDB_TYPE_TEXT, null, null, null, null, null);
        $table->add_field('total', XMLDB_TYPE_NUMBER, '10,2', null, XMLDB_NOTNULL, null, '0.00');
        $table->add_field('grade', XMLDB_TYPE_CHAR, '10', null, XMLDB_NOTNULL, null, 'F');
        $table->add_field('points', XMLDB_TYPE_NUMBER, '5,2', null, XMLDB_NOTNULL, null, '0.00');
        $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));
        $table->add_key('user_course_session_term', XMLDB_KEY_UNIQUE, array('userid', 'courseid', 'sessionid', 'termid'));
        $table->add_index('courseid_idx', XMLDB_INDEX_NOTUNIQUE, array('courseid'));
        $table->add_index('userid_idx', XMLDB_INDEX_NOTUNIQUE, array('userid'));
        $table->add_index('session_term_idx', XMLDB_INDEX_NOTUNIQUE, array('sessionid', 'termid'));
        
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        // Create table: local_sis_school_settings
        $table = new xmldb_table('local_sis_school_settings');
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('schoolname', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, '');
        $table->add_field('schooladdress', XMLDB_TYPE_TEXT, null, null, null, null, null);
        $table->add_field('schoolmotto', XMLDB_TYPE_CHAR, '255', null, null, null, '');
        $table->add_field('phone', XMLDB_TYPE_CHAR, '50', null, null, null, '');
        $table->add_field('state', XMLDB_TYPE_CHAR, '100', null, null, null, '');
        $table->add_field('country', XMLDB_TYPE_CHAR, '100', null, null, null, '');
        $table->add_field('schoollogo', XMLDB_TYPE_CHAR, '255', null, null, null, '');
        $table->add_field('principalsignature', XMLDB_TYPE_CHAR, '255', null, null, null, '');
        $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));
        
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        // Create table: local_sis_sessions
        $table = new xmldb_table('local_sis_sessions');
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('sessionname', XMLDB_TYPE_CHAR, '50', null, XMLDB_NOTNULL, null, '');
        $table->add_field('isactive', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('isdefault', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0');
        $table->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));
        $table->add_index('isactive_idx', XMLDB_INDEX_NOTUNIQUE, array('isactive'));
        $table->add_index('isdefault_idx', XMLDB_INDEX_NOTUNIQUE, array('isdefault'));
        
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        // Create table: local_sis_student_access
        $table = new xmldb_table('local_sis_student_access');
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('categoryid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('sessionid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('termid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('can_attempt_quiz', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('can_view_results', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));
        $table->add_key('user_category_session_term', XMLDB_KEY_UNIQUE, array('userid', 'categoryid', 'sessionid', 'termid'));
        $table->add_index('userid_idx', XMLDB_INDEX_NOTUNIQUE, array('userid'));
        $table->add_index('categoryid_idx', XMLDB_INDEX_NOTUNIQUE, array('categoryid'));
        $table->add_index('session_term_idx', XMLDB_INDEX_NOTUNIQUE, array('sessionid', 'termid'));
        
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        // Create table: local_sis_terms
        $table = new xmldb_table('local_sis_terms');
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('sessionid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('termname', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, '');
        $table->add_field('isdefault', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('calculate_cumulative', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '0');
        $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));
        $table->add_key('session_term', XMLDB_KEY_UNIQUE, array('sessionid', 'termname'));
        $table->add_index('sessionid_idx', XMLDB_INDEX_NOTUNIQUE, array('sessionid'));
        $table->add_index('isdefault_idx', XMLDB_INDEX_NOTUNIQUE, array('isdefault'));
        
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

        upgrade_plugin_savepoint(true, 2024100100, 'local', 'sis');
    }

    // ========== VERSION 2024100101 - FIX duplicate session/term fields in comments table ==========
    if ($oldversion < 2024100101) {
        // Fix: local_sis_comments has both sessionid/session and termid/term - this is confusing
        // Let's add indexes to help with queries
        $table = new xmldb_table('local_sis_comments');
        
        // Add index on session, term (the numeric fields, not the id fields)
        $index = new xmldb_index('session_term_alt_idx', XMLDB_INDEX_NOTUNIQUE, array('session', 'term'));
        
        if (!$dbman->index_exists($table, $index)) {
            $dbman->add_index($table, $index);
        }
        
        upgrade_plugin_savepoint(true, 2024100101, 'local', 'sis');
    }

    // ========== VERSION 2024100102 - ADD missing default values ==========
    if ($oldversion < 2024100102) {
        // Add default for timemodified in comments table
        $table = new xmldb_table('local_sis_comments');
        $field = new xmldb_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0');
        
        // Check if field exists before trying to change it
        if ($dbman->field_exists($table, $field)) {
            $dbman->change_field_default($table, $field);
        }
        
        upgrade_plugin_savepoint(true, 2024100102, 'local', 'sis');
    }

    // ========== VERSION 2024100103 - ADD courseid index to payments table ==========
    if ($oldversion < 2024100103) {
        $table = new xmldb_table('local_sis_payments');
        $index = new xmldb_index('courseid_idx', XMLDB_INDEX_NOTUNIQUE, array('courseid'));
        
        if (!$dbman->index_exists($table, $index)) {
            $dbman->add_index($table, $index);
        }
        
        upgrade_plugin_savepoint(true, 2024100103, 'local', 'sis');
    }

    // ========== VERSION 2024100104 - ADD transaction_id index to payments table ==========
    if ($oldversion < 2024100104) {
        $table = new xmldb_table('local_sis_payments');
        $index = new xmldb_index('transaction_id_idx', XMLDB_INDEX_NOTUNIQUE, array('transaction_id'));
        
        if (!$dbman->index_exists($table, $index)) {
            $dbman->add_index($table, $index);
        }
        
        upgrade_plugin_savepoint(true, 2024100104, 'local', 'sis');
    }

    // ========== VERSION 2024100105 - ADD fee_id field to payments table for better tracking ==========
    if ($oldversion < 2024100105) {
        $table = new xmldb_table('local_sis_payments');
        $field = new xmldb_field('fee_id', XMLDB_TYPE_INTEGER, '10', null, null, null, null, 'courseid');
        
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
            
            // Add index for fee_id
            $index = new xmldb_index('fee_id_idx', XMLDB_INDEX_NOTUNIQUE, array('fee_id'));
            if (!$dbman->index_exists($table, $index)) {
                $dbman->add_index($table, $index);
            }
        }
        
        upgrade_plugin_savepoint(true, 2024100105, 'local', 'sis');
    }

    // ========== VERSION 2024100106 - ADD created_at field to fee table ==========
    if ($oldversion < 2024100106) {
        $table = new xmldb_table('local_sis_fee');
        $field = new xmldb_field('created_at', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0', 'timemodified');
        
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }
        
        upgrade_plugin_savepoint(true, 2024100106, 'local', 'sis');
    }

    // ========== VERSION 2024100107 - ADD timecreated field to ca_config table ==========
    if ($oldversion < 2024100107) {
        $table = new xmldb_table('local_sis_ca_config');
        $field = new xmldb_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, '0', 'termid');
        
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }
        
        upgrade_plugin_savepoint(true, 2024100107, 'local', 'sis');
    }

    return true;
}