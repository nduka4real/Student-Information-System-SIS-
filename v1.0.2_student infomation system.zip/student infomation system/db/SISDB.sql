

--
-- Table structure for table `mdl_local_sis_ca_config`
--

CREATE TABLE `mdl_local_sis_ca_config` (
  `id` bigint(10) NOT NULL,
  `courseid` bigint(10) NOT NULL DEFAULT 0,
  `sessionid` bigint(10) NOT NULL DEFAULT 0,
  `termid` int(10) NOT NULL DEFAULT 0,
  `timemodified` bigint(10) NOT NULL DEFAULT 0,
  `components` longtext DEFAULT NULL,
  `grading_scale` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Continuous assessment configuration' ROW_FORMAT=COMPRESSED;

--
-- Dumping data for table `mdl_local_sis_ca_config`
--

INSERT INTO `mdl_local_sis_ca_config` (`id`, `courseid`, `sessionid`, `termid`, `timemodified`, `components`, `grading_scale`) VALUES
(28, 16, 3, 7, 1760889600, '[{\"name\":\"First CA\",\"weight\":10,\"max\":10},{\"name\":\"Second CA\",\"weight\":20,\"max\":20},{\"name\":\"Exam\",\"weight\":70,\"max\":70}]', '[{\"min\":70,\"grade\":\"A\",\"points\":5},{\"min\":65,\"grade\":\"B\",\"points\":4},{\"min\":60,\"grade\":\"C\",\"points\":3},{\"min\":55,\"grade\":\"D\",\"points\":2},{\"min\":50,\"grade\":\"E\",\"points\":1},{\"min\":45,\"grade\":\"E_\",\"points\":0.5},{\"min\":0,\"grade\":\"F\",\"points\":0}]'),
(29, 15, 3, 1, 1760045495, '[{\"name\":\"First CA\",\"weight\":20,\"max\":20},{\"name\":\"Second CA\",\"weight\":20,\"max\":20},{\"name\":\"Exam\",\"weight\":60,\"max\":60}]', '[{\"min\":70,\"grade\":\"A\",\"points\":5},{\"min\":65,\"grade\":\"B\",\"points\":4},{\"min\":60,\"grade\":\"C\",\"points\":3},{\"min\":55,\"grade\":\"D\",\"points\":2},{\"min\":50,\"grade\":\"E\",\"points\":1},{\"min\":45,\"grade\":\"P\",\"points\":0.5},{\"min\":0,\"grade\":\"F\",\"points\":0}]'),
(30, 3, 3, 1, 1760241567, '[{\"name\":\"First CA\",\"weight\":20,\"max\":20},{\"name\":\"Second CA\",\"weight\":20,\"max\":20},{\"name\":\"Exam\",\"weight\":60,\"max\":60}]', '[{\"min\":70,\"grade\":\"A\",\"points\":5},{\"min\":65,\"grade\":\"B\",\"points\":4},{\"min\":60,\"grade\":\"C\",\"points\":3},{\"min\":55,\"grade\":\"D\",\"points\":2},{\"min\":50,\"grade\":\"E\",\"points\":1},{\"min\":45,\"grade\":\"E_\",\"points\":0.5},{\"min\":0,\"grade\":\"F\",\"points\":0}]'),
(31, 3, 3, 7, 1760051315, '[{\"name\":\"First CA\",\"weight\":10,\"max\":10},{\"name\":\"Second CA\",\"weight\":20,\"max\":20},{\"name\":\"Exam\",\"weight\":70,\"max\":70}]', '[{\"min\":70,\"grade\":\"A\",\"points\":5},{\"min\":65,\"grade\":\"B\",\"points\":4},{\"min\":60,\"grade\":\"C\",\"points\":3},{\"min\":55,\"grade\":\"D\",\"points\":2},{\"min\":50,\"grade\":\"E\",\"points\":1},{\"min\":45,\"grade\":\"P\",\"points\":0.5},{\"min\":0,\"grade\":\"F\",\"points\":0}]'),
(32, 2, 3, 1, 1760241706, '[{\"name\":\"First CA\",\"weight\":20,\"max\":20},{\"name\":\"Second CA\",\"weight\":20,\"max\":20},{\"name\":\"Exam\",\"weight\":60,\"max\":60}]', '[{\"min\":70,\"grade\":\"A\",\"points\":5},{\"min\":65,\"grade\":\"B\",\"points\":4},{\"min\":60,\"grade\":\"C\",\"points\":3},{\"min\":55,\"grade\":\"D\",\"points\":2},{\"min\":50,\"grade\":\"E\",\"points\":1},{\"min\":45,\"grade\":\"E_\",\"points\":0.5},{\"min\":0,\"grade\":\"F\",\"points\":0}]'),
(33, 2, 3, 7, 1760052286, '[{\"name\":\"First CA\",\"weight\":10,\"max\":10},{\"name\":\"Second CA\",\"weight\":20,\"max\":20},{\"name\":\"Exam\",\"weight\":70,\"max\":70}]', '[{\"min\":70,\"grade\":\"A\",\"points\":5},{\"min\":65,\"grade\":\"B\",\"points\":4},{\"min\":60,\"grade\":\"C\",\"points\":3},{\"min\":55,\"grade\":\"D\",\"points\":2},{\"min\":50,\"grade\":\"E\",\"points\":1},{\"min\":45,\"grade\":\"E_\",\"points\":0.5},{\"min\":0,\"grade\":\"F\",\"points\":0}]'),
(34, 2, 3, 4, 1760050562, '[{\"name\":\"First CA\",\"weight\":15,\"max\":15},{\"name\":\"Second CA\",\"weight\":15,\"max\":15},{\"name\":\"Exam\",\"weight\":70,\"max\":70}]', '[{\"min\":70,\"grade\":\"A\",\"points\":5},{\"min\":65,\"grade\":\"B\",\"points\":4},{\"min\":60,\"grade\":\"C\",\"points\":3},{\"min\":55,\"grade\":\"D\",\"points\":2},{\"min\":50,\"grade\":\"E\",\"points\":1},{\"min\":45,\"grade\":\"E_\",\"points\":0.5},{\"min\":0,\"grade\":\"F\",\"points\":0}]'),
(35, 16, 3, 1, 1760880377, '[{\"name\":\"First CA\",\"weight\":10,\"max\":10},{\"name\":\"Second CA\",\"weight\":20,\"max\":20},{\"name\":\"Exam\",\"weight\":70,\"max\":70}]', '[{\"min\":70,\"grade\":\"A\",\"points\":5},{\"min\":60,\"grade\":\"B\",\"points\":4},{\"min\":50,\"grade\":\"C\",\"points\":3},{\"min\":45,\"grade\":\"D\",\"points\":2},{\"min\":40,\"grade\":\"E\",\"points\":1},{\"min\":0,\"grade\":\"F\",\"points\":0},{\"min\":1,\"grade\":\"f\",\"points\":0}]'),
(36, 8, 3, 1, 1760303384, '[{\"name\":\"First CA\",\"weight\":15,\"max\":15},{\"name\":\"Second CA\",\"weight\":15,\"max\":15},{\"name\":\"Exam\",\"weight\":70,\"max\":70}]', '[{\"min\":70,\"grade\":\"A\",\"points\":5},{\"min\":65,\"grade\":\"B\",\"points\":4},{\"min\":60,\"grade\":\"C\",\"points\":3},{\"min\":55,\"grade\":\"D\",\"points\":2},{\"min\":50,\"grade\":\"E\",\"points\":1},{\"min\":45,\"grade\":\"E_\",\"points\":0.5},{\"min\":0,\"grade\":\"F\",\"points\":0}]'),
(37, 8, 2, 1, 1760303399, '[{\"name\":\"First CA\",\"weight\":15,\"max\":15},{\"name\":\"Second CA\",\"weight\":15,\"max\":15},{\"name\":\"Exam\",\"weight\":70,\"max\":70}]', '[{\"min\":70,\"grade\":\"A\",\"points\":5},{\"min\":65,\"grade\":\"B\",\"points\":4},{\"min\":60,\"grade\":\"C\",\"points\":3},{\"min\":55,\"grade\":\"D\",\"points\":2},{\"min\":50,\"grade\":\"E\",\"points\":1},{\"min\":45,\"grade\":\"E_\",\"points\":0.5},{\"min\":0,\"grade\":\"F\",\"points\":0}]'),
(38, 16, 3, 4, 1760888206, '[{\"name\":\"First CA\",\"weight\":15,\"max\":15},{\"name\":\"Second CA\",\"weight\":15,\"max\":15},{\"name\":\"Exam\",\"weight\":70,\"max\":70}]', '[{\"min\":70,\"grade\":\"A\",\"points\":5},{\"min\":65,\"grade\":\"B\",\"points\":4},{\"min\":60,\"grade\":\"C\",\"points\":3},{\"min\":55,\"grade\":\"D\",\"points\":2},{\"min\":50,\"grade\":\"E\",\"points\":1},{\"min\":45,\"grade\":\"E_\",\"points\":0.5},{\"min\":0,\"grade\":\"F\",\"points\":0}]'),
(39, 16, 1, 1, 1760888806, '[{\"name\":\"First CA\",\"weight\":15,\"max\":15},{\"name\":\"Second CA\",\"weight\":15,\"max\":15},{\"name\":\"Exam\",\"weight\":70,\"max\":70}]', '[{\"min\":70,\"grade\":\"A\",\"points\":5},{\"min\":65,\"grade\":\"B\",\"points\":4},{\"min\":60,\"grade\":\"C\",\"points\":3},{\"min\":55,\"grade\":\"D\",\"points\":2},{\"min\":50,\"grade\":\"E\",\"points\":1},{\"min\":45,\"grade\":\"E_\",\"points\":0.5},{\"min\":0,\"grade\":\"F\",\"points\":0}]'),
(40, 16, 2, 4, 1760888826, '[{\"name\":\"First CA\",\"weight\":15,\"max\":15},{\"name\":\"Second CA\",\"weight\":15,\"max\":15},{\"name\":\"Exam\",\"weight\":70,\"max\":70}]', '[{\"min\":70,\"grade\":\"A\",\"points\":5},{\"min\":65,\"grade\":\"B\",\"points\":4},{\"min\":60,\"grade\":\"C\",\"points\":3},{\"min\":55,\"grade\":\"D\",\"points\":2},{\"min\":50,\"grade\":\"E\",\"points\":1},{\"min\":45,\"grade\":\"E_\",\"points\":0.5},{\"min\":0,\"grade\":\"F\",\"points\":0}]'),
(41, 15, 3, 7, 1760889600, '[{\"name\":\"First CA\",\"weight\":10,\"max\":10},{\"name\":\"Second CA\",\"weight\":20,\"max\":20},{\"name\":\"Exam\",\"weight\":70,\"max\":70}]', '[{\"min\":70,\"grade\":\"A\",\"points\":5},{\"min\":65,\"grade\":\"B\",\"points\":4},{\"min\":60,\"grade\":\"C\",\"points\":3},{\"min\":55,\"grade\":\"D\",\"points\":2},{\"min\":50,\"grade\":\"E\",\"points\":1},{\"min\":45,\"grade\":\"E_\",\"points\":0.5},{\"min\":0,\"grade\":\"F\",\"points\":0}]'),
(42, 9, 3, 7, 1760889600, '[{\"name\":\"First CA\",\"weight\":10,\"max\":10},{\"name\":\"Second CA\",\"weight\":20,\"max\":20},{\"name\":\"Exam\",\"weight\":70,\"max\":70}]', '[{\"min\":70,\"grade\":\"A\",\"points\":5},{\"min\":65,\"grade\":\"B\",\"points\":4},{\"min\":60,\"grade\":\"C\",\"points\":3},{\"min\":55,\"grade\":\"D\",\"points\":2},{\"min\":50,\"grade\":\"E\",\"points\":1},{\"min\":45,\"grade\":\"E_\",\"points\":0.5},{\"min\":0,\"grade\":\"F\",\"points\":0}]'),
(43, 10, 3, 7, 1760889600, '[{\"name\":\"First CA\",\"weight\":10,\"max\":10},{\"name\":\"Second CA\",\"weight\":20,\"max\":20},{\"name\":\"Exam\",\"weight\":70,\"max\":70}]', '[{\"min\":70,\"grade\":\"A\",\"points\":5},{\"min\":65,\"grade\":\"B\",\"points\":4},{\"min\":60,\"grade\":\"C\",\"points\":3},{\"min\":55,\"grade\":\"D\",\"points\":2},{\"min\":50,\"grade\":\"E\",\"points\":1},{\"min\":45,\"grade\":\"E_\",\"points\":0.5},{\"min\":0,\"grade\":\"F\",\"points\":0}]'),
(44, 11, 3, 7, 1760889600, '[{\"name\":\"First CA\",\"weight\":10,\"max\":10},{\"name\":\"Second CA\",\"weight\":20,\"max\":20},{\"name\":\"Exam\",\"weight\":70,\"max\":70}]', '[{\"min\":70,\"grade\":\"A\",\"points\":5},{\"min\":65,\"grade\":\"B\",\"points\":4},{\"min\":60,\"grade\":\"C\",\"points\":3},{\"min\":55,\"grade\":\"D\",\"points\":2},{\"min\":50,\"grade\":\"E\",\"points\":1},{\"min\":45,\"grade\":\"E_\",\"points\":0.5},{\"min\":0,\"grade\":\"F\",\"points\":0}]'),
(45, 12, 3, 7, 1760889600, '[{\"name\":\"First CA\",\"weight\":10,\"max\":10},{\"name\":\"Second CA\",\"weight\":20,\"max\":20},{\"name\":\"Exam\",\"weight\":70,\"max\":70}]', '[{\"min\":70,\"grade\":\"A\",\"points\":5},{\"min\":65,\"grade\":\"B\",\"points\":4},{\"min\":60,\"grade\":\"C\",\"points\":3},{\"min\":55,\"grade\":\"D\",\"points\":2},{\"min\":50,\"grade\":\"E\",\"points\":1},{\"min\":45,\"grade\":\"E_\",\"points\":0.5},{\"min\":0,\"grade\":\"F\",\"points\":0}]'),
(46, 13, 3, 7, 1760889600, '[{\"name\":\"First CA\",\"weight\":10,\"max\":10},{\"name\":\"Second CA\",\"weight\":20,\"max\":20},{\"name\":\"Exam\",\"weight\":70,\"max\":70}]', '[{\"min\":70,\"grade\":\"A\",\"points\":5},{\"min\":65,\"grade\":\"B\",\"points\":4},{\"min\":60,\"grade\":\"C\",\"points\":3},{\"min\":55,\"grade\":\"D\",\"points\":2},{\"min\":50,\"grade\":\"E\",\"points\":1},{\"min\":45,\"grade\":\"E_\",\"points\":0.5},{\"min\":0,\"grade\":\"F\",\"points\":0}]'),
(47, 14, 3, 7, 1760889600, '[{\"name\":\"First CA\",\"weight\":10,\"max\":10},{\"name\":\"Second CA\",\"weight\":20,\"max\":20},{\"name\":\"Exam\",\"weight\":70,\"max\":70}]', '[{\"min\":70,\"grade\":\"A\",\"points\":5},{\"min\":65,\"grade\":\"B\",\"points\":4},{\"min\":60,\"grade\":\"C\",\"points\":3},{\"min\":55,\"grade\":\"D\",\"points\":2},{\"min\":50,\"grade\":\"E\",\"points\":1},{\"min\":45,\"grade\":\"E_\",\"points\":0.5},{\"min\":0,\"grade\":\"F\",\"points\":0}]'),
(48, 17, 3, 7, 1760889600, '[{\"name\":\"First CA\",\"weight\":10,\"max\":10},{\"name\":\"Second CA\",\"weight\":20,\"max\":20},{\"name\":\"Exam\",\"weight\":70,\"max\":70}]', '[{\"min\":70,\"grade\":\"A\",\"points\":5},{\"min\":65,\"grade\":\"B\",\"points\":4},{\"min\":60,\"grade\":\"C\",\"points\":3},{\"min\":55,\"grade\":\"D\",\"points\":2},{\"min\":50,\"grade\":\"E\",\"points\":1},{\"min\":45,\"grade\":\"E_\",\"points\":0.5},{\"min\":0,\"grade\":\"F\",\"points\":0}]'),
(49, 18, 3, 7, 1760889600, '[{\"name\":\"First CA\",\"weight\":10,\"max\":10},{\"name\":\"Second CA\",\"weight\":20,\"max\":20},{\"name\":\"Exam\",\"weight\":70,\"max\":70}]', '[{\"min\":70,\"grade\":\"A\",\"points\":5},{\"min\":65,\"grade\":\"B\",\"points\":4},{\"min\":60,\"grade\":\"C\",\"points\":3},{\"min\":55,\"grade\":\"D\",\"points\":2},{\"min\":50,\"grade\":\"E\",\"points\":1},{\"min\":45,\"grade\":\"E_\",\"points\":0.5},{\"min\":0,\"grade\":\"F\",\"points\":0}]'),
(50, 19, 3, 7, 1760889600, '[{\"name\":\"First CA\",\"weight\":10,\"max\":10},{\"name\":\"Second CA\",\"weight\":20,\"max\":20},{\"name\":\"Exam\",\"weight\":70,\"max\":70}]', '[{\"min\":70,\"grade\":\"A\",\"points\":5},{\"min\":65,\"grade\":\"B\",\"points\":4},{\"min\":60,\"grade\":\"C\",\"points\":3},{\"min\":55,\"grade\":\"D\",\"points\":2},{\"min\":50,\"grade\":\"E\",\"points\":1},{\"min\":45,\"grade\":\"E_\",\"points\":0.5},{\"min\":0,\"grade\":\"F\",\"points\":0}]'),
(51, 22, 3, 7, 1761080637, '[{\"name\":\"First CA\",\"weight\":15,\"max\":15},{\"name\":\"Second CA\",\"weight\":15,\"max\":15},{\"name\":\"Exam\",\"weight\":70,\"max\":70}]', '[{\"min\":70,\"grade\":\"A\",\"points\":5},{\"min\":65,\"grade\":\"B\",\"points\":4},{\"min\":60,\"grade\":\"C\",\"points\":3},{\"min\":55,\"grade\":\"D\",\"points\":2},{\"min\":50,\"grade\":\"E\",\"points\":1},{\"min\":45,\"grade\":\"E_\",\"points\":0.5},{\"min\":0,\"grade\":\"F\",\"points\":0}]'),
(52, 20, 3, 7, 1762195191, '[{\"name\":\"First CA\",\"weight\":10,\"max\":10},{\"name\":\"Second CA\",\"weight\":20,\"max\":20},{\"name\":\"Exam\",\"weight\":70,\"max\":70}]', '[{\"min\":70,\"grade\":\"A\",\"points\":5},{\"min\":65,\"grade\":\"B\",\"points\":4},{\"min\":60,\"grade\":\"C\",\"points\":3},{\"min\":55,\"grade\":\"D\",\"points\":2},{\"min\":50,\"grade\":\"E\",\"points\":1},{\"min\":45,\"grade\":\"E_\",\"points\":0.5},{\"min\":0,\"grade\":\"F\",\"points\":0}]'),
(53, 23, 3, 7, 1762195191, '[{\"name\":\"First CA\",\"weight\":10,\"max\":10},{\"name\":\"Second CA\",\"weight\":20,\"max\":20},{\"name\":\"Exam\",\"weight\":70,\"max\":70}]', '[{\"min\":70,\"grade\":\"A\",\"points\":5},{\"min\":65,\"grade\":\"B\",\"points\":4},{\"min\":60,\"grade\":\"C\",\"points\":3},{\"min\":55,\"grade\":\"D\",\"points\":2},{\"min\":50,\"grade\":\"E\",\"points\":1},{\"min\":45,\"grade\":\"E_\",\"points\":0.5},{\"min\":0,\"grade\":\"F\",\"points\":0}]');

-- --------------------------------------------------------

--
-- Table structure for table `mdl_local_sis_comments`
--

CREATE TABLE `mdl_local_sis_comments` (
  `id` bigint(10) NOT NULL,
  `userid` bigint(10) NOT NULL,
  `categoryid` bigint(10) NOT NULL,
  `sessionid` bigint(10) NOT NULL DEFAULT 0,
  `termid` bigint(10) NOT NULL DEFAULT 0,
  `session` bigint(10) NOT NULL DEFAULT 0,
  `term` bigint(10) NOT NULL DEFAULT 0,
  `teachercomment` longtext DEFAULT NULL,
  `principalcomment` longtext DEFAULT NULL,
  `timemodified` bigint(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mdl_local_sis_comments`
--

INSERT INTO `mdl_local_sis_comments` (`id`, `userid`, `categoryid`, `sessionid`, `termid`, `session`, `term`, `teachercomment`, `principalcomment`, `timemodified`) VALUES
(1, 4, 1, 3, 7, 3, 7, 'Outstanding performance with a total of 185.75 marks and an excellent average of 92.88%. Keep it up!', 'Excellent achievement. Maintain this high standard across all subjects.', 1761598657),
(2, 3, 1, 3, 7, 3, 7, 'Outstanding performance with a total of 183.25 marks and an excellent average of 91.63%. Keep it up!', 'Excellent achievement. Maintain this high standard across all subjects.', 1761598657),
(3, 2, 1, 3, 7, 3, 7, 'Poor result (total marks: 0, average: 0.00%). Serious improvement and dedication are required.', 'Performance is below expectation. Strong commitment is needed to improve.', 1761598657),
(4, 6, 6, 3, 7, 3, 7, 'Good work with a total of 672 marks and an average of 67.20%. With more effort, you can reach the top.', 'A commendable effort. Strive for more consistency and aim higher.', 1762331852),
(5, 13, 6, 3, 7, 3, 7, 'Good work with a total of 689 marks and an average of 68.90%. With more effort, you can reach the top.', 'A commendable effort. Strive for more consistency and aim higher.', 1762331852),
(6, 5, 6, 3, 7, 3, 7, 'Good work with a total of 682 marks and an average of 75.78%. With more effort, you can reach the top.', 'A commendable effort. Strive for more consistency and aim higher.', 1762331852),
(7, 8, 6, 3, 7, 3, 7, 'Good work with a total of 760 marks and an average of 76.00%. With more effort, you can reach the top.', 'A commendable effort. Strive for more consistency and aim higher.', 1762331852),
(8, 14, 6, 3, 7, 3, 7, 'Outstanding performance with a total of 805 marks and an excellent average of 80.50%. Keep it up!', 'Excellent achievement. Maintain this high standard across all subjects.', 1762331852),
(9, 12, 6, 3, 7, 3, 7, 'Good work with a total of 707 marks and an average of 70.70%. With more effort, you can reach the top.', 'A commendable effort. Strive for more consistency and aim higher.', 1762331852),
(10, 7, 6, 3, 7, 3, 7, 'Good work with a total of 786 marks and an average of 78.60%. With more effort, you can reach the top.', 'A commendable effort. Strive for more consistency and aim higher.', 1762331852),
(11, 10, 6, 3, 7, 3, 7, 'Outstanding performance with a total of 778 marks and an excellent average of 86.44%. Keep it up!', 'Excellent achievement. Maintain this high standard across all subjects.', 1762331852),
(12, 11, 6, 3, 7, 3, 7, 'Good work with a total of 772 marks and an average of 77.20%. With more effort, you can reach the top.', 'A commendable effort. Strive for more consistency and aim higher.', 1762331853),
(13, 9, 6, 3, 7, 3, 7, 'Good work with a total of 777 marks and an average of 77.70%. With more effort, you can reach the top.', 'A commendable effort. Strive for more consistency and aim higher.', 1762331853);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_local_sis_fee`
--

CREATE TABLE `mdl_local_sis_fee` (
  `id` bigint(10) NOT NULL,
  `userid` bigint(10) NOT NULL,
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `session` bigint(10) NOT NULL DEFAULT 0,
  `term` bigint(10) NOT NULL DEFAULT 0,
  `timemodified` bigint(10) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Student fee tracking' ROW_FORMAT=COMPRESSED;

-- --------------------------------------------------------

--
-- Table structure for table `mdl_local_sis_payments`
--

CREATE TABLE `mdl_local_sis_payments` (
  `id` bigint(10) NOT NULL,
  `userid` bigint(10) NOT NULL,
  `courseid` bigint(10) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(10) NOT NULL DEFAULT 'USD',
  `gateway` varchar(50) NOT NULL,
  `transaction_id` varchar(255) DEFAULT NULL,
  `reference` varchar(255) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'pending',
  `payment_data` text DEFAULT NULL,
  `created_at` bigint(10) NOT NULL,
  `updated_at` bigint(10) NOT NULL,
  `metadata` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mdl_local_sis_payments`
--

INSERT INTO `mdl_local_sis_payments` (`id`, `userid`, `courseid`, `amount`, `currency`, `gateway`, `transaction_id`, `reference`, `status`, `payment_data`, `created_at`, `updated_at`, `metadata`) VALUES
(1, 11, NULL, 50000.00, 'NGN', 'flutterwave', NULL, 'SIS_1761947929_5283', 'pending', NULL, 1761947929, 1761947929, '{\"description\":\"Course Fee\",\"categoryid\":\"6\",\"user\":\"iyeta treasure\"}'),
(2, 11, NULL, 50000.00, 'NGN', 'flutterwave', NULL, 'SIS_1761948155_5522', 'pending', NULL, 1761948155, 1761948155, '{\"description\":\"Course Fee\",\"categoryid\":\"6\",\"user\":\"iyeta treasure\"}'),
(3, 11, NULL, 50000.00, 'NGN', 'flutterwave', NULL, 'SIS_1761948615_5326', 'pending', NULL, 1761948615, 1761948615, '{\"description\":\"Course Fee\",\"categoryid\":\"6\",\"user\":\"iyeta treasure\"}'),
(4, 11, NULL, 50000.00, 'NGN', 'flutterwave', NULL, 'SIS_1761948836_1175', 'pending', NULL, 1761948836, 1761948836, '{\"description\":\"Course Fee\",\"categoryid\":\"6\",\"user\":\"iyeta treasure\"}'),
(5, 11, NULL, 50000.00, 'NGN', 'paystack', NULL, 'SIS_1761948874_5844', 'pending', NULL, 1761948874, 1761948874, '{\"description\":\"Course Fee\",\"categoryid\":\"6\",\"user\":\"iyeta treasure\"}'),
(6, 11, NULL, 50000.00, 'NGN', 'flutterwave', NULL, 'SIS_1761948885_1425', 'pending', NULL, 1761948885, 1761948885, '{\"description\":\"Course Fee\",\"categoryid\":\"6\",\"user\":\"iyeta treasure\"}'),
(7, 11, NULL, 1000.00, 'NGN', 'flutterwave', NULL, 'SIS_1761949420_8153', 'pending', NULL, 1761949420, 1761949420, '{\"description\":\"Custom Payment\",\"categoryid\":null,\"user\":\"iyeta treasure\"}'),
(8, 11, NULL, 1000.00, 'NGN', 'flutterwave', NULL, 'SIS_1761949453_8815', 'pending', NULL, 1761949453, 1761949453, '{\"description\":\"Custom Payment\",\"categoryid\":null,\"user\":\"iyeta treasure\"}'),
(9, 11, NULL, 50000.00, 'NGN', 'flutterwave', NULL, 'SIS_1762011179_6884', 'pending', NULL, 1762011179, 1762011179, '{\"description\":\"Course Fee - SS3\",\"categoryid\":6,\"user_fullname\":\"iyeta treasure\"}'),
(10, 11, NULL, 50000.00, 'NGN', 'flutterwave', NULL, 'SIS_1762013620_4955', 'pending', NULL, 1762013620, 1762013620, '{\"description\":\"Course Fee - SS3\",\"categoryid\":6,\"user_fullname\":\"iyeta treasure\"}'),
(11, 11, NULL, 50000.00, 'NGN', 'paystack', NULL, 'SIS_1762013944_4853', 'pending', NULL, 1762013944, 1762013944, '{\"description\":\"Course Fee - SS3\",\"categoryid\":6,\"user_fullname\":\"iyeta treasure\"}'),
(12, 11, NULL, 50000.00, 'NGN', 'flutterwave', NULL, 'SIS_1762014478_7546', 'pending', NULL, 1762014478, 1762014478, '{\"description\":\"Course Fee - SS3\",\"categoryid\":6,\"user_fullname\":\"iyeta treasure\"}'),
(13, 11, NULL, 50000.00, 'NGN', 'flutterwave', NULL, 'SIS_1762016121_4529', 'pending', NULL, 1762016121, 1762016121, '{\"description\":\"Course Fee - SS3\",\"categoryid\":6,\"user_fullname\":\"iyeta treasure\"}'),
(14, 11, NULL, 50000.00, 'NGN', 'paystack', NULL, 'SIS_1762016601_9188', 'pending', NULL, 1762016601, 1762016601, '{\"description\":\"Course Fee - SS3\",\"categoryid\":6,\"user_fullname\":\"iyeta treasure\"}'),
(15, 11, NULL, 50000.00, 'NGN', 'paystack', NULL, 'SIS_1762016712_5421', 'pending', NULL, 1762016712, 1762016712, '{\"description\":\"Course Fee - SS3\",\"categoryid\":6,\"user_fullname\":\"iyeta treasure\"}'),
(16, 11, NULL, 204000.00, 'NGN', 'flutterwave', NULL, 'SIS_1762034950_5893', 'pending', NULL, 1762034950, 1762034950, '{\"description\":\"Payment for ALL fees - SS3\",\"categoryid\":\"6\"}'),
(17, 11, NULL, 150000.00, 'NGN', 'flutterwave', NULL, 'SIS_1762035481_9491', 'pending', NULL, 1762035481, 1762035481, '{\"description\":\"Other Fee - SS3\",\"categoryid\":\"6\"}'),
(18, 11, NULL, 2000.00, 'NGN', 'flutterwave', NULL, 'SIS_1762035495_4413', 'pending', NULL, 1762035495, 1762035495, '{\"description\":\"Registration Fee - SS3\",\"categoryid\":\"6\"}'),
(19, 11, NULL, 50000.00, 'NGN', 'flutterwave', NULL, 'SIS_1762035568_4562', 'pending', NULL, 1762035568, 1762035568, '{\"description\":\"Course Fee - SS3\",\"categoryid\":\"6\"}'),
(20, 11, NULL, 2000.00, 'NGN', 'flutterwave', NULL, 'SIS_1762035585_7821', 'pending', NULL, 1762035585, 1762035585, '{\"description\":\"Registration Fee - SS3\",\"categoryid\":\"6\"}'),
(21, 11, NULL, 2000.00, 'NGN', 'flutterwave', NULL, 'SIS_1762036016_9505', 'pending', NULL, 1762036016, 1762036016, '{\"description\":\"Exam Fee - SS3\",\"categoryid\":\"6\"}'),
(22, 11, NULL, 204000.00, 'NGN', 'flutterwave', NULL, 'SIS_1762037107_4190', 'pending', NULL, 1762037107, 1762037107, '{\"description\":\"All Fees - All Categories\",\"categoryid\":null,\"fee_type\":\"all_categories\",\"user_fullname\":\"iyeta treasure\"}'),
(23, 4, NULL, 152000.00, 'NGN', 'flutterwave', NULL, 'SIS_1762037972_7882', 'pending', NULL, 1762037972, 1762037972, '{\"description\":\"All Fees - All Categories\",\"categoryid\":null,\"fee_type\":\"all_categories\",\"user_fullname\":\"michael akpati\"}'),
(24, 11, NULL, 204000.00, 'NGN', 'flutterwave', NULL, 'SIS_1762037991_9210', 'pending', NULL, 1762037991, 1762037991, '{\"description\":\"All Fees - All Categories\",\"categoryid\":null,\"fee_type\":\"all_categories\",\"user_fullname\":\"iyeta treasure\"}'),
(25, 11, NULL, 81600.00, 'NGN', 'flutterwave', NULL, 'SIS_1762113795_8074', 'pending', NULL, 1762113795, 1762113795, '{\"description\":\"40% Payment - All Categories\",\"categoryid\":null,\"fee_type\":\"all_categories_40\",\"user_fullname\":\"iyeta treasure\"}'),
(26, 11, NULL, 2000.00, 'NGN', 'flutterwave', NULL, 'SIS_1762114113_7988', 'pending', NULL, 1762114113, 1762114113, '{\"description\":\"Registration Fee - SS3\",\"categoryid\":\"6\",\"fee_type\":\"registration\",\"user_fullname\":\"iyeta treasure\"}'),
(27, 11, NULL, 81600.00, 'NGN', 'flutterwave', NULL, 'SIS_1762114162_6216', 'pending', NULL, 1762114162, 1762114162, '{\"description\":\"40% Payment - All Categories\",\"categoryid\":null,\"fee_type\":\"all_categories_40\",\"user_fullname\":\"iyeta treasure\"}'),
(28, 11, NULL, 2000.00, 'NGN', 'flutterwave', NULL, 'SIS_1762114677_3480', 'pending', NULL, 1762114677, 1762114677, '{\"description\":\"Registration Fee - SS3\",\"categoryid\":\"6\",\"fee_type\":\"registration\",\"user_fullname\":\"iyeta treasure\"}'),
(29, 11, NULL, 2000.00, 'NGN', 'flutterwave', NULL, 'SIS_1762115208_7167', 'pending', NULL, 1762115208, 1762115208, '{\"description\":\"Exam Fee - SS3\",\"categoryid\":\"6\",\"fee_type\":\"exam\",\"user_fullname\":\"iyeta treasure\"}'),
(30, 11, NULL, 2000.00, 'NGN', 'paystack', NULL, 'SIS_1762255154_9921', 'pending', NULL, 1762255154, 1762255154, '{\"description\":\"Exam Fee - SS3\",\"categoryid\":\"6\",\"fee_type\":\"exam\",\"user_fullname\":\"iyeta treasure\"}'),
(31, 11, NULL, 2000.00, 'NGN', 'flutterwave', NULL, 'SIS_1762255172_2596', 'pending', NULL, 1762255172, 1762255172, '{\"description\":\"Exam Fee - SS3\",\"categoryid\":\"6\",\"fee_type\":\"exam\",\"user_fullname\":\"iyeta treasure\"}'),
(32, 11, NULL, 2000.00, 'NGN', 'paystack', NULL, 'SIS_1762255180_8939', 'pending', NULL, 1762255180, 1762255180, '{\"description\":\"Exam Fee - SS3\",\"categoryid\":\"6\",\"fee_type\":\"exam\",\"user_fullname\":\"iyeta treasure\"}'),
(33, 11, NULL, 2000.00, 'NGN', 'flutterwave', NULL, 'SIS_1762255906_2825', 'pending', NULL, 1762255906, 1762255906, '{\"description\":\"Registration Fee - SS3\",\"categoryid\":\"6\",\"fee_type\":\"registration\",\"user_fullname\":\"iyeta treasure\"}'),
(34, 11, NULL, 2000.00, 'NGN', 'paystack', NULL, 'SIS_1762256089_3479', 'pending', NULL, 1762256089, 1762256089, '{\"description\":\"Registration Fee - SS3\",\"categoryid\":\"6\",\"fee_type\":\"registration\",\"user_fullname\":\"iyeta treasure\"}'),
(35, 11, NULL, 2000.00, 'NGN', 'flutterwave', NULL, 'SIS_1762256305_6296', 'pending', NULL, 1762256305, 1762256305, '{\"description\":\"Registration Fee - SS3\",\"categoryid\":\"6\",\"fee_type\":\"registration\",\"user_fullname\":\"iyeta treasure\"}'),
(36, 11, NULL, 50000.00, 'NGN', 'flutterwave', NULL, 'SIS_1762256363_7681', 'pending', NULL, 1762256363, 1762256363, '{\"description\":\"Course Fee - SS3\",\"categoryid\":\"6\",\"fee_type\":\"course\",\"user_fullname\":\"iyeta treasure\"}');

-- --------------------------------------------------------

--
-- Table structure for table `mdl_local_sis_payment_categories`
--

CREATE TABLE `mdl_local_sis_payment_categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `categoryid` int(10) UNSIGNED NOT NULL,
  `course_fee` decimal(10,2) NOT NULL DEFAULT 0.00,
  `registration_fee` decimal(10,2) NOT NULL DEFAULT 0.00,
  `exam_fee` decimal(10,2) NOT NULL DEFAULT 0.00,
  `library_fee` decimal(10,2) NOT NULL DEFAULT 0.00,
  `other_fee` decimal(10,2) NOT NULL DEFAULT 0.00,
  `currency` char(3) NOT NULL DEFAULT 'USD',
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `payallfees` tinyint(1) DEFAULT 0,
  `created_at` int(10) UNSIGNED NOT NULL,
  `updated_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mdl_local_sis_payment_categories`
--

INSERT INTO `mdl_local_sis_payment_categories` (`id`, `categoryid`, `course_fee`, `registration_fee`, `exam_fee`, `library_fee`, `other_fee`, `currency`, `enabled`, `payallfees`, `created_at`, `updated_at`) VALUES
(1, 1, 45000.00, 2000.00, 5000.00, 0.00, 100000.00, 'NGN', 1, 0, 1762032514, 1762037807),
(2, 2, 0.00, 0.00, 0.00, 0.00, 0.00, 'USD', 1, 0, 1762032514, 1762037807),
(3, 3, 0.00, 0.00, 0.00, 0.00, 0.00, 'USD', 1, 0, 1762032514, 1762037807),
(4, 4, 0.00, 0.00, 0.00, 0.00, 0.00, 'USD', 1, 0, 1762032514, 1762037807),
(5, 5, 0.00, 0.00, 0.00, 0.00, 0.00, 'USD', 1, 0, 1762032514, 1762037807),
(6, 6, 50000.00, 2000.00, 2000.00, 0.00, 150000.00, 'NGN', 1, 0, 1762032514, 1762037807);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_local_sis_payment_config`
--

CREATE TABLE `mdl_local_sis_payment_config` (
  `id` bigint(10) NOT NULL,
  `gateway` varchar(50) NOT NULL,
  `config_key` varchar(255) NOT NULL,
  `config_value` text NOT NULL,
  `is_secret` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mdl_local_sis_payment_config`
--

INSERT INTO `mdl_local_sis_payment_config` (`id`, `gateway`, `config_key`, `config_value`, `is_secret`) VALUES
(1, 'flutterwave', 'enabled', '1', 0),
(2, 'flutterwave', 'test_mode', '0', 0),
(3, 'flutterwave', 'public_key', 'FLWPUBK-c3bf0954fb2c912ceb5d34d7ec9355c1-X', 0),
(4, 'flutterwave', 'secret_key', 'FLWSECK-3515f7ba24ff024825607c7686477333-192e3ea4c8cvt-X', 1),
(5, 'flutterwave', 'currency', 'NGN', 0),
(6, 'paystack', 'enabled', '1', 0),
(7, 'paystack', 'test_mode', '0', 0),
(8, 'paystack', 'public_key', 'pk_live_acebedaa686de456435dd44e3be9ec9a34925076', 0),
(9, 'paystack', 'secret_key', 'sk_live_39af36d79c0011d1f9630b0d59901687972e07f0', 1),
(10, 'paystack', 'currency', 'NGN', 0),
(11, 'paypal', 'enabled', '0', 0),
(12, 'paypal', 'test_mode', '0', 0),
(13, 'paypal', 'public_key', '', 0),
(14, 'paypal', 'secret_key', '', 1),
(15, 'paypal', 'currency', 'USD', 0),
(16, 'paypal', 'client_id', 'nduks', 0),
(17, 'paypal', 'client_secret', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_local_sis_promotions_log`
--

CREATE TABLE `mdl_local_sis_promotions_log` (
  `id` bigint(10) UNSIGNED NOT NULL,
  `source_category` bigint(10) UNSIGNED NOT NULL,
  `target_category` bigint(10) UNSIGNED NOT NULL,
  `source_session` bigint(10) UNSIGNED NOT NULL,
  `target_session` bigint(10) UNSIGNED NOT NULL,
  `students_promoted` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `promoted_by` bigint(10) UNSIGNED NOT NULL,
  `timecreated` bigint(10) UNSIGNED NOT NULL,
  `details` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mdl_local_sis_quizmap`
--

CREATE TABLE `mdl_local_sis_quizmap` (
  `id` bigint(10) NOT NULL,
  `quizid` bigint(10) NOT NULL,
  `courseid` bigint(10) NOT NULL,
  `categoryid` bigint(10) NOT NULL,
  `weight` decimal(10,2) NOT NULL DEFAULT 0.00,
  `timemodified` bigint(10) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Mapping between quizzes and courses' ROW_FORMAT=COMPRESSED;

-- --------------------------------------------------------

--
-- Table structure for table `mdl_local_sis_result`
--

CREATE TABLE `mdl_local_sis_result` (
  `id` bigint(10) NOT NULL,
  `courseid` bigint(10) NOT NULL,
  `userid` bigint(10) NOT NULL,
  `sessionid` bigint(10) NOT NULL,
  `termid` bigint(10) NOT NULL,
  `data` longtext DEFAULT NULL,
  `total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `grade` varchar(10) NOT NULL DEFAULT 'F',
  `points` decimal(5,2) NOT NULL DEFAULT 0.00,
  `timecreated` bigint(10) NOT NULL DEFAULT 0,
  `timemodified` bigint(10) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mdl_local_sis_result`
--

INSERT INTO `mdl_local_sis_result` (`id`, `courseid`, `userid`, `sessionid`, `termid`, `data`, `total`, `grade`, `points`, `timecreated`, `timemodified`) VALUES
(1, 3, 4, 3, 1, '[20,20,49.5]', 89.50, 'A', 5.00, 0, 1760241628),
(2, 3, 3, 3, 1, '[20,20,46.5]', 86.50, 'A', 5.00, 0, 1760241628),
(3, 3, 2, 3, 1, '[0,0,0]', 0.00, 'F', 0.00, 0, 1760241628),
(4, 1, 1, 1, 1, NULL, 0.00, 'A', 0.00, 1760235217, 1760235217),
(6, 3, 3, 3, 7, '[10,20,54.25]', 84.25, 'A', 5.00, 0, 1761599048),
(7, 3, 2, 3, 7, '[0,0,0]', 0.00, 'F', 0.00, 0, 1760240786),
(8, 16, 6, 3, 1, '[10,20,16]', 46.00, 'D', 2.00, 0, 1760888181),
(9, 16, 13, 3, 1, '[5,8,30]', 43.00, 'E', 1.00, 0, 1760888181),
(10, 16, 5, 3, 1, '[5,15,35]', 55.00, 'C', 3.00, 0, 1760888181),
(11, 16, 8, 3, 1, '[10,20,44]', 74.00, 'A', 5.00, 0, 1760888181),
(12, 16, 14, 3, 1, '[10,20,52]', 82.00, 'A', 5.00, 0, 1760888181),
(13, 16, 12, 3, 1, '[10,15,35]', 60.00, 'B', 4.00, 0, 1760888181),
(14, 16, 7, 3, 1, '[10,20,52]', 82.00, 'A', 5.00, 0, 1760888181),
(15, 16, 10, 3, 1, '[10,20,58]', 88.00, 'A', 5.00, 0, 1760888181),
(16, 16, 11, 3, 1, '[10,20,56]', 86.00, 'A', 5.00, 0, 1760888181),
(17, 16, 9, 3, 1, '[10,20,50]', 80.00, 'A', 5.00, 0, 1760888181),
(18, 16, 6, 3, 7, '[5,8,16]', 29.00, 'F', 0.00, 1760888929, 1761592034),
(19, 16, 13, 3, 7, '[5,8,20]', 33.00, 'F', 0.00, 1760888929, 1761592034),
(20, 16, 5, 3, 7, '[10,20,30]', 60.00, 'C', 3.00, 1760888929, 1761592034),
(21, 16, 8, 3, 7, '[10,20,44]', 74.00, 'A', 5.00, 1760888929, 1761592034),
(22, 16, 14, 3, 7, '[10,20,52]', 82.00, 'A', 5.00, 1760888929, 1761592034),
(23, 16, 12, 3, 7, '[5,10,25]', 40.00, 'F', 0.00, 1760888929, 1761592034),
(24, 16, 7, 3, 7, '[10,20,52]', 82.00, 'A', 5.00, 1760888929, 1761592034),
(26, 16, 11, 3, 7, '[10,20,56]', 86.00, 'A', 5.00, 1760888929, 1761592034),
(27, 16, 9, 3, 7, '[10,20,50]', 80.00, 'A', 5.00, 1760888929, 1761592034),
(28, 15, 6, 3, 7, '[10,20,50]', 80.00, 'A', 5.00, 1761335033, 1761335033),
(29, 15, 13, 3, 7, '[10,20,45]', 75.00, 'A', 5.00, 1761335033, 1761335033),
(30, 15, 5, 3, 7, '[10,20,51]', 81.00, 'A', 5.00, 1761335033, 1761335033),
(31, 15, 8, 3, 7, '[10,20,55]', 85.00, 'A', 5.00, 1761335033, 1761335033),
(32, 15, 14, 3, 7, '[10,20,58]', 88.00, 'A', 5.00, 1761335033, 1761335033),
(33, 15, 12, 3, 7, '[10,20,55]', 85.00, 'A', 5.00, 1761335033, 1761335033),
(34, 15, 7, 3, 7, '[10,20,54]', 84.00, 'A', 5.00, 1761335033, 1761335033),
(35, 15, 10, 3, 7, '[10,20,59]', 89.00, 'A', 5.00, 1761335033, 1761335033),
(36, 15, 11, 3, 7, '[10,20,48]', 78.00, 'A', 5.00, 1761335033, 1761335033),
(37, 15, 9, 3, 7, '[10,20,54]', 84.00, 'A', 5.00, 1761335033, 1761335033),
(38, 18, 6, 3, 7, '[10,20,56]', 86.00, 'A', 5.00, 1761335128, 1761335128),
(39, 18, 13, 3, 7, '[10,20,54]', 84.00, 'A', 5.00, 1761335128, 1761335128),
(40, 18, 5, 3, 7, '[10,20,57]', 87.00, 'A', 5.00, 1761335128, 1761335128),
(41, 18, 8, 3, 7, '[10,20,55]', 85.00, 'A', 5.00, 1761335128, 1761335128),
(42, 18, 14, 3, 7, '[10,20,56]', 86.00, 'A', 5.00, 1761335128, 1761335128),
(43, 18, 12, 3, 7, '[10,20,45]', 75.00, 'A', 5.00, 1761335128, 1761335128),
(44, 18, 7, 3, 7, '[10,20,51]', 81.00, 'A', 5.00, 1761335128, 1761335128),
(45, 18, 10, 3, 7, '[10,20,53]', 83.00, 'A', 5.00, 1761335128, 1761335128),
(46, 18, 11, 3, 7, '[10,20,54]', 84.00, 'A', 5.00, 1761335128, 1761335128),
(47, 18, 9, 3, 7, '[10,20,45]', 75.00, 'A', 5.00, 1761335128, 1761335128),
(48, 12, 6, 3, 7, '[10,20,45]', 75.00, 'A', 5.00, 1761335145, 1761335233),
(49, 12, 13, 3, 7, '[10,20,45]', 75.00, 'A', 5.00, 1761335145, 1761335233),
(50, 12, 5, 3, 7, '[10,20,46]', 76.00, 'A', 5.00, 1761335145, 1761335233),
(51, 12, 8, 3, 7, '[10,20,50]', 80.00, 'A', 5.00, 1761335145, 1761335233),
(52, 12, 14, 3, 7, '[10,20,54]', 84.00, 'A', 5.00, 1761335145, 1761335233),
(53, 12, 12, 3, 7, '[10,20,55]', 85.00, 'A', 5.00, 1761335145, 1761335233),
(54, 12, 7, 3, 7, '[10,20,50]', 80.00, 'A', 5.00, 1761335145, 1761335233),
(55, 12, 10, 3, 7, '[10,20,65]', 95.00, 'A', 5.00, 1761335145, 1761335233),
(56, 12, 11, 3, 7, '[10,20,45]', 75.00, 'A', 5.00, 1761335145, 1761335233),
(57, 12, 9, 3, 7, '[10,20,54]', 84.00, 'A', 5.00, 1761335145, 1761335233),
(58, 19, 6, 3, 7, '[10,20,45]', 75.00, 'A', 5.00, 1761335384, 1761335384),
(59, 19, 13, 3, 7, '[10,20,29]', 59.00, 'D', 2.00, 1761335384, 1761335384),
(60, 19, 5, 3, 7, '[10,20,45]', 75.00, 'A', 5.00, 1761335384, 1761335384),
(61, 19, 8, 3, 7, '[10,20,54]', 84.00, 'A', 5.00, 1761335384, 1761335384),
(62, 19, 14, 3, 7, '[10,20,56]', 86.00, 'A', 5.00, 1761335384, 1761335384),
(63, 19, 12, 3, 7, '[10,20,25]', 55.00, 'D', 2.00, 1761335384, 1761335384),
(64, 19, 7, 3, 7, '[10,20,61]', 91.00, 'A', 5.00, 1761335384, 1761335384),
(65, 19, 10, 3, 7, '[10,20,65]', 95.00, 'A', 5.00, 1761335384, 1761335384),
(66, 19, 11, 3, 7, '[10,20,52]', 82.00, 'A', 5.00, 1761335384, 1761335384),
(67, 19, 9, 3, 7, '[10,20,54]', 84.00, 'A', 5.00, 1761335384, 1761335384),
(68, 17, 6, 3, 7, '[10,20,45]', 75.00, 'A', 5.00, 1761335524, 1761337035),
(69, 17, 13, 3, 7, '[10,20,54]', 84.00, 'A', 5.00, 1761335524, 1761337035),
(70, 17, 5, 3, 7, '[10,20,56]', 86.00, 'A', 5.00, 1761335524, 1761337035),
(71, 17, 8, 3, 7, '[10,20,56]', 86.00, 'A', 5.00, 1761335524, 1761337035),
(72, 17, 14, 3, 7, '[10,20,56]', 86.00, 'A', 5.00, 1761335524, 1761337035),
(73, 17, 12, 3, 7, '[10,20,54]', 84.00, 'A', 5.00, 1761335524, 1761337035),
(74, 17, 7, 3, 7, '[10,20,50]', 80.00, 'A', 5.00, 1761335524, 1761337035),
(76, 17, 11, 3, 7, '[10,20,56]', 86.00, 'A', 5.00, 1761335524, 1761337035),
(77, 17, 9, 3, 7, '[10,20,54]', 84.00, 'A', 5.00, 1761335524, 1761337035),
(78, 13, 6, 3, 7, '[10,20,25]', 55.00, 'D', 2.00, 1761335855, 1761335855),
(79, 13, 13, 3, 7, '[10,20,40]', 70.00, 'A', 5.00, 1761335855, 1761335855),
(80, 13, 5, 3, 7, '[10,20,45]', 75.00, 'A', 5.00, 1761335855, 1761335855),
(81, 13, 8, 3, 7, '[10,20,46]', 76.00, 'A', 5.00, 1761335855, 1761335855),
(82, 13, 14, 3, 7, '[10,20,52]', 82.00, 'A', 5.00, 1761335855, 1761335855),
(83, 13, 12, 3, 7, '[10,20,48]', 78.00, 'A', 5.00, 1761335855, 1761335855),
(84, 13, 7, 3, 7, '[10,20,48]', 78.00, 'A', 5.00, 1761335855, 1761335855),
(85, 13, 10, 3, 7, '[10,20,50]', 80.00, 'A', 5.00, 1761335855, 1761335855),
(86, 13, 11, 3, 7, '[10,20,49]', 79.00, 'A', 5.00, 1761335855, 1761335855),
(87, 13, 9, 3, 7, '[10,20,48]', 78.00, 'A', 5.00, 1761335855, 1761335855),
(88, 9, 6, 3, 7, '[10,15,42]', 67.00, 'B', 4.00, 1761335976, 1761335976),
(89, 9, 13, 3, 7, '[10,18,45]', 73.00, 'A', 5.00, 1761335976, 1761335976),
(90, 9, 5, 3, 7, '[10,16,45]', 71.00, 'A', 5.00, 1761335976, 1761335976),
(91, 9, 8, 3, 7, '[10,20,30]', 60.00, 'C', 3.00, 1761335976, 1761335976),
(92, 9, 14, 3, 7, '[10,20,46]', 76.00, 'A', 5.00, 1761335976, 1761335976),
(93, 9, 12, 3, 7, '[10,20,51]', 81.00, 'A', 5.00, 1761335976, 1761335976),
(94, 9, 7, 3, 7, '[10,20,49]', 79.00, 'A', 5.00, 1761335976, 1761335976),
(95, 9, 10, 3, 7, '[10,20,55]', 85.00, 'A', 5.00, 1761335976, 1761335976),
(96, 9, 11, 3, 7, '[10,20,45]', 75.00, 'A', 5.00, 1761335976, 1761335976),
(97, 9, 9, 3, 7, '[10,20,46]', 76.00, 'A', 5.00, 1761335976, 1761335976),
(98, 14, 6, 3, 7, '[10,15,30]', 55.00, 'D', 2.00, 1761336121, 1761336121),
(99, 14, 13, 3, 7, '[10,15,40]', 65.00, 'B', 4.00, 1761336121, 1761336121),
(100, 14, 8, 3, 7, '[10,15,45]', 70.00, 'A', 5.00, 1761336121, 1761336121),
(101, 14, 14, 3, 7, '[10,20,40]', 70.00, 'A', 5.00, 1761336121, 1761336121),
(102, 14, 12, 3, 7, '[10,12,30]', 52.00, 'E', 1.00, 1761336121, 1761336121),
(103, 14, 7, 3, 7, '[10,15,25]', 50.00, 'E', 1.00, 1761336121, 1761336121),
(104, 14, 10, 3, 7, '[10,20,45]', 75.00, 'A', 5.00, 1761336121, 1761336121),
(105, 14, 11, 3, 7, '[10,18,40]', 68.00, 'B', 4.00, 1761336121, 1761336121),
(106, 14, 9, 3, 7, '[10,16,35]', 61.00, 'C', 3.00, 1761336121, 1761336121),
(107, 10, 6, 3, 7, '[10,20,45]', 75.00, 'A', 5.00, 1761336843, 1761337514),
(108, 10, 13, 3, 7, '[10,20,41]', 71.00, 'A', 5.00, 1761336843, 1761337514),
(109, 10, 5, 3, 7, '[10,20,41]', 71.00, 'A', 5.00, 1761336843, 1761337514),
(110, 10, 8, 3, 7, '[10,20,30]', 60.00, 'C', 3.00, 1761336843, 1761337514),
(111, 10, 14, 3, 7, '[10,20,35]', 65.00, 'B', 4.00, 1761336843, 1761337514),
(112, 10, 12, 3, 7, '[10,20,42]', 72.00, 'A', 5.00, 1761336843, 1761337514),
(113, 10, 7, 3, 7, '[10,20,51]', 81.00, 'A', 5.00, 1761336843, 1761337514),
(114, 10, 10, 3, 7, '[10,20,58]', 88.00, 'A', 5.00, 1761336843, 1761337514),
(115, 10, 11, 3, 7, '[10,20,29]', 59.00, 'D', 2.00, 1761336843, 1761337514),
(116, 10, 9, 3, 7, '[10,16,45]', 71.00, 'A', 5.00, 1761336843, 1761337514),
(117, 16, 10, 3, 7, '[10,20,58]', 88.00, 'A', 5.00, 1761592009, 1761592034),
(118, 2, 4, 3, 7, '[10,20,68]', 98.00, 'A', 5.00, 1761598145, 1761598175),
(119, 2, 3, 3, 7, '[10,20,69]', 99.00, 'A', 5.00, 1761598145, 1761598175),
(120, 3, 4, 3, 7, '[10,20,57.75]', 87.75, 'A', 5.00, 1761598290, 1761599048);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_local_sis_school_settings`
--

CREATE TABLE `mdl_local_sis_school_settings` (
  `id` bigint(10) NOT NULL,
  `schoolname` varchar(255) NOT NULL DEFAULT '',
  `schooladdress` text DEFAULT NULL,
  `schoolmotto` varchar(255) DEFAULT '',
  `phone` varchar(50) DEFAULT '',
  `state` varchar(100) DEFAULT '',
  `country` varchar(100) DEFAULT '',
  `schoollogo` varchar(255) DEFAULT '',
  `principalsignature` varchar(255) DEFAULT '',
  `timemodified` bigint(10) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `mdl_local_sis_school_settings`
--

INSERT INTO `mdl_local_sis_school_settings` (`id`, `schoolname`, `schooladdress`, `schoolmotto`, `phone`, `state`, `country`, `schoollogo`, `principalsignature`, `timemodified`) VALUES
(1, 'NDUKS-TECH LAB', '10 iwrheko road, Ughelli, Delta State', 'As long as there are systems, there will always be need for system administrators and engineers', '+2347034602628', 'Delta', 'NG', 'schoollogo_1762478033.png', 'principalsignature_1761732662.png', 1762478033);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_local_sis_sessions`
--

CREATE TABLE `mdl_local_sis_sessions` (
  `id` bigint(10) NOT NULL,
  `sessionname` varchar(50) NOT NULL DEFAULT '',
  `isactive` tinyint(1) NOT NULL DEFAULT 0,
  `timemodified` bigint(10) NOT NULL DEFAULT 0,
  `isdefault` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Academic sessions and terms' ROW_FORMAT=COMPRESSED;

--
-- Dumping data for table `mdl_local_sis_sessions`
--

INSERT INTO `mdl_local_sis_sessions` (`id`, `sessionname`, `isactive`, `timemodified`, `isdefault`) VALUES
(1, '2023/2024', 0, 1760037681, 0),
(2, '2024/2025', 0, 1760037764, 0),
(3, '2025/2026', 0, 1760040271, 1);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_local_sis_student_access`
--

CREATE TABLE `mdl_local_sis_student_access` (
  `id` bigint(10) NOT NULL,
  `userid` bigint(10) NOT NULL,
  `categoryid` bigint(10) NOT NULL,
  `sessionid` bigint(10) NOT NULL,
  `termid` bigint(10) NOT NULL,
  `can_attempt_quiz` tinyint(1) NOT NULL DEFAULT 0,
  `can_view_results` tinyint(1) NOT NULL DEFAULT 0,
  `timecreated` bigint(10) NOT NULL,
  `timemodified` bigint(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci COMMENT='Student access control for quizzes and results';

--
-- Dumping data for table `mdl_local_sis_student_access`
--

INSERT INTO `mdl_local_sis_student_access` (`id`, `userid`, `categoryid`, `sessionid`, `termid`, `can_attempt_quiz`, `can_view_results`, `timecreated`, `timemodified`) VALUES
(4, 6, 6, 3, 7, 0, 0, 1760755004, 1762120264),
(5, 13, 6, 3, 7, 0, 0, 1760755004, 1762120264),
(6, 5, 6, 3, 7, 0, 0, 1760755004, 1762120264),
(7, 8, 6, 3, 7, 0, 0, 1760755004, 1762120264),
(8, 14, 6, 3, 7, 0, 0, 1760755004, 1762120264),
(9, 12, 6, 3, 7, 0, 0, 1760755004, 1762120264),
(10, 7, 6, 3, 7, 0, 0, 1760755004, 1762120264),
(11, 10, 6, 3, 7, 0, 0, 1760755004, 1762120264),
(12, 11, 6, 3, 7, 0, 0, 1760755004, 1762120264),
(13, 2, 6, 3, 7, 0, 0, 1760755004, 1762120264),
(14, 9, 6, 3, 7, 0, 0, 1760755004, 1762120264),
(21, 4, 1, 3, 7, 0, 0, 1760764087, 1761598879),
(22, 3, 1, 3, 7, 0, 0, 1760764087, 1761598879),
(23, 2, 1, 3, 7, 1, 1, 1760764087, 1761598879);

-- --------------------------------------------------------

--
-- Table structure for table `mdl_local_sis_terms`
--

CREATE TABLE `mdl_local_sis_terms` (
  `id` bigint(10) NOT NULL,
  `sessionid` bigint(10) NOT NULL,
  `termname` varchar(255) NOT NULL DEFAULT '',
  `isdefault` tinyint(1) NOT NULL DEFAULT 0,
  `calculate_cumulative` tinyint(1) NOT NULL DEFAULT 0,
  `timecreated` bigint(10) NOT NULL,
  `timemodified` bigint(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=COMPRESSED;

--
-- Dumping data for table `mdl_local_sis_terms`
--

INSERT INTO `mdl_local_sis_terms` (`id`, `sessionid`, `termname`, `isdefault`, `calculate_cumulative`, `timecreated`, `timemodified`) VALUES
(1, 1, 'First Term', 0, 0, 1760037681, 1760037681),
(2, 1, 'Second Term', 0, 0, 1760037681, 1760037681),
(3, 1, 'Third Term', 0, 1, 1760037681, 1760037681),
(4, 2, 'First Term', 0, 0, 1760037764, 1760037764),
(5, 2, 'Second Term', 0, 1, 1760037764, 1760037764),
(6, 2, 'Third Term', 0, 0, 1760037764, 1760037764),
(7, 3, 'First Term', 0, 0, 1760040271, 1760040271),
(8, 3, 'Second Term', 0, 0, 1760040271, 1760040271),
(9, 3, 'Third Term', 0, 1, 1760040271, 1760040271);

-- --------------------------------------------------------

--

--
--

--
-- AUTO_INCREMENT for table `mdl_local_sis_ca_config`
--
ALTER TABLE `mdl_local_sis_ca_config`
  MODIFY `id` bigint(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `mdl_local_sis_comments`
--
ALTER TABLE `mdl_local_sis_comments`
  MODIFY `id` bigint(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `mdl_local_sis_fee`
--
ALTER TABLE `mdl_local_sis_fee`
  MODIFY `id` bigint(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mdl_local_sis_payments`
--
ALTER TABLE `mdl_local_sis_payments`
  MODIFY `id` bigint(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `mdl_local_sis_payment_categories`
--
ALTER TABLE `mdl_local_sis_payment_categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `mdl_local_sis_payment_config`
--
ALTER TABLE `mdl_local_sis_payment_config`
  MODIFY `id` bigint(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `mdl_local_sis_promotions_log`
--
ALTER TABLE `mdl_local_sis_promotions_log`
  MODIFY `id` bigint(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mdl_local_sis_quizmap`
--
ALTER TABLE `mdl_local_sis_quizmap`
  MODIFY `id` bigint(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mdl_local_sis_result`
--
ALTER TABLE `mdl_local_sis_result`
  MODIFY `id` bigint(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=121;

--
-- AUTO_INCREMENT for table `mdl_local_sis_school_settings`
--
ALTER TABLE `mdl_local_sis_school_settings`
  MODIFY `id` bigint(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `mdl_local_sis_sessions`
--
ALTER TABLE `mdl_local_sis_sessions`
  MODIFY `id` bigint(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `mdl_local_sis_student_access`
--
ALTER TABLE `mdl_local_sis_student_access`
  MODIFY `id` bigint(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `mdl_local_sis_terms`
--
ALTER TABLE `mdl_local_sis_terms`
  MODIFY `id` bigint(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
