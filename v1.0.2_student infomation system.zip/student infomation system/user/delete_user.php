<?php
// This file is part of the Student Information System (SIS) plugin for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Script: Delete multiple users with optional retention of SIS results
// Location: local/sis/user/delete_user.php

require_once(__DIR__ . '/../../../config.php');
require_login();
require_capability('moodle/user:delete', context_system::instance());

global $DB, $PAGE, $OUTPUT;

$PAGE->set_context(context_system::instance());
$PAGE->set_url(new moodle_url('/local/sis/user/delete_user.php'));
$PAGE->set_title('Bulk User Deletion');
$PAGE->set_heading('Delete Users');

// Get filter parameters
$categoryid = optional_param('categoryid', 0, PARAM_INT);
$search = optional_param('search', '', PARAM_TEXT);

// Handle form submission
if (optional_param('confirm', false, PARAM_BOOL) && confirm_sesskey()) {
    $userids = optional_param_array('userids', [], PARAM_INT);
    $keeprecords = optional_param('keeprecords', 0, PARAM_BOOL);

    require_once($CFG->dirroot . '/user/lib.php');
    $deleted = 0;

    foreach ($userids as $userid) {
        if ($user = $DB->get_record('user', ['id' => $userid, 'deleted' => 0])) {
            user_delete_user($user);
            if (!$keeprecords) {
                $DB->delete_records('local_sis_result', ['userid' => $userid]);
            }
            $deleted++;
        }
    }

    echo $OUTPUT->header();
    echo $OUTPUT->notification("$deleted user(s) deleted successfully.", 'notifysuccess');
    echo $OUTPUT->continue_button(new moodle_url('/local/sis/user/delete_user.php'));
    echo $OUTPUT->footer();
    exit;
}

// Prepare filter options
$categories = $DB->get_records_menu('course_categories', null, 'name ASC', 'id, name');

echo $OUTPUT->header();
echo $OUTPUT->heading('Bulk User Deletion');

// Search and filter form
echo html_writer::start_tag('form', ['method' => 'get', 'action' => new moodle_url('/local/sis/user/delete_user.php'), 'class' => 'form-inline mb-3']);
echo html_writer::start_tag('div', ['class' => 'd-flex align-items-end gap-2']);

// Search box
echo html_writer::start_tag('div', ['class' => 'me-2']);
echo html_writer::tag('label', 'Search:', ['for' => 'search', 'class' => 'form-label mb-1']);
echo html_writer::empty_tag('input', [
    'type' => 'text',
    'name' => 'search', 
    'id' => 'search',
    'value' => $search,
    'class' => 'form-control',
    'placeholder' => 'Name, username, or email',
    'size' => 30
]);
echo html_writer::end_tag('div');

// Category filter
echo html_writer::start_tag('div', ['class' => 'me-2']);
echo html_writer::tag('label', 'Category:', ['for' => 'categoryid', 'class' => 'form-label mb-1']);
echo html_writer::select($categories, 'categoryid', $categoryid, ['0' => 'All categories'], ['class' => 'form-select']);
echo html_writer::end_tag('div');

// Filter buttons
echo html_writer::empty_tag('input', [
    'type' => 'submit', 
    'value' => 'Search',
    'class' => 'btn btn-primary me-1'
]);
echo html_writer::link(
    new moodle_url('/local/sis/user/delete_user.php'),
    'Clear',
    ['class' => 'btn btn-secondary']
);

echo html_writer::end_tag('div');
echo html_writer::end_tag('form');

// Build query for users
$sql = "SELECT u.id, u.firstname, u.lastname, u.username, u.email, 
               u.firstnamephonetic, u.lastnamephonetic, u.middlename, u.alternatename
        FROM {user} u
        WHERE u.deleted = 0 AND u.id > 2";
$params = [];

// Apply search filter
if (!empty($search)) {
    $sql .= " AND (u.firstname LIKE :search1 OR u.lastname LIKE :search2 OR u.username LIKE :search3 OR u.email LIKE :search4)";
    $searchterm = '%' . $search . '%';
    $params['search1'] = $searchterm;
    $params['search2'] = $searchterm;
    $params['search3'] = $searchterm;
    $params['search4'] = $searchterm;
}

// Apply category filter
if ($categoryid) {
    $sql .= " AND u.id IN (
        SELECT ue.userid
        FROM {user_enrolments} ue
        JOIN {enrol} e ON e.id = ue.enrolid
        JOIN {course} c ON c.id = e.courseid
        WHERE c.category = :catid
    )";
    $params['catid'] = $categoryid;
}

$sql .= " ORDER BY u.lastname, u.firstname";
$users = $DB->get_records_sql($sql, $params);

if (empty($users)) {
    echo $OUTPUT->notification('No users found for the selected criteria.', 'notifyproblem');
    echo $OUTPUT->footer();
    exit;
}

// Show results count
echo html_writer::div('Found ' . count($users) . ' user(s)', 'alert alert-info mb-3');

// Start delete form
$url = new moodle_url('/local/sis/user/delete_user.php');
echo html_writer::start_tag('form', ['method' => 'post', 'action' => $url]);
echo html_writer::start_tag('table', ['class' => 'generaltable']);
echo html_writer::start_tag('tr');
echo html_writer::tag('th', html_writer::checkbox('selectall', 1, false, '', ['id' => 'selectall']), ['width' => '30px']);
echo html_writer::tag('th', 'Full Name');
echo html_writer::tag('th', 'Username');
echo html_writer::tag('th', 'Email');
echo html_writer::end_tag('tr');

// Populate table with users
foreach ($users as $u) {
    // Ensure missing phonetic/middle fields exist
    foreach (['firstnamephonetic','lastnamephonetic','middlename','alternatename'] as $field) {
        if (!isset($u->$field)) {
            $u->$field = '';
        }
    }

    $fullname = fullname($u);
    $checkbox = html_writer::checkbox('userids[]', $u->id, false);
    echo html_writer::start_tag('tr');
    echo html_writer::tag('td', $checkbox);
    echo html_writer::tag('td', $fullname);
    echo html_writer::tag('td', s($u->username));
    echo html_writer::tag('td', s($u->email));
    echo html_writer::end_tag('tr');
}
echo html_writer::end_tag('table');

// Checkbox for SIS records
echo html_writer::empty_tag('br');
echo html_writer::checkbox('keeprecords', 1, false, ' Keep SIS result records');
echo html_writer::empty_tag('br');
echo html_writer::empty_tag('br');

// Hidden form data
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'confirm', 'value' => 1]);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey()]);

// Submit button
echo html_writer::empty_tag('input', [
    'type' => 'submit',
    'value' => 'Delete Selected Users',
    'class' => 'btn btn-danger',
    'onclick' => "return confirm('Are you sure you want to delete selected users? This action cannot be undone.');"
]);

echo html_writer::end_tag('form');

// Add JavaScript for "select all" checkbox
$PAGE->requires->js_amd_inline("
require(['jquery'], function($) {
    $('#selectall').change(function() {
        $('input[name=\"userids[]\"]').prop('checked', this.checked);
    });
});
");

echo $OUTPUT->footer();