define(['jquery'], function($) {
    return {
        init: function() {
            // Category change handler - redirect to same page with category ID
            $('#categoryid').on('change', function() {
                var categoryId = $(this).val();
                var baseUrl = $(this).data('url') || M.cfg.wwwroot + '/local/sis/register_courses.php';
                
                if (categoryId) {
                    window.location.href = baseUrl + '?categoryid=' + categoryId;
                } else {
                    window.location.href = baseUrl;
                }
            });

            // Accordion toggle for carry-over courses
            $('.accordion-toggle').on('click', function(e) {
                e.preventDefault();
                var target = $(this).data('bs-target');
                $(target).collapse('toggle');
            });
        }
    };
});
