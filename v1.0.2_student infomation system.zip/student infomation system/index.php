<?php
// This file is part of the Student Information System plugin for Moodle.
// this is the index file with links to all other files
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version information for the Student Information System plugin
 *
 * @package    local_sis
 * @copyright  2025 NduksTech - https://facebook.com/ndukshub
 * @author     Nduka Akapti  (https://github.com/nduka4real)
 * @author     Ndukstech (https://www.youtube.com/@nduks-tech)
 * @author     https://www.linkedin.com/in/ndukaakpati/
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @details
 * Display Name: Student Information System
 * Description: A comprehensive system for managing student records, assessments, fees, and school operations.
 * Contact: https://github.com/nduka4real
 * Social: https://facebook.com/ndukshub
 */

require_once(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/lib.php');

// Set up the page
require_login();
$context = context_system::instance();
require_capability('local/sis:view', $context);
$PAGE->set_url(new moodle_url('/local/sis/index.php'));
$PAGE->set_context($context);
$PAGE->set_title(get_string('pluginname', 'local_sis'));
$PAGE->set_heading(get_string('pluginname', 'local_sis'));

echo $OUTPUT->header();

echo $OUTPUT->heading(get_string('pluginname', 'local_sis'));

// Get statistics data
$total_students = $DB->count_records('user', array('deleted' => 0, 'suspended' => 0)) - 1; // Exclude guest user

// Get active term from local_sis_terms table - using isdefault field
$active_term = 'Not Set';
$term_record = $DB->get_record('local_sis_terms', array('isdefault' => 1));
if ($term_record) {
    $active_term = $term_record->termname;
    
    // If you have a sessions table, you might want to get session name too
    // For now, we'll just use the term name
}

// Get total number of courses (excluding site course)
$total_courses = $DB->count_records('course') - 1; // Exclude site course (id=1)

// Get pending tasks (you can customize this based on your needs)
$pending_tasks = 0; // Placeholder - you can add your own logic here

// Custom CSS for button styling and donation notice
echo '
<style>
.sis-dashboard {
    max-width: 1400px;
    margin: 0 auto;
    padding: 0 1rem;
}
.sis-section {
    margin-bottom: 2.5rem;
    background: #fff;
    border-radius: 15px;
    padding: 1.5rem;
    box-shadow: 0 4px 20px rgba(0,0,0,0.08);
    border: 1px solid #e9ecef;
}
.sis-section-title {
    font-size: 1.4rem;
    color: #2c3e50;
    border-bottom: 3px solid #3498db;
    padding-bottom: 0.8rem;
    margin-bottom: 1.5rem;
    font-weight: 700;
    display: flex;
    align-items: center;
    gap: 0.8rem;
}
.sis-section-title i {
    font-size: 1.6rem;
    opacity: 0.9;
}
.sis-buttons-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 1.2rem;
    margin-bottom: 0.5rem;
}
.sis-btn {
    display: flex;
    align-items: flex-start;
    padding: 1.2rem 1.5rem;
    background: white;
    color: #2c3e50;
    text-decoration: none;
    border-radius: 12px;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    box-shadow: 0 3px 12px rgba(0,0,0,0.08);
    border: 2px solid transparent;
    font-weight: 500;
    min-height: 90px;
    position: relative;
    overflow: hidden;
}
.sis-btn::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, var(--gradient-start), var(--gradient-end));
}
.sis-btn:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.15);
    color: #2c3e50;
    text-decoration: none;
    border-color: var(--gradient-start);
}
.sis-btn i {
    font-size: 1.6rem;
    margin-right: 1rem;
    margin-top: 0.2rem;
    opacity: 0.9;
    background: linear-gradient(135deg, var(--gradient-start), var(--gradient-end));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}
.sis-btn-content {
    flex: 1;
}
.sis-btn-title {
    font-size: 1.1rem;
    font-weight: 700;
    margin-bottom: 0.3rem;
    color: #2c3e50;
}
.sis-btn-desc {
    font-size: 0.85rem;
    opacity: 0.8;
    line-height: 1.4;
    color: #5a6c7d;
}

/* Button color themes with CSS variables */
.sis-btn-results { 
    --gradient-start: #667eea;
    --gradient-end: #764ba2;
}
.sis-btn-assessment { 
    --gradient-start: #11998e;
    --gradient-end: #38ef7d;
}
.sis-btn-users { 
    --gradient-start: #f46b45;
    --gradient-end: #eea849;
}
.sis-btn-courses { 
    --gradient-start: #4facfe;
    --gradient-end: #00f2fe;
}
.sis-btn-settings { 
    --gradient-start: #fa709a;
    --gradient-end: #fee140;
}
.sis-btn-enrollment { 
    --gradient-start: #a8c0ff;
    --gradient-end: #3f2b96;
}
.sis-btn-fees { 
    --gradient-start: #ff9a9e;
    --gradient-end: #fecfef;
}
.sis-btn-exams { 
    --gradient-start: #a8ff78;
    --gradient-end: #78ffd6;
}

/* Donation Section Styling */
.sis-donation-notice {
    text-align: center;
    padding: 3rem 2rem;
    margin-top: 3rem;
    border-radius: 20px;
    background: linear-gradient(135deg, #fff9e6 0%, #ffe6e6 100%);
    border: 3px solid #ff6b6b;
    box-shadow: 0 10px 30px rgba(255, 107, 107, 0.2);
    position: relative;
    overflow: hidden;
}
.sis-donation-notice::before {
    content: "??";
    position: absolute;
    top: -20px;
    right: -20px;
    font-size: 8rem;
    opacity: 0.1;
    transform: rotate(15deg);
}
.sis-donation-text {
    font-size: 1.3rem;
    color: #444;
    margin-bottom: 2rem;
    line-height: 1.7;
    font-weight: 600;
    position: relative;
    z-index: 2;
}
.sis-donate-btn {
    display: inline-flex;
    align-items: center;
    gap: 0.8rem;
    padding: 1.2rem 3rem;
    background: linear-gradient(90deg, #ff4e50 0%, #f9d423 100%);
    color: white !important;
    text-decoration: none !important;
    border-radius: 50px;
    font-size: 1.3rem;
    font-weight: 700;
    transition: all 0.3s ease;
    box-shadow: 0 6px 20px rgba(255, 78, 80, 0.4);
    text-transform: uppercase;
    letter-spacing: 0.5px;
    position: relative;
    z-index: 2;
}
.sis-donate-btn:hover {
    transform: scale(1.08);
    box-shadow: 0 10px 30px rgba(255, 78, 80, 0.6);
}
.sis-donate-btn i {
    font-size: 1.4rem;
}

/* Quick Stats Section */
.sis-stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1rem;
    margin-bottom: 2rem;
}
.sis-stat-card {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 1.5rem;
    border-radius: 12px;
    text-align: center;
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
}
.sis-stat-number {
    font-size: 2.5rem;
    font-weight: 700;
    margin-bottom: 0.5rem;
}
.sis-stat-label {
    font-size: 0.9rem;
    opacity: 0.9;
}

/* Section icons */
.sis-section-icon {
    background: linear-gradient(135deg, var(--icon-start), var(--icon-end));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}
.sis-section-results { --icon-start: #667eea; --icon-end: #764ba2; }
.sis-section-users { --icon-start: #f46b45; --icon-end: #eea849; }
.sis-section-courses { --icon-start: #4facfe; --icon-end: #00f2fe; }
.sis-section-settings { --icon-start: #fa709a; --icon-end: #fee140; }
.sis-section-enrollment { --icon-start: #a8c0ff; --icon-end: #3f2b96; }

@media (max-width: 768px) {
    .sis-buttons-grid {
        grid-template-columns: 1fr;
    }
    .sis-btn {
        min-height: 85px;
        padding: 1rem 1.2rem;
    }
    .sis-donation-notice {
        padding: 2rem 1.5rem;
    }
    .sis-donation-text {
        font-size: 1.1rem;
    }
    .sis-donate-btn {
        padding: 1rem 2rem;
        font-size: 1.1rem;
    }
    .sis-stats-grid {
        grid-template-columns: repeat(2, 1fr);
    }
}
</style>
';

echo '<div class="sis-dashboard">';

// Quick Stats Section with real data
echo '<div class="sis-stats-grid">';
echo '<div class="sis-stat-card">';
echo '<div class="sis-stat-number">' . number_format($total_students) . '</div>';
echo '<div class="sis-stat-label">Total Students</div>';
echo '</div>';
echo '<div class="sis-stat-card" style="background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);">';
echo '<div class="sis-stat-number">' . htmlspecialchars($active_term) . '</div>';
echo '<div class="sis-stat-label">Active Term</div>';
echo '</div>';
echo '<div class="sis-stat-card" style="background: linear-gradient(135deg, #f46b45 0%, #eea849 100%);">';
echo '<div class="sis-stat-number">' . number_format($total_courses) . '</div>';
echo '<div class="sis-stat-label">Total Courses</div>';
echo '</div>';
echo '<div class="sis-stat-card" style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);">';
echo '<div class="sis-stat-number">' . number_format($pending_tasks) . '</div>';
echo '<div class="sis-stat-label">Pending Tasks</div>';
echo '</div>';
echo '</div>';

// Results Management Section
echo '<div class="sis-section">';
echo '<h3 class="sis-section-title sis-section-results"><i class="fa fa-chart-line"></i> Results Management</h3>';
echo '<div class="sis-buttons-grid">';

echo html_writer::link(new moodle_url('/local/sis/enterca.php'), '
    <i class="fa fa-edit"></i>
    <div class="sis-btn-content">
        <div class="sis-btn-title">Enter Scores</div>
        <div class="sis-btn-desc">Enter continuous assessment and exam scores for students</div>
    </div>
', ['class' => 'sis-btn sis-btn-results']);

echo html_writer::link(new moodle_url('/local/sis/managescores.php'), '
    <i class="fa fa-trash-alt"></i>
    <div class="sis-btn-content">
        <div class="sis-btn-title">Delete Records</div>
        <div class="sis-btn-desc">Delete/sanitize records for students who unenrolled late</div>
    </div>
', ['class' => 'sis-btn sis-btn-results']);

echo html_writer::link(new moodle_url('/local/sis/viewresults.php'), '
    <i class="fa fa-eye"></i>
    <div class="sis-btn-content">
        <div class="sis-btn-title">View Results</div>
        <div class="sis-btn-desc">View student results and generate report cards</div>
    </div>
', ['class' => 'sis-btn sis-btn-assessment']);

echo html_writer::link(new moodle_url('/local/sis/broadsheet.php'), '
    <i class="fa fa-file-csv"></i>
    <div class="sis-btn-content">
        <div class="sis-btn-title">Generate Broadsheet </div>
        <div class="sis-btn-desc">Generate class broadsheets in CSV format</div>
    </div>
', ['class' => 'sis-btn sis-btn-assessment']);

echo '</div>';
echo '</div>';

// User Management Section
echo '<div class="sis-section">';
echo '<h3 class="sis-section-title sis-section-users"><i class="fa fa-users"></i> User Management</h3>';
echo '<div class="sis-buttons-grid">';

echo html_writer::link(new moodle_url('/local/sis/bulk_upload.php'), '
    <i class="fa fa-upload"></i>
    <div class="sis-btn-content">
        <div class="sis-btn-title">Upload Students/Teachers</div>
        <div class="sis-btn-desc">Bulk upload user data via CSV file</div>
    </div>
', ['class' => 'sis-btn sis-btn-users']);

echo html_writer::link(new moodle_url('/local/sis/user/delete_user.php'), '
    <i class="fa fa-user-slash"></i>
    <div class="sis-btn-content">
        <div class="sis-btn-title">Delete Users</div>
        <div class="sis-btn-desc">Bulk delete users with all associated records</div>
    </div>
', ['class' => 'sis-btn sis-btn-users']);

echo html_writer::link(new moodle_url('/local/sis/promote.php'), '
    <i class="fa fa-graduation-cap"></i>
    <div class="sis-btn-content">
        <div class="sis-btn-title">Promote Students</div>
        <div class="sis-btn-desc">Promote students from one class to another</div>
    </div>
', ['class' => 'sis-btn sis-btn-users']);

echo '</div>';
echo '</div>';

// Course & Enrollment Management Section
echo '<div class="sis-section">';
echo '<h3 class="sis-section-title sis-section-courses"><i class="fa fa-book"></i> Course & Enrollment Management</h3>';
echo '<div class="sis-buttons-grid">';

echo html_writer::link(new moodle_url('/local/sis/coursemanager.php'), '
    <i class="fa fa-cogs"></i>
    <div class="sis-btn-content">
        <div class="sis-btn-title">Manage School Subjects</div>
        <div class="sis-btn-desc">Create and edit subjects/courses</div>
    </div>
', ['class' => 'sis-btn sis-btn-courses']);

echo html_writer::link(new moodle_url('/local/sis/register.php'), '
    <i class="fa fa-clipboard-list"></i>
    <div class="sis-btn-content">
        <div class="sis-btn-title">Manage Student Courses</div>
        <div class="sis-btn-desc">Enroll/edit students in registered subjects</div>
    </div>
', ['class' => 'sis-btn sis-btn-enrollment']);


echo html_writer::link(new moodle_url('/local/sis/register_courses.php'), '
    <i class="fa fa-clipboard-list"></i>
    <div class="sis-btn-content">
        <div class="sis-btn-title"> Bulk Manage Student Courses</div>
        <div class="sis-btn-desc">Bulk Enroll/Unenroll students in registered subjects</div>
    </div>
', ['class' => 'sis-btn sis-btn-enrollment']);

echo '</div>';
echo '</div>';

// System Configuration Section
echo '<div class="sis-section">';
echo '<h3 class="sis-section-title sis-section-settings"><i class="fa fa-cog"></i> System Configuration</h3>';
echo '<div class="sis-buttons-grid">';

echo html_writer::link(new moodle_url('/local/sis/managecomments.php'), '
    <i class="fa fa-comments"></i>
    <div class="sis-btn-content">
        <div class="sis-btn-title">Manage Comments</div>
        <div class="sis-btn-desc">Add/edit teacher and principal comments</div>
    </div>
', ['class' => 'sis-btn sis-btn-settings']);

echo html_writer::link(new moodle_url('/local/sis/manage_fees.php'), '
    <i class="fa fa-lock"></i>
    <div class="sis-btn-content">
        <div class="sis-btn-title">Result Access Control</div>
        <div class="sis-btn-desc">Grant/deny access to students who owe fees</div>
    </div>
', ['class' => 'sis-btn sis-btn-fees']);

echo html_writer::link(new moodle_url('/local/sis/session_terms.php'), '
    <i class="fa fa-calendar-alt"></i>
    <div class="sis-btn-content">
        <div class="sis-btn-title">Session & Terms</div>
        <div class="sis-btn-desc">Manage academic sessions and terms</div>
    </div>
', ['class' => 'sis-btn sis-btn-settings']);

echo html_writer::link(new moodle_url('/local/sis/resultsettings.php'), '
    <i class="fa fa-file-pdf"></i>
    <div class="sis-btn-content">
        <div class="sis-btn-title">Report Card Settings</div>
        <div class="sis-btn-desc">Configure report card appearance and layout</div>
    </div>
', ['class' => 'sis-btn sis-btn-settings']);

echo html_writer::link(new moodle_url('/local/sis/pay/payment_settings.php'), '
    <i class="fa fa-credit-card"></i>
    <div class="sis-btn-content">
        <div class="sis-btn-title">Fee Settings</div>
        <div class="sis-btn-desc">Configure all forms of payments and fees</div>
    </div>
', ['class' => 'sis-btn sis-btn-fees']);

echo html_writer::link(new moodle_url('/local/sis/managequiz.php'), '
    <i class="fa fa-tasks"></i>
    <div class="sis-btn-content">
        <div class="sis-btn-title">Manage Exams</div>
        <div class="sis-btn-desc">Manage exams and quizzes settings</div>
    </div>
', ['class' => 'sis-btn sis-btn-exams']);

echo '</div>';
echo '</div>';

// Donation Section
echo '<div class="sis-donation-notice">';
echo html_writer::tag('p', 'If this plugin has helped you, consider making a donation to support its further development and maintenance. You can give an equivalent of $1, $5, $10, or anything from your heart.', ['class' => 'sis-donation-text']);
echo html_writer::link('https://flutterwave.com/pay/ndukstechhy30ndgsumej', '
    <i class="fa fa-heart"></i> Support Development
', ['class' => 'sis-donate-btn']);
echo '</div>';

echo '</div>'; // close sis-dashboard

echo $OUTPUT->footer();