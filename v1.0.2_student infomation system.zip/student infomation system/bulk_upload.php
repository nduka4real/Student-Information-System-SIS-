<?php
// This file is part of the Student Information System plugin for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version information for the Student Information System plugin
 *
 * @package    local_sis
 * @copyright  2025 NduksTech - https://facebook.com/ndukshub
 * @author     Nduka Akapti  (https://github.com/nduka4real)
 * @author     Ndukstech (https://www.youtube.com/@nduks-tech)
 * @author     https://www.linkedin.com/in/ndukaakpati/
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @details
 * Display Name: Student Information System
 * Description: A comprehensive system for managing student records, assessments, fees, and school operations.
 * Contact: https://github.com/nduka4real
 * Social: https://facebook.com/ndukshub
 */

// local/sis/bulk_upload.php
require_once(__DIR__ . '/../../config.php');
require_login();
require_capability('moodle/site:config', context_system::instance());

global $DB, $CFG, $USER, $PAGE, $OUTPUT;

// Increase limits for bulk operations
@ini_set('max_execution_time', 300);
@ini_set('memory_limit', '512M');
@set_time_limit(0);

// --- AJAX HANDLER FOR DYNAMIC TERM LOADING ---
if (optional_param('action', '', PARAM_TEXT) === 'get_terms') {
    $sessionid = optional_param('sessionid', 0, PARAM_INT);
    
    require_sesskey();

    if (empty($sessionid)) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => 'No session ID provided.']);
        exit;
    }

    $terms_data = get_terms($sessionid);
    $terms_list = array_values($terms_data);

    header('Content-Type: application/json');
    echo json_encode(['success' => true, 'terms' => $terms_list]);
    exit;
}
// --- END AJAX HANDLER ---

// --- AJAX HANDLER FOR COURSE LOADING ---
if (optional_param('action', '', PARAM_TEXT) === 'get_courses') {
    $categoryid = optional_param('categoryid', 0, PARAM_INT);
    
    require_sesskey();

    if (empty($categoryid)) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => 'No category ID provided.']);
        exit;
    }

    $courses_data = get_all_category_courses($categoryid);
    $courses_list = array_values($courses_data);

    header('Content-Type: application/json');
    echo json_encode(['success' => true, 'courses' => $courses_list]);
    exit;
}
// --- END AJAX HANDLER ---

// --- AJAX HANDLER FOR UPLOAD PREVIEW ---
if (optional_param('action', '', PARAM_TEXT) === 'preview_upload') {
    require_sesskey();

    header('Content-Type: application/json');

    if (empty($_FILES['csvfile']['tmp_name'])) {
        echo json_encode(['success' => false, 'error' => 'No file uploaded for preview.']);
        exit;
    }

    $filename = $_FILES['csvfile']['tmp_name'];
    $rows = [];
    $max_rows_to_preview = 20;
    $row_count = 0;
    $is_header = false;

    if (($handle = fopen($filename, "r")) !== FALSE) {
        $first_row = fgetcsv($handle);
        
        if ($first_row) {
            // Check if first row looks like header (contains expected column names)
            $first_row_lower = array_map('strtolower', $first_row);
            if (in_array('firstname', $first_row_lower) || in_array('username', $first_row_lower)) {
                $is_header = true;
                $rows[] = $first_row; // Include header in preview data
            } else {
                $rows[] = $first_row;
            }
        }
        $row_count = count($rows);

        while (($row = fgetcsv($handle)) !== FALSE && $row_count < $max_rows_to_preview) {
            $rows[] = $row;
            $row_count++;
        }
        fclose($handle);
    } else {
        echo json_encode(['success' => false, 'error' => 'Failed to open CSV file.']);
        exit;
    }

    // Check if we read any data rows (excluding header)
    $data_row_count = $is_header ? count($rows) - 1 : count($rows);
    if ($data_row_count < 1) {
            echo json_encode(['success' => false, 'error' => 'CSV file is empty or contains only a header.']);
            exit;
    }

    echo json_encode([
        'success' => true,
        'data' => $rows,
        'is_header' => $is_header,
        'total_rows' => $data_row_count, // Report only data row count
        'has_more' => ($row_count === $max_rows_to_preview && $data_row_count > 0)
    ]);
    exit;
}
// --- END AJAX HANDLER FOR UPLOAD PREVIEW ---

$context = context_system::instance();
$PAGE->set_context($context);
$PAGE->set_url(new moodle_url('/local/sis/bulk_upload.php'));
$PAGE->set_title('Bulk Upload Students/Teachers');
$PAGE->set_heading('Bulk Upload Students/Teachers');
$PAGE->requires->css(new moodle_url('/local/sis/styles.css'));

// Download sample CSV
if (optional_param('downloadcsv', 0, PARAM_BOOL)) {
    $filename = "user_upload_sample.csv";
    header("Content-Type: text/csv");
    header("Content-Disposition: attachment; filename=$filename");
    $out = fopen("php://output", "w");
    
    fputcsv($out, ['firstname', 'lastname', 'username', 'email', 'password', 'idnumber']);
    fputcsv($out, ['John', 'Doe', 'johndoe001', 'johndoe@school.com', 'TempPass123', 'STD001']);
    fputcsv($out, ['Jane', 'Smith', 'janesmith002', 'janesmith@school.com', 'TempPass123', 'STD002']);
    fputcsv($out, ['Robert', 'Johnson', 'rjohnson003', 'rjohnson@school.com', 'TempPass123', 'STD003']);
    fputcsv($out, ['Sarah', 'Wilson', 'swilsonT01', 'swilson@school.com', 'TempPass123', 'TCH001']);
    
    fclose($out);
    exit;
}

// Function to get sessions
function get_sessions() {
    global $DB;
    return $DB->get_records('local_sis_sessions', [], 'sessionname ASC');
}

// Function to get terms for a session
function get_terms($sessionid) {
    global $DB;
    if (!$sessionid) {
        return [];
    }
    return $DB->get_records('local_sis_terms', ['sessionid' => $sessionid], 'termname ASC');
}

// Function to get categories/classes
function get_categories() {
    global $DB;
    return $DB->get_records('course_categories', ['visible' => 1], 'name ASC');
}

// Function to get all courses in a category (including subcategories)
function get_all_category_courses($categoryid) {
    global $DB;
    
    // Get the category and all its subcategories
    $categories = $DB->get_records_sql("
        SELECT id, name FROM {course_categories} 
        WHERE path LIKE ? OR id = ?
    ", ['%/' . $categoryid . '/%', $categoryid]);
    
    $category_ids = array_keys($categories);
    if (empty($category_ids)) {
        return [];
    }
    
    list($insql, $inparams) = $DB->get_in_or_equal($category_ids, SQL_PARAMS_QM);
    
    // Get all courses in these categories
    $courses = $DB->get_records_sql("
        SELECT c.id, c.fullname, c.shortname, c.category, cc.name as categoryname
        FROM {course} c
        LEFT JOIN {course_categories} cc ON c.category = cc.id
        WHERE c.category $insql AND c.visible = 1
        ORDER BY cc.name, c.fullname ASC
    ", $inparams);
    
    return $courses;
}

// Function to enrol user without sending welcome emails using Moodle API
function safe_enrol_user($instance, $userid, $roleid, $courseid) {
    global $DB, $USER, $CFG;
    
    try {
        // Use Moodle's enrolment API with welcome message disabled
        $plugin = enrol_get_plugin('manual');
        if (!$plugin) {
            return false;
        }
        
        // Check if enrolment already exists
        $existing = $DB->get_record('user_enrolments', [
            'userid' => $userid,    
            'enrolid' => $instance->id
        ]);
        
        if (!$existing) {
            // METHOD 1: Temporarily disable course welcome messages globally
            $old_setting = $CFG->sendcoursewelcomemessage ?? null;
            $CFG->sendcoursewelcomemessage = false;
            
            // METHOD 2: Use a custom approach to avoid triggering events
            try {
                // Create enrolment record directly
                $enrol_record = new stdClass();
                $enrol_record->enrolid = $instance->id;
                $enrol_record->userid = $userid;
                $enrol_record->timestart = time();
                $enrol_record->timeend = 0;
                $enrol_record->modifierid = $USER->id;
                $enrol_record->timecreated = time();
                $enrol_record->timemodified = time();
                $enrol_record->status = ENROL_USER_ACTIVE;
                
                $enrol_record->id = $DB->insert_record('user_enrolments', $enrol_record);
                
                // Assign role without triggering events
                $context = context_course::instance($courseid);
                role_assign($roleid, $userid, $context->id, 'enrol_manual', $instance->id);
                
                $result = true;
                
            } catch (Exception $e) {
                // Fallback: use standard method but catch any errors
                try {
                    $plugin->enrol_user($instance, $userid, $roleid, time(), 0, ENROL_USER_ACTIVE);
                    $result = true;
                } catch (Exception $e2) {
                    error_log("Enrolment error for user $userid in course $courseid: " . $e2->getMessage());
                    $result = false;
                }
            }
            
            // Restore original setting
            if ($old_setting !== null) {
                $CFG->sendcoursewelcomemessage = $old_setting;
            }
            
            return $result;
        }
        return true; // Already enrolled
        
    } catch (Exception $e) {
        error_log("Enrolment error for user $userid in course $courseid: " . $e->getMessage());
        return false;
    }
}

// Process form submission - FIXED CSV READING
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_FILES['csvfile']['tmp_name'])) {
    $sessionid    = required_param('sessionid', PARAM_INT);
    $termid       = required_param('termid', PARAM_INT);
    $categoryid   = required_param('categoryid', PARAM_INT);
    $user_type    = required_param('user_type', PARAM_TEXT);
    $update_existing = optional_param('update_existing', 0, PARAM_BOOL);
    $update_passwords = optional_param('update_passwords', 0, PARAM_BOOL);
    $register_courses = optional_param('register_courses', 0, PARAM_BOOL);
    
    // FIX: Use optional_param_array() instead of optional_param() for array parameters
    $selected_courses = optional_param_array('selected_courses', [], PARAM_INT);

    $results = [
        'created' => 0,
        'updated' => 0,
        'enrolled' => 0,
        'errors' => 0,
        'details' => []
    ];

    // FIXED: Use simple file reading instead of csv_import_reader
    $filename = $_FILES['csvfile']['tmp_name'];
    
    // Check if file is readable
    if (!is_readable($filename)) {
        redirect(new moodle_url('/local/sis/bulk_upload.php'),    
                    'Cannot read uploaded file.', null, \core\output\notification::NOTIFY_ERROR);
    }

    // Read CSV file directly
    $rows = [];
    if (($handle = fopen($filename, "r")) !== FALSE) {
        // Optionally skip header row if present
        $first_row = fgetcsv($handle);
        
        // Check if first row looks like header (contains expected column names)
        $is_header = false;
        if ($first_row) {
            $first_row_lower = array_map('strtolower', $first_row);
            if (in_array('firstname', $first_row_lower) || in_array('username', $first_row_lower)) {
                $is_header = true;
            } else {
                // First row is data, not header - add it back
                $rows[] = $first_row;
            }
        }
        
        while (($row = fgetcsv($handle)) !== FALSE) {
            $rows[] = $row;
        }
        fclose($handle);
    } else {
        redirect(new moodle_url('/local/sis/bulk_upload.php'),    
                    'Failed to open CSV file.', null, \core\output\notification::NOTIFY_ERROR);
    }

    if (empty($rows)) {
        redirect(new moodle_url('/local/sis/bulk_upload.php'),    
                    'CSV file is empty.', null, \core\output\notification::NOTIFY_ERROR);
    }

    // Get role based on user type
    if ($user_type === 'teacher') {
        $role = $DB->get_record('role', ['shortname' => 'editingteacher']);
        if (!$role) {
            $role = $DB->get_record('role', ['shortname' => 'teacher']);
        }
    } else {
        $role = $DB->get_record('role', ['shortname' => 'student']);
    }
    
    if (!$role) {
        redirect(new moodle_url('/local/sis/bulk_upload.php'),    
                    'Required role not found.', null, \core\output\notification::NOTIFY_ERROR);
    }

    // FIXED: Get courses based on selection - This was the main issue
    $courses_to_enroll = [];
    if ($register_courses) {
        if (!empty($selected_courses)) {
            // Use only selected courses
            list($insql, $inparams) = $DB->get_in_or_equal($selected_courses, SQL_PARAMS_QM);
            $courses_to_enroll = $DB->get_records_sql("
                SELECT c.*, cc.name as categoryname 
                FROM {course} c 
                LEFT JOIN {course_categories} cc ON c.category = cc.id 
                WHERE c.id $insql AND c.visible = 1
                ORDER BY cc.name, c.fullname
            ", $inparams);
        } else {
            // Use all courses in category if no specific courses selected
            $courses_to_enroll = get_all_category_courses($categoryid);
        }
    }

    // Disable welcome messages globally for the entire bulk operation
    $old_welcome_setting = $CFG->sendcoursewelcomemessage ?? null;
    $CFG->sendcoursewelcomemessage = false;

    // Debug: Log course information
    error_log("Category ID: $categoryid");
    error_log("Register courses: $register_courses");
    error_log("Selected courses count: " . count($selected_courses));
    error_log("Courses to enroll count: " . count($courses_to_enroll));

    foreach ($rows as $row_index => $row) {
        $row_number = $row_index + ($is_header ? 2 : 1); // Adjust row number for display
        
        if (count($row) < 5) {
            $results['errors']++;
            $results['details'][] = "Row $row_number: Insufficient columns (expected at least 5, got " . count($row) . ")";
            continue;
        }

        $firstname = trim($row[0]);
        $lastname    = trim($row[1]);
        $username    = trim($row[2]);
        $email       = trim($row[3]);
        $password    = trim($row[4]); // Plain text password from CSV
        $idnumber    = isset($row[5]) ? trim($row[5]) : '';

        // Validate required fields
        if (empty($username) || empty($firstname) || empty($lastname)) {
            $results['errors']++;
            $results['details'][] = "Row $row_number: Missing required fields (firstname, lastname, username)";
            continue;
        }

        try {
            // Check if user exists
            $existing_user = $DB->get_record('user', ['username' => $username, 'mnethostid' => $CFG->mnet_localhost_id]);
            
            if ($existing_user) {
                // FIX: Properly handle update_existing checkbox
                if (!$update_existing) {
                    $results['errors']++;
                    $results['details'][] = "Row $row_number: User '$username' already exists (update not allowed)";
                    continue;
                }
                
                // Update existing user
                $existing_user->firstname = $firstname;
                $existing_user->lastname    = $lastname;
                $existing_user->email       = !empty($email) ? $email : $existing_user->email;
                $existing_user->idnumber    = !empty($idnumber) ? $idnumber : $existing_user->idnumber;

                $update_message = "Updated user '$username' (Name/Email/ID)";

                // Update password only if the update_passwords checkbox is checked AND a password was provided in the CSV
                if ($update_passwords && !empty($password) && $existing_user->auth === 'manual') {
                    // Use Moodle's secure password hashing API
                    $existing_user->password = hash_internal_user_password($password);
                    $update_message = "Updated user '$username' (Name/Email/ID/Password)";
                }
                
                $DB->update_record('user', $existing_user);
                $userid = $existing_user->id;
                $results['updated']++;
                $results['details'][] = "Row $row_number: $update_message";
            } else {
                // Create new user
                
                // If creating a new user, password must be set. Generate one if CSV column was empty.
                if (empty($password)) {
                    $password = generate_temp_password();
                }

                $newuser = new stdClass();
                $newuser->username       = $username;
                // IMPORTANT: Use Moodle's secure password hashing API
                $newuser->password       = hash_internal_user_password($password); 
                $newuser->firstname      = $firstname;
                $newuser->lastname       = $lastname;
                $newuser->email          = !empty($email) ? $email : $username . '@' . parse_url($CFG->wwwroot, PHP_URL_HOST);
                $newuser->idnumber       = $idnumber;
                $newuser->auth           = 'manual';
                $newuser->confirmed      = 1;
                $newuser->mnethostid = $CFG->mnet_localhost_id;
                $newuser->timecreated = time();
                
                $userid = $DB->insert_record('user', $newuser);
                $results['created']++;
                $results['details'][] = "Row $row_number: Created user '$username'";
            }

            // FIXED: Enrol user in courses based on role and checkbox setting
            $enrolment_success = true;
            $enrolled_courses = [];
            
            if ($register_courses && !empty($courses_to_enroll)) {
                // Process course enrollment for both students and teachers
                $total_courses = count($courses_to_enroll);
                $processed_courses = 0;
                
                foreach ($courses_to_enroll as $course) {
                    $processed_courses++;
                    
                    // Enrol using our safe enrolment function with Moodle API
                    $enrolinstances = enrol_get_instances($course->id, false);
                    $enrolled_in_this_course = false;
                    
                    foreach ($enrolinstances as $instance) {
                        if ($instance->enrol === 'manual') {
                            if (safe_enrol_user($instance, $userid, $role->id, $course->id)) {
                                $results['enrolled']++;
                                $enrolled_in_this_course = true;
                                $enrolled_courses[] = $course->fullname;
                                break; // Only need one manual enrolment instance per course
                            }
                        }
                    }
                    
                    if (!$enrolled_in_this_course) {
                        $enrolment_success = false;
                        $results['details'][] = "Row $row_number: Warning: Failed to enrol user '$username' in course '{$course->fullname}'";
                    }

                    // Create empty result record for student only
                    if ($user_type === 'student') {
                        $existing_result = $DB->get_record('local_sis_result', [
                            'userid' => $userid,
                            'courseid' => $course->id,
                            'sessionid' => $sessionid,
                            'termid' => $termid
                        ]);

                        if (!$existing_result) {
                            $result_record = new stdClass();
                            $result_record->userid = $userid;
                            $result_record->courseid = $course->id;
                            $result_record->sessionid = $sessionid;
                            $result_record->termid = $termid;
                            $result_record->data = null;
                            $result_record->total = 0;
                            $result_record->grade = null;
                            $result_record->points = 0;
                            $result_record->timecreated = time();
                            $result_record->timemodified = time();
                            
                            $DB->insert_record('local_sis_result', $result_record);
                        }
                    }
                }
                
                // Add summary of enrolled courses
                if (!empty($enrolled_courses)) {
                    $course_summary = count($enrolled_courses) . " courses";
                    if (count($enrolled_courses) <= 5) {
                        $course_summary .= ": " . implode(', ', $enrolled_courses);
                    }
                    $results['details'][] = "Row $row_number: Enrolled $user_type '$username' in $course_summary";
                }
            }

            // Store student session/term mapping for students only
            if ($user_type === 'student') {
                $student_mapping = new stdClass();
                $student_mapping->userid = $userid;
                $student_mapping->categoryid = $categoryid;
                $student_mapping->sessionid = $sessionid;
                $student_mapping->termid = $termid;
                $student_mapping->timecreated = time();
                
                // Check if mapping already exists
                $existing_mapping = $DB->get_record('local_sis_student_sessions', [
                    'userid' => $userid,
                    'sessionid' => $sessionid,
                    'categoryid' => $categoryid
                ]);
                
                if (!$existing_mapping) {
                    // Create the table if it doesn't exist
                    try {
                        $dbman = $DB->get_manager();
                        $table = new xmldb_table('local_sis_student_sessions');
                        if (!$dbman->table_exists($table)) {
                            // Simple creation without complex structure
                            $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
                            $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL);
                            $table->add_field('categoryid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL);
                            $table->add_field('sessionid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL);
                            $table->add_field('termid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL);
                            $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL);
                            $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
                            $dbman->create_table($table);
                        }
                    } catch (\Exception $e) {
                        // Suppress if table already exists or other non-critical error
                    }
                    
                    $DB->insert_record('local_sis_student_sessions', $student_mapping);
                }
            }

        } catch (Exception $e) {
            $results['errors']++;
            $results['details'][] = "Row $row_number: Error processing user '$username' - " . $e->getMessage();
        }
    }

    // Restore original welcome message setting
    if ($old_welcome_setting !== null) {
        $CFG->sendcoursewelcomemessage = $old_welcome_setting;
    }

    // Display results
    echo $OUTPUT->header();
    echo '<div class="alert alert-info">';
    echo '<h4>Upload Results</h4>';
    echo "<p><strong>Created:</strong> {$results['created']} users</p>";
    echo "<p><strong>Updated:</strong> {$results['updated']} users</p>";
    echo "<p><strong>Enrolments:</strong> {$results['enrolled']} successful enrolments</p>";
    echo "<p><strong>Errors:</strong> {$results['errors']}</p>";
    
    if (!empty($results['details'])) {
        echo '<details><summary>View Details</summary><ul class="mt-2" style="max-height: 300px; overflow-y: auto;">';
        foreach ($results['details'] as $detail) {
            echo "<li>$detail</li>";
        }
        echo '</ul></details>';
    }
    echo '</div>';
    
    echo '<div class="text-center mt-3">';
    echo '<a href="' . new moodle_url('/local/sis/bulk_upload.php') . '" class="btn btn-primary">Upload More Users</a>';
    echo ' <a href="' . new moodle_url('/local/sis/index.php') . '" class="btn btn-secondary">Back to Dashboard</a>';
    echo '</div>';
    
    echo $OUTPUT->footer();
    exit;
}

// Generate temporary password function
function generate_temp_password($length = 12) {
    $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()';
    $password = '';
    for ($i = 0; $i < $length; $i++) {
        $password .= $chars[random_int(0, strlen($chars) - 1)];
    }
    return $password;
}

// Main form
echo $OUTPUT->header();
?>
<div class="sis-form-container">
    <div class="card sis-card">
        <div class="card-body">
            <h3 class="card-title">Bulk Upload Students/Teachers</h3>
            <p class="text-muted">Upload users via CSV file. Users will be registered in the selected class and session.</p>
            
            <div class="alert alert-success">
                <strong>Email Notifications Disabled:</strong> Welcome emails have been completely disabled for bulk operations to prevent email processor errors.
            </div>
            
            <div class="alert alert-info">
                <strong>CSV Format:</strong> firstname, lastname, username, email, password, idnumber<br>
                <strong>Note:</strong> Password is required for new users. For existing users, password updates are controlled by the checkbox below.
            </div>
            
            <p><a href="?downloadcsv=1" class="btn btn-outline-primary btn-sm">Download Sample CSV</a></p>

            <form method="post" enctype="multipart/form-data" id="uploadForm">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="sessionid">Session:</label>
                            <select name="sessionid" id="sessionid" class="form-control" required>
                                <option value="">Select Session</option>
                                <?php
                                $sessions = get_sessions();
                                foreach ($sessions as $session) {
                                    echo "<option value='{$session->id}'>" . htmlspecialchars($session->sessionname) . "</option>";
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="termid">Term:</label>
                            <select name="termid" id="termid" class="form-control" required>
                                <option value="">Select Term</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="categoryid">Class/Category:</label>
                            <select name="categoryid" id="categoryid" class="form-control" required>
                                <option value="">Select Class</option>
                                <?php
                                $categories = get_categories();
                                foreach ($categories as $category) {
                                    echo "<option value='{$category->id}'>" . htmlspecialchars($category->name) . "</option>";
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="user_type">User Type:</label>
                            <select name="user_type" id="user_type" class="form-control" required>
                                <option value="student">Student</option>
                                <option value="teacher">Teacher</option>
                            </select>
                            <small class="form-text text-muted">
                                Students will be registered in all subjects with empty result records. Teachers will be assigned as course teachers.
                            </small>
                        </div>
                    </div>
                </div>

                <!-- Course Selection Area -->
                <div id="course-selection-area" class="mt-3" style="display: none;">
                    <div class="form-group">
                        <label>Select Courses for Enrollment:</label>
                        <div class="alert alert-info">
                            <small>Select specific courses to enroll users in. If no courses are selected, users will be enrolled in ALL courses in the category.</small>
                        </div>
                        <div id="courses-loading" class="text-center" style="display: none;">
                            <div class="spinner-border text-primary" role="status">
                                <span class="sr-only">Loading courses...</span>
                            </div>
                            <p>Loading courses...</p>
                        </div>
                        <div id="courses-list" class="border rounded p-3 bg-light" style="max-height: 300px; overflow-y: auto;">
                            <!-- Courses will be loaded here dynamically -->
                        </div>
                        <div class="mt-2">
                            <button type="button" id="select-all-courses" class="btn btn-outline-primary btn-sm">Select All</button>
                            <button type="button" id="deselect-all-courses" class="btn btn-outline-secondary btn-sm">Deselect All</button>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <div class="form-check">
                        <input type="checkbox" name="update_existing" id="update_existing" value="1" class="form-check-input">
                        <label for="update_existing" class="form-check-label">Update existing users if found</label>
                    </div>
                    <small class="form-text text-muted">
                        If checked, existing users will be updated with new information from CSV.
                    </small>
                </div>

                <!-- NEW: Password Update Control -->
                <div class="form-group" id="password_update_group" style="display: none;">
                    <div class="form-check">
                        <input type="checkbox" name="update_passwords" id="update_passwords" value="1" class="form-check-input">
                        <label for="update_passwords" class="form-check-label">Update passwords for existing users</label>
                    </div>
                    <small class="form-text text-muted">
                        If checked, passwords from CSV will be used to update existing users' passwords. Only applies when updating existing users.
                    </small>
                </div>

                <!-- NEW: Course Registration Control -->
                <div class="form-group">
                    <div class="form-check">
                        <input type="checkbox" name="register_courses" id="register_courses" value="1" class="form-check-input" checked>
                        <label for="register_courses" class="form-check-label">Register users to courses</label>
                    </div>
                    <small class="form-text text-muted">
                        If checked, users will be enrolled in the selected courses above. If no courses are selected, they will be enrolled in ALL courses in the category.
                    </small>
                </div>

                <div class="form-group">
                    <label for="csvfile">CSV File:</label>
                    <input type="file" name="csvfile" id="csvfile" class="form-control-file" accept=".csv" required>
                    <small class="form-text text-muted">File must be in CSV format with UTF-8 encoding. Select a file and click "Preview" below.</small>
                </div>
                
                <!-- File Preview Area -->
                <div id="upload-preview-area" class="mt-4" style="display: none;">
                    <h4 class="mb-2">File Preview <small class="text-muted" id="preview-row-count"></small></h4>
                    <div class="table-responsive bg-light p-2 rounded" style="max-height: 400px; overflow-y: auto; border: 1px solid #ddd;">
                        <table class="table table-sm table-hover table-striped" id="preview-table">
                            <thead></thead>
                            <tbody></tbody>
                        </table>
                    </div>
                    <div class="alert alert-danger mt-2" id="preview-error" style="display:none;"></div>
                </div>


                <div class="form-group text-center mt-4">
                    <button type="button" id="previewButton" class="btn btn-info btn-lg" disabled>Preview Upload File</button>
                    <button type="submit" id="submitButton" class="btn btn-success btn-lg" style="display: none;">Confirm & Upload Users</button>
                    <a href="<?php echo new moodle_url('/local/sis/index.php'); ?>" class="btn btn-secondary btn-lg">Back to Main Dashboard</a>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const sessionSelect = document.getElementById('sessionid');
    const termSelect = document.getElementById('termid');
    const categorySelect = document.getElementById('categoryid');
    const csvFile = document.getElementById('csvfile');
    const previewButton = document.getElementById('previewButton');
    const submitButton = document.getElementById('submitButton');
    const uploadForm = document.getElementById('uploadForm');
    const previewArea = document.getElementById('upload-preview-area');
    const previewTableHead = document.querySelector('#preview-table thead');
    const previewTableBody = document.querySelector('#preview-table tbody');
    const previewRowCount = document.getElementById('preview-row-count');
    const previewError = document.getElementById('preview-error');
    const updateExistingCheckbox = document.getElementById('update_existing');
    const passwordUpdateGroup = document.getElementById('password_update_group');
    const courseSelectionArea = document.getElementById('course-selection-area');
    const coursesList = document.getElementById('courses-list');
    const coursesLoading = document.getElementById('courses-loading');
    const selectAllCoursesBtn = document.getElementById('select-all-courses');
    const deselectAllCoursesBtn = document.getElementById('deselect-all-courses');
    const registerCoursesCheckbox = document.getElementById('register_courses');
    
    // --- Initial setup and Validity Check ---
    submitButton.style.display = 'none';
    previewError.style.display = 'none';

    // Function to check if all required fields are filled to enable the Preview button
    const checkFormValidity = () => {
        const isReady = uploadForm.checkValidity() && csvFile.files.length > 0;
        previewButton.disabled = !isReady;
        if (!isReady) {
            submitButton.style.display = 'none';
            previewArea.style.display = 'none';
        }
    }

    // FIX: Properly handle update_existing checkbox state
    function handleUpdateExistingChange() {
        if (this.checked) {
            passwordUpdateGroup.style.display = 'block';
        } else {
            passwordUpdateGroup.style.display = 'none';
            document.getElementById('update_passwords').checked = false;
        }
    }

    // Add event listeners properly
    updateExistingCheckbox.addEventListener('change', handleUpdateExistingChange);
    
    // Also handle on page load
    handleUpdateExistingChange.call(updateExistingCheckbox);

    // Show/hide course selection based on register_courses checkbox
    registerCoursesCheckbox.addEventListener('change', function() {
        if (this.checked && categorySelect.value) {
            courseSelectionArea.style.display = 'block';
            loadCoursesForCategory(categorySelect.value);
        } else {
            courseSelectionArea.style.display = 'none';
        }
    });

    // Load courses when category changes
    categorySelect.addEventListener('change', function() {
        if (registerCoursesCheckbox.checked && this.value) {
            courseSelectionArea.style.display = 'block';
            loadCoursesForCategory(this.value);
        } else {
            courseSelectionArea.style.display = 'none';
        }
        checkFormValidity();
    });

    // Select all courses
    selectAllCoursesBtn.addEventListener('click', function() {
        const checkboxes = coursesList.querySelectorAll('input[type="checkbox"]');
        checkboxes.forEach(checkbox => {
            checkbox.checked = true;
        });
    });

    // Deselect all courses
    deselectAllCoursesBtn.addEventListener('click', function() {
        const checkboxes = coursesList.querySelectorAll('input[type="checkbox"]');
        checkboxes.forEach(checkbox => {
            checkbox.checked = false;
        });
    });

    // Function to load courses for a category
    function loadCoursesForCategory(categoryId) {
        coursesLoading.style.display = 'block';
        coursesList.innerHTML = '';

        const formData = new FormData();
        formData.append('sesskey', '<?php echo sesskey(); ?>');
        formData.append('action', 'get_courses');
        formData.append('categoryid', categoryId);
        
        fetch('<?php echo new moodle_url('/local/sis/bulk_upload.php'); ?>', {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (!response.ok) {
                return response.text().then(text => { throw new Error('Server error: ' + text); });
            }
            return response.json();
        })
        .then(data => {
            coursesLoading.style.display = 'none';
            
            if (data.success && data.courses && data.courses.length > 0) {
                let coursesHtml = '';
                let currentCategory = '';
                
                data.courses.forEach(course => {
                    if (course.categoryname !== currentCategory) {
                        if (currentCategory !== '') {
                            coursesHtml += '</div>';
                        }
                        currentCategory = course.categoryname;
                        coursesHtml += `<div class="mb-2"><strong>${course.categoryname}</strong><div class="ml-3">`;
                    }
                    
                    coursesHtml += `
                        <div class="form-check">
                            <input type="checkbox" name="selected_courses[]" value="${course.id}" id="course_${course.id}" class="form-check-input course-checkbox" checked>
                            <label for="course_${course.id}" class="form-check-label">
                                ${course.fullname} (${course.shortname})
                            </label>
                        </div>
                    `;
                });
                
                if (currentCategory !== '') {
                    coursesHtml += '</div></div>';
                }
                
                coursesList.innerHTML = coursesHtml;
            } else {
                coursesList.innerHTML = '<div class="alert alert-warning">No courses found in this category.</div>';
            }
        })
        .catch(error => {
            coursesLoading.style.display = 'none';
            coursesList.innerHTML = '<div class="alert alert-danger">Error loading courses: ' + error.message + '</div>';
            console.error('Error loading courses:', error);
        });
    }

    // Check validity on change of required fields and file input
    document.querySelectorAll('#sessionid, #termid, #categoryid, #user_type, #csvfile').forEach(el => {
        el.addEventListener('change', checkFormValidity);
    });

    // Initial check
    checkFormValidity();

    // --- Dynamic Term Loading Logic ---
    sessionSelect.addEventListener('change', function() {
        const sessionId = this.value;
        termSelect.innerHTML = '<option value="">Loading terms...</option>';
        checkFormValidity(); // Re-check validity when session changes
        
        if (!sessionId) {
            termSelect.innerHTML = '<option value="">Select Term</option>';
            return;
        }
        
        const formData = new FormData();
        formData.append('sesskey', '<?php echo sesskey(); ?>');
        formData.append('action', 'get_terms');
        formData.append('sessionid', sessionId);
        
        fetch('<?php echo new moodle_url('/local/sis/bulk_upload.php'); ?>', {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (!response.ok) {
                return response.text().then(text => { throw new Error('Server error: ' + text); });
            }
            return response.json();
        })
        .then(data => {
            termSelect.innerHTML = '<option value="">Select Term</option>';
            if (data.success && data.terms) {
                data.terms.forEach(term => {
                    const option = document.createElement('option');
                    option.value = term.id;
                    option.textContent = term.termname;
                    termSelect.appendChild(option);
                });
            } else if (data.error) {
                termSelect.innerHTML = '<option value="">Error: ' + data.error + '</option>';
            }
            checkFormValidity(); // Re-check validity after terms load
        })
        .catch(error => {
            termSelect.innerHTML = '<option value="">Error loading terms</option>';
            console.error('Error loading terms:', error);
            checkFormValidity();
        });
    });
    
    // Trigger change if session is already selected on page load
    if (sessionSelect.value) {
        sessionSelect.dispatchEvent(new Event('change'));
    }

    // --- File Preview Logic ---
    previewButton.addEventListener('click', function() {
        if (!uploadForm.checkValidity() || csvFile.files.length === 0) {
            // Trigger browser validation errors if not valid
            uploadForm.reportValidity();
            return;
        }

        // Show loading state
        previewButton.textContent = 'Processing...';
        previewButton.disabled = true;
        submitButton.style.display = 'none';
        previewArea.style.display = 'none';
        previewError.style.display = 'none';

        // Collect all necessary form data including the file
        const formData = new FormData(uploadForm);
        formData.append('sesskey', '<?php echo sesskey(); ?>');
        formData.append('action', 'preview_upload');
        // The file is automatically included via new FormData(uploadForm)

        fetch('<?php echo new moodle_url('/local/sis/bulk_upload.php'); ?>', {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (!response.ok) {
                return response.text().then(text => { throw new Error('Server error: ' + text); });
            }
            return response.json();
        })
        .then(data => {
            previewButton.textContent = 'Preview Upload File';
            previewButton.disabled = false;

            if (data.success && data.data) {
                // Clear previous content
                previewTableHead.innerHTML = '';
                previewTableBody.innerHTML = '';

                const rows = data.data;
                
                // Determine header and data rows
                const headerRowData = rows[0];
                const dataRows = data.is_header ? rows.slice(1) : rows;

                // 1. Render Header
                const defaultHeaders = ['firstname', 'lastname', 'username', 'email', 'password', 'idnumber'];
                const headerTitles = data.is_header    
                    ? headerRowData
                    : defaultHeaders.slice(0, headerRowData.length);
                
                let headHtml = '<tr>';
                headerTitles.forEach(title => {
                    headHtml += `<th scope="col" class="text-nowrap">${title}</th>`;
                });
                headHtml += '</tr>';
                previewTableHead.innerHTML = headHtml;


                // 2. Render Body Rows
                let tableHtml = '';
                dataRows.forEach(row => {
                    tableHtml += '<tr>';
                    row.forEach(cell => {
                        tableHtml += `<td>${cell}</td>`;
                    });
                    tableHtml += '</tr>';
                });
                previewTableBody.innerHTML = tableHtml;

                // 3. Update summary and display
                previewRowCount.textContent = `(${data.total_rows} rows${data.has_more ? ', showing first 20' : ''})`;
                previewArea.style.display = 'block';
                submitButton.style.display = 'inline-block';

            } else if (data.error) {
                previewError.textContent = data.error;
                previewError.style.display = 'block';
            }
        })
        .catch(error => {
            previewButton.textContent = 'Preview Upload File';
            previewButton.disabled = false;
            previewError.textContent = 'An error occurred during preview: ' + error.message;
            previewError.style.display = 'block';
            console.error('Fetch error:', error);
        });
    });
});
</script>
<?php
echo $OUTPUT->footer();
?>