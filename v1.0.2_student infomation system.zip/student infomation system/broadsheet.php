<?php
// This file is part of the Student Information System plugin for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version information for the Student Information System plugin
 *
 * @package    local_sis
 * @copyright  2025 NduksTech - https://facebook.com/ndukshub
 * @author     Nduka Akapti  (https://github.com/nduka4real)
 * @author     Ndukstech (https://www.youtube.com/@nduks-tech)
 * @author     https://www.linkedin.com/in/ndukaakpati/
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @details
 * Display Name: Student Information System
 * Description: A comprehensive system for managing student records, assessments, fees, and school operations.
 * Contact: https://github.com/nduka4real
 * Social: https://facebook.com/ndukshub
 */

// local/sis/broadsheet.php
require_once(__DIR__ . '/../../config.php');

// Declare Moodle global objects for use throughout the script
global $DB, $USER, $PAGE, $OUTPUT;

// Ensure user is logged in and has the capability to access this tool
require_login();
require_capability('moodle/site:config', context_system::instance());

// Get and clean URL parameters
$categoryid = optional_param('categoryid', 0, PARAM_INT);
$sessionid = optional_param('sessionid', 0, PARAM_INT);
$termid = optional_param('termid', 0, PARAM_INT);
$download = optional_param('download', 0, PARAM_BOOL);

// --- Page setup ---
$context = context_system::instance();
$PAGE->set_context($context);
$PAGE->set_url(new moodle_url('/local/sis/broadsheet.php', [
    'categoryid' => $categoryid,
    'sessionid' => $sessionid,
    'termid' => $termid
]));
$PAGE->set_title('SIS - Broadsheet Generator');
$PAGE->set_heading('Broadsheet Generator');

// ---------- Function to get component names ----------
function get_component_names($courseid) {
    global $DB;
    
    // Use get_records and order by id to get the most recent one
    $ca_configs = $DB->get_records('local_sis_ca_config', ['courseid' => $courseid], 'id DESC', '*', 0, 1);
    
    if (empty($ca_configs)) {
        return ['CA1', 'CA2', 'Exam'];
    }
    
    $ca_config = reset($ca_configs);
    $components = json_decode($ca_config->components, true);
    
    if (json_last_error() !== JSON_ERROR_NONE || !is_array($components)) {
        return ['CA1', 'CA2', 'Exam'];
    }
    
    $component_names = [];
    foreach ($components as $component) {
        if (isset($component['name'])) {
            $component_names[] = $component['name'];
        }
    }
    
    if (empty($component_names)) {
        return ['CA1', 'CA2', 'Exam'];
    }
    
    return $component_names;
}

// ---------- Function to get session and term information ----------
function get_session_term_info($sessionid = 0, $termid = 0) {
    global $DB;
    
    $sessions = $DB->get_records('local_sis_sessions', [], 'sessionname ASC');
    
    // Handle Session ID
    if (!$sessionid) {
        $current_session = $DB->get_record('local_sis_sessions', ['isdefault' => 1]);
        $sessionid = $current_session ? $current_session->id : 0;
        $sessionname = $current_session ? $current_session->sessionname : 'Current Session';
    } else {
        $session = $DB->get_record('local_sis_sessions', ['id' => $sessionid]);
        $sessionname = $session ? $session->sessionname : 'Selected Session';
    }
    
    // Get available terms for the selected session
    $terms = $DB->get_records('local_sis_terms', ['sessionid' => $sessionid], 'termname ASC');
    
    // Handle Term ID
    if (!$termid) {
        $current_term = $DB->get_record('local_sis_terms', ['sessionid' => $sessionid, 'isdefault' => 1]);
        $termid = $current_term ? $current_term->id : 0;
        $termname = $current_term ? $current_term->termname : 'Current Term';
    } else {
        $term = $DB->get_record('local_sis_terms', ['id' => $termid]);
        $termname = $term ? $term->termname : 'Selected Term';
    }
    
    return [
        'sessionid' => $sessionid,
        'sessionname' => $sessionname,
        'termid' => $termid,
        'termname' => $termname,
        'sessions' => $sessions,
        'terms' => $terms
    ];
}

// ---------- Function to generate CSV broadsheet ----------
function generate_broadsheet_csv($categoryid, $sessionid, $termid) {
    global $DB;
    
    $category = $DB->get_record('course_categories', ['id' => $categoryid]);
    if (!$category) { return false; }
    
    $session_term_info = get_session_term_info($sessionid, $termid);
    
    // Fetch students - Note: We are not fetching 'username' here.
    $students = $DB->get_records_sql("
        SELECT DISTINCT u.id, u.firstname, u.lastname
        FROM {user} u
        JOIN {local_sis_result} r ON r.userid = u.id
        JOIN {course} c ON c.id = r.courseid
        WHERE c.category = :catid
        AND r.sessionid = :sessionid
        AND r.termid = :termid
        ORDER BY u.lastname, u.firstname
    ", [
        'catid' => $categoryid,
        'sessionid' => $sessionid,
        'termid' => $termid
    ]);
    
    if (empty($students)) { return false; }
    
    // Fetch courses
    $courses = $DB->get_records('course', ['category' => $categoryid], 'fullname ASC');
    if (empty($courses)) { return false; }
    
    $csv_data = [];
    
    // Headers - Confirmed: 'Username' is explicitly removed.
    $headers = ['S/N', 'Student ID', 'Student Name'];
    
    // Add subject columns with components
    foreach ($courses as $course) {
        $component_names = get_component_names($course->id);
        foreach ($component_names as $component) {
            $headers[] = $course->shortname . ' - ' . $component;
        }
        $headers[] = $course->shortname . ' - Total';
        $headers[] = $course->shortname . ' - Grade';
    }
    
    $headers = array_merge($headers, [
        'Grand Total', 
        'Average Score', 
        'Position',
        'Teacher Comment',
        'Principal Comment'
    ]);
    
    // --- CSV Information Header Block (New Order: School Name, Term, Class) ---
    $schoolname = get_config('local_sis', 'schoolname') ?: 'School';
    $categoryname = $DB->get_record('course_categories', ['id' => $categoryid])->name ?? 'Class';

    // Row 0: School Name
    $csv_data[] = [$schoolname . ' - Broadsheet']; 
    // Row 1: Term & Session
    $csv_data[] = ['Term: ' . $session_term_info['termname'] . ' - Session: ' . $session_term_info['sessionname']]; 
    // Row 2: Class
    $csv_data[] = ['Class: ' . $categoryname]; 
    // Row 3: Generated Date
    $csv_data[] = ['Generated on: ' . date('F j, Y')]; 
    $csv_data[] = []; // Empty row for spacing (Row 4)
    
    // Add main student data headers (Row 5)
    $csv_data[] = $headers;
    
    // Student data processing
    $student_counter = 1;
    $student_totals = [];
    
    foreach ($students as $student) {
        // Data Row Construction - Confirmed: No 'username' data is included.
        $row = [
            $student_counter++, // S/N is the first cell (index 0)
            $student->id,       // Student ID is the second cell (index 1)
            $student->lastname . ' ' . $student->firstname // Full name in one cell (index 2)
        ];
        
        $student_total = 0;
        $subject_count = 0;
        
        foreach ($courses as $course) {
            $result = $DB->get_record('local_sis_result', [
                'userid' => $student->id,
                'courseid' => $course->id,
                'sessionid' => $sessionid,
                'termid' => $termid
            ]);
            
            $component_names = get_component_names($course->id);
            
            if ($result) {
                $columns = $DB->get_columns('local_sis_result');
                $has_new_structure = array_key_exists('data', $columns);
                
                if ($has_new_structure && $result->data) {
                    $component_data = json_decode($result->data, true);
                } else {
                    $component_data = [
                        $result->firstca ?? 0,
                        $result->secondca ?? 0,
                        $result->exam ?? 0
                    ];
                }
                
                foreach ($component_names as $index => $component) {
                    $score = $component_data[$index] ?? 0;
                    $row[] = $score > 0 ? number_format($score, 1) : '-';
                }
                
                $subject_total = $result->total ?? 0;
                $row[] = $subject_total > 0 ? number_format($subject_total, 1) : '-';
                $row[] = $result->grade ?? '-';
                
                if (is_numeric($subject_total) && $subject_total > 0) {
                    $student_total += $subject_total;
                    $subject_count++;
                }
            } else {
                foreach ($component_names as $component) { $row[] = '-'; }
                $row[] = '-'; // Total
                $row[] = '-'; // Grade
            }
        }
        
        $average = $subject_count > 0 ? $student_total / $subject_count : 0;
        
        // Add grand total, average, and placeholder for position and comments
        $row[] = $student_total > 0 ? number_format($student_total, 1) : '-';
        $row[] = $average > 0 ? number_format($average, 1) : '-';
        $row[] = ''; // Position placeholder
        $row[] = ''; // Teacher comment placeholder
        $row[] = ''; // Principal comment placeholder
        
        $csv_data[] = $row;
        $student_totals[$student->id] = $average;
    }
    
    // Calculate and insert positions/comments
    arsort($student_totals);
    $positions = [];
    $rank = 0;
    $index = 0;
    $prev = null;
    
    foreach ($student_totals as $student_id => $score) {
        $index++;
        if ($prev === null || (string)$score !== (string)$prev) {
            $rank = $index;
            $prev = $score;
        }
        $positions[$student_id] = $rank;
    }
    
    // Add positions and comments to CSV data
    $position_index = count($headers) - 3; 
    foreach ($csv_data as $i => &$row) {
        // Student data starts at index 6 (0-4 are info, 5 is header)
        if ($i >= 6 && count($row) > 2 && is_numeric($row[1])) { // It's a student row
            $student_id = $row[1];

            if (isset($positions[$student_id])) {
                $row[$position_index] = $positions[$student_id];
                
                $comments = $DB->get_record('local_sis_comments', [
                    'userid' => $student_id,
                    'categoryid' => $categoryid,
                    'sessionid' => $sessionid,
                    'termid' => $termid
                ]);
                
                if (!$comments) {
                    $comments = $DB->get_record('local_sis_comments', [
                        'userid' => $student_id,
                        'categoryid' => $categoryid,
                        'session' => $sessionid,
                        'term' => $termid
                    ]);
                }
                
                if ($comments) {
                    $row[$position_index + 1] = $comments->teachercomment ?? '';
                    $row[$position_index + 2] = $comments->principalcomment ?? '';
                }
            }
        }
    }
    
    return $csv_data;
}

// Handle CSV download (Must be before any output)
if ($download && $categoryid && $sessionid && $termid) {
    $csv_data = generate_broadsheet_csv($categoryid, $sessionid, $termid);
    
    if (!$csv_data) {
        print_error('No data found for the selected criteria.');
    }
    
    $category = $DB->get_record('course_categories', ['id' => $categoryid]);
    $session_term_info = get_session_term_info($sessionid, $termid);
    
    $filename = 'broadsheet_' . 
                format_string($category->name) . '_' . 
                $session_term_info['sessionname'] . '_' . 
                $session_term_info['termname'] . '_' . 
                date('Y-m-d') . '.csv';
    
    $filename = preg_replace('/[^a-zA-Z0-9-_\.]/', '_', $filename);
    
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    
    $output = fopen('php://output', 'w');
    fwrite($output, "\xEF\xBB\xBF"); // Add BOM for Excel compatibility
    
    foreach ($csv_data as $row) {
        fputcsv($output, $row);
    }
    
    fclose($output);
    exit;
}

// --- Start Page Output ---
echo $OUTPUT->header();

// --- Dashboard Button Definition ---
$dashboard_button = html_writer::tag(
    'a', 
    'Back to Main Dashboard', 
    ['href' => new moodle_url('/local/sis/index.php'), 'class' => 'btn btn-info mb-4']
);

// --- Output Dashboard Button at Top ---
echo $dashboard_button;
echo $OUTPUT->heading('Broadsheet Generator');

// Get session and term information
$session_term_info = get_session_term_info($sessionid, $termid);

// Fetch categories, sessions, and terms
$categories = $DB->get_records_menu('course_categories', null, 'name ASC', 'id, name');
$session_options = [0 => 'Select Session'];
foreach ($session_term_info['sessions'] as $session) {
    $session_options[$session->id] = $session->sessionname;
}
$term_options = [0 => 'Select Term'];
foreach ($session_term_info['terms'] as $term) {
    $term_options[$term->id] = $term->termname;
}

// --- Start of Styled Form Box (for better visual appeal) ---
echo html_writer::start_div('p-4 mb-4 bg-white rounded shadow-lg border');
echo $OUTPUT->heading('Select Parameters', 3);

// Selection form
echo html_writer::start_tag('form', ['method' => 'get', 'class' => 'form-inline d-flex flex-wrap align-items-end']);

// Helper function for dropdowns
$create_dropdown = function($label, $name, $options, $selected) {
    $html = html_writer::start_div('form-group mr-4 mb-3');
    $html .= html_writer::label($label . ':', $name, false, ['class' => 'mr-2 font-weight-bold text-muted']);
    $html .= html_writer::select($options, $name, $selected, ['' => 'Choose...'], ['class' => 'form-control']);
    $html .= html_writer::end_div();
    return $html;
};

// Dropdowns
echo $create_dropdown('Class', 'categoryid', $categories, $categoryid);
echo $create_dropdown('Session', 'sessionid', $session_options, $sessionid);
echo $create_dropdown('Term', 'termid', $term_options, $termid);

echo html_writer::empty_tag('input', [
    'type' => 'submit', 
    'value' => 'Generate Broadsheet', 
    'class' => 'btn btn-primary mb-3 mr-2 font-weight-bold'
]);

// Download button (only show when parameters are selected)
if ($categoryid && $sessionid && $termid) {
    $download_url = new moodle_url('/local/sis/broadsheet.php', [
        'categoryid' => $categoryid,
        'sessionid' => $sessionid,
        'termid' => $termid,
        'download' => 1
    ]);
    
    echo html_writer::link($download_url, 'Download CSV', [
        'class' => 'btn btn-success mb-3',
        'target' => '_blank'
    ]);
}

echo html_writer::end_tag('form');
echo html_writer::end_div(); // --- End of Styled Form Box ---

// Preview table (when parameters are selected)
if ($categoryid && $sessionid && $termid) {
    $csv_data = generate_broadsheet_csv($categoryid, $sessionid, $termid);
    
    if ($csv_data) {
        echo $OUTPUT->heading('Broadsheet Preview', 3);
        
        // Table styling for scrollability and aesthetics
        echo '<div class="table-responsive bg-white rounded shadow p-3">';
        // The inner div creates the vertical scrollbar only on the table body
        echo '<div style="max-height: 70vh; overflow: auto; border: 1px solid #dee2e6;">';
        // w-100 ensures table fills container, table-hover adds interactivity
        echo '<table class="table table-bordered table-hover table-sm w-100 mb-0">';
        
        // We calculate the number of columns from the student data header row (index 5)
        $colspan = (count($csv_data) > 5) ? count($csv_data[5]) : 10; // Default to 10 if data is incomplete
        $total_headers = $colspan;
        
        // Define fixed widths for S/N, Student ID, and Student Name data cells for better readability
        $column_widths = [
            0 => '30px',  // S/N
            1 => '50px',  // Student ID
            2 => '120px'  // Student Name (Wide enough for full name)
        ];

        foreach ($csv_data as $row_index => $row) {
            echo '<tr>';
            
            // Check if this is one of the initial information rows (Rows 0, 1, 2, 3)
            $is_info_row = ($row_index >= 0 && $row_index <= 3);
            
            if ($is_info_row) { 
                // Apply full-width colspan and centering for School Name, Class, Session, and Date
                $tag = 'th';
                $fontsize = ($row_index == 0) ? '1.2em' : '1em'; // Larger font for School Name
                $style = 'colspan="' . $colspan . '" style="background-color: #f1f1f1; font-weight: 700; text-align: center; font-size: ' . $fontsize . ';"';
                
                // Since $row has only one cell, we use $row[0]
                echo "<{$tag} {$style}>" . s($row[0]) . "</{$tag}>";
            } else if ($row_index == 4) {
                // Empty row for spacing - output an empty row with colspan
                echo '<td colspan="' . $colspan . '" style="height: 10px; background-color: #ffffff;"></td>';
            } else {
                // Main Headers (Row 5) and Student Data (Row 6+)
                foreach ($row as $cell_index => $cell) {
                    $cell_content = s($cell);
                    $tag = ($row_index == 5) ? 'th' : 'td';
                    $style = '';
                    
                    $should_rotate = ($row_index == 5); // Rotate ALL headers

                    if ($should_rotate) {
                        // Header to Rotate: Apply 90-degree rotation
                        
                        // Set width slightly larger for Student Name header
                        // S/N column width adjusted for header rotation (cell_index 0)
                        $base_width = ($cell_index == 0) ? '40px' : (($cell_index == 2) ? '130px' : '60px'); 

                        // Style for the TH container (sets the required height and minimal width)
                        $th_container_style = '
                            width: ' . $base_width . '; /* Width for the TH container */
                            height: 120px; /* Space for the rotated text */
                            position: sticky; top: 0; z-index: 10;
                            background-color: #d1d8df;
                            font-weight: 700;
                            padding: 0; /* Important: remove padding on the TH */
                            vertical-align: bottom;
                            text-align: left;
                            border-bottom: 0;
                            border-right-width: 1px;
                        ';
                        
                        // Style for the inner DIV (performs the rotation)
                        $rotated_div_style = '
                            transform: rotate(-90deg); 
                            transform-origin: 0% 100%; 
                            white-space: nowrap; 
                            padding: 5px; 
                            margin-top: 110px; /* Shifts text down to be visible */
                            text-align: left;
                        ';
                        
                        // Wrap content in a div to perform rotation
                        $rotated_content = html_writer::tag('div', $cell_content, ['style' => $rotated_div_style]);
                        
                        $style = 'style="' . $th_container_style . '"';
                        $cell_content = $rotated_content; 
                    } 
                    
                    // For student data rows (td)
                    if ($row_index > 5) {
                        $td_style = 'text-align: center; vertical-align: middle;';
                        if (isset($column_widths[$cell_index])) {
                            // Apply specific width to data cells for S/N, ID, Name
                            $td_style .= ' min-width:' . $column_widths[$cell_index] . ';';
                        } else {
                            // Standard width for score columns
                            $td_style .= ' min-width: 60px;';
                        }

                        // Special case for S/N (index 0) data cell
                        if ($cell_index === 0) {
                             $td_style .= ' font-weight: bold;';
                        }
                        
                        $style = 'style="' . $td_style . '"';
                    }

                    echo "<{$tag} {$style}>" . $cell_content . "</{$tag}>";
                }
            }
            echo '</tr>';
        }
        
        echo '</table>';
        echo '</div>';
        echo '</div>';
        
        $download_url = new moodle_url('/local/sis/broadsheet.php', [
            'categoryid' => $categoryid,
            'sessionid' => $sessionid,
            'termid' => $termid,
            'download' => 1
        ]);
        
        // Large download button below the preview
        echo '<div class="mt-4 text-center">';
        echo html_writer::link($download_url, 'Download Full Broadsheet as CSV', [
            'class' => 'btn btn-success btn-lg shadow-sm',
            'target' => '_blank'
        ]);
        echo '</div>';
    } else {
        echo $OUTPUT->notification('No result data found for the selected Class, Session, and Term.', 'notifywarning');
    }
} else {
    echo $OUTPUT->notification('Please select all parameters (Class, Session, and Term) to generate the broadsheet.', 'notifymessage');
}

// --- Output Dashboard Button at Bottom ---
echo html_writer::start_div('mt-5 text-center');
echo $dashboard_button;
echo html_writer::end_div();

echo $OUTPUT->footer();