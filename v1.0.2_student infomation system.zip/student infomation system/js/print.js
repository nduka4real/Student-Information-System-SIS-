// Print functionality with better styling
document.addEventListener('DOMContentLoaded', function() {
    // Add print styles dynamically
    const printStyle = document.createElement('style');
    printStyle.innerHTML = `
        @media print {
            body * {
                visibility: hidden;
            }
            .printable-area, .printable-area * {
                visibility: visible;
            }
            .printable-area {
                position: absolute;
                left: 0;
                top: 0;
                width: 100%;
            }
            .action-buttons, .header, .footer {
                display: none !important;
            }
            .report-card {
                page-break-after: always;
                margin: 0;
                padding: 0;
            }
            .report-header {
                text-align: center !important;
            }
        }
    `;
    document.head.appendChild(printStyle);
});