<?php
// This file is part of the Student Information System plugin for Moodle.
// This file helps to create PDF files of results
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version information for the Student Information System plugin
 *
 * @package    local_sis
 * @copyright  2025 NduksTech - https://facebook.com/ndukshub
 * @author     Nduka Akapti  (https://github.com/nduka4real)
 * @author     Ndukstech (https://www.youtube.com/@nduks-tech)
 * @author     https://www.linkedin.com/in/ndukaakpati/
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @details
 * Display Name: Student Information System
 * Description: A comprehensive system for managing student records, assessments, fees, and school operations.
 * Contact: https://github.com/nduka4real
 * Social: https://facebook.com/ndukshub
 */


require_once('../../config.php');
require_login();

require_once($CFG->dirroot . '/vendor/autoload.php'); // load mPDF

$userid = required_param('userid', PARAM_INT);
$sessionid = optional_param('sessionid', 0, PARAM_INT);
$termid = optional_param('termid', 0, PARAM_INT);
$categoryid = optional_param('categoryid', 0, PARAM_INT);

$context = context_system::instance();

// Security check - allow users to view their own reports or admins to view any
if ($USER->id != $userid && !has_capability('moodle/site:viewparticipants', $context)) {
    print_error('nopermissions', 'error', '', 'view report');
}

$user = $DB->get_record('user', ['id' => $userid], '*', MUST_EXIST);

// ---------- Function to get school settings from database ----------
function get_school_settings() {
    global $DB;
    
    // Try to get school settings from the new table
    $school_settings = $DB->get_record('local_sis_school_settings', array('id' => 1));
    
    if (!$school_settings) {
        // Fallback to old config if new table doesn't exist or is empty
        return (object) [
            'schoolname' => 'NDUKS TECH',
            'schooladdress' => '',
            'schoolmotto' => '',
            'phone' => '',
            'state' => '',
            'country' => '',
            'schoollogo' => '',
            'principalsignature' => ''
        ];
    }
    
    return $school_settings;
}

// Get school settings
$school_settings = get_school_settings();

// Get session and term information
function get_session_term_info($sessionid = 0, $termid = 0) {
    global $DB;
    
    // Get all sessions ordered by name
    $sessions = $DB->get_records('local_sis_sessions', [], 'sessionname ASC');
    
    // If no session ID provided, get default session
    if (!$sessionid) {
        $current_session = $DB->get_record('local_sis_sessions', ['isdefault' => 1]);
        if ($current_session) {
            $sessionid = $current_session->id;
            $sessionname = $current_session->sessionname;
        } else {
            // Fallback to first session if no default found
            $first_session = reset($sessions);
            $sessionid = $first_session ? $first_session->id : 0;
            $sessionname = $first_session ? $first_session->sessionname : 'No Session Available';
        }
    } else {
        // Get the specific session
        $session = $DB->get_record('local_sis_sessions', ['id' => $sessionid]);
        $sessionname = $session ? $session->sessionname : 'Selected Session';
    }
    
    // Get terms for the selected session
    $terms = [];
    if ($sessionid) {
        $terms = $DB->get_records('local_sis_terms', ['sessionid' => $sessionid], 'termname ASC');
    }
    
    // If no term ID provided, get default term for the session
    if (!$termid && $sessionid) {
        $current_term = $DB->get_record('local_sis_terms', ['sessionid' => $sessionid, 'isdefault' => 1]);
        if ($current_term) {
            $termid = $current_term->id;
            $termname = $current_term->termname;
        } else {
            // Fallback to first term if no default found
            $first_term = reset($terms);
            $termid = $first_term ? $first_term->id : 0;
            $termname = $first_term ? $first_term->termname : 'No Term Available';
        }
    } else if ($termid) {
        // Get the specific term
        $term = $DB->get_record('local_sis_terms', ['id' => $termid]);
        $termname = $term ? $term->termname : 'Selected Term';
    } else {
        $termname = 'Select Term';
    }
    
    return [
        'sessionid' => $sessionid,
        'sessionname' => $sessionname,
        'termid' => $termid,
        'termname' => $termname,
        'sessions' => $sessions,
        'terms' => $terms
    ];
}

$session_term_info = get_session_term_info($sessionid, $termid);

// Check if we're using the new database structure
$columns = $DB->get_columns('local_sis_result');
$has_new_structure = array_key_exists('data', $columns);

// Build query conditions
$conditions = ['userid' => $userid];
if ($sessionid) {
    $conditions['sessionid'] = $sessionid;
}
if ($termid) {
    $conditions['termid'] = $termid;
}

if ($has_new_structure) {
    $results = $DB->get_records('local_sis_result', $conditions);
} else {
    $results = $DB->get_records('local_sis_ca', $conditions);
}

// If categoryid is provided, filter results by course category
if ($categoryid) {
    $filtered_results = [];
    foreach ($results as $result) {
        $course = $DB->get_record('course', ['id' => $result->courseid]);
        if ($course && $course->category == $categoryid) {
            $filtered_results[] = $result;
        }
    }
    $results = $filtered_results;
}

// Start PDF
$mpdf = new \Mpdf\Mpdf([
    'format' => 'A4', 
    'tempDir' => $CFG->tempdir,
    'margin_left' => 10,
    'margin_right' => 10,
    'margin_top' => 25,
    'margin_bottom' => 20,
    'margin_header' => 5,
    'margin_footer' => 5
]);

$mpdf->SetTitle("Report Card - " . fullname($user));

// Add watermark
$mpdf->SetWatermarkText($school_settings->schoolname ?: "NDUKS TECH");
$mpdf->showWatermarkText = true;
$mpdf->watermarkTextAlpha = 0.05;
$mpdf->watermark_font = 'dejavusans';

// CSS Wrapper for PDF Styling
$style = '
<style>
    body {
        font-family: dejavusans, sans-serif;
        margin: 0;
        padding: 0;
        color: #333;
        line-height: 1.4;
    }
    
    /* Header Styles */
    .header-table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 15px;
        border-bottom: 3px solid #3498db;
        padding-bottom: 10px;
    }
    .school-name {
        font-size: 20px;
        font-weight: bold;
        color: #2c3e50;
        margin: 0;
        text-transform: uppercase;
    }
    .motto {
        font-style: italic;
        font-size: 11px;
        color: #7f8c8d;
        margin-top: 3px;
    }
    .report-title {
        text-align: center;
        margin: 10px 0;
        font-size: 16px;
        color: #2c3e50;
        font-weight: bold;
        text-decoration: underline;
    }
    
    /* Student Info Styles */
    .student-info {
        background: #f8f9fa;
        padding: 12px;
        border-radius: 5px;
        margin-bottom: 15px;
        border-left: 4px solid #3498db;
        font-size: 12px;
    }
    .student-info b {
        color: #2c3e50;
    }
    
    /* Table Styles */
    .report-table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 20px;
        font-size: 10px;
        page-break-inside: avoid;
    }
    .report-table th {
        background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
        color: white;
        font-weight: bold;
        padding: 8px 4px;
        border: 1px solid #ddd;
        text-align: center;
        font-size: 9px;
    }
    .report-table td {
        border: 1px solid #e0e0e0;
        padding: 6px 4px;
        text-align: center;
    }
    .report-table tbody tr:nth-child(even) {
        background-color: #f8f9fa;
    }
    .report-table .summary-row {
        font-weight: bold;
        background-color: #e3f2fd !important;
        color: #1976d2;
    }
    
    /* Performance Summary */
    .performance-summary {
        background: #e3f2fd;
        padding: 12px;
        border-radius: 5px;
        margin: 15px 0;
        border-left: 4px solid #2196f3;
        font-size: 11px;
    }
    .summary-grid {
        display: table;
        width: 100%;
    }
    .summary-item {
        display: table-cell;
        text-align: center;
        padding: 5px;
    }
    .summary-item strong {
        display: block;
        color: #2c3e50;
        font-size: 10px;
    }
    .summary-value {
        font-size: 14px;
        font-weight: bold;
        color: #1976d2;
    }
    
    /* Comments Section */
    .comments-section {
        margin: 20px 0;
        page-break-inside: avoid;
    }
    .comments-header {
        font-size: 12px;
        font-weight: bold;
        color: #2c3e50;
        margin-bottom: 10px;
        padding-bottom: 5px;
        border-bottom: 1px solid #bdc3c7;
    }
    .comment-blocks {
        display: table;
        width: 100%;
    }
    .comment-block {
        display: table-cell;
        width: 48%;
        padding: 10px;
        background: white;
        border-radius: 5px;
        border: 1px solid #e0e0e0;
        margin: 0 1%;
    }
    .comment-block.teacher {
        border-left: 3px solid #4caf50;
    }
    .comment-block.principal {
        border-left: 3px solid #ff9800;
    }
    .comment-title {
        font-size: 10px;
        font-weight: bold;
        margin-bottom: 8px;
    }
    .comment-title.teacher {
        color: #4caf50;
    }
    .comment-title.principal {
        color: #ff9800;
    }
    .comment-content {
        padding: 8px;
        background: #fafafa;
        border-radius: 3px;
        border: 1px solid #eee;
        min-height: 50px;
        font-style: italic;
        font-size: 10px;
        line-height: 1.3;
    }
    
    /* Signature Section */
    .signature-section {
        text-align: center;
        margin-top: 30px;
        padding-top: 15px;
        border-top: 1px solid #bdc3c7;
        page-break-inside: avoid;
    }
    .signature-block {
        display: inline-block;
        text-align: center;
        margin: 0 20px;
    }
    .signature-line {
        border-bottom: 1px solid #000;
        width: 200px;
        height: 20px;
        margin: 5px 0;
    }
    .signature-label {
        font-size: 10px;
        font-weight: bold;
        color: #2c3e50;
    }
    
    /* Footer */
    .plugin-footer {
        text-align: center;
        margin-top: 15px;
        padding-top: 10px;
        border-top: 1px solid #ecf0f1;
        font-size: 8px;
        color: #7f8c8d;
        font-style: italic;
    }
    
    /* Utility Classes */
    .text-center { text-align: center; }
    .text-left { text-align: left; }
    .text-right { text-align: right; }
    .bold { font-weight: bold; }
    .italic { font-style: italic; }
</style>
';

$mpdf->WriteHTML($style);

// Handle logo path
$logopath = $CFG->dataroot . '/local/sis/pix/' . ($school_settings->schoollogo ?: 'schoollogo.png');
$logopathweb = '';

if (file_exists($logopath)) {
    $logopathweb = $CFG->wwwroot . '/local/sis/pix/' . ($school_settings->schoollogo ?: 'schoollogo.png');
} else {
    // Use a default logo or leave empty
    $logopathweb = '';
}

// Header (school logo, name, motto)
$schoolname = $school_settings->schoolname ?: "NDUKS TECH";
$schoolmotto = $school_settings->schoolmotto ?: "Excellence and Discipline";
$schooladdress = $school_settings->schooladdress ?: "";

$headerHTML = "
<table class='header-table'>
    <tr>
        <td style='width: 20%; text-align: left; vertical-align: middle;'>";
        
if ($logopathweb) {
    $headerHTML .= "<img src='$logopathweb' height='50' alt='School Logo'>";
}

$headerHTML .= "
        </td>
        <td style='width: 60%; text-align: center; vertical-align: middle;'>
            <div class='school-name'>$schoolname</div>";
            
if ($schooladdress) {
    $headerHTML .= "<div style='font-size: 9px; color: #666; margin: 2px 0;'>$schooladdress</div>";
}

if ($schoolmotto) {
    $headerHTML .= "<div class='motto'>\"$schoolmotto\"</div>";
}

$headerHTML .= "
        </td>
        <td style='width: 20%; text-align: right; vertical-align: middle; font-size: 9px; color: #666;'>
            Student Report Card
        </td>
    </tr>
</table>
";

$mpdf->SetHTMLHeader($headerHTML);

// Footer (page numbers + motto)
$footerHTML = "
<table width='100%' style='border-top: 1px solid #bdc3c7; font-size: 8px; color: #7f8c8d; padding-top: 5px;'>
    <tr>
        <td width='40%'>Generated: " . date('d M Y H:i') . "</td>
        <td width='20%' style='text-align: center;'>Page {PAGENO} of {nb}</td>
        <td width='40%' style='text-align: right;'>$schoolname Report Card</td>
    </tr>
</table>
";

$mpdf->SetHTMLFooter($footerHTML);

// Report content
$html = "
<div class='report-title'>STUDENT REPORT CARD</div>

<div class='student-info'>
    <table width='100%' style='font-size: 11px;'>
        <tr>
            <td width='25%'><b>Student:</b> " . fullname($user) . "</td>
            <td width='25%'><b>Username:</b> $user->username</td>
            <td width='25%'><b>Session:</b> " . $session_term_info['sessionname'] . "</td>
            <td width='25%'><b>Term:</b> " . $session_term_info['termname'] . "</td>
        </tr>
    </table>
</div>
";

if ($results) {
    $grandtotal = 0;
    $coursecount = 0;
    $courses_data = [];

    // Organize results by course and get additional data
    foreach ($results as $result) {
        $course = $DB->get_record('course', ['id' => $result->courseid], 'fullname, id');
        if ($course) {
            $courses_data[] = [
                'course' => $course,
                'result' => $result
            ];
            $grandtotal += (float)$result->total;
            $coursecount++;
        }
    }

    // Get component names for the table header
    $component_names = [];
    if ($has_new_structure && !empty($courses_data)) {
        $first_course = reset($courses_data);
        $component_names = get_component_names($first_course['course']->id, $session_term_info['sessionid'], $session_term_info['termid']);
    }

    if (empty($component_names)) {
        $component_names = ['CA1', 'CA2', 'Exam'];
    }

    $html .= "<table class='report-table'>
    <thead>
        <tr>
            <th style='width: 25%;'>Subject</th>";

    // Add component headers
    foreach ($component_names as $name) {
        $html .= "<th style='width: 8%;'>$name</th>";
    }

    $html .= "
            <th style='width: 8%;'>Total</th>
            <th style='width: 8%;'>Grade</th>
            <th style='width: 8%;'>Points</th>
            <th style='width: 15%;'>Position</th>
        </tr>
    </thead>
    <tbody>
    ";

    foreach ($courses_data as $course_data) {
        $course = $course_data['course'];
        $r = $course_data['result'];
        
        if ($has_new_structure) {
            // New structure: data is stored in JSON
            $component_data = !empty($r->data) ? json_decode($r->data, true) : [];
            $total = $r->total;
            $grade = $r->grade ?: '-';
            $points = $r->points ?: '0.0';
        } else {
            // Old structure: individual columns
            $component_data = [
                isset($r->firstca) ? $r->firstca : 0,
                isset($r->secondca) ? $r->secondca : 0,
                isset($r->exam) ? $r->exam : 0
            ];
            $total = $r->total;
            $grade = $r->grade ?: '-';
            $points = '0.0';
        }
        
        // Calculate position in course
        $pos_sql = "SELECT r.userid, r.total 
                   FROM {local_sis_result} r 
                   WHERE r.courseid = ? 
                   AND r.sessionid = ? 
                   AND r.termid = ? 
                   ORDER BY r.total DESC";
        $all_results = $DB->get_records_sql($pos_sql, [$course->id, $session_term_info['sessionid'], $session_term_info['termid']]);
        
        $positions = [];
        $current_rank = 0;
        $current_index = 0;
        $prev_score = null;
        
        foreach ($all_results as $student_result) {
            $current_index++;
            if ($prev_score === null || (string)$student_result->total !== (string)$prev_score) {
                $current_rank = $current_index;
                $prev_score = $student_result->total;
            }
            $positions[$student_result->userid] = $current_rank;
        }
        
        $position = $positions[$userid] ?? '-';
        $class_size = count($all_results);
        $position_display = is_numeric($position) ? $position . ' of ' . $class_size : '-';

        $html .= "
        <tr>
            <td style='text-align: left;'>". format_string($course->fullname) ."</td>";

        // Add component scores
        foreach ($component_names as $index => $name) {
            $score = isset($component_data[$index]) ? $component_data[$index] : 0;
            $html .= "<td>" . ($score > 0 ? $score : '-') . "</td>";
        }

        $html .= "
            <td><b>$total</b></td>
            <td>$grade</td>
            <td>$points</td>
            <td>$position_display</td>
        </tr>
        ";
    }

    // Performance Summary
    $average = $coursecount ? round($grandtotal / $coursecount, 1) : 0;
    
    // Get student comments
    $student_comments = $DB->get_record('local_sis_comments', [
        'userid' => $userid,
        'sessionid' => $session_term_info['sessionid'],
        'termid' => $session_term_info['termid']
    ]);
    
    $teacher_comment = $student_comments ? ($student_comments->teachercomment ?: 'No comment provided') : 'No comment provided';
    $principal_comment = $student_comments ? ($student_comments->principalcomment ?: 'No comment provided') : 'No comment provided';

    // Calculate overall position
    $overall_position = '-';
    if ($categoryid) {
        // Calculate position within the class/category
        $class_students = get_class_students($categoryid, $session_term_info['sessionid'], $session_term_info['termid']);
        if ($class_students) {
            $student_scores = [];
            foreach ($class_students as $student) {
                $student_total = 0;
                $student_count = 0;
                foreach ($courses_data as $course_data) {
                    $student_result = $DB->get_record('local_sis_result', [
                        'userid' => $student->id,
                        'courseid' => $course_data['course']->id,
                        'sessionid' => $session_term_info['sessionid'],
                        'termid' => $session_term_info['termid']
                    ]);
                    if ($student_result && is_numeric($student_result->total)) {
                        $student_total += (float)$student_result->total;
                        $student_count++;
                    }
                }
                if ($student_count > 0) {
                    $student_scores[$student->id] = $student_total / $student_count;
                }
            }
            
            arsort($student_scores);
            $overall_position = array_search($userid, array_keys($student_scores)) + 1;
            $overall_position .= ' of ' . count($student_scores);
        }
    }

    $html .= "
    </tbody>
    </table>
    
    <div class='performance-summary'>
        <div class='summary-grid'>
            <div class='summary-item'>
                <strong>Total Score</strong>
                <div class='summary-value'>$grandtotal</div>
            </div>
            <div class='summary-item'>
                <strong>Average Score</strong>
                <div class='summary-value'>$average</div>
            </div>
            <div class='summary-item'>
                <strong>Subjects Taken</strong>
                <div class='summary-value'>$coursecount</div>
            </div>
            <div class='summary-item'>
                <strong>Class Position</strong>
                <div class='summary-value'>$overall_position</div>
            </div>
        </div>
    </div>
    ";

    // Comments Section
    $html .= "
    <div class='comments-section'>
        <div class='comments-header'>COMMENTS AND REMARKS</div>
        <div class='comment-blocks'>
            <div class='comment-block teacher'>
                <div class='comment-title teacher'>CLASS TEACHER'S COMMENT</div>
                <div class='comment-content'>$teacher_comment</div>
            </div>
            <div class='comment-block principal'>
                <div class='comment-title principal'>PRINCIPAL'S COMMENT</div>
                <div class='comment-content'>$principal_comment</div>
            </div>
        </div>
    </div>
    ";

    // Signature Section
    $html .= "
    <div class='signature-section'>
        <div class='signature-block'>
            <div class='signature-line'></div>
            <div class='signature-label'>Class Teacher's Signature</div>
        </div>
        <div class='signature-block'>
            <div class='signature-line'></div>
            <div class='signature-label'>Principal's Signature</div>
        </div>
    </div>
    
    <div class='plugin-footer'>
        Generated by NduksTech SIS Plugin � facebook.com/ndukshub
    </div>
    ";
} else {
    $html .= "
    <div style='text-align: center; padding: 40px; color: #7f8c8d;'>
        <h3>No Results Found</h3>
        <p>No results available for the selected criteria.</p>
        <p><small>Session: " . $session_term_info['sessionname'] . " | Term: " . $session_term_info['termname'] . "</small></p>
    </div>
    ";
}

$mpdf->WriteHTML($html);

// Helper function to get component names
function get_component_names($courseid, $sessionid, $termid) {
    global $DB;
    
    $ca_config = $DB->get_record('local_sis_ca_config', [
        'courseid' => $courseid,
        'sessionid' => $sessionid,
        'termid' => $termid
    ]);
    
    if (!$ca_config || empty($ca_config->components)) {
        return ['CA1', 'CA2', 'Exam'];
    }
    
    $components = json_decode($ca_config->components, true);
    $component_names = [];
    foreach ($components as $component) {
        $component_names[] = $component['name'];
    }
    return $component_names;
}

// Helper function to get class students
function get_class_students($categoryid, $sessionid, $termid) {
    global $DB;
    
    $sql = "SELECT DISTINCT u.*
             FROM {user} u
             JOIN {local_sis_result} r ON r.userid = u.id
             JOIN {course} c ON c.id = r.courseid
            WHERE c.category = :catid
              AND r.sessionid = :sessionid
              AND r.termid = :termid
          ORDER BY u.lastname, u.firstname";
    
    return $DB->get_records_sql($sql, [
        'catid' => $categoryid,
        'sessionid' => $sessionid,
        'termid' => $termid
    ]);
}

// Output PDF
$filename = "ReportCard_" . clean_filename(fullname($user)) . "_" . date('Y-m-d') . ".pdf";
$mpdf->Output($filename, "D");

// Helper function for filename cleaning
function clean_filename($filename) {
    return preg_replace('/[^a-zA-Z0-9_-]/', '_', $filename);
}