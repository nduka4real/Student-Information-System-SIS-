<?php
// This file is part of the Student Information System plugin for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version information for the Student Information System plugin
 *
 * @package    local_sis
 * @copyright  2025 NduksTech - https://facebook.com/ndukshub
 * @author     Nduka Akapti  (https://github.com/nduka4real)
 * @author     Ndukstech (https://www.youtube.com/@nduks-tech)
 * @author     https://www.linkedin.com/in/ndukaakpati/
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @details
 * Display Name: Student Information System
 * Description: A comprehensive system for managing student records, assessments, fees, and school operations.
 * Contact: https://github.com/nduka4real
 * Social: https://facebook.com/ndukshub
 */

// local/sis/aikenlib.php

require_once($CFG->dirroot . '/question/format.php');
require_once($CFG->dirroot . '/question/engine/bank.php');
require_once($CFG->dirroot . '/question/type/multichoice/question.php');

/**
 * Parse Aiken format content with improved parsing
 */
function parse_aiken_content($content) {
    $questions = [];
    
    // Normalize line endings and split into lines
    $content = str_replace(["\r\n", "\r"], "\n", $content);
    $lines = explode("\n", $content);
    
    $currentQuestion = null;
    $collectingQuestion = false;
    
    foreach ($lines as $line) {
        $line = trim($line);
        
        if (empty($line)) {
            if ($currentQuestion !== null && !empty($currentQuestion['question'])) {
                $collectingQuestion = false;
            }
            continue;
        }
        
        // Check if this is an answer line
        if (preg_match('/^ANSWER:\s*([A-Z])/i', $line, $matches)) {
            if ($currentQuestion !== null && !empty($currentQuestion['choices'])) {
                $currentQuestion['answer'] = strtoupper(trim($matches[1]));
                if (!empty($currentQuestion['question']) && count($currentQuestion['choices']) >= 2) {
                    $questions[] = $currentQuestion;
                }
                $currentQuestion = null;
                $collectingQuestion = false;
            }
            continue;
        }
        
        // Choice lines
        if (preg_match('/^([A-D])[\.\)]\s*(.+)$/i', $line, $matches)) {
            $choiceLetter = strtoupper(trim($matches[1]));
            $choiceText = trim($matches[2]);
            
            if ($currentQuestion === null) {
                $currentQuestion = [
                    'question' => '',
                    'choices' => [],
                    'answer' => ''
                ];
            }
            
            $currentQuestion['choices'][$choiceLetter] = $choiceText;
            $collectingQuestion = false;
            continue;
        }
        
        // Question line
        if ($currentQuestion === null) {
            $currentQuestion = [
                'question' => $line,
                'choices' => [],
                'answer' => ''
            ];
            $collectingQuestion = true;
        } else if ($collectingQuestion) {
            $currentQuestion['question'] .= ' ' . $line;
        } else if (!empty($currentQuestion['choices'])) {
            $lastChoice = array_keys($currentQuestion['choices'])[count($currentQuestion['choices']) - 1];
            $currentQuestion['choices'][$lastChoice] .= ' ' . $line;
        } else {
            $currentQuestion['question'] .= ' ' . $line;
        }
    }
    
    // Include last question if not closed by ANSWER:
    if ($currentQuestion !== null && !empty($currentQuestion['question']) && 
        !empty($currentQuestion['choices']) && count($currentQuestion['choices']) >= 2) {
        $questions[] = $currentQuestion;
    }
    
    // Filter invalid entries
    $questions = array_filter($questions, function($q) {
        return !empty($q['question']) && 
               !empty($q['choices']) && 
               count($q['choices']) >= 2 && 
               !empty($q['answer']) &&
               isset($q['choices'][$q['answer']]);
    });
    
    return $questions;
}

/**
 * Import Aiken format questions into a quiz
 */
function import_aiken_to_quiz($filepath, $courseid, $quizid) {
    global $DB, $USER;
    
    $content = file_get_contents($filepath);
    $questions = parse_aiken_content($content);
    
    if (empty($questions)) {
        throw new Exception('No valid Aiken questions found in the file.');
    }
    
    $context = context_course::instance($courseid);
    
    // Get or create category
    $category = $DB->get_record_sql("
        SELECT id 
        FROM {question_categories} 
        WHERE contextid = ? 
        ORDER BY id ASC 
        LIMIT 1
    ", [$context->id]);
    
    if (!$category) {
        $category = new stdClass();
        $category->name = 'Default';
        $category->contextid = $context->id;
        $category->info = 'Default question category';
        $category->sortorder = 999;
        $category->stamp = make_unique_id_code();
        $category->id = $DB->insert_record('question_categories', $category);
    }
    
    $count = 0;
    
    foreach ($questions as $qdata) {
        $questionText = trim($qdata['question']);
        $questionName = shorten_text($questionText, 250);
        
        $question = new stdClass();
        $question->category = $category->id;
        $question->parent = 0;
        $question->name = $questionName;
        $question->questiontext = $questionText;
        $question->questiontextformat = FORMAT_PLAIN;
        $question->generalfeedback = '';
        $question->generalfeedbackformat = FORMAT_HTML;
        $question->defaultmark = 1;
        $question->penalty = 0.3333333;
        $question->qtype = 'multichoice';
        $question->length = 1;
        $question->stamp = make_unique_id_code();
        $question->version = make_unique_id_code();
        $question->hidden = 0;
        $question->timecreated = time();
        $question->timemodified = time();
        $question->createdby = $USER->id;
        $question->modifiedby = $USER->id;
        
        $question->id = $DB->insert_record('question', $question);
        
        if ($question->id) {
            $mc = new stdClass();
            $mc->questionid = $question->id;
            $mc->layout = 0;
            $mc->single = 1;
            $mc->shuffleanswers = 1;
            $mc->correctfeedback = 'Your answer is correct.';
            $mc->correctfeedbackformat = FORMAT_HTML;
            $mc->partiallycorrectfeedback = 'Your answer is partially correct.';
            $mc->partiallycorrectfeedbackformat = FORMAT_HTML;
            $mc->incorrectfeedback = 'Your answer is incorrect.';
            $mc->incorrectfeedbackformat = FORMAT_HTML;
            $mc->answernumbering = 'abc';
            $mc->showstandardinstruction = 0;
            $DB->insert_record('qtype_multichoice_options', $mc);
            
            foreach ($qdata['choices'] as $letter => $choice) {
                $answer = new stdClass();
                $answer->question = $question->id;
                $answer->answer = trim($choice);
                $answer->answerformat = FORMAT_PLAIN;
                $answer->fraction = ($letter === $qdata['answer']) ? 1.0 : 0.0;
                $answer->feedback = '';
                $answer->feedbackformat = FORMAT_HTML;
                $DB->insert_record('question_answers', $answer);
            }
            
            $slot = new stdClass();
            $slot->quizid = $quizid;
            $slot->questionid = $question->id;
            $slot->page = 1;
            $slot->maxmark = 1;
            $maxslot = $DB->get_field_sql("SELECT MAX(slot) FROM {quiz_slots} WHERE quizid = ?", [$quizid]);
            $slot->slot = ($maxslot ? $maxslot + 1 : 1);
            $DB->insert_record('quiz_slots', $slot);
            $count++;
        }
    }
    
    if ($count > 0) {
        $quiz = $DB->get_record('quiz', ['id' => $quizid]);
        $quiz->sumgrades = $count;
        $DB->update_record('quiz', $quiz);
    }
    
    return $count;
}

/**
 * ? Safe, rollback-protected import into Question Bank
 */
function import_aiken_to_question_bank($filepath, $courseid) {
    global $DB, $USER;
    
    $result = ['imported' => 0, 'errors' => []];
    $content = file_get_contents($filepath);
    $questions = parse_aiken_content($content);
    
    if (empty($questions)) {
        $result['errors'][] = "No valid AIKEN questions found in file.";
        return $result;
    }
    
    $context = context_course::instance($courseid);
    $transaction = $DB->start_delegated_transaction();
    
    try {
        $category = $DB->get_record('question_categories', ['contextid' => $context->id]);
        if (!$category) {
            $category = new stdClass();
            $category->name = 'Imported Questions';
            $category->contextid = $context->id;
            $category->info = 'Questions imported from AIKEN format.';
            $category->infoformat = FORMAT_HTML;
            $category->stamp = make_unique_id_code();
            $category->sortorder = 999;
            $category->id = $DB->insert_record('question_categories', $category);
        }

        foreach ($questions as $index => $qdata) {
            if (!isset($qdata['question']) || !isset($qdata['choices'][$qdata['answer']])) {
                $result['errors'][] = "Question " . ($index + 1) . " skipped (invalid format).";
                continue;
            }

            $question = new stdClass();
            $question->category = $category->id;
            $question->parent = 0;
            $question->name = shorten_text($qdata['question'], 250);
            $question->questiontext = $qdata['question'];
            $question->questiontextformat = FORMAT_HTML;
            $question->generalfeedback = '';
            $question->generalfeedbackformat = FORMAT_HTML;
            $question->defaultmark = 1;
            $question->penalty = 0.3333333;
            $question->qtype = 'multichoice';
            $question->length = 1;
            $question->stamp = make_unique_id_code();
            $question->version = make_unique_id_code();
            $question->hidden = 0;
            $question->timecreated = time();
            $question->timemodified = time();
            $question->createdby = $USER->id;
            $question->modifiedby = $USER->id;
            $question->id = $DB->insert_record('question', $question);

            foreach ($qdata['choices'] as $letter => $choice) {
                $ans = new stdClass();
                $ans->question = $question->id;
                $ans->answer = trim($choice);
                $ans->answerformat = FORMAT_HTML;
                $ans->fraction = ($letter === $qdata['answer']) ? 1.0 : 0.0;
                $ans->feedback = '';
                $ans->feedbackformat = FORMAT_HTML;
                $DB->insert_record('question_answers', $ans);
            }

            $opts = new stdClass();
            $opts->question = $question->id;
            $opts->layout = 0;
            $opts->single = 1;
            $opts->shuffleanswers = 1;
            $opts->answernumbering = 'abc';
            $opts->showstandardinstruction = 1;
            $DB->insert_record('qtype_multichoice_options', $opts);

            $result['imported']++;
        }

        $transaction->allow_commit();

    } catch (Exception $e) {
        $transaction->rollback($e);
        $result['errors'][] = "Import failed: " . $e->getMessage();
        return $result;
    }

    return $result;
}

/**
 * Simple AIKEN preview for validation
 */
function preview_aiken_file($filename) {
    $lines = file($filename, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $questions = [];
    $current = null;
    foreach ($lines as $line) {
        $line = trim($line);
        if (preg_match('/^[A-D]\./', $line)) {
            $current['options'][] = $line;
        } elseif (preg_match('/^ANSWER:/i', $line)) {
            $current['answer'] = trim(substr($line, 7));
            $questions[] = $current;
            $current = null;
        } elseif ($line !== '') {
            $current = ['question' => $line, 'options' => [], 'answer' => ''];
        }
    }
    return $questions;
}