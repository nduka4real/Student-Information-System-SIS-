<?php
// This file is part of the Student Information System plugin for Moodle.
// This file helps to import questions in aiken format
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version information for the Student Information System plugin
 *
 * @package    local_sis
 * @copyright  2025 NduksTech - https://facebook.com/ndukshub
 * @author     Nduka Akapti  (https://github.com/nduka4real)
 * @author     Ndukstech (https://www.youtube.com/@nduks-tech)
 * @author     https://www.linkedin.com/in/ndukaakpati/
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @details
 * Display Name: Student Information System
 * Description: A comprehensive system for managing student records, assessments, fees, and school operations.
 * Contact: https://github.com/nduka4real
 * Social: https://facebook.com/ndukshub
 */
require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir.'/formslib.php');
require_login();
require_capability('moodle/site:config', context_system::instance());

global $DB, $USER, $PAGE, $OUTPUT;

// Page setup
$courseid = required_param('courseid', PARAM_INT);
$quizid   = optional_param('quizid', 0, PARAM_INT);

$PAGE->set_url(new moodle_url('/local/sis/import_aiken.php', ['courseid' => $courseid, 'quizid' => $quizid]));
$PAGE->set_context(context_course::instance($courseid));
$PAGE->set_title("Import Aiken Questions");
$PAGE->set_heading("Import Aiken Questions");

// Include parser/insert functions
require_once(__DIR__ . '/aikenlib.php'); // put the functions we wrote earlier in this file

/**
 * Define the form
 */
class aiken_upload_form extends moodleform {
    function definition() {
        $mform = $this->_form;
        $courseid = $this->_customdata['courseid'];
        $quizid   = $this->_customdata['quizid'];

        $mform->addElement('filepicker', 'aikenfile', 'Upload Aiken file', null,
            ['accepted_types' => ['.txt']]);
        $mform->addRule('aikenfile', 'Required', 'required', null, 'client');

        if ($quizid) {
            $mform->addElement('static', 'importto', 'Import Target', 'Selected Quiz');
        } else {
            $mform->addElement('select', 'categoryid', 'Select Question Bank Category',
                $this->get_categories($courseid));
            $mform->addRule('categoryid', 'Required', 'required', null, 'client');
        }

        $this->add_action_buttons(true, 'Preview');
    }

    private function get_categories($courseid) {
        global $DB;
        $context = context_course::instance($courseid);
        $cats = $DB->get_records('question_categories', ['contextid' => $context->id], 'name ASC', 'id,name');
        $options = [];
        foreach ($cats as $cat) {
            $options[$cat->id] = $cat->name;
        }
        if (empty($options)) {
            $options[0] = 'No categories found (a new one will be created)';
        }
        return $options;
    }
}

echo $OUTPUT->header();
echo $OUTPUT->heading("Aiken Import");

// Instantiate form
$mform = new aiken_upload_form(null, ['courseid' => $courseid, 'quizid' => $quizid]);

if ($mform->is_cancelled()) {
    redirect(new moodle_url('/course/view.php', ['id' => $courseid]));
}
else if ($data = $mform->get_data()) {
    // Handle uploaded file
    $fs = get_file_storage();
    $draftid = file_get_submitted_draft_itemid('aikenfile');
    $usercontext = context_user::instance($USER->id);
    $files = file_get_drafarea_files($draftid, $usercontext->id, 'user', 'draft', $draftid);
    $file = reset($files->list);

    if (!$file) {
        echo $OUTPUT->notification("No file uploaded", 'error');
        $mform->display();
        echo $OUTPUT->footer();
        exit;
    }

    $content = $file->get_content();
    $questions = parse_aiken_content($content);

    if (empty($questions)) {
        echo $OUTPUT->notification("No valid Aiken questions found in the file.", 'error');
    } else {
        // Preview questions
        echo html_writer::tag('h3', "Preview Questions");
        echo html_writer::start_tag('ol');
        foreach ($questions as $q) {
            echo html_writer::tag('li', format_text($q['question']));
            echo html_writer::start_tag('ul');
            foreach ($q['choices'] as $letter => $text) {
                $feedback = isset($q['feedback'][$letter]) ? " <em>({$q['feedback'][$letter]})</em>" : "";
                echo html_writer::tag('li', "$letter. $text $feedback");
            }
            echo html_writer::end_tag('ul');
            echo html_writer::tag('p', "<strong>Answer:</strong> " . $q['answer']);
        }
        echo html_writer::end_tag('ol');

        // Final import button
        $importurl = new moodle_url('/local/sis/import_aiken.php', [
            'courseid' => $courseid,
            'quizid' => $quizid,
            'confirm' => 1
        ]);
        $importurl->param('filename', $file->get_id());

        echo $OUTPUT->single_button($importurl, 'Import Now', 'post');
    }
}
else if (optional_param('confirm', 0, PARAM_BOOL)) {
    // Actually import
    $fileid = required_param('filename', PARAM_INT);
    $file = $DB->get_record('files', ['id' => $fileid], '*', MUST_EXIST);
    $fs = get_file_storage();
    $stored = $fs->get_file_instance($file);
    $content = $stored->get_content();
    $questions = parse_aiken_content($content);

    if ($quizid) {
        $count = import_aiken_questions($stored->get_content_file_location(), $courseid, $quizid);
        echo $OUTPUT->notification("$count questions imported into quiz.", 'notifysuccess');
    } else {
        $categoryid = optional_param('categoryid', 0, PARAM_INT);
        if (!$categoryid) {
            $categoryid = create_question_bank_category($courseid, 'Imported Aiken Questions');
        }
        $count = import_aiken_to_question_bank($stored->get_content_file_location(), $categoryid);
        echo $OUTPUT->notification("$count questions imported into question bank.", 'notifysuccess');
    }
}

$mform->display();
echo $OUTPUT->footer();
