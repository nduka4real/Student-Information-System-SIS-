<?php
// This file is part of the Student Information System plugin for Moodle.
// this file is part of course management
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version information for the Student Information System plugin
 *
 * @package    local_sis
 * @copyright  2025 NduksTech - https://facebook.com/ndukshub
 * @author     Nduka Akapti  (https://github.com/nduka4real)
 * @author     Ndukstech (https://www.youtube.com/@nduks-tech)
 * @author     https://www.linkedin.com/in/ndukaakpati/
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @details
 * Display Name: Student Information System
 * Description: A comprehensive system for managing student records, assessments, fees, and school operations.
 * Contact: https://github.com/nduka4real
 * Social: https://facebook.com/ndukshub
 */

// local/sis/coursemanager.php
require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/formslib.php');
require_once($CFG->dirroot . '/course/lib.php');

require_login();

global $DB, $USER, $PAGE, $OUTPUT;

// Check permissions
require_capability('moodle/course:create', context_system::instance());

$action = optional_param('action', 'list', PARAM_ALPHA);
$courseid = optional_param('courseid', 0, PARAM_INT);
$categoryid = optional_param('categoryid', 0, PARAM_INT);
$confirm = optional_param('confirm', 0, PARAM_BOOL);

$PAGE->set_url(new moodle_url('/local/sis/coursemanager.php'));
$PAGE->set_context(context_system::instance());
$PAGE->set_title('Course Management');
$PAGE->set_heading('Course Management');

// Add back to SIS main dashboard button
$sis_dashboard_url = new moodle_url('/local/sis/index.php'); // Adjust path as needed

// Custom course creation form
class course_creation_form extends moodleform {
    public function definition() {
        global $DB;
        
        $mform = $this->_form;
        
        // Category selection
        $categories = core_course_category::make_categories_list();
        $category_options = [0 => '-- Select Category --'] + $categories;
        
        $mform->addElement('select', 'categoryid', 'Category', $category_options);
        $mform->addRule('categoryid', 'Required', 'required', null, 'client');
        $mform->addHelpButton('categoryid', 'coursecategory');
        
        // Course full name
        $mform->addElement('text', 'fullname', 'Course Full Name', ['size' => '50']);
        $mform->setType('fullname', PARAM_TEXT);
        $mform->addRule('fullname', 'Required', 'required', null, 'client');
        $mform->addHelpButton('fullname', 'fullnamecourse');
        
        // Course short name
        $mform->addElement('text', 'shortname', 'Course Short Name', ['size' => '20']);
        $mform->setType('shortname', PARAM_TEXT);
        $mform->addRule('shortname', 'Required', 'required', null, 'client');
        $mform->addHelpButton('shortname', 'shortnamecourse');
        
        // Course ID number
        $mform->addElement('text', 'idnumber', 'Course ID Number', ['size' => '20']);
        $mform->setType('idnumber', PARAM_TEXT);
        $mform->addHelpButton('idnumber', 'idnumbercourse');
        
        // Course summary
        $mform->addElement('editor', 'summary_editor', 'Course Description');
        $mform->setType('summary_editor', PARAM_RAW);
        $mform->addHelpButton('summary_editor', 'coursesummary');
        
        // Course format
        $formats = get_sorted_course_formats(true);
        $format_options = [];
        foreach ($formats as $format) {
            $format_options[$format] = get_string('pluginname', "format_$format");
        }
        $mform->addElement('select', 'format', 'Course Format', $format_options);
        $mform->setDefault('format', 'topics');
        // Use correct help string for format
        $mform->addHelpButton('format', 'format', 'moodle');
        
        // Number of sections - only show for topics format
        $mform->addElement('text', 'numsections', 'Number of Sections/Topics', ['size' => '3']);
        $mform->setType('numsections', PARAM_INT);
        $mform->setDefault('numsections', 10);
        // Use correct help string for numsections
        $mform->addHelpButton('numsections', 'numberofsections', 'moodle');
        
        // Course start date
        $mform->addElement('date_selector', 'startdate', 'Course Start Date');
        $mform->setDefault('startdate', time());
        $mform->addHelpButton('startdate', 'startdate');
        
        // Course visibility
        $mform->addElement('select', 'visible', 'Course Visibility', [
            1 => 'Show',
            0 => 'Hide'
        ]);
        $mform->setDefault('visible', 1);
        $mform->addHelpButton('visible', 'visible');
        
        // Buttons
        $buttonarray = [];
        $buttonarray[] = $mform->createElement('submit', 'submitbutton', 'Create Course');
        $buttonarray[] = $mform->createElement('cancel');
        $mform->addGroup($buttonarray, 'buttonar', '', ' ', false);
    }
    
    public function validation($data, $files) {
        global $DB;
        
        $errors = parent::validation($data, $files);
        
        // Check if shortname already exists
        if ($DB->record_exists('course', ['shortname' => $data['shortname']])) {
            $errors['shortname'] = 'A course with this short name already exists';
        }
        
        // Check if idnumber already exists (if provided)
        if (!empty($data['idnumber']) && $DB->record_exists('course', ['idnumber' => $data['idnumber']])) {
            $errors['idnumber'] = 'A course with this ID number already exists';
        }
        
        // Validate category
        if (empty($data['categoryid']) || !core_course_category::get($data['categoryid'], IGNORE_MISSING)) {
            $errors['categoryid'] = 'Please select a valid category';
        }
        
        // Validate number of sections
        if (empty($data['numsections']) || $data['numsections'] < 1) {
            $errors['numsections'] = 'Number of sections must be at least 1';
        }
        
        return $errors;
    }
}

// Handle different actions
switch ($action) {
    case 'create':
        display_create_form();
        break;
        
    case 'edit':
        display_edit_form($courseid);
        break;
        
    case 'delete':
        handle_delete_course($courseid, $confirm);
        break;
        
    case 'moodlecreate':
        redirect(new moodle_url('/course/edit.php', ['category' => $categoryid]));
        break;
        
    default:
        display_course_list();
        break;
}

function display_create_form() {
    global $PAGE, $OUTPUT, $sis_dashboard_url;
    
    echo $OUTPUT->header();
    echo $OUTPUT->heading('Create New Course');
    
    // Navigation
    echo html_writer::start_div('mb-4');
    echo html_writer::link(
        $sis_dashboard_url,
        'Back to SIS Main Dashboard',
        ['class' => 'btn btn-secondary mr-2']
    );
    echo html_writer::link(
        new moodle_url('/local/sis/coursemanager.php'),
        'Back to Course List',
        ['class' => 'btn btn-outline-secondary']
    );
    echo html_writer::end_div();
    
    $mform = new course_creation_form();
    
    if ($mform->is_cancelled()) {
        redirect(new moodle_url('/local/sis/coursemanager.php'));
    } else if ($data = $mform->get_data()) {
        // Create the course using proper course creation method
        $courseconfig = get_config('moodlecourse');
        
        $course = new stdClass();
        $course->category = $data->categoryid;
        $course->fullname = $data->fullname;
        $course->shortname = $data->shortname;
        $course->idnumber = $data->idnumber;
        $course->summary = $data->summary_editor['text'];
        $course->summaryformat = $data->summary_editor['format'];
        $course->format = $data->format;
        $course->numsections = $data->numsections;
        $course->startdate = $data->startdate;
        $course->visible = $data->visible;
        $course->timecreated = time();
        $course->timemodified = time();
        
        // Set default course settings
        $course->newsitems = $courseconfig->newsitems;
        $course->showgrades = 1;
        $course->showreports = 1;
        $course->maxbytes = $courseconfig->maxbytes;
        $course->groupmode = $courseconfig->groupmode;
        $course->groupmodeforce = $courseconfig->groupmodeforce;
        $course->lang = current_language();
        
        try {
            // Use create_course function which handles all the necessary setup
            $new_course = create_course($course);
            
            \core\notification::success("Course '{$new_course->fullname}' created successfully!");
            redirect(new moodle_url('/local/sis/coursemanager.php'));
            
        } catch (moodle_exception $e) {
            \core\notification::error("Failed to create course: " . $e->getMessage());
            // Re-display the form with error
            $mform->display();
        }
    } else {
        $mform->display();
    }
    
    echo $OUTPUT->footer();
}

function display_edit_form($courseid) {
    global $DB, $PAGE, $OUTPUT, $sis_dashboard_url;
    
    if (!$course = $DB->get_record('course', ['id' => $courseid])) {
        \core\notification::error('Course not found');
        redirect(new moodle_url('/local/sis/coursemanager.php'));
    }
    
    echo $OUTPUT->header();
    echo $OUTPUT->heading('Edit Course: ' . format_string($course->fullname));
    
    // Navigation
    echo html_writer::start_div('mb-4');
    echo html_writer::link(
        $sis_dashboard_url,
        'Back to SIS Main Dashboard',
        ['class' => 'btn btn-secondary mr-2']
    );
    echo html_writer::link(
        new moodle_url('/local/sis/coursemanager.php'),
        'Back to Course List',
        ['class' => 'btn btn-outline-secondary']
    );
    echo html_writer::end_div();
    
    // Use Moodle's built-in course editing
    echo html_writer::start_div('alert alert-info mb-4');
    echo html_writer::tag('h5', 'Use Moodle Course Editor');
    echo html_writer::tag('p', 'For full course editing capabilities, use Moodle\'s built-in course editor.');
    echo html_writer::link(
        new moodle_url('/course/edit.php', ['id' => $courseid]),
        'Open Course Settings',
        ['class' => 'btn btn-primary']
    );
    echo html_writer::end_div();
    
    // Quick edit form for basic properties
    $mform = new course_creation_form();
    
    // Prepare data for the form
    $formdata = new stdClass();
    $formdata->categoryid = $course->category;
    $formdata->fullname = $course->fullname;
    $formdata->shortname = $course->shortname;
    $formdata->idnumber = $course->idnumber;
    $formdata->summary_editor = [
        'text' => $course->summary,
        'format' => $course->summaryformat
    ];
    $formdata->format = $course->format;
    $formdata->numsections = $course->numsections;
    $formdata->startdate = $course->startdate;
    $formdata->visible = $course->visible;
    
    $mform->set_data($formdata);
    
    if ($mform->is_cancelled()) {
        redirect(new moodle_url('/local/sis/coursemanager.php'));
    } else if ($data = $mform->get_data()) {
        // Update the course
        $course->category = $data->categoryid;
        $course->fullname = $data->fullname;
        $course->shortname = $data->shortname;
        $course->idnumber = $data->idnumber;
        $course->summary = $data->summary_editor['text'];
        $course->summaryformat = $data->summary_editor['format'];
        $course->format = $data->format;
        $course->numsections = $data->numsections;
        $course->startdate = $data->startdate;
        $course->visible = $data->visible;
        $course->timemodified = time();
        
        try {
            update_course($course);
            
            \core\notification::success("Course '{$course->fullname}' updated successfully!");
            redirect(new moodle_url('/local/sis/coursemanager.php'));
            
        } catch (moodle_exception $e) {
            \core\notification::error("Failed to update course: " . $e->getMessage());
            $mform->display();
        }
    } else {
        $mform->display();
    }
    
    echo $OUTPUT->footer();
}

function handle_delete_course($courseid, $confirm) {
    global $DB, $PAGE, $OUTPUT, $sis_dashboard_url;
    
    if (!$course = $DB->get_record('course', ['id' => $courseid])) {
        \core\notification::error('Course not found');
        redirect(new moodle_url('/local/sis/coursemanager.php'));
    }
    
    if (!$confirm) {
        // Show confirmation page
        echo $OUTPUT->header();
        echo $OUTPUT->heading('Delete Course');
        
        // Navigation
        echo html_writer::start_div('mb-4');
        echo html_writer::link(
            $sis_dashboard_url,
            'Back to SIS Main Dashboard',
            ['class' => 'btn btn-secondary mr-2']
        );
        echo html_writer::link(
            new moodle_url('/local/sis/coursemanager.php'),
            'Back to Course List',
            ['class' => 'btn btn-outline-secondary']
        );
        echo html_writer::end_div();
        
        echo html_writer::start_div('alert alert-danger');
        echo html_writer::tag('h4', 'Warning: This action cannot be undone!');
        echo html_writer::tag('p', 'You are about to delete the course: ' . format_string($course->fullname));
        echo html_writer::tag('p', 'All course data, including user enrolments, activities, and grades will be permanently deleted.');
        echo html_writer::end_div();
        
        echo html_writer::start_div('mt-4');
        echo html_writer::link(
            new moodle_url('/local/sis/coursemanager.php', [
                'action' => 'delete',
                'courseid' => $courseid,
                'confirm' => 1
            ]),
            'Yes, Delete This Course',
            ['class' => 'btn btn-danger mr-2']
        );
        echo html_writer::link(
            new moodle_url('/local/sis/coursemanager.php'),
            'Cancel',
            ['class' => 'btn btn-secondary']
        );
        echo html_writer::end_div();
        
        echo $OUTPUT->footer();
        return;
    }
    
    // Actually delete the course
    try {
        $course_name = $course->fullname;
        delete_course($courseid, false);
        
        \core\notification::success("Course '{$course_name}' deleted successfully!");
        
    } catch (moodle_exception $e) {
        \core\notification::error("Failed to delete course: " . $e->getMessage());
    }
    
    redirect(new moodle_url('/local/sis/coursemanager.php'));
}

function display_course_list() {
    global $DB, $OUTPUT, $sis_dashboard_url, $categoryid;
    
    echo $OUTPUT->header();
    echo $OUTPUT->heading('Course Management');
    
    // Navigation
    echo html_writer::start_div('mb-4');
    echo html_writer::link(
        $sis_dashboard_url,
        'Back to SIS Main Dashboard',
        ['class' => 'btn btn-secondary mr-2']
    );
    echo html_writer::end_div();
    
    // Get categories for dropdown
    $categories = core_course_category::make_categories_list();
    $category_options = [0 => '-- All Categories --'] + $categories;
    
    // Category selection form
    echo html_writer::start_tag('form', [
        'method' => 'get',
        'action' => new moodle_url('/local/sis/coursemanager.php'),
        'class' => 'form-inline mb-4'
    ]);
    echo html_writer::start_div('card');
    echo html_writer::start_div('card-body');
    echo html_writer::tag('h5', 'Category Selection', ['class' => 'card-title']);
    echo html_writer::start_div('form-row align-items-center');
    
    // Category dropdown
    echo html_writer::start_div('col-auto');
    echo html_writer::label('Select Category:', 'categoryselect', false, ['class' => 'mr-2']);
    echo html_writer::select($category_options, 'categoryid', $categoryid, false, ['id' => 'categoryselect', 'class' => 'form-control']);
    echo html_writer::end_div();
    
    // Filter button
    echo html_writer::start_div('col-auto');
    echo html_writer::empty_tag('input', [
        'type' => 'submit',
        'value' => 'Filter Courses',
        'class' => 'btn btn-primary mr-2'
    ]);
    echo html_writer::end_div();
    
    // Reset button
    echo html_writer::start_div('col-auto');
    echo html_writer::link(
        new moodle_url('/local/sis/coursemanager.php'),
        'Show All',
        ['class' => 'btn btn-outline-secondary']
    );
    echo html_writer::end_div();
    
    echo html_writer::end_div(); // form-row
    echo html_writer::end_div(); // card-body
    echo html_writer::end_div(); // card
    echo html_writer::end_tag('form');
    
    // Action buttons with selected category
    $selected_category_param = $categoryid ? ['categoryid' => $categoryid] : [];
    
    echo html_writer::start_div('mb-4');
    echo html_writer::link(
        new moodle_url('/local/sis/coursemanager.php', array_merge(['action' => 'create'], $selected_category_param)),
        'Create New Course (Custom Form)',
        ['class' => 'btn btn-primary mr-2']
    );
    
    // Moodle Course Creator button - only show if a category is selected
    if ($categoryid) {
        echo html_writer::link(
            new moodle_url('/local/sis/coursemanager.php', [
                'action' => 'moodlecreate',
                'categoryid' => $categoryid
            ]),
            'Use Moodle Course Creator in Selected Category',
            ['class' => 'btn btn-info mr-2']
        );
    } else {
        echo html_writer::link(
            new moodle_url('/local/sis/coursemanager.php', ['action' => 'moodlecreate']),
            'Use Moodle Course Creator',
            ['class' => 'btn btn-info mr-2']
        );
    }
    
    echo html_writer::link(
        new moodle_url('/course/index.php'),
        'View All Courses',
        ['class' => 'btn btn-secondary']
    );
    echo html_writer::end_div();
    
    // Get categories with courses (filtered if category selected)
    if ($categoryid) {
        // Show only selected category
        $category = core_course_category::get($categoryid, IGNORE_MISSING);
        if ($category) {
            $categories_to_display = [$category];
        } else {
            echo $OUTPUT->notification('Selected category not found.', 'notifyerror');
            echo $OUTPUT->footer();
            return;
        }
    } else {
        // Show all categories
        $categories_to_display = core_course_category::get_all();
    }
    
    if (empty($categories_to_display)) {
        echo $OUTPUT->notification('No categories found.', 'notifyinfo');
        echo $OUTPUT->footer();
        return;
    }
    
    foreach ($categories_to_display as $category) {
        $courses = $category->get_courses();
        
        echo html_writer::start_div('card mb-4');
        echo html_writer::start_div('card-header bg-light');
        echo html_writer::tag('h5', format_string($category->name) . " (" . count($courses) . " courses)");
        echo html_writer::end_div();
        
        echo html_writer::start_div('card-body');
        
        if (empty($courses)) {
            echo html_writer::tag('p', 'No courses in this category.', ['class' => 'text-muted']);
        } else {
            $table = new html_table();
            $table->head = [
                'Course Name',
                'Short Name',
                'ID Number',
                'Visible',
                'Actions'
            ];
            $table->attributes['class'] = 'table table-striped table-sm';
            
            foreach ($courses as $course) {
                $actions = [];
                
                // Edit action
                $actions[] = html_writer::link(
                    new moodle_url('/local/sis/coursemanager.php', [
                        'action' => 'edit',
                        'courseid' => $course->id
                    ]),
                    $OUTPUT->pix_icon('t/edit', 'Edit', 'moodle', ['class' => 'icon']) . ' Edit',
                    ['class' => 'btn btn-sm btn-outline-primary mr-1']
                );
                
                // View course
                $actions[] = html_writer::link(
                    new moodle_url('/course/view.php', ['id' => $course->id]),
                    $OUTPUT->pix_icon('i/course', 'View', 'moodle', ['class' => 'icon']) . ' View',
                    ['class' => 'btn btn-sm btn-outline-info mr-1']
                );
                
                // Moodle course settings
                $actions[] = html_writer::link(
                    new moodle_url('/course/edit.php', ['id' => $course->id]),
                    $OUTPUT->pix_icon('t/edit', 'Settings', 'moodle', ['class' => 'icon']) . ' Settings',
                    ['class' => 'btn btn-sm btn-outline-secondary mr-1']
                );
                
                // Delete action (only for non-system courses)
                if ($course->id > 1) {
                    $actions[] = html_writer::link(
                        new moodle_url('/local/sis/coursemanager.php', [
                            'action' => 'delete',
                            'courseid' => $course->id
                        ]),
                        $OUTPUT->pix_icon('t/delete', 'Delete', 'moodle', ['class' => 'icon']) . ' Delete',
                        ['class' => 'btn btn-sm btn-outline-danger']
                    );
                }
                
                $table->data[] = [
                    format_string($course->fullname),
                    s($course->shortname),
                    s($course->idnumber),
                    $course->visible ? html_writer::tag('span', 'Yes', ['class' => 'badge badge-success']) : 
                                     html_writer::tag('span', 'No', ['class' => 'badge badge-secondary']),
                    implode(' ', $actions)
                ];
            }
            
            echo html_writer::table($table);
        }
        
        echo html_writer::end_div(); // card-body
        echo html_writer::end_div(); // card
    }
    
    echo $OUTPUT->footer();
}