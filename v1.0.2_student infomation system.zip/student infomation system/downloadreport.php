<?php
// This file is part of the Student Information System plugin for Moodle.
// this is used to download reports
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version information for the Student Information System plugin
 *
 * @package    local_sis
 * @copyright  2025 NduksTech - https://facebook.com/ndukshub
 * @author     Nduka Akapti  (https://github.com/nduka4real)
 * @author     Ndukstech (https://www.youtube.com/@nduks-tech)
 * @author     https://www.linkedin.com/in/ndukaakpati/
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @details
 * Display Name: Student Information System
 * Description: A comprehensive system for managing student records, assessments, fees, and school operations.
 * Contact: https://github.com/nduka4real
 * Social: https://facebook.com/ndukshub
 */

// local/sis/downloadreport.php
require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/pdflib.php');
require_once(__DIR__ . '/viewresults.php'); // Include the main file to reuse its functions

require_login();

$categoryid = required_param('categoryid', PARAM_INT);
$userid     = required_param('userid', PARAM_INT);

// Check if the user is a valid student for this category
$category = $DB->get_record('course_categories', ['id' => $categoryid], '*', MUST_EXIST);
$students = get_class_students($categoryid);

if (!array_key_exists($userid, $students)) {
    // If user is not in the class, redirect back to the selection page
    redirect(new moodle_url('/local/sis/viewresults.php', ['categoryid' => $categoryid]), 'Student not found in this class.', 5);
}

// Gather all courses
$courses = $DB->get_records('course', ['category' => $categoryid], 'fullname ASC', 'id, fullname');

// Check DB structure
$columns = $DB->get_columns('local_sis_result');
$has_new_structure = array_key_exists('data', $columns);

// School info
$schoolname = 'NDUKS TECH';
$logopathweb = $CFG->wwwroot . '/local/sis/pix/logo.png';

// --- Overall ranking logic ---
$all_students = get_class_students($categoryid);
$overall_scores = [];
$courseids = array_keys($courses);
foreach ($all_students as $student_obj) {
    $total_sum = 0;
    $count = 0;
    foreach ($courseids as $courseid) {
        $res = $DB->get_record('local_sis_result', ['userid' => $student_obj->id, 'courseid' => $courseid]);
        if (is_numeric($res->total)) {
            $total_sum += (float)$res->total;
            $count++;
        }
    }
    if ($count > 0) {
        $overall_scores[$student_obj->id] = $total_sum / $count;
    }
}
$overall_positions = sis_rank_with_ties($overall_scores);
$class_size = count($overall_scores);
// --- End of overall ranking logic ---


// Generate individual student report
$student  = $DB->get_record('user', ['id' => $userid], '*', MUST_EXIST);
$overall_rank = $overall_positions[$student->id] ?? '-';
$contenthtml = generate_student_report_card($student, $category, $courses, $has_new_structure, $schoolname, $logopathweb, $overall_rank, $class_size);

// --- PDF Generation ---
$pdf = new pdf();
$pdf->SetTitle('Report Card - ' . fullname($student));
$pdf->SetMargins(10, 10, 10);
$pdf->AddPage();
// Pass the full HTML content, which includes all the inline styles, directly to writeHTML.
$pdf->writeHTML($contenthtml, true, false, true, false, '');
$pdf->Output('report_card_' . preg_replace('~[^a-z0-9_]+~i', '_', $student->username) . '.pdf', 'D');
exit;