<?php
// This file is part of the Student Information System plugin for Moodle.
// this maps quize 
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version information for the Student Information System plugin
 *
 * @package    local_sis
 * @copyright  2025 NduksTech - https://facebook.com/ndukshub
 * @author     Nduka Akapti  (https://github.com/nduka4real)
 * @author     Ndukstech (https://www.youtube.com/@nduks-tech)
 * @author     https://www.linkedin.com/in/ndukaakpati/
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @details
 * Display Name: Student Information System
 * Description: A comprehensive system for managing student records, assessments, fees, and school operations.
 * Contact: https://github.com/nduka4real
 * Social: https://facebook.com/ndukshub
 */

require_once(__DIR__ . '/../../config.php');
require_login();

$courseid = required_param('courseid', PARAM_INT);
$context = context_course::instance($courseid);
require_capability('mod/quiz:viewreports', $context);

$PAGE->set_url(new moodle_url('/local/sis/mapquiz.php', ['courseid' => $courseid]));
$PAGE->set_heading("Map Quizzes to Assessments");
$PAGE->set_title("Quiz Mapping");

echo $OUTPUT->header();

// Get all quizzes in this course
$quizzes = $DB->get_records('quiz', ['course' => $courseid], 'name ASC');
$options = ['0' => '--- None ---'];
foreach ($quizzes as $q) {
    $options[$q->id] = $q->name;
}

// Get existing mapping
$map = $DB->get_record('local_sis_quizmap', ['courseid' => $courseid]);

if ($_POST) {
    $data = new stdClass();
    $data->courseid = $courseid;
    $data->firstcaquiz = optional_param('firstcaquiz', 0, PARAM_INT) ?: null;
    $data->secondcaquiz = optional_param('secondcaquiz', 0, PARAM_INT) ?: null;
    $data->examquiz = optional_param('examquiz', 0, PARAM_INT) ?: null;

    if ($map) {
        $data->id = $map->id;
        $DB->update_record('local_sis_quizmap', $data);
    } else {
        $DB->insert_record('local_sis_quizmap', $data);
    }

    redirect(new moodle_url('/local/sis/enterca.php', ['courseid' => $courseid]), 'Quiz mapping updated!');
}

// Form
echo '<form method="post">';
echo html_writer::label('First CA Quiz', 'firstcaquiz') . html_writer::select($options, 'firstcaquiz', $map->firstcaquiz ?? 0);
echo '<br>';
echo html_writer::label('Second CA Quiz', 'secondcaquiz') . html_writer::select($options, 'secondcaquiz', $map->secondcaquiz ?? 0);
echo '<br>';
echo html_writer::label('Exam Quiz', 'examquiz') . html_writer::select($options, 'examquiz', $map->examquiz ?? 0);
echo '<br><br>';
echo '<button type="submit" class="btn btn-primary">Save Mapping</button>';
echo '</form>';

echo $OUTPUT->footer();
