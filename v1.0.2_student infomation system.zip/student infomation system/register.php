<?php
// This file is part of the Student Information System plugin for Moodle.
// this file is used for course registration
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version information for the Student Information System plugin
 *
 * @package    local_sis
 * @copyright  2025 NduksTech - https://facebook.com/ndukshub
 * @author     Nduka Akapti  (https://github.com/nduka4real)
 * @author     Ndukstech (https://www.youtube.com/@nduks-tech)
 * @author     https://www.linkedin.com/in/ndukaakpati/
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @details
 * Display Name: Student Information System
 * Description: A comprehensive system for managing student records, assessments, fees, and school operations.
 * Contact: https://github.com/nduka4real
 * Social: https://facebook.com/ndukshub
 */

// local/sis/register.php
require_once('../../config.php');
require_once($CFG->libdir . '/formslib.php');
require_once(__DIR__ . '/lib.php');

require_login();

// Check if current user is admin - prevent access if not
if (!is_siteadmin()) {
    throw new moodle_exception('nopermissions', 'error', '', 'Admin access required');
}

global $DB, $USER, $PAGE, $OUTPUT;

$categoryid = optional_param('categoryid', 0, PARAM_INT);
$studentid  = optional_param('studentid', 0, PARAM_INT);

// Additional protection: prevent admin from being selected as student
if ($studentid && is_siteadmin($studentid)) {
    throw new moodle_exception('admincannotbestudent', 'local_sis');
}

$PAGE->set_url(new moodle_url('/local/sis/register.php'));
$PAGE->set_context(context_system::instance());
$PAGE->set_title(get_string('studentregistration', 'local_sis'));
$PAGE->set_heading(get_string('studentregistration', 'local_sis'));

// Add JavaScript for master checkbox functionality
$PAGE->requires->js_init_code("
// Master checkbox functionality
function toggleAllCheckboxes(source) {
    var checkboxes = document.querySelectorAll('input.course-checkbox');
    for (var i = 0; i < checkboxes.length; i++) {
        checkboxes[i].checked = source.checked;
    }
    updateSelectedCount();
}

function updateSelectedCount() {
    var checkboxes = document.querySelectorAll('input.course-checkbox');
    var checkedCount = 0;
    for (var i = 0; i < checkboxes.length; i++) {
        if (checkboxes[i].checked) {
            checkedCount++;
        }
    }
    var totalCount = checkboxes.length;
    
    // Update counter
    var selectedCountElement = document.getElementById('selected-count');
    if (selectedCountElement) {
        selectedCountElement.textContent = checkedCount + ' of ' + totalCount + ' courses selected';
    }
    
    // Update master checkbox state
    var masterCheckbox = document.getElementById('master-checkbox');
    if (masterCheckbox) {
        if (checkedCount === 0) {
            masterCheckbox.checked = false;
            masterCheckbox.indeterminate = false;
        } else if (checkedCount === totalCount) {
            masterCheckbox.checked = true;
            masterCheckbox.indeterminate = false;
        } else {
            masterCheckbox.checked = false;
            masterCheckbox.indeterminate = true;
        }
    }
}

function selectAllCourses() {
    var checkboxes = document.querySelectorAll('input.course-checkbox');
    for (var i = 0; i < checkboxes.length; i++) {
        checkboxes[i].checked = true;
    }
    updateSelectedCount();
}

function deselectAllCourses() {
    var checkboxes = document.querySelectorAll('input.course-checkbox');
    for (var i = 0; i < checkboxes.length; i++) {
        checkboxes[i].checked = false;
    }
    updateSelectedCount();
}

function selectOnlyEnrolled() {
    var checkboxes = document.querySelectorAll('input.course-checkbox');
    for (var i = 0; i < checkboxes.length; i++) {
        var checkbox = checkboxes[i];
        var row = checkbox.closest('tr');
        var statusBadge = row.querySelector('.badge');
        if (statusBadge && statusBadge.textContent.includes('Enrolled')) {
            checkbox.checked = true;
        } else {
            checkbox.checked = false;
        }
    }
    updateSelectedCount();
}

// Initialize when page loads
document.addEventListener('DOMContentLoaded', function() {
    // Set up master checkbox
    var masterCheckbox = document.getElementById('master-checkbox');
    if (masterCheckbox) {
        masterCheckbox.addEventListener('change', function() {
            toggleAllCheckboxes(this);
        });
    }
    
    // Set up individual checkboxes
    var checkboxes = document.querySelectorAll('input.course-checkbox');
    for (var i = 0; i < checkboxes.length; i++) {
        checkboxes[i].addEventListener('change', updateSelectedCount);
    }
    
    // Set up action buttons
    var selectAllBtn = document.getElementById('select-all-btn');
    if (selectAllBtn) {
        selectAllBtn.addEventListener('click', selectAllCourses);
    }
    
    var deselectAllBtn = document.getElementById('deselect-all-btn');
    if (deselectAllBtn) {
        deselectAllBtn.addEventListener('click', deselectAllCourses);
    }
    
    var selectEnrolledBtn = document.getElementById('select-enrolled-btn');
    if (selectEnrolledBtn) {
        selectEnrolledBtn.addEventListener('click', selectOnlyEnrolled);
    }
    
    // Set up form confirmation
    var form = document.getElementById('course-registration-form');
    if (form) {
        form.addEventListener('submit', function(e) {
            if (!confirm('Are you sure you want to update the course enrollment for this student?')) {
                e.preventDefault();
            }
        });
    }
    
    // Initial count update
    updateSelectedCount();
});
");

// Navbar
$PAGE->navbar->add(get_string('pluginname', 'local_sis'), new moodle_url('/local/sis/index.php'));
$PAGE->navbar->add(get_string('studentregistration', 'local_sis'));

echo $OUTPUT->header();

// Dashboard button
echo html_writer::div(
    html_writer::link(
        new moodle_url('/local/sis/index.php'),
        get_string('backtodashboard', 'local_sis'),
        ['class' => 'btn btn-secondary mb-3']
    )
);

echo html_writer::start_div('container-fluid');

// Step flow
if (empty($categoryid)) {
    show_category_selection();
} elseif (empty($studentid)) {
    show_students_list($categoryid);
} else {
    // Final protection before showing student courses
    if (is_siteadmin($studentid)) {
        echo $OUTPUT->notification(get_string('admincannotbestudent', 'local_sis'), 'notifyproblem');
        echo html_writer::link(
            new moodle_url('/local/sis/register.php', ['categoryid' => $categoryid]),
            get_string('backtostudents', 'local_sis'),
            ['class' => 'btn btn-outline-secondary mb-3']
        );
    } else {
        show_student_courses($categoryid, $studentid);
    }
}

echo html_writer::end_div();
echo $OUTPUT->footer();

/**
 * Step 1: Show available categories
 */
function show_category_selection() {
    global $DB, $USER, $OUTPUT;

    echo $OUTPUT->heading(get_string('selectcategory', 'local_sis'));

    // Get all categories that have courses (not limited to current user's enrollments)
    $categories = $DB->get_records_sql("
        SELECT DISTINCT c.id, c.name, c.description
        FROM {course_categories} c
        JOIN {course} co ON co.category = c.id
        WHERE co.visible = 1
        ORDER BY c.name ASC
    ");

    if (empty($categories)) {
        echo $OUTPUT->notification(get_string('nocategories', 'local_sis'), 'notifyproblem');
        return;
    }

    echo html_writer::start_div('row');
    foreach ($categories as $category) {
        $url = new moodle_url('/local/sis/register.php', ['categoryid' => $category->id]);

        echo html_writer::start_div('col-md-4 mb-3');
        echo html_writer::start_div('card h-100');
        echo html_writer::start_div('card-body');
        echo html_writer::tag('h5', format_string($category->name), ['class' => 'card-title']);

        if (!empty($category->description)) {
            echo html_writer::tag('p', format_text($category->description, FORMAT_HTML), ['class' => 'card-text']);
        }

        // Updated query to explicitly exclude admin users
        $studentcount = $DB->count_records_sql("
            SELECT COUNT(DISTINCT u.id)
            FROM {user} u
            JOIN {user_enrolments} ue ON ue.userid = u.id
            JOIN {enrol} e ON e.id = ue.enrolid
            JOIN {course} c ON c.id = e.courseid
            JOIN {role_assignments} ra ON ra.userid = u.id
            JOIN {role} r ON r.id = ra.roleid
            WHERE c.category = ? 
            AND r.archetype = 'student' 
            AND u.deleted = 0
            AND u.id NOT IN (
                SELECT userid 
                FROM {role_assignments} ra2 
                JOIN {role} r2 ON r2.id = ra2.roleid 
                WHERE r2.archetype = 'admin'
            )
            AND u.id NOT IN (
                SELECT DISTINCT userid 
                FROM {role_assignments} ra3 
                JOIN {context} ctx ON ctx.id = ra3.contextid 
                WHERE ctx.contextlevel = 10 
                AND ra3.roleid IN (SELECT id FROM {role} WHERE archetype = 'admin')
            )
        ", [$category->id]);

        echo html_writer::tag('p', get_string('studentscount', 'local_sis', $studentcount), ['class' => 'text-muted']);
        echo html_writer::end_div();
        echo html_writer::start_div('card-footer');
        echo html_writer::link($url, get_string('viewstudents', 'local_sis'), ['class' => 'btn btn-primary btn-sm']);
        echo html_writer::end_div(); // footer
        echo html_writer::end_div(); // card
        echo html_writer::end_div(); // col
    }
    echo html_writer::end_div();
}

/**
 * Step 2: Show students in category
 */
function show_students_list($categoryid) {
    global $DB, $OUTPUT;

    $category = $DB->get_record('course_categories', ['id' => $categoryid], '*', MUST_EXIST);

    echo html_writer::div(
        html_writer::link(
            new moodle_url('/local/sis/register.php'),
            get_string('backtocategories', 'local_sis'),
            ['class' => 'btn btn-outline-secondary mb-3']
        )
    );

    echo $OUTPUT->heading(get_string('studentsin', 'local_sis', format_string($category->name)));

    // Get all user fields required by fullname() function using Moodle API
    $userfieldsapi = \core_user\fields::for_name();
    $allnamefields = $userfieldsapi->get_sql('u', false, '', '', false)->selects;
    
    // Enhanced query to exclude admin users more comprehensively
    $students = $DB->get_records_sql("
        SELECT DISTINCT u.id, $allnamefields, u.email, u.idnumber,
               u.lastaccess, COUNT(DISTINCT c.id) AS enrolled_courses
        FROM {user} u
        JOIN {user_enrolments} ue ON ue.userid = u.id
        JOIN {enrol} e ON e.id = ue.enrolid
        JOIN {course} c ON c.id = e.courseid
        JOIN {role_assignments} ra ON ra.userid = u.id
        JOIN {role} r ON r.id = ra.roleid
        WHERE c.category = ? 
        AND r.archetype = 'student' 
        AND u.deleted = 0
        AND u.id NOT IN (
            SELECT userid 
            FROM {role_assignments} ra2 
            JOIN {role} r2 ON r2.id = ra2.roleid 
            WHERE r2.archetype = 'admin'
        )
        AND u.id NOT IN (
            SELECT DISTINCT userid 
            FROM {role_assignments} ra3 
            JOIN {context} ctx ON ctx.id = ra3.contextid 
            WHERE ctx.contextlevel = 10 
            AND ra3.roleid IN (SELECT id FROM {role} WHERE archetype = 'admin')
        )
        GROUP BY u.id, u.email, u.idnumber, u.lastaccess
        ORDER BY u.lastname, u.firstname
    ", [$categoryid]);

    if (empty($students)) {
        echo $OUTPUT->notification(get_string('nostudents', 'local_sis'), 'notifyinfo');
        return;
    }

    // Search
    echo html_writer::start_tag('form', ['method' => 'get', 'class' => 'form-inline mb-4']);
    echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'categoryid', 'value' => $categoryid]);
    echo html_writer::empty_tag('input', [
        'type' => 'text',
        'name' => 'search',
        'value' => optional_param('search', '', PARAM_TEXT),
        'placeholder' => get_string('searchstudents', 'local_sis'),
        'class' => 'form-control mr-2',
        'style' => 'width:300px;'
    ]);
    echo html_writer::empty_tag('input', [
        'type' => 'submit',
        'value' => get_string('search', 'local_sis'),
        'class' => 'btn btn-primary'
    ]);
    echo html_writer::end_tag('form');

    $search = optional_param('search', '', PARAM_TEXT);
    if (!empty($search)) {
        $students = array_filter($students, function($s) use ($search) {
            return stripos($s->firstname, $search) !== false ||
                   stripos($s->lastname, $search) !== false ||
                   stripos($s->email, $search) !== false ||
                   stripos($s->idnumber, $search) !== false;
        });
    }

    $table = new html_table();
    $table->attributes['class'] = 'table table-striped table-bordered';
    $table->head = [
        get_string('student', 'local_sis'),
        get_string('idnumber', 'local_sis'),
        get_string('email', 'local_sis'),
        get_string('enrolledcourses', 'local_sis'),
        get_string('lastaccess', 'local_sis'),
        get_string('actions', 'local_sis')
    ];

    foreach ($students as $student) {
        // Final check - ensure student is not admin
        if (is_siteadmin($student->id)) {
            continue; // Skip admin users
        }
        
        $profile = new moodle_url('/user/profile.php', ['id' => $student->id]);
        $regurl  = new moodle_url('/local/sis/register.php', ['categoryid' => $categoryid, 'studentid' => $student->id]);
        $last    = $student->lastaccess ? userdate($student->lastaccess, get_string('strftimedatetimeshort', 'langconfig')) : get_string('never', 'local_sis');

        $table->data[] = [
            html_writer::link($profile, fullname($student)),
            s($student->idnumber),
            s($student->email),
            $student->enrolled_courses,
            $last,
            html_writer::link($regurl, get_string('managecourses', 'local_sis'), ['class' => 'btn btn-primary btn-sm'])
        ];
    }

    echo html_writer::table($table);
}

/**
 * Step 3: Show student course registration with master checkbox
 */
function show_student_courses($categoryid, $studentid) {
    global $DB, $OUTPUT;

    $category = $DB->get_record('course_categories', ['id' => $categoryid], '*', MUST_EXIST);
    $student  = $DB->get_record('user', ['id' => $studentid, 'deleted' => 0], '*', MUST_EXIST);

    // Final protection - ensure student is not admin
    if (is_siteadmin($studentid)) {
        throw new moodle_exception('admincannotbestudent', 'local_sis');
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && confirm_sesskey()) {
        handle_course_registration($categoryid, $studentid);
    }

    echo html_writer::div(
        html_writer::link(new moodle_url('/local/sis/register.php', ['categoryid' => $categoryid]),
            get_string('backtostudents', 'local_sis'),
            ['class' => 'btn btn-outline-secondary mb-3']
        )
    );

    echo $OUTPUT->heading(get_string('courseregistrationfor', 'local_sis', fullname($student)));
    echo html_writer::tag('p', get_string('category', 'local_sis') . ': ' . format_string($category->name), ['class' => 'text-muted']);

    $courses = $DB->get_records('course', ['category' => $categoryid, 'visible' => 1], 'fullname ASC');
    if (empty($courses)) {
        echo $OUTPUT->notification(get_string('nocoursesincategory', 'local_sis'), 'notifyproblem');
        return;
    }

    $enrolled = $DB->get_records_sql("
        SELECT c.id
        FROM {course} c
        JOIN {enrol} e ON e.courseid = c.id
        JOIN {user_enrolments} ue ON ue.enrolid = e.id
        WHERE c.category = ? AND ue.userid = ? AND c.visible = 1
    ", [$categoryid, $studentid]);

    $enrolledids = array_keys($enrolled);

    echo html_writer::start_tag('form', ['method' => 'post', 'id' => 'course-registration-form']);
    echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey()]);
    echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'categoryid', 'value' => $categoryid]);
    echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'studentid', 'value' => $studentid]);

    // Selection summary
    echo html_writer::start_div('alert alert-info mb-3 d-flex justify-content-between align-items-center');
    echo html_writer::tag('span', '<strong>Course Selection:</strong> Check the boxes to enroll student in courses', ['style' => 'font-size: 14px;']);
    echo html_writer::tag('span', '<span id="selected-count">0 of ' . count($courses) . ' courses selected</span>', [
        'class' => 'badge badge-primary badge-pill',
        'style' => 'font-size: 14px;'
    ]);
    echo html_writer::end_div();

    $table = new html_table();
    $table->attributes['class'] = 'table table-striped table-hover';
    $table->head = [
        // Master checkbox column
        html_writer::div(
            html_writer::empty_tag('input', [
                'type' => 'checkbox',
                'id' => 'master-checkbox',
                'title' => 'Select/Deselect All Courses'
            ]) . ' ' . html_writer::tag('span', 'All', ['style' => 'font-weight: bold;']),
            'text-center'
        ),
        get_string('course', 'local_sis'),
        get_string('courseshortname', 'local_sis'),
        get_string('enrollmentstatus', 'local_sis'),
        'Actions'
    ];

    foreach ($courses as $c) {
        $isenrolled = in_array($c->id, $enrolledids);
        $status = $isenrolled
            ? html_writer::span(get_string('enrolled', 'local_sis'), 'badge badge-success')
            : html_writer::span(get_string('notenrolled', 'local_sis'), 'badge badge-secondary');

        $checkbox = html_writer::empty_tag('input', [
            'type' => 'checkbox',
            'name' => 'courses['.$c->id.']',
            'value' => '1',
            'class' => 'course-checkbox',
            'checked' => $isenrolled
        ]);

        // Action buttons
        $actions = html_writer::div(
            html_writer::link(
                new moodle_url('/course/view.php', ['id' => $c->id]),
                'View Course',
                ['class' => 'btn btn-outline-info btn-sm', 'target' => '_blank']
            ),
            'btn-group'
        );

        $table->data[] = [
            html_writer::div($checkbox, 'text-center'),
            html_writer::div(format_string($c->fullname), 'font-weight-bold'),
            html_writer::div(s($c->shortname), 'text-muted small'),
            $status,
            $actions
        ];
    }

    echo html_writer::table($table);

    // Action buttons
    echo html_writer::start_div('card mt-4');
    echo html_writer::start_div('card-header bg-primary text-white');
    echo html_writer::tag('h5', 'Course Registration Actions', ['class' => 'mb-0']);
    echo html_writer::end_div();
    echo html_writer::start_div('card-body');
    
    echo html_writer::start_div('row');
    
    // Left side - Quick actions
    echo html_writer::start_div('col-md-6');
    echo html_writer::tag('h6', 'Quick Actions:', ['class' => 'mb-3']);
    
    echo html_writer::start_div('btn-group-vertical w-100');
    echo html_writer::tag('button', 'Select All Courses', [
        'type' => 'button',
        'class' => 'btn btn-outline-primary btn-sm mb-2',
        'id' => 'select-all-btn'
    ]);
    echo html_writer::tag('button', 'Deselect All Courses', [
        'type' => 'button',
        'class' => 'btn btn-outline-secondary btn-sm mb-2',
        'id' => 'deselect-all-btn'
    ]);
    echo html_writer::tag('button', 'Select Only Enrolled', [
        'type' => 'button',
        'class' => 'btn btn-outline-info btn-sm',
        'id' => 'select-enrolled-btn'
    ]);
    echo html_writer::end_div(); // btn-group-vertical
    echo html_writer::end_div(); // col-md-6
    
    // Right side - Save button
    echo html_writer::start_div('col-md-6 text-right');
    echo html_writer::tag('h6', 'Save Changes:', ['class' => 'mb-3']);
    echo html_writer::empty_tag('input', [
        'type' => 'submit',
        'name' => 'save',
        'value' => get_string('savechanges', 'local_sis'),
        'class' => 'btn btn-success btn-lg px-5'
    ]);
    echo html_writer::end_div(); // col-md-6
    
    echo html_writer::end_div(); // row
    echo html_writer::end_div(); // card-body
    echo html_writer::end_div(); // card

    echo html_writer::end_tag('form');
}

/**
 * Handle save
 */
function handle_course_registration($categoryid, $studentid) {
    global $DB, $OUTPUT;

    // Protection in save handler
    if (is_siteadmin($studentid)) {
        echo $OUTPUT->notification(get_string('admincannotbestudent', 'local_sis'), 'notifyproblem');
        return;
    }

    $selected = optional_param_array('courses', [], PARAM_INT);
    $courses  = $DB->get_records('course', ['category' => $categoryid, 'visible' => 1]);

    $enrolled = 0;
    $unenrolled = 0;

    foreach ($courses as $c) {
        $should = isset($selected[$c->id]);
        $is     = is_user_enrolled_in_course($studentid, $c->id);

        if ($should && !$is && enroll_student_in_course($studentid, $c->id)) {
            $enrolled++;
        } elseif (!$should && $is && unenroll_student_from_course($studentid, $c->id)) {
            $unenrolled++;
        }
    }

    $msg = '';
    if ($enrolled > 0) {
        $msg .= get_string('studentsenrolled', 'local_sis', $enrolled) . ' ';
    }
    if ($unenrolled > 0) {
        $msg .= get_string('studentsunenrolled', 'local_sis', $unenrolled);
    }
    if (!$msg) {
        $msg = get_string('nochangesmade', 'local_sis');
    }

    echo $OUTPUT->notification($msg, 'notifysuccess');
}

/**
 * Check if user is enrolled in course
 */
function is_user_enrolled_in_course($userid, $courseid) {
    global $DB;
    
    return $DB->record_exists_sql("
        SELECT 1
        FROM {user_enrolments} ue
        JOIN {enrol} e ON e.id = ue.enrolid
        WHERE ue.userid = ? AND e.courseid = ?
    ", [$userid, $courseid]);
}

/**
 * Enroll student in course
 */
function enroll_student_in_course($userid, $courseid) {
    global $DB;
    
    // Final protection - never enroll admin users
    if (is_siteadmin($userid)) {
        return false;
    }
    
    // Get manual enrollment instance
    $enrol = $DB->get_record('enrol', [
        'courseid' => $courseid, 
        'enrol' => 'manual'
    ], '*', IGNORE_MISSING);
    
    if (!$enrol) {
        return false;
    }
    
    // Check if already enrolled
    if (is_user_enrolled_in_course($userid, $courseid)) {
        return true;
    }
    
    // Get student role
    $student_role = $DB->get_record('role', ['archetype' => 'student'], '*', MUST_EXIST);
    
    // Enroll user
    $user_enrolment = new stdClass();
    $user_enrolment->enrolid = $enrol->id;
    $user_enrolment->userid = $userid;
    $user_enrolment->timestart = time();
    $user_enrolment->timecreated = time();
    $user_enrolment->timemodified = time();
    
    $enrolment_id = $DB->insert_record('user_enrolments', $user_enrolment);
    
    if ($enrolment_id) {
        // Assign student role
        $context = context_course::instance($courseid);
        role_assign($student_role->id, $userid, $context->id);
        return true;
    }
    
    return false;
}

/**
 * Unenroll student from course
 */
function unenroll_student_from_course($userid, $courseid) {
    global $DB;
    
    // Protection - though this should never be called for admin users
    if (is_siteadmin($userid)) {
        return false;
    }
    
    // Get enrollment record
    $sql = "SELECT ue.*, e.enrol
            FROM {user_enrolments} ue
            JOIN {enrol} e ON e.id = ue.enrolid
            WHERE ue.userid = ? AND e.courseid = ?";
    
    $enrolments = $DB->get_records_sql($sql, [$userid, $courseid]);
    
    $success = true;
    foreach ($enrolments as $enrolment) {
        // Remove role assignments
        $context = context_course::instance($courseid);
        role_unassign_all([
            'userid' => $userid, 
            'contextid' => $context->id,
            'component' => 'enrol_' . $enrolment->enrol,
            'itemid' => $enrolment->enrolid
        ]);
        
        // Remove enrollment
        $success = $success && $DB->delete_records('user_enrolments', ['id' => $enrolment->id]);
    }
    
    return $success;
}