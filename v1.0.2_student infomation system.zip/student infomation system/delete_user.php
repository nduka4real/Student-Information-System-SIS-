<?php
// moodle/local/sis/delete_user.php

require_once('../../config.php');
require_once($CFG->libdir . '/adminlib.php');

require_login();
require_capability('moodle/site:config', context_system::instance());

$PAGE->set_url(new moodle_url('/local/sis/delete_user.php'));
$PAGE->set_context(context_system::instance());
$PAGE->set_title(get_string('deleteusers', 'local_sis'));
$PAGE->set_heading(get_string('deleteusers', 'local_sis'));

// Initialize variables
$message = "";
$users = [];
$selected_category = optional_param('category', 'all', PARAM_ALPHA);
$delete_user = optional_param('delete_user', 0, PARAM_INT);
$user_category = optional_param('user_category', '', PARAM_ALPHA);

// Handle user deletion
if ($delete_user && confirm_sesskey()) {
    $user_id = required_param('user_id', PARAM_INT);
    
    try {
        // Start transaction
        $transaction = $DB->start_delegated_transaction();
        
        // Delete exam records from quiz attempts and other result tables
        // Moodle has multiple tables that store user activity data
        
        // Delete quiz attempts
        $DB->delete_records('quiz_attempts', array('userid' => $user_id));
        $DB->delete_records('quiz_grades', array('userid' => $user_id));
        
        // Delete assignment submissions
        $DB->delete_records('assign_submission', array('userid' => $user_id));
        $DB->delete_records('assign_grades', array('userid' => $user_id));
        
        // Delete course completions
        $DB->delete_records('course_completions', array('userid' => $user_id));
        
        // Delete grades
        $DB->delete_records('grade_grades', array('userid' => $user_id));
        
        // Delete log data
        $DB->delete_records('logstore_standard_log', array('userid' => $user_id));
        
        // Finally delete the user based on category or completely
        if ($user_category === 'student' || $user_category === 'teacher') {
            // For Moodle, we typically update user status rather than delete completely
            // But if you want full deletion:
            $user = $DB->get_record('user', array('id' => $user_id));
            if ($user && $user->id != $USER->id && $user->id != 1) { // Don't delete current user or admin
                delete_user($user);
                $message = get_string('userdeleted', 'local_sis');
            } else {
                $message = get_string('cannoteditsiteadmin', 'local_sis');
            }
        }
        
        // Commit transaction
        $transaction->allow_commit();
        
    } catch (Exception $e) {
        $transaction->rollback($e);
        $message = get_string('deleteerror', 'local_sis') . $e->getMessage();
    }
}

// Fetch users based on selected category
if ($selected_category === 'all') {
    // Fetch all users (excluding guest and admin for safety)
    $users = $DB->get_records_sql("
        SELECT u.id, u.username, u.email, u.firstname, u.lastname, u.suspended, 
               (CASE 
                   WHEN EXISTS (SELECT 1 FROM {role_assignments} ra 
                               JOIN {context} ctx ON ra.contextid = ctx.id 
                               WHERE ra.userid = u.id AND ctx.contextlevel = 50 
                               AND ra.roleid IN (SELECT id FROM {role} WHERE shortname = 'editingteacher'))
                   THEN 'teacher'
                   WHEN u.id = 1 THEN 'admin'
                   ELSE 'student'
                END) as category
        FROM {user} u
        WHERE u.deleted = 0 AND u.id > 2
        ORDER BY u.firstname, u.lastname
    ");
} else {
    // Fetch users by specific role/category
    switch($selected_category) {
        case 'student':
            $users = $DB->get_records_sql("
                SELECT u.id, u.username, u.email, u.firstname, u.lastname, u.suspended, 'student' as category
                FROM {user} u
                WHERE u.deleted = 0 AND u.id > 2 
                AND NOT EXISTS (
                    SELECT 1 FROM {role_assignments} ra 
                    JOIN {context} ctx ON ra.contextid = ctx.id 
                    WHERE ra.userid = u.id AND ctx.contextlevel = 50 
                    AND ra.roleid IN (SELECT id FROM {role} WHERE shortname IN ('editingteacher', 'manager'))
                )
                ORDER BY u.firstname, u.lastname
            ");
            break;
            
        case 'teacher':
            $users = $DB->get_records_sql("
                SELECT u.id, u.username, u.email, u.firstname, u.lastname, u.suspended, 'teacher' as category
                FROM {user} u
                JOIN {role_assignments} ra ON u.id = ra.userid
                JOIN {context} ctx ON ra.contextid = ctx.id
                JOIN {role} r ON ra.roleid = r.id
                WHERE u.deleted = 0 AND u.id > 2 
                AND ctx.contextlevel = 50 
                AND r.shortname = 'editingteacher'
                ORDER BY u.firstname, u.lastname
            ");
            break;
            
        case 'admin':
            $users = $DB->get_records_sql("
                SELECT u.id, u.username, u.email, u.firstname, u.lastname, u.suspended, 'admin' as category
                FROM {user} u
                JOIN {role_assignments} ra ON u.id = ra.userid
                JOIN {context} ctx ON ra.contextid = ctx.id
                JOIN {role} r ON ra.roleid = r.id
                WHERE u.deleted = 0 AND u.id > 2 
                AND ctx.contextlevel = 50 
                AND r.shortname = 'manager'
                ORDER BY u.firstname, u.lastname
            ");
            break;
    }
}

echo $OUTPUT->header();

// Display messages
if ($message) {
    $message_type = (strpos($message, 'error') !== false) ? \core\output\notification::NOTIFY_ERROR : \core\output\notification::NOTIFY_SUCCESS;
    \core\notification::add($message, $message_type);
}
?>

<div class="container-fluid">
    <h2><?php echo get_string('deleteusers', 'local_sis'); ?></h2>
    
    <!-- Filter Section -->
    <div class="card mb-4">
        <div class="card-body">
            <h5 class="card-title"><?php echo get_string('filterusers', 'local_sis'); ?></h5>
            <form method="GET" action="<?php echo $PAGE->url; ?>">
                <div class="form-group">
                    <label for="category"><?php echo get_string('usercategory', 'local_sis'); ?>:</label>
                    <select name="category" id="category" class="form-control" onchange="this.form.submit()">
                        <option value="all" <?php echo $selected_category === 'all' ? 'selected' : ''; ?>>
                            <?php echo get_string('allusers', 'local_sis'); ?>
                        </option>
                        <option value="student" <?php echo $selected_category === 'student' ? 'selected' : ''; ?>>
                            <?php echo get_string('students', 'local_sis'); ?>
                        </option>
                        <option value="teacher" <?php echo $selected_category === 'teacher' ? 'selected' : ''; ?>>
                            <?php echo get_string('teachers', 'local_sis'); ?>
                        </option>
                        <option value="admin" <?php echo $selected_category === 'admin' ? 'selected' : ''; ?>>
                            <?php echo get_string('administrators', 'local_sis'); ?>
                        </option>
                    </select>
                </div>
            </form>
        </div>
    </div>

    <!-- Users Table -->
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">
                <?php echo get_string('userlist', 'local_sis'); ?> 
                (<?php 
                    if ($selected_category === 'all') {
                        echo get_string('allusers', 'local_sis');
                    } else {
                        echo get_string($selected_category . 's', 'local_sis');
                    }
                ?>)
            </h5>
            
            <?php if (empty($users)): ?>
                <div class="alert alert-info">
                    <?php echo get_string('nousersfound', 'local_sis'); ?>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead class="thead-dark">
                            <tr>
                                <th><?php echo get_string('id', 'local_sis'); ?></th>
                                <th><?php echo get_string('username', 'local_sis'); ?></th>
                                <th><?php echo get_string('name', 'local_sis'); ?></th>
                                <th><?php echo get_string('email', 'local_sis'); ?></th>
                                <th><?php echo get_string('category', 'local_sis'); ?></th>
                                <th><?php echo get_string('status', 'local_sis'); ?></th>
                                <th><?php echo get_string('actions', 'local_sis'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $user): ?>
                            <tr>
                                <td><?php echo $user->id; ?></td>
                                <td><?php echo s($user->username); ?></td>
                                <td><?php echo s($user->firstname . ' ' . $user->lastname); ?></td>
                                <td><?php echo s($user->email); ?></td>
                                <td>
                                    <span class="badge 
                                        <?php echo $user->category === 'teacher' ? 'badge-warning' : 
                                               ($user->category === 'admin' ? 'badge-danger' : 'badge-primary'); ?>">
                                        <?php echo get_string($user->category, 'local_sis'); ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="badge <?php echo $user->suspended ? 'badge-secondary' : 'badge-success'; ?>">
                                        <?php echo $user->suspended ? get_string('suspended', 'local_sis') : get_string('active', 'local_sis'); ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if ($user->id != $USER->id && $user->id != 1): ?>
                                    <form method="POST" action="<?php echo $PAGE->url; ?>">
                                        <input type="hidden" name="user_id" value="<?php echo $user->id; ?>">
                                        <input type="hidden" name="user_category" value="<?php echo $user->category; ?>">
                                        <input type="hidden" name="sesskey" value="<?php echo sesskey(); ?>">
                                        <button type="submit" name="delete_user" value="1" 
                                                class="btn btn-danger btn-sm"
                                                onclick="return confirm('<?php echo get_string('deleteconfirm', 'local_sis'); ?>');">
                                            <?php echo get_string('delete', 'local_sis'); ?>
                                        </button>
                                    </form>
                                    <?php else: ?>
                                    <span class="text-muted"><?php echo get_string('protected', 'local_sis'); ?></span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="mt-3">
        <a href="<?php echo new moodle_url('/admin/user.php'); ?>" class="btn btn-primary">
            <?php echo get_string('backtousermanagement', 'local_sis'); ?>
        </a>
        <a href="<?php echo new moodle_url('/admin/search.php'); ?>" class="btn btn-secondary">
            <?php echo get_string('backtoadmin', 'local_sis'); ?>
        </a>
    </div>
</div>

<?php
echo $OUTPUT->footer();
?>