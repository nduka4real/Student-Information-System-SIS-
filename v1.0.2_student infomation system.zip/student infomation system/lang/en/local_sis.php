<?php
// This file is part of the Student Information System plugin for Moodle.
// this file is used to manage all language strings
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version information for the Student Information System plugin
 *
 * @package    local_sis
 * @copyright  2025 NduksTech - https://facebook.com/ndukshub
 * @author     Nduka Akapti  (https://github.com/nduka4real)
 * @author     Ndukstech (https://www.youtube.com/@nduks-tech)
 * @author     https://www.linkedin.com/in/ndukaakpati/
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @details
 * Display Name: Student Information System
 * Description: A comprehensive system for managing student records, assessments, fees, and school operations.
 * Contact: https://github.com/nduka4real
 * Social: https://facebook.com/ndukshub
 */

// This file is part of your Moodle plugin

defined('MOODLE_INTERNAL') || die();

/**
 * Language strings for the Course SIS plugin
 */

$string['pluginname'] = 'Student Information System';
$string['enterca'] = 'Enter CA';
$string['viewresults'] = 'View Results';

$string['coursesis'] = 'Course SIS';
$string['managecomments'] = 'Manage Comments';
$string['manageca'] = 'Manage CA Configuration';
$string['enterscores'] = 'Enter Subject Scores';
$string['settings'] = 'Settings';
$string['currentsession'] = 'Current Session';
$string['currentterm'] = 'Current Term';
$string['firstterm'] = 'First Term';
$string['secondterm'] = 'Second Term';
$string['thirdterm'] = 'Third Term';
$string['cumulativeaverage'] = 'Calculate Cumulative Average for Third Term';

// Form strings
$string['sessionname'] = 'Session Name';
$string['termname'] = 'Term Name';
$string['setasdefault'] = 'Set as default session/term';
$string['calculatecumulative'] = 'Calculate Cumulative Average';
$string['cumulativeinfo'] = 'Check this box if this term should calculate cumulative average (typically for third term)';
$string['savesessionterm'] = 'Save Session/Term';
$string['sessiontermexists'] = 'This session/term combination already exists!';
$string['required'] = 'Required field';
$string['maximumchars'] = 'Maximum {$a} characters';

$string['myresults'] = 'My Results';

// Help strings
$string['sessionname_help'] = 'Enter the academic session name (e.g., 2023/2024)';
$string['termname_help'] = 'Enter the term name (e.g., First Term, Second Term, Third Term)';
$string['isdefault_help'] = 'Set this as the current active session/term';
$string['calculatecumulative_help'] = 'If checked, this term will calculate cumulative average including previous terms';

// Additional strings (previously missing)
$string['choosestudent'] = 'Choose a student';
$string['viewstudentreport'] = 'View student report';
$string['viewallclassresults'] = 'View all class results';

$string['sis:view'] = 'Access the SIS plugin';
$string['sis:manage'] = 'Manage SIS plugin settings';
$string['sis:viewresults'] = 'View student results';

// Registration module strings
$string['studentregistration'] = 'Student Registration';
$string['backtodashboard'] = 'Back to Dashboard';
$string['selectcategory'] = 'Select Category';
$string['studentscount'] = '{$a} students';
$string['viewstudents'] = 'View Students';
$string['nocategories'] = 'No categories available';
$string['backtocategories'] = 'Back to Categories';
$string['studentsin'] = 'Students in {$a}';
$string['nostudents'] = 'No students found in this category';
$string['searchstudents'] = 'Search students...';
$string['search'] = 'Search';
$string['student'] = 'Student';
$string['idnumber'] = 'ID Number';
$string['email'] = 'Email';
$string['enrolledcourses'] = 'Enrolled Courses';
$string['lastaccess'] = 'Last Access';
$string['actions'] = 'Actions';
$string['never'] = 'Never';
$string['managecourses'] = 'Manage Courses';
$string['backtostudents'] = 'Back to Students List';
$string['courseregistrationfor'] = 'Course Registration for {$a}';
$string['category'] = 'Category';
$string['nocoursesincategory'] = 'No courses available in this category';
$string['availablecourses'] = 'Available Courses';
$string['checkboxtoenroll'] = 'Check the boxes to enroll student in courses';
$string['enroll'] = 'Enroll';
$string['course'] = 'Course';
$string['courseshortname'] = 'Short Name';
$string['enrollmentstatus'] = 'Status';
$string['enrolled'] = 'Enrolled';
$string['notenrolled'] = 'Not Enrolled';
$string['savechanges'] = 'Save Changes';
$string['studentsenrolled'] = 'Enrolled in {$a} course(s)';
$string['studentsunenrolled'] = 'Unenrolled from {$a} course(s)';
$string['nochangesmade'] = 'No changes made';

// Quiz management
$string['managequiz'] = 'Manage Quiz';
$string['backtodashboard'] = 'Back to Dashboard';
$string['selectcategory'] = 'Select Class/Category';
$string['selectcourse'] = 'Select Subject in ';
$string['managequizfor'] = 'Manage Quiz for ';
$string['createquiz'] = 'Create Quiz';
$string['createnewquiz'] = 'Create New Quiz';
$string['createquizfor'] = 'Create Quiz for ';
$string['quizname'] = 'Quiz Name';
$string['quizdescription'] = 'Description';
$string['uploadquestions'] = 'Upload Questions (TXT/DOCX)';
$string['markperquestion'] = 'Mark per Question';
$string['questiontype'] = 'Question Type';
$string['essayquestion'] = 'Essay Question';
$string['shortanswerquestion'] = 'Short Answer Question';
$string['viewquiz'] = 'View Quiz';
$string['existingquizzes'] = 'Existing Quizzes';
$string['totalquestions'] = '{$a} questions';
$string['quizcreated'] = 'Quiz created: ';
$string['questionsadded'] = '{$a} questions added successfully';
$string['errorcreatingquiz'] = 'Error creating quiz: ';
$string['nocategoriesfound'] = 'No categories found';
$string['nocoursesincategory'] = 'No courses in this category';

/**
 * Language strings for local_sis (Student Information System)
 */

// --- General ---
$string['managequiz'] = 'Manage Quizzes';
$string['backtodashboard'] = 'Back to Dashboard';

// --- Navigation/Flow ---
$string['selectcategory'] = 'Select Class/Category';
$string['selectcourse'] = 'Select Subject/Course in: ';
$string['nocategoriesfound'] = 'No categories found.';
$string['nocoursesincategory'] = 'No courses found in this category.';
$string['managequizfor'] = 'Quiz Management for: ';
$string['existingquizzes'] = 'Existing Quizzes';
$string['totalquestions'] = 'Total Questions: {$a}';
$string['createquiz'] = 'Create New Quiz';
$string['createnewquiz'] = 'Create New Quiz';
$string['nopermission'] = 'You do not have permission to access this page.';

// --- Form Fields ---
$string['quizname'] = 'Quiz Name';
$string['quizdescription'] = 'Quiz Description';
$string['uploadquestions'] = 'Upload Questions File (Aiken/GIFT/Moodle XML)';
$string['markperquestion'] = 'Default Mark per Question';
$string['gradelimit'] = 'Maximum Quiz Grade';

// --- Notifications/Errors ---
$string['quizcreated'] = 'Quiz instance created: {$a}';
$string['questionsimported'] = 'Successfully imported {$a} questions into the course Question Bank.';
$string['importerror'] = 'Question import failed: {$a}';
$string['viewquiz'] = 'View Quiz';
$string['nextsteps'] = 'Questions were saved to the course question bank. Please use the button below to add them to your new quiz structure.';
$string['addquestionsnow'] = 'Add Questions to Quiz';
$string['errorcreatingquiz'] = 'An error occurred while creating the quiz: ';

// Manage quiz
$string['quizmanagement'] = 'Quiz Management';
$string['createquiz'] = 'Create Quiz';
$string['managequizzes'] = 'Manage Quizzes';
$string['uploadquestions'] = 'Upload Questions';
$string['quizname'] = 'Quiz Name';
$string['quizintro'] = 'Quiz Description';
$string['defaultmark'] = 'Default Mark';
$string['timelimit'] = 'Time Limit';
$string['attemptsallowed'] = 'Attempts Allowed';
$string['questions'] = 'Questions';
$string['selectcategory'] = 'Select Category';
$string['selectcourse'] = 'Select Course';
$string['choosecategory'] = 'Choose a category...';
$string['choosecourse'] = 'Choose a course...';
$string['existingquizzes'] = 'Existing Quizzes';
$string['manage'] = 'Manage';
$string['delete'] = 'Delete';
$string['deleteconfirm'] = 'Are you sure you want to delete this quiz?';
$string['quizcreated'] = 'Quiz "{$a}" created successfully!';
$string['quizdeleted'] = 'Quiz deleted successfully!';
$string['quiznotfound'] = 'Quiz not found!';
$string['questionsadded'] = '{$a} questions added successfully!';
$string['selectquiztomanage'] = 'Select a quiz from the left to manage questions';
$string['questionformathelp'] = 'Enter questions in the following format. Separate questions with a blank line:';
$string['questionformatexample'] = 'Question Format Example';
$string['required'] = 'This field is required';
$string['next'] = 'Next';
$string['managequiz'] = 'Manage Quiz';
$string['unlimited'] = 'Unlimited';

$string['class'] = 'Class';
$string['session'] = 'Session';
$string['term'] = 'Term';
$string['open_dashboard'] = 'Open SIS Dashboard';
$string['view_results'] = 'View Results';
$string['view_my_results'] = 'View My Results';

// Specific string for the viewresults page header/selector
$string['selectclassterm'] = 'Select Class, Session, and Term';

$string['studentportal'] = 'Student Portal';
$string['myresults'] = 'My Results';
$string['sisadmin'] = 'SIS Admin';
$string['sisdashboard'] = 'SIS Dashboard';
$string['schoolsettings'] = 'School Settings';
$string['sessionterms'] = 'Session & Terms';

// Self enrollment strings
$string['selfenrollment'] = 'Self Enrollment';
$string['mycourseregistration'] = 'My Course Registration';
$string['selectyourcategory'] = 'Select Your Class/Category';
$string['coursesavailable'] = '{$a} courses available';
$string['viewcourses'] = 'View Courses';
$string['nocategoriesfound'] = 'No categories found for your account. Please contact administrator.';
$string['nocategoryselected'] = 'No category selected.';
$string['noaccesstocategory'] = 'You do not have access to this category.';
$string['coursesin'] = 'Courses in {$a}';
$string['selectcoursestoenroll'] = 'Select the courses you want to enroll in by checking the boxes below.';
$string['courseselection'] = 'Course Selection';
$string['checkboxtoenroll'] = 'Check the box to enroll in a course';
$string['selectdeselectall'] = 'Select/Deselect All Courses';
$string['all'] = 'All';
$string['description'] = 'Description';
$string['enrollmentguidelines'] = 'Please note: Some courses may have prerequisites or enrollment limits. If you encounter issues enrolling, please contact your administrator.';
$string['important'] = 'Important';
$string['enrollmentactions'] = 'Enrollment Actions';
$string['quickactions'] = 'Quick Actions';
$string['selectallcourses'] = 'Select All Courses';
$string['deselectallcourses'] = 'Deselect All Courses';
$string['selectonlyenrolled'] = 'Select Only Enrolled';
$string['saveenrollment'] = 'Save Enrollment';
$string['viewcourse'] = 'View Course';
$string['successenrolled'] = 'Successfully enrolled in {$a} courses.';
$string['successunenrolled'] = 'Successfully unenrolled from {$a} courses.';
$string['errorenrolling'] = 'Error enrolling in course: {$a}';
$string['errorunenrolling'] = 'Error unenrolling from course: {$a}';
$string['admincannotuseselfenroll'] = 'Admin users cannot use self-enrollment. Please use the admin registration system.';

// ==================== PAYMENT SYSTEM STRINGS ====================

// General Payment Strings
$string['paymentsettings'] = 'Payment Settings';
$string['paymentprocessing'] = 'Payment Processing';
$string['paymentverification'] = 'Payment Verification';
$string['paymentsettingssaved'] = 'Payment settings saved successfully';
$string['configuration'] = 'Configuration';
$string['enable'] = 'Enable';
$string['testmode'] = 'Test Mode';
$string['publickey'] = 'Public Key';
$string['secretkey'] = 'Secret Key';
$string['clientid'] = 'Client ID';
$string['clientsecret'] = 'Client Secret';
$string['currency'] = 'Currency';
$string['enterpublickey'] = 'Enter public key';
$string['entersecretkey'] = 'Enter secret key';
$string['enterclientid'] = 'Enter client ID';
$string['enterclientsecret'] = 'Enter client secret';
$string['paynow'] = 'Pay Now';
$string['coursepayment'] = 'Course Payment';
$string['paymentamount'] = 'Payment Amount';
$string['paymentreference'] = 'Reference';
$string['paymentsuccess'] = 'Payment Successful!';
$string['paymentfailed'] = 'Payment Failed';
$string['paymentcompleted'] = 'Your payment has been completed successfully.';
$string['transactionid'] = 'Transaction ID';
$string['enrolledincourse'] = 'You have been enrolled in the course';
$string['accesscourse'] = 'Access Course';
$string['invalidpayment'] = 'Invalid payment reference';
$string['generalfee'] = 'General Fee';
$string['paymentconfirmationsubject'] = 'Payment Confirmation';
$string['paymentconfirmationmessage'] = 'Your payment of {$a->amount} {$a->currency} for {$a->coursename} has been confirmed. Reference: {$a->reference}';

// Payment Gateway Strings
$string['paymentviaflutterwave'] = 'Payment via Flutterwave';
$string['paymentviapaystack'] = 'Payment via Paystack';
$string['paymentviapaypal'] = 'Payment via PayPal';

// Student Payment Strings
$string['makepayment'] = 'Make Payment';
$string['selectpaymentoption'] = 'Select Payment Option';
$string['paymentoptions'] = 'Payment Options';
$string['paymentdetails'] = 'Payment Details';
$string['paymentsummary'] = 'Payment Summary';
$string['selectpaymentoptionfirst'] = 'Please select a payment option first';
$string['selectpaymentgateway'] = 'Select Payment Gateway';
$string['proceedtopayment'] = 'Proceed to Payment';
$string['customamount'] = 'Custom Amount';
$string['customamountdesc'] = 'Enter a custom payment amount';
$string['custompayment'] = 'Custom Payment';
$string['enteramount'] = 'Enter amount';
$string['amount'] = 'Amount';
$string['invalidamount'] = 'Invalid amount';
$string['paymentcreationfailed'] = 'Failed to create payment';
$string['nopaymentgateways'] = 'No payment gateways are currently available';
$string['nopaymentoptions'] = 'No payment options are currently available for your categories';

// Payment Types
$string['coursefee'] = 'Course Fee';
$string['registrationfee'] = 'Registration Fee';
$string['examfee'] = 'Exam Fee';
$string['libraryfee'] = 'Library Fee';
$string['otherfee'] = 'Other Fee';

// Payment Categories Admin
$string['paymentcategories'] = 'Payment Categories';
$string['backtopaymentsettings'] = 'Back to Payment Settings';
$string['configurecategorypayments'] = 'Configure Category Payments';
$string['existingpaymentconfigs'] = 'Existing Payment Configurations';
$string['addnewpaymentcategory'] = 'Add New Payment Category';
$string['savepaymentconfigs'] = 'Save Payment Configurations';
$string['paymenttype'] = 'Payment Type';
$string['enabled'] = 'Enabled';
$string['paymentconfigssaved'] = 'Payment configurations saved successfully';
$string['paymentcategoryexists'] = 'Payment configuration for this category already exists';
$string['paymentcategoryadded'] = 'Payment category added successfully';
$string['paymentcategoryaddfailed'] = 'Failed to add payment category';
$string['confirmdeletepaymentcategory'] = 'Are you sure you want to delete this payment category?';
$string['managepaymentcategories'] = 'Manage Payment Categories';

// General strings
$string['add'] = 'Add';


// other validations  


$string['sis'] = 'SIS';
$string['studentadmission'] = 'Student Admission';
$string['studentprofiles'] = 'Student Profiles';
$string['academichistory'] = 'Academic History';
$string['transcript'] = 'Academic Transcript';
$string['idcards'] = 'ID Cards';

// Capabilities
$string['sis:manageadmission'] = 'Manage student admissions';
$string['sis:manageprofiles'] = 'Manage student profiles';
$string['sis:viewtranscripts'] = 'View academic transcripts';
$string['sis:generateidcards'] = 'Generate student ID cards';

// Notifications
$string['admissionsuccess'] = 'Student admitted successfully with ID: {$a}';
$string['admissionerror'] = 'Error admitting student: {$a}';
$string['profilesuccess'] = 'Profile updated successfully';
$string['gradesuccess'] = 'Grade added successfully';
$string['idcardsuccess'] = 'ID card generated successfully';
$string['notranscript'] = 'No transcript data found';

// Form fields
$string['firstname'] = 'First Name';
$string['lastname'] = 'Last Name';
$string['email'] = 'Email';
$string['program'] = 'Program';
$string['department'] = 'Department';
$string['admissiondate'] = 'Admission Date';
$string['expectedgraduation'] = 'Expected Graduation';
$string['emergencycontact'] = 'Emergency Contact';
$string['medicalinfo'] = 'Medical Information';

// Academic
$string['gpa'] = 'GPA';
$string['credits'] = 'Credits';
$string['semester'] = 'Semester';
$string['academicyear'] = 'Academic Year';
$string['course'] = 'Course';
$string['grade'] = 'Grade';
$string['completiondate'] = 'Completion Date';

// ID Cards
$string['cardnumber'] = 'Card Number';
$string['issuedate'] = 'Issue Date';
$string['expirydate'] = 'Expiry Date';
$string['cardstatus'] = 'Card Status';


// Add this to your existing language strings
$string['nostudentid'] = 'No student ID provided or current user is not a student';
$string['studentnotfound'] = 'Student not found';
$string['accessdenied'] = 'You do not have permission to view this transcript';

// Add these to your existing language strings
$string['viewresults_desc'] = 'View student results and generate report cards';
$string['broadsheetgenerator_desc'] = 'Generate class broadsheets in CSV format';
$string['managecomments_desc'] = 'Add/edit teacher and principal comments';
$string['sessionterms_desc'] = 'Manage academic sessions and terms';
$string['reportcardsettings_desc'] = 'Configure report card appearance and layout';




// Language strings for local_sis plugin

$string['pluginname'] = 'Student Information System';

// Dashboard statistics
$string['totalstudents'] = 'Total Students';
$string['activeterm'] = 'Active Term';
$string['totalcourses'] = 'Total Courses';
$string['pendingtasks'] = 'Pending Tasks';

// Section titles
$string['resultsmanagement'] = 'Results Management';
$string['usermanagement'] = 'User Management';
$string['coursemanagement'] = 'Course & Enrollment Management';
$string['systemconfiguration'] = 'System Configuration';

// Buttons and descriptions (optional)
$string['enterca'] = 'Enter CA Scores';
$string['viewresults'] = 'View Results';
$string['broadsheet'] = 'Broadsheet Generator';
$string['uploadusers'] = 'Upload Students/Teachers';
$string['promotestudents'] = 'Promote Students';
$string['managesubjects'] = 'Manage School Subjects';
$string['managecourses'] = 'Manage Student Courses';
$string['managecomments'] = 'Manage Comments';
$string['resultaccess'] = 'Result Access Control';
$string['sessionterms'] = 'Session & Terms';
$string['reportsettings'] = 'Report Card Settings';
$string['feesettings'] = 'Fee Settings';
$string['manageexams'] = 'Manage Exams';






// Privacy-related strings
$string['privacy:metadata:local_sis_result'] = 'Stores academic results and grades for students.';
$string['privacy:metadata:local_sis_result:userid'] = 'The ID of the user who received the grade.';
$string['privacy:metadata:local_sis_result:courseid'] = 'The ID of the course associated with the result.';
$string['privacy:metadata:local_sis_result:termid'] = 'The academic term when the result was recorded.';
$string['privacy:metadata:local_sis_result:assessment_type'] = 'Type of assessment (exam, quiz, assignment, etc.).';
$string['privacy:metadata:local_sis_result:score'] = 'Numerical score obtained by the student.';
$string['privacy:metadata:local_sis_result:grade'] = 'Letter grade or remark.';
$string['privacy:metadata:local_sis_result:grade_points'] = 'Grade points for GPA calculation.';
$string['privacy:metadata:local_sis_result:comments'] = 'Additional comments from the grader.';
$string['privacy:metadata:local_sis_result:graded_by'] = 'User ID of the person who graded the assessment.';
$string['privacy:metadata:local_sis_result:timecreated'] = 'Timestamp when the result was created.';
$string['privacy:metadata:local_sis_result:timemodified'] = 'Timestamp when the result was last modified.';

$string['privacy:metadata:local_sis_attendance'] = 'Stores student attendance records.';
$string['privacy:metadata:local_sis_attendance:userid'] = 'The ID of the user whose attendance is recorded.';
$string['privacy:metadata:local_sis_attendance:courseid'] = 'The ID of the course for the attendance session.';
$string['privacy:metadata:local_sis_attendance:session_date'] = 'The date of the attendance session.';
$string['privacy:metadata:local_sis_attendance:status'] = 'Attendance status (present, absent, late, etc.).';
$string['privacy:metadata:local_sis_attendance:remarks'] = 'Additional remarks about the attendance.';
$string['privacy:metadata:local_sis_attendance:recorded_by'] = 'User ID of the person who recorded the attendance.';
$string['privacy:metadata:local_sis_attendance:timecreated'] = 'Timestamp when the attendance record was created.';
$string['privacy:metadata:local_sis_attendance:timemodified'] = 'Timestamp when the attendance record was last modified.';

$string['privacy:metadata:local_sis_fees'] = 'Stores student fee and payment information.';
$string['privacy:metadata:local_sis_fees:userid'] = 'The ID of the user associated with the fee record.';
$string['privacy:metadata:local_sis_fees:academic_year'] = 'Academic year for the fee record.';
$string['privacy:metadata:local_sis_fees:term'] = 'Academic term for the fee record.';
$string['privacy:metadata:local_sis_fees:amount_due'] = 'The amount due for payment.';
$string['privacy:metadata:local_sis_fees:amount_paid'] = 'The amount actually paid.';
$string['privacy:metadata:local_sis_fees:payment_method'] = 'Method used for payment.';
$string['privacy:metadata:local_sis_fees:transaction_id'] = 'Unique identifier for the payment transaction.';
$string['privacy:metadata:local_sis_fees:payment_date'] = 'Date when payment was made.';
$string['privacy:metadata:local_sis_fees:processed_by'] = 'User ID of the person who processed the payment.';
$string['privacy:metadata:local_sis_fees:timecreated'] = 'Timestamp when the fee record was created.';
$string['privacy:metadata:local_sis_fees:timemodified'] = 'Timestamp when the fee record was last modified.';

$string['privacy:metadata:local_sis_student_profile'] = 'Stores extended student profile information.';
$string['privacy:metadata:local_sis_student_profile:userid'] = 'The ID of the user whose profile is stored.';
$string['privacy:metadata:local_sis_student_profile:student_id'] = 'Official student identification number.';
$string['privacy:metadata:local_sis_student_profile:emergency_contact'] = 'Emergency contact information.';
$string['privacy:metadata:local_sis_student_profile:medical_info'] = 'Medical information and special needs.';
$string['privacy:metadata:local_sis_student_profile:guardian_info'] = 'Parent or guardian information.';
$string['privacy:metadata:local_sis_student_profile:academic_notes'] = 'Academic advisor notes and comments.';
$string['privacy:metadata:local_sis_student_profile:timecreated'] = 'Timestamp when the profile was created.';
$string['privacy:metadata:local_sis_student_profile:timemodified'] = 'Timestamp when the profile was last modified.';

$string['privacy:metadata:local_sis_user_logs'] = 'Stores user activity logs for audit purposes.';
$string['privacy:metadata:local_sis_user_logs:userid'] = 'The ID of the user who performed the action.';
$string['privacy:metadata:local_sis_user_logs:action'] = 'The action performed by the user.';
$string['privacy:metadata:local_sis_user_logs:component'] = 'The component where the action occurred.';
$string['privacy:metadata:local_sis_user_logs:target_userid'] = 'The ID of the user affected by the action.';
$string['privacy:metadata:local_sis_user_logs:ip_address'] = 'IP address from which the action was performed.';
$string['privacy:metadata:local_sis_user_logs:user_agent'] = 'Browser or client user agent string.';
$string['privacy:metadata:local_sis_user_logs:description'] = 'Description of the action performed.';
$string['privacy:metadata:local_sis_user_logs:timecreated'] = 'Timestamp when the log entry was created.';

$string['privacy:metadata:sis_external_system'] = 'Data shared with external student information systems.';
$string['privacy:metadata:sis_external_system:student_id'] = 'Student identification number shared with external systems.';
$string['privacy:metadata:sis_external_system:academic_records'] = 'Academic performance data shared for reporting.';
$string['privacy:metadata:sis_external_system:attendance_data'] = 'Attendance records shared with external systems.';
$string['privacy:metadata:sis_external_system:financial_info'] = 'Fee and payment information for external processing.';

$string['privacy:path:sis_data'] = 'Student Information System Data';
$string['privacy:anonymous_user'] = 'Anonymous User';
$string['privacy:unknown_user'] = 'Unknown User';
// other strings  
// Add these to your local_sis.php language file
$string['currentsettings'] = 'Current Settings';
$string['noschoollogouploaded'] = 'No school logo uploaded';
$string['noprincipalsignatureuploaded'] = 'No principal signature uploaded';
$string['settingssavedsuccessfully'] = 'Settings saved successfully';


// Add these to your existing language file - SCHOOL SETTINGS STRINGS
$string['schoolname'] = 'School Name';
$string['schooladdress'] = 'School Address';
$string['schoolmotto'] = 'School Motto';
$string['phone'] = 'Phone Number';
$string['state'] = 'State/Province';
$string['country'] = 'Country';
$string['schoollogo'] = 'School Logo';
$string['principalsignature'] = 'Principal Signature';
$string['required'] = 'Required field';
$string['currentsettings'] = 'Current Settings';
$string['noschoollogouploaded'] = 'No school logo uploaded';
$string['noprincipalsignatureuploaded'] = 'No principal signature uploaded';
$string['settingssavedsuccessfully'] = 'Settings saved successfully';

// registration strings  
$string['courseregistration'] = 'Course Registration';
$string['selectcategory'] = 'Select Category:';
$string['choosecategory'] = 'Choose a category...';
$string['nostudentsincategory'] = 'No students found in this category';
$string['categorycourses'] = 'Category Courses';
$string['carryovercourses'] = 'Carry-over Courses';
$string['registercourses'] = 'Register Selected Courses';
$string['registrationsuccess'] = 'Successfully registered {$a} students to courses';
$string['registrationerrors'] = '{$a} registration errors occurred';
$string['sis:registerstudents'] = 'Register students to courses';






$string['sis:view'] = 'View Student Information System';
$string['sis:manage'] = 'Manage Student Information System';
$string['sis:registerstudents'] = 'Register students to courses';

// Navigation strings
$string['studentportal'] = 'Student Portal';
$string['myresults'] = 'My Results';
$string['sisadmin'] = 'SIS Admin';
$string['sisdashboard'] = 'SIS Dashboard';
$string['schoolsettings'] = 'School Settings';
$string['sessionterms'] = 'Session & Terms';
$string['coursesis'] = 'Course SIS';
$string['courseregistration'] = 'Course Registration';

// Course registration strings
$string['selectcategory'] = 'Select Category:';
$string['choosecategory'] = 'Choose a category...';
$string['nostudentsincategory'] = 'No students found in this category';
$string['categorycourses'] = 'Category Courses';
$string['carryovercourses'] = 'Carry-over Courses';
$string['registercourses'] = 'Register Selected Courses';
$string['registrationsuccess'] = 'Successfully registered {$a} students to courses';
$string['registrationerrors'] = '{$a} registration errors occurred';

//  updates 

$string['sessionsandterms'] = 'SIS Sessions & Terms';
$string['sessionname'] = 'Session name';
$string['setasdefaultsession'] = 'Set as default session';
$string['createsessionandterms'] = 'Create session & terms';
$string['createsession'] = 'Create New Session';
$string['sessioncreated'] = 'Session and terms created successfully.';
$string['nosessionsfound'] = 'No sessions found.';
$string['managedefaults'] = 'Active / Default Session & Term';
$string['activesession'] = 'Active Session';
$string['session'] = 'Session';
$string['term'] = 'Term';
$string['activeterm'] = 'Active Term';
$string['cumulative'] = 'Cumulative';
$string['actions'] = 'Actions';
$string['deletesession'] = 'Delete Session';
$string['deleteterm'] = 'Delete Term';
$string['termdeleted'] = 'Term deleted.';
$string['sessiondeleted'] = 'Session deleted.';
$string['cumulativetoggled'] = 'Cumulative setting toggled.';
$string['addmissingterms'] = 'Add missing terms';
$string['termsadded'] = 'Missing terms added.';
$string['adddefaultterms'] = 'Add default terms';
$string['noterms'] = 'No terms';
$string['savedefaults'] = 'Save active settings';
$string['defaultsupdated'] = 'Active session/term updated.';
$string['confirmdeletion'] = 'Confirm deletion';
$string['confirmdeletetext'] = 'Are you sure you want to delete this item? This action cannot be undone.';
$string['confirmdeletesession'] = 'Are you sure you want to delete the session \"{name}\" and all its terms?';
$string['confirmdeleteterm'] = 'Are you sure you want to delete the term \"{name}\"?';
$string['createsessionandterms'] = 'Create Session + 3 Terms';
$string['saved'] = 'Saved';
$string['yes'] = 'Yes';
$string['no'] = 'No';
$string['required'] = 'Required';

// ==================== SESSION & TERMS MANAGEMENT STRINGS ====================

// Session and Terms Management Strings
$string['isactive'] = 'Active Session';
$string['isactive_help'] = 'If checked, this session will be set as the currently active session. Only one session can be active at a time.';

$string['isdefault'] = 'Default Session';
$string['isdefault_help'] = 'If checked, this session will be set as the default session for new enrollments and system operations.';

$string['activesession'] = 'Active Session';
$string['activesession_help'] = 'The currently active academic session. This session will be used for current operations, attendance, and result processing.';

$string['defaultsession'] = 'Default Session';
$string['defaultsession_help'] = 'The default academic session used for new student enrollments and system defaults when no active session is specified.';

$string['activeterm'] = 'Active Term';
$string['activeterm_help'] = 'The currently active academic term within the active session. This term will be used for current assessments and grading.';

$string['defaultterm'] = 'Default Term';
$string['defaultterm_help'] = 'The default academic term used for system operations when no active term is specified.';

// Navigation and General Strings
$string['managesessions'] = 'Manage Sessions & Terms';
$string['backtosishome'] = 'Back to SIS Home';
$string['createsessionwithterms'] = 'Create Session with Terms';
$string['saveactivedefaults'] = 'Save Active & Default Settings';

// Status and Display Strings
$string['currentactivedefault'] = 'Current Active & Default Settings';
$string['notset'] = 'Not set';
$string['setactivedefaultsessionterm'] = 'Set Active & Default Session/Term';
$string['createnewsession'] = 'Create New Session';
$string['allsessionsterms'] = 'All Sessions & Terms';
$string['termstatus'] = 'Term Status';
$string['cumulative'] = 'Cumulative';
$string['active'] = 'Active';
$string['default'] = 'Default';
$string['deletesession'] = 'Delete Session';
$string['deleteterm'] = 'Delete Term';
$string['addmissingterms'] = 'Add Missing Terms to Sessions';
$string['addtermsto'] = 'Add Terms to {$a}';
$string['nosessionsfound'] = 'No sessions or terms found.';

// Success Messages
$string['sessioncreated'] = 'Session with 3 terms created successfully.';
$string['settingsupdated'] = 'Active and default settings updated successfully.';
$string['deletedsuccessfully'] = 'Deleted successfully.';
$string['cumulativesettingupdated'] = 'Cumulative setting updated.';
$string['termsadded'] = 'Missing terms added.';

// Confirmation Messages
$string['confirmdelete'] = 'Are you sure you want to delete the {$a->type} "{$a->name}"? This action cannot be undone.';
$string['cancel'] = 'Cancel';

// Form Labels
$string['sessionname'] = 'Session Name';
$string['setasactivesession'] = 'Set as active session';
$string['setasdefaultsession'] = 'Set as default session';

// Session and Terms Specific Strings
$string['sessionsandterms'] = 'SIS Sessions & Terms';
$string['sessionname'] = 'Session name';
$string['setasdefaultsession'] = 'Set as default session';
$string['createsessionandterms'] = 'Create session & terms';
$string['createsession'] = 'Create New Session';
$string['sessioncreated'] = 'Session and terms created successfully.';
$string['nosessionsfound'] = 'No sessions found.';
$string['managedefaults'] = 'Active / Default Session & Term';
$string['activesession'] = 'Active Session';
$string['session'] = 'Session';
$string['term'] = 'Term';
$string['activeterm'] = 'Active Term';
$string['cumulative'] = 'Cumulative';
$string['actions'] = 'Actions';
$string['deletesession'] = 'Delete Session';
$string['deleteterm'] = 'Delete Term';
$string['termdeleted'] = 'Term deleted.';
$string['sessiondeleted'] = 'Session deleted.';
$string['cumulativetoggled'] = 'Cumulative setting toggled.';
$string['addmissingterms'] = 'Add missing terms';
$string['termsadded'] = 'Missing terms added.';
$string['adddefaultterms'] = 'Add default terms';
$string['noterms'] = 'No terms';
$string['savedefaults'] = 'Save active settings';
$string['defaultsupdated'] = 'Active session/term updated.';
$string['confirmdeletion'] = 'Confirm deletion';
$string['confirmdeletetext'] = 'Are you sure you want to delete this item? This action cannot be undone.';
$string['confirmdeletesession'] = 'Are you sure you want to delete the session "{$a}" and all its terms?';
$string['confirmdeleteterm'] = 'Are you sure you want to delete the term "{$a}"?';
$string['createsessionandterms'] = 'Create Session + 3 Terms';
$string['saved'] = 'Saved';
$string['yes'] = 'Yes';
$string['no'] = 'No';
$string['required'] = 'Required';

// Academic Terms
$string['firstterm'] = 'First Term';
$string['secondterm'] = 'Second Term';
$string['thirdterm'] = 'Third Term';
$string['cumulativeaverage'] = 'Calculate Cumulative Average for Third Term';

// Form Strings
$string['calculatecumulative'] = 'Calculate Cumulative Average';
$string['cumulativeinfo'] = 'Check this box if this term should calculate cumulative average (typically for third term)';
$string['savesessionterm'] = 'Save Session/Term';
$string['sessiontermexists'] = 'This session/term combination already exists!';
$string['maximumchars'] = 'Maximum {$a} characters';

// Help Strings
$string['sessionname_help'] = 'Enter the academic session name (e.g., 2023/2024)';
$string['termname_help'] = 'Enter the term name (e.g., First Term, Second Term, Third Term)';
$string['isdefault_help'] = 'Set this as the current active session/term';
$string['calculatecumulative_help'] = 'If checked, this term will calculate cumulative average including previous terms';

// Session and Terms Descriptions
$string['sessionterms_desc'] = 'Manage academic sessions and terms';
$string['sessionterms'] = 'Session & Terms';