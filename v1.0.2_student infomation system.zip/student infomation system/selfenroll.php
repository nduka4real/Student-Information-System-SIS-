<?php
// This file is part of the Student Information System plugin for Moodle.
// this helps students to self enroll or unroll from courses
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version information for the Student Information System plugin
 *
 * @package    local_sis
 * @copyright  2025 NduksTech - https://facebook.com/ndukshub
 * @author     Nduka Akapti  (https://github.com/nduka4real)
 * @author     Ndukstech (https://www.youtube.com/@nduks-tech)
 * @author     https://www.linkedin.com/in/ndukaakpati/
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @details
 * Display Name: Student Information System
 * Description: A comprehensive system for managing student records, assessments, fees, and school operations.
 * Contact: https://github.com/nduka4real
 * Social: https://facebook.com/ndukshub
 */


// local/sis/selfenroll.php
require_once('../../config.php');
require_once($CFG->libdir . '/formslib.php');
require_once(__DIR__ . '/lib.php');

require_login();

global $DB, $USER, $PAGE, $OUTPUT;

// Check if user is a student - only students can use this
if (is_siteadmin($USER->id)) {
    throw new moodle_exception('admincannotuseselfenroll', 'local_sis');
}

$PAGE->set_url(new moodle_url('/local/sis/selfenroll.php'));
$PAGE->set_context(context_system::instance());
$PAGE->set_title(get_string('selfenrollment', 'local_sis'));
$PAGE->set_heading(get_string('selfenrollment', 'local_sis'));

// Add JavaScript for master checkbox functionality
$PAGE->requires->js_init_code("
// Master checkbox functionality
function toggleAllCheckboxes(source) {
    var checkboxes = document.querySelectorAll('input.course-checkbox');
    for (var i = 0; i < checkboxes.length; i++) {
        checkboxes[i].checked = source.checked;
    }
    updateSelectedCount();
}

function updateSelectedCount() {
    var checkboxes = document.querySelectorAll('input.course-checkbox');
    var checkedCount = 0;
    for (var i = 0; i < checkboxes.length; i++) {
        if (checkboxes[i].checked) {
            checkedCount++;
        }
    }
    var totalCount = checkboxes.length;
    
    // Update counter
    var selectedCountElement = document.getElementById('selected-count');
    if (selectedCountElement) {
        selectedCountElement.textContent = checkedCount + ' of ' + totalCount + ' courses selected';
    }
    
    // Update master checkbox state
    var masterCheckbox = document.getElementById('master-checkbox');
    if (masterCheckbox) {
        if (checkedCount === 0) {
            masterCheckbox.checked = false;
            masterCheckbox.indeterminate = false;
        } else if (checkedCount === totalCount) {
            masterCheckbox.checked = true;
            masterCheckbox.indeterminate = false;
        } else {
            masterCheckbox.checked = false;
            masterCheckbox.indeterminate = true;
        }
    }
}

function selectAllCourses() {
    var checkboxes = document.querySelectorAll('input.course-checkbox');
    for (var i = 0; i < checkboxes.length; i++) {
        checkboxes[i].checked = true;
    }
    updateSelectedCount();
}

function deselectAllCourses() {
    var checkboxes = document.querySelectorAll('input.course-checkbox');
    for (var i = 0; i < checkboxes.length; i++) {
        checkboxes[i].checked = false;
    }
    updateSelectedCount();
}

function selectOnlyEnrolled() {
    var checkboxes = document.querySelectorAll('input.course-checkbox');
    for (var i = 0; i < checkboxes.length; i++) {
        var checkbox = checkboxes[i];
        var row = checkbox.closest('tr');
        var statusBadge = row.querySelector('.badge');
        if (statusBadge && statusBadge.textContent.includes('Enrolled')) {
            checkbox.checked = true;
        } else {
            checkbox.checked = false;
        }
    }
    updateSelectedCount();
}

// Initialize when page loads
document.addEventListener('DOMContentLoaded', function() {
    // Set up master checkbox
    var masterCheckbox = document.getElementById('master-checkbox');
    if (masterCheckbox) {
        masterCheckbox.addEventListener('change', function() {
            toggleAllCheckboxes(this);
        });
    }
    
    // Set up individual checkboxes
    var checkboxes = document.querySelectorAll('input.course-checkbox');
    for (var i = 0; i < checkboxes.length; i++) {
        checkboxes[i].addEventListener('change', updateSelectedCount);
    }
    
    // Set up action buttons
    var selectAllBtn = document.getElementById('select-all-btn');
    if (selectAllBtn) {
        selectAllBtn.addEventListener('click', selectAllCourses);
    }
    
    var deselectAllBtn = document.getElementById('deselect-all-btn');
    if (deselectAllBtn) {
        deselectAllBtn.addEventListener('click', deselectAllCourses);
    }
    
    var selectEnrolledBtn = document.getElementById('select-enrolled-btn');
    if (selectEnrolledBtn) {
        selectEnrolledBtn.addEventListener('click', selectOnlyEnrolled);
    }
    
    // Set up form confirmation
    var form = document.getElementById('course-registration-form');
    if (form) {
        form.addEventListener('submit', function(e) {
            if (!confirm('Are you sure you want to update your course enrollment?')) {
                e.preventDefault();
            }
        });
    }
    
    // Initial count update
    updateSelectedCount();
});
");

// Navbar
$PAGE->navbar->add(get_string('pluginname', 'local_sis'), new moodle_url('/local/sis/index.php'));
$PAGE->navbar->add(get_string('selfenrollment', 'local_sis'));

echo $OUTPUT->header();

// Dashboard button
echo html_writer::div(
    html_writer::link(
        new moodle_url('/local/sis/index.php'),
        get_string('backtodashboard', 'local_sis'),
        ['class' => 'btn btn-secondary mb-3']
    )
);

echo html_writer::start_div('container-fluid');

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && confirm_sesskey()) {
    handle_self_enrollment();
}

// Show student's available courses
show_student_courses();

echo html_writer::end_div();
echo $OUTPUT->footer();

/**
 * Show courses available for the current student to enroll in
 */
function show_student_courses() {
    global $DB, $USER, $OUTPUT;

    echo $OUTPUT->heading(get_string('mycourseregistration', 'local_sis'));

    // Get the student's category/categories
    $categories = $DB->get_records_sql("
        SELECT DISTINCT cat.id, cat.name, cat.description
        FROM {course_categories} cat
        JOIN {course} c ON c.category = cat.id
        JOIN {enrol} e ON e.courseid = c.id
        JOIN {user_enrolments} ue ON ue.enrolid = e.id
        WHERE ue.userid = ? AND c.visible = 1
        ORDER BY cat.name ASC
    ", [$USER->id]);

    if (empty($categories)) {
        echo $OUTPUT->notification(get_string('nocategoriesfound', 'local_sis'), 'notifyinfo');
        return;
    }

    // If student has multiple categories, show category selection
    if (count($categories) > 1) {
        show_category_selection($categories);
        return;
    }

    // Student has only one category - show courses directly
    $category = reset($categories);
    show_category_courses($category->id);
}

/**
 * Show category selection for students in multiple categories
 */
function show_category_selection($categories) {
    global $OUTPUT;

    echo $OUTPUT->heading(get_string('selectyourcategory', 'local_sis'));

    echo html_writer::start_div('row');
    foreach ($categories as $category) {
        $url = new moodle_url('/local/sis/selfenroll.php', ['categoryid' => $category->id]);

        echo html_writer::start_div('col-md-4 mb-3');
        echo html_writer::start_div('card h-100');
        echo html_writer::start_div('card-body');
        echo html_writer::tag('h5', format_string($category->name), ['class' => 'card-title']);

        if (!empty($category->description)) {
            echo html_writer::tag('p', format_text($category->description, FORMAT_HTML), ['class' => 'card-text small']);
        }

        // Get course count in this category
        $coursecount = $DB->count_records('course', ['category' => $category->id, 'visible' => 1]);
        echo html_writer::tag('p', get_string('coursesavailable', 'local_sis', $coursecount), ['class' => 'text-muted small']);

        echo html_writer::end_div();
        echo html_writer::start_div('card-footer');
        echo html_writer::link($url, get_string('viewcourses', 'local_sis'), ['class' => 'btn btn-primary btn-sm']);
        echo html_writer::end_div(); // footer
        echo html_writer::end_div(); // card
        echo html_writer::end_div(); // col
    }
    echo html_writer::end_div();
}

/**
 * Show courses in student's category with enrollment options
 */
function show_category_courses($categoryid = null) {
    global $DB, $USER, $OUTPUT;

    // If categoryid is provided via GET parameter
    if (!$categoryid) {
        $categoryid = optional_param('categoryid', 0, PARAM_INT);
        if (!$categoryid) {
            echo $OUTPUT->notification(get_string('nocategoryselected', 'local_sis'), 'notifyproblem');
            return;
        }
    }

    $category = $DB->get_record('course_categories', ['id' => $categoryid], '*', MUST_EXIST);

    // Verify student has access to this category
    $has_access = $DB->record_exists_sql("
        SELECT 1
        FROM {course} c
        JOIN {enrol} e ON e.courseid = c.id
        JOIN {user_enrolments} ue ON ue.enrolid = e.id
        WHERE c.category = ? AND ue.userid = ? AND c.visible = 1
    ", [$categoryid, $USER->id]);

    if (!$has_access) {
        echo $OUTPUT->notification(get_string('noaccesstocategory', 'local_sis'), 'notifyproblem');
        return;
    }

    // Back button if multiple categories
    $categories_count = $DB->count_records_sql("
        SELECT COUNT(DISTINCT cat.id)
        FROM {course_categories} cat
        JOIN {course} c ON c.category = cat.id
        JOIN {enrol} e ON e.courseid = c.id
        JOIN {user_enrolments} ue ON ue.enrolid = e.id
        WHERE ue.userid = ?
    ", [$USER->id]);

    if ($categories_count > 1) {
        echo html_writer::div(
            html_writer::link(
                new moodle_url('/local/sis/selfenroll.php'),
                get_string('backtocategories', 'local_sis'),
                ['class' => 'btn btn-outline-secondary mb-3']
            )
        );
    }

    echo $OUTPUT->heading(get_string('coursesin', 'local_sis', format_string($category->name)));
    echo html_writer::tag('p', get_string('selectcoursestoenroll', 'local_sis'), ['class' => 'text-muted']);

    // Get all visible courses in the category
    $courses = $DB->get_records('course', ['category' => $categoryid, 'visible' => 1], 'fullname ASC');

    if (empty($courses)) {
        echo $OUTPUT->notification(get_string('nocoursesincategory', 'local_sis'), 'notifyproblem');
        return;
    }

    // Get current enrollments
    $enrolled = $DB->get_records_sql("
        SELECT c.id
        FROM {course} c
        JOIN {enrol} e ON e.courseid = c.id
        JOIN {user_enrolments} ue ON ue.enrolid = e.id
        WHERE c.category = ? AND ue.userid = ? AND c.visible = 1
    ", [$categoryid, $USER->id]);

    $enrolledids = array_keys($enrolled);

    echo html_writer::start_tag('form', ['method' => 'post', 'id' => 'course-registration-form']);
    echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey()]);
    echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'categoryid', 'value' => $categoryid]);

    // Selection summary
    echo html_writer::start_div('alert alert-info mb-3 d-flex justify-content-between align-items-center');
    echo html_writer::tag('span', '<strong>' . get_string('courseselection', 'local_sis') . ':</strong> ' . get_string('checkboxtoenroll', 'local_sis'), ['style' => 'font-size: 14px;']);
    echo html_writer::tag('span', '<span id="selected-count">0 of ' . count($courses) . ' courses selected</span>', [
        'class' => 'badge badge-primary badge-pill',
        'style' => 'font-size: 14px;'
    ]);
    echo html_writer::end_div();

    $table = new html_table();
    $table->attributes['class'] = 'table table-striped table-hover';
    $table->head = [
        // Master checkbox column
        html_writer::div(
            html_writer::empty_tag('input', [
                'type' => 'checkbox',
                'id' => 'master-checkbox',
                'title' => get_string('selectdeselectall', 'local_sis')
            ]) . ' ' . html_writer::tag('span', get_string('all', 'local_sis'), ['style' => 'font-weight: bold;']),
            'text-center'
        ),
        get_string('course', 'local_sis'),
        get_string('courseshortname', 'local_sis'),
        get_string('description'),
        get_string('enrollmentstatus', 'local_sis'),
        get_string('actions', 'local_sis')
    ];

    foreach ($courses as $c) {
        $isenrolled = in_array($c->id, $enrolledids);
        $status = $isenrolled
            ? html_writer::span(get_string('enrolled', 'local_sis'), 'badge badge-success')
            : html_writer::span(get_string('notenrolled', 'local_sis'), 'badge badge-secondary');

        $checkbox = html_writer::empty_tag('input', [
            'type' => 'checkbox',
            'name' => 'courses['.$c->id.']',
            'value' => '1',
            'class' => 'course-checkbox',
            'checked' => $isenrolled
        ]);

        // Course description (truncated)
        $description = '';
        if (!empty($c->summary)) {
            $description = format_string($c->summary);
            if (strlen($description) > 150) {
                $description = substr($description, 0, 150) . '...';
            }
        }

        // Action buttons
        $actions = html_writer::div(
            html_writer::link(
                new moodle_url('/course/view.php', ['id' => $c->id]),
                get_string('viewcourse', 'local_sis'),
                ['class' => 'btn btn-outline-info btn-sm', 'target' => '_blank']
            ),
            'btn-group'
        );

        $table->data[] = [
            html_writer::div($checkbox, 'text-center'),
            html_writer::div(format_string($c->fullname), 'font-weight-bold'),
            html_writer::div(s($c->shortname), 'text-muted small'),
            html_writer::div($description, 'small'),
            $status,
            $actions
        ];
    }

    echo html_writer::table($table);

    // Enrollment limits warning
    echo html_writer::start_div('alert alert-warning mt-3');
    echo html_writer::tag('h6', get_string('important', 'local_sis'), ['class' => 'alert-heading']);
    echo html_writer::tag('p', get_string('enrollmentguidelines', 'local_sis'), ['class' => 'mb-0 small']);
    echo html_writer::end_div();

    // Action buttons
    echo html_writer::start_div('card mt-4');
    echo html_writer::start_div('card-header bg-primary text-white');
    echo html_writer::tag('h5', get_string('enrollmentactions', 'local_sis'), ['class' => 'mb-0']);
    echo html_writer::end_div();
    echo html_writer::start_div('card-body');
    
    echo html_writer::start_div('row');
    
    // Left side - Quick actions
    echo html_writer::start_div('col-md-6');
    echo html_writer::tag('h6', get_string('quickactions', 'local_sis') . ':', ['class' => 'mb-3']);
    
    echo html_writer::start_div('btn-group-vertical w-100');
    echo html_writer::tag('button', get_string('selectallcourses', 'local_sis'), [
        'type' => 'button',
        'class' => 'btn btn-outline-primary btn-sm mb-2',
        'id' => 'select-all-btn'
    ]);
    echo html_writer::tag('button', get_string('deselectallcourses', 'local_sis'), [
        'type' => 'button',
        'class' => 'btn btn-outline-secondary btn-sm mb-2',
        'id' => 'deselect-all-btn'
    ]);
    echo html_writer::tag('button', get_string('selectonlyenrolled', 'local_sis'), [
        'type' => 'button',
        'class' => 'btn btn-outline-info btn-sm',
        'id' => 'select-enrolled-btn'
    ]);
    echo html_writer::end_div(); // btn-group-vertical
    echo html_writer::end_div(); // col-md-6
    
    // Right side - Save button
    echo html_writer::start_div('col-md-6 text-right');
    echo html_writer::tag('h6', get_string('saveenrollment', 'local_sis') . ':', ['class' => 'mb-3']);
    echo html_writer::empty_tag('input', [
        'type' => 'submit',
        'name' => 'save',
        'value' => get_string('savechanges', 'local_sis'),
        'class' => 'btn btn-success btn-lg px-5'
    ]);
    echo html_writer::end_div(); // col-md-6
    
    echo html_writer::end_div(); // row
    echo html_writer::end_div(); // card-body
    echo html_writer::end_div(); // card

    echo html_writer::end_tag('form');
}

/**
 * Handle self enrollment form submission
 */
function handle_self_enrollment() {
    global $DB, $USER, $OUTPUT;

    $categoryid = optional_param('categoryid', 0, PARAM_INT);
    $selected = optional_param_array('courses', [], PARAM_INT);

    // Verify category access
    $has_access = $DB->record_exists_sql("
        SELECT 1
        FROM {course} c
        JOIN {enrol} e ON e.courseid = c.id
        JOIN {user_enrolments} ue ON ue.enrolid = e.id
        WHERE c.category = ? AND ue.userid = ? AND c.visible = 1
    ", [$categoryid, $USER->id]);

    if (!$has_access) {
        echo $OUTPUT->notification(get_string('noaccesstocategory', 'local_sis'), 'notifyproblem');
        return;
    }

    $courses = $DB->get_records('course', ['category' => $categoryid, 'visible' => 1]);

    $enrolled = 0;
    $unenrolled = 0;
    $errors = [];

    foreach ($courses as $c) {
        $should = isset($selected[$c->id]);
        $is     = is_user_enrolled_in_course($USER->id, $c->id);

        if ($should && !$is) {
            if (enroll_student_in_course($USER->id, $c->id)) {
                $enrolled++;
            } else {
                $errors[] = get_string('errorenrolling', 'local_sis', format_string($c->fullname));
            }
        } elseif (!$should && $is) {
            if (unenroll_student_from_course($USER->id, $c->id)) {
                $unenrolled++;
            } else {
                $errors[] = get_string('errorunenrolling', 'local_sis', format_string($c->fullname));
            }
        }
    }

    // Show success/error messages
    $msg = '';
    if ($enrolled > 0) {
        $msg .= get_string('successenrolled', 'local_sis', $enrolled) . ' ';
    }
    if ($unenrolled > 0) {
        $msg .= get_string('successunenrolled', 'local_sis', $unenrolled);
    }
    if (!$msg && empty($errors)) {
        $msg = get_string('nochangesmade', 'local_sis');
    }

    if (!empty($msg)) {
        echo $OUTPUT->notification($msg, 'notifysuccess');
    }

    if (!empty($errors)) {
        foreach ($errors as $error) {
            echo $OUTPUT->notification($error, 'notifyproblem');
        }
    }
}

/**
 * Check if user is enrolled in course
 */
function is_user_enrolled_in_course($userid, $courseid) {
    global $DB;
    
    return $DB->record_exists_sql("
        SELECT 1
        FROM {user_enrolments} ue
        JOIN {enrol} e ON e.id = ue.enrolid
        WHERE ue.userid = ? AND e.courseid = ?
    ", [$userid, $courseid]);
}

/**
 * Enroll student in course
 */
function enroll_student_in_course($userid, $courseid) {
    global $DB;
    
    // Check if already enrolled
    if (is_user_enrolled_in_course($userid, $courseid)) {
        return true;
    }
    
    // Get manual enrollment instance
    $enrol = $DB->get_record('enrol', [
        'courseid' => $courseid, 
        'enrol' => 'manual',
        'status' => 0 // Enabled
    ], '*', IGNORE_MISSING);
    
    if (!$enrol) {
        return false;
    }

    // Check if self enrollment is allowed (custom setting or default behavior)
    // You might want to add additional checks here based on your requirements
    
    // Get student role
    $student_role = $DB->get_record('role', ['archetype' => 'student'], '*', MUST_EXIST);
    
    // Enroll user
    $user_enrolment = new stdClass();
    $user_enrolment->enrolid = $enrol->id;
    $user_enrolment->userid = $userid;
    $user_enrolment->timestart = time();
    $user_enrolment->timecreated = time();
    $user_enrolment->timemodified = time();
    
    $enrolment_id = $DB->insert_record('user_enrolments', $user_enrolment);
    
    if ($enrolment_id) {
        // Assign student role
        $context = context_course::instance($courseid);
        role_assign($student_role->id, $userid, $context->id, 'enrol_manual', $enrol->id);
        return true;
    }
    
    return false;
}

/**
 * Unenroll student from course
 */
function unenroll_student_from_course($userid, $courseid) {
    global $DB;
    
    // Get enrollment record
    $sql = "SELECT ue.*, e.enrol
            FROM {user_enrolments} ue
            JOIN {enrol} e ON e.id = ue.enrolid
            WHERE ue.userid = ? AND e.courseid = ?";
    
    $enrolments = $DB->get_records_sql($sql, [$userid, $courseid]);
    
    $success = true;
    foreach ($enrolments as $enrolment) {
        // Remove role assignments
        $context = context_course::instance($courseid);
        role_unassign_all([
            'userid' => $userid, 
            'contextid' => $context->id,
            'component' => 'enrol_' . $enrolment->enrol,
            'itemid' => $enrolment->enrolid
        ]);
        
        // Remove enrollment
        $success = $success && $DB->delete_records('user_enrolments', ['id' => $enrolment->id]);
    }
    
    return $success;
}