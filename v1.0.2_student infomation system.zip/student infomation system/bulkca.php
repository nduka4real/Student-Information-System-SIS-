<?php
// This file is part of the Student Information System plugin for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version information for the Student Information System plugin
 *
 * @package    local_sis
 * @copyright  2025 NduksTech - https://facebook.com/ndukshub
 * @author     Nduka Akapti  (https://github.com/nduka4real)
 * @author     Ndukstech (https://www.youtube.com/@nduks-tech)
 * @author     https://www.linkedin.com/in/ndukaakpati/
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @details
 * Display Name: Student Information System
 * Description: A comprehensive system for managing student records, assessments, fees, and school operations.
 * Contact: https://github.com/nduka4real
 * Social: https://facebook.com/ndukshub
 */

require_once(__DIR__ . '/../../config.php');
require_login();
require_sesskey();

$courseid = optional_param('courseid', 0, PARAM_INT);
$context = context_system::instance();
require_capability('moodle/site:config', $context);

$PAGE->set_url('/local/sis/savebulkca.php');

if (!isset($_FILES['csvfile']) || $_FILES['csvfile']['error'] !== UPLOAD_ERR_OK) {
    print_error('nofile');
}

$path = $_FILES['csvfile']['tmp_name'];
$handle = fopen($path, 'r');
if (!$handle) {
    print_error('cannotreadfile');
}

$header = fgetcsv($handle);
$map = array_flip($header);
$required = ['userid','courseid','firstca','secondca','exam'];
foreach ($required as $col) {
    if (!array_key_exists($col, $map)) {
        fclose($handle);
        print_error('missingfield', '', "", "Missing column: $col");
    }
}

global $DB;
$time = time();
$count = 0;
while (($row = fgetcsv($handle)) !== false) {
    $userid = (int)$row[$map['userid']];
    $cID = (int)$row[$map['courseid']];
    if ($courseid && $cID != $courseid) { continue; }
    $first = $row[$map['firstca']] === '' ? null : (float)$row[$map['firstca']];
    $second = $row[$map['secondca']] === '' ? null : (float)$row[$map['secondca']];
    $exam = $row[$map['exam']] === '' ? null : (float)$row[$map['exam']];
    $total = 0;
    foreach ([$first,$second,$exam] as $v) if ($v !== null && $v !== '') $total += (float)$v;
    $grade = null;
    if ($total !== null) {
        if ($total >= 70) $grade = 'A';
        else if ($total >= 60) $grade = 'B';
        else if ($total >= 50) $grade = 'C';
        else if ($total >= 45) $grade = 'D';
        else if ($total > 0) $grade = 'F';
    }
    $existing = $DB->get_record('local_sis_result', ['userid'=>$userid, 'courseid'=>$cID]);
    $rec = (object)[
        'userid'=>$userid,
        'courseid'=>$cID,
        'firstca'=>$first,
        'secondca'=>$second,
        'exam'=>$exam,
        'total'=>$total,
        'grade'=>$grade,
        'timemodified'=>$time
    ];
    if ($existing) {
        $rec->id = $existing->id;
        $DB->update_record('local_sis_result', $rec);
    } else {
        $rec->timecreated = $time;
        $DB->insert_record('local_sis_result', $rec);
    }
    $count++;
}
fclose($handle);

redirect(new moodle_url('/local/sis/index.php'), "$count rows processed", 0, \core\output\notification::NOTIFY_SUCCESS);
