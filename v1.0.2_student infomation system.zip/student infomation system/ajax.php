<?php
// local/sis/ajax/ajax.php
define('AJAX_SCRIPT', true);
require_once(__DIR__ . '/../../../config.php');
require_login();

global $DB, $OUTPUT, $USER;

$action = required_param('action', PARAM_TEXT);

// Simple capability guard: only admins/site managers by default
$systemcontext = context_system::instance();
require_capability('moodle/site:config', $systemcontext);

header('Content-Type: application/json; charset=utf-8');

try {
    switch ($action) {

        case 'loadsubjects':
            // Params
            $categoryid = required_param('categoryid', PARAM_INT);
            $sessionid  = required_param('sessionid', PARAM_INT);
            $termid     = required_param('termid', PARAM_INT);
            $userid     = required_param('userid', PARAM_INT);

            // Fetch courses (subjects) for the category
            $courses = $DB->get_records('course', ['category' => $categoryid], 'sortorder,fullname');

            // Build results: for each course find local_sis_result record for this userid/session/term
            $out = ['courses' => []];
            foreach ($courses as $c) {
                // Try to find an existing result record
                $result = $DB->get_record('local_sis_result', [
                    'userid' => $userid,
                    'courseid' => $c->id,
                    'sessionid' => $sessionid,
                    'termid' => $termid
                ]);

                if ($result) {
                    // Decode data (array of scores) if present
                    $data = json_decode($result->data, true);
                    $firstca = isset($data[0]) ? $data[0] : null;
                    $secondca = isset($data[1]) ? $data[1] : null;
                    $exam = isset($data[2]) ? $data[2] : null;
                    $total = isset($result->total) ? $result->total : (($firstca ?? 0) + ($secondca ?? 0) + ($exam ?? 0));
                } else {
                    $firstca = $secondca = $exam = $total = null;
                }

                $out['courses'][] = [
                    'id' => $c->id,
                    'name' => $c->fullname,
                    'resultid' => $result ? $result->id : null,
                    'firstca' => $firstca,
                    'secondca' => $secondca,
                    'exam' => $exam,
                    'total' => $total
                ];
            }

            echo json_encode($out);
            break;

        case 'deletescores':
            // POST JSON expected: { sesskey: '...', ids: [1,2,3] }
            $raw = file_get_contents('php://input');
            $json = json_decode($raw, true);
            if (!is_array($json)) {
                throw new Exception('Invalid payload');
            }
            $sesskey = isset($json['sesskey']) ? $json['sesskey'] : '';
            $ids = isset($json['ids']) && is_array($json['ids']) ? $json['ids'] : [];

            if (!confirm_sesskey($sesskey)) {
                throw new Exception('Invalid session key');
            }

            if (empty($ids)) {
                throw new Exception('No result ids provided');
            }

            // Validate all ids are integers
            $ids = array_map('intval', $ids);
            $ids = array_filter($ids, function($v) { return $v > 0; });
            if (empty($ids)) {
                throw new Exception('No valid result ids provided');
            }

            // Security: ensure each result exists and optionally check more (like session/term/course)
            list($insql, $params) = $DB->get_in_or_equal($ids, SQL_PARAMS_NAMED, 'rid');
            // Optionally fetch records to verify they match expected constraints or ownership
            $records = $DB->get_records_select('local_sis_result', "id $insql", $params);

            if (empty($records)) {
                throw new Exception('No matching result records found');
            }

            // Delete only the provided ids
            $deleted = 0;
            foreach ($records as $rec) {
                // Additional guard: require capability checked earlier; optionally check rec fields
                try {
                    $DB->delete_records('local_sis_result', ['id' => $rec->id]);
                    $deleted++;
                } catch (Exception $e) {
                    // skip and continue
                }
            }

            echo json_encode(['deletedcount' => $deleted]);
            break;

        default:
            http_response_code(400);
            echo json_encode(['error' => 'Unknown action']);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}