<?php
// This file is part of the Student Information System plugin for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//This file bulk uploads students primarily.
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version information for the Student Information System plugin
 *
 * @package    local_sis
 * @copyright  2025 NduksTech - https://facebook.com/ndukshub
 * @author     Nduka Akapti  (https://github.com/nduka4real)
 * @author     Ndukstech (https://www.youtube.com/@nduks-tech)
 * @author     https://www.linkedin.com/in/ndukaakpati/
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @details
 * Display Name: Student Information System
 * Description: A comprehensive system for managing student records, assessments, fees, and school operations.
 * Contact: https://github.com/nduka4real
 * Social: https://facebook.com/ndukshub
 */

require_once(__DIR__ . '/../../config.php');
require_login();
require_capability('moodle/site:config', context_system::instance());

global $DB, $PAGE, $OUTPUT, $CFG;

$PAGE->set_url(new moodle_url('/local/sis/bulk_upload_students_confirm.php'));
$PAGE->set_context(context_system::instance());
$PAGE->set_title("Confirm Bulk Student Import");

$sessionid = required_param('sessionid', PARAM_INT);
$termid = required_param('termid', PARAM_INT);
$categoryid = required_param('categoryid', PARAM_INT);
$csvcontent = required_param('csvcontent', PARAM_RAW);

echo $OUTPUT->header();

/**
 * Enforce course enrollment for students in all category courses
 * This function ensures students are registered even if exams exist
 */
function enforce_course_enrollment($userid, $courseid, $sessionid, $termid) {
    global $DB;
    
    // Check if enrollment already exists
    $enrol_instance = $DB->get_record('enrol', [
        'courseid' => $courseid,
        'enrol' => 'manual'
    ]);
    
    if (!$enrol_instance) {
        return false; // No manual enrollment method available
    }
    
    // Check if user is already enrolled
    $existing_enrollment = $DB->get_record('user_enrolments', [
        'userid' => $userid,
        'enrolid' => $enrol_instance->id
    ]);
    
    if (!$existing_enrollment) {
        // Create new enrollment
        $enrollment = new stdClass();
        $enrollment->userid = $userid;
        $enrollment->enrolid = $enrol_instance->id;
        $enrollment->timestart = time();
        $enrollment->timeend = 0; // No end date
        $enrollment->modifierid = 2; // Admin user
        $enrollment->timecreated = time();
        $enrollment->timemodified = time();
        
        $DB->insert_record('user_enrolments', $enrollment);
        
        // Record in SIS enrollment table if it exists
        if ($DB->get_manager()->table_exists('local_sis_enrollments')) {
            $sis_enrollment = new stdClass();
            $sis_enrollment->userid = $userid;
            $sis_enrollment->courseid = $courseid;
            $sis_enrollment->sessionid = $sessionid;
            $sis_enrollment->termid = $termid;
            $sis_enrollment->timecreated = time();
            $sis_enrollment->timemodified = time();
            
            $DB->insert_record('local_sis_enrollments', $sis_enrollment);
        }
        
        return true;
    }
    
    return false; // Enrollment already exists
}

// Decode and process CSV
$content = base64_decode($csvcontent);
$lines = explode("\n", trim($content));
$header = str_getcsv(array_shift($lines));

$rows = [];
foreach ($lines as $line) {
    $row = array_combine($header, str_getcsv($line));
    if (!empty($row['username'])) {
        $rows[] = $row;
    }
}

// Get ALL courses in the selected category
$courses = $DB->get_records('course', ['category' => $categoryid], '', 'id, fullname, shortname');

echo $OUTPUT->heading("Import Processing");

// Show courses that students will be enrolled in
if ($courses) {
    echo $OUTPUT->heading("Enrolling students in these courses:", 3);
    $course_table = new html_table();
    $course_table->head = ['Course ID', 'Course Name', 'Short Name'];
    foreach ($courses as $course) {
        $course_table->data[] = [$course->id, $course->fullname, $course->shortname];
    }
    echo html_writer::table($course_table);
}

// Process the import
$success_count = 0;
$error_count = 0;
$enrollment_count = 0;

foreach ($rows as $row) {
    try {
        $user = null;
        $user_created = false;
        
        // Check if user already exists
        if ($DB->record_exists('user', ['username' => $row['username']])) {
            $user = $DB->get_record('user', ['username' => $row['username']]);
            echo "<p style='color:orange'>User {$row['username']} already exists - updating enrollment</p>";
        } elseif ($DB->record_exists('user', ['email' => $row['email']])) {
            $user = $DB->get_record('user', ['email' => $row['email']]);
            echo "<p style='color:orange'>User with email {$row['email']} already exists - updating enrollment</p>";
        } else {
            // Create new user
            $user = new stdClass();
            $user->username = $row['username'];
            $user->email = $row['email'];
            $user->firstname = $row['firstname'];
            $user->lastname = $row['lastname'];
            $user->password = hash_internal_user_password($row['password']);
            $user->confirmed = 1;
            $user->mnethostid = $CFG->mnet_localhost_id;
            $user->timecreated = time();
            $user->timemodified = time();
            
            $user->id = $DB->insert_record('user', $user);
            $user_created = true;
            echo "<p style='color:green'>Created new user: {$row['username']}</p>";
        }
        
        // ENROLL USER IN ALL COURSES IN THE CATEGORY
        foreach ($courses as $course) {
            $enrolled = enforce_course_enrollment($user->id, $course->id, $sessionid, $termid);
            if ($enrolled) {
                $enrollment_count++;
                echo "<p style='color:green'>? Enrolled in: {$course->shortname}</p>";
            } else {
                echo "<p style='color:blue'>? Already enrolled in: {$course->shortname}</p>";
            }
        }
        
        $success_count++;
        
    } catch (Exception $e) {
        echo "<p style='color:red'>Error processing {$row['username']}: " . $e->getMessage() . "</p>";
        $error_count++;
    }
}

echo $OUTPUT->heading("Import Complete");
echo "<p>Successfully processed: $success_count students</p>";
echo "<p>Errors: $error_count</p>";
echo "<p>Total course enrollments: $enrollment_count</p>";

echo $OUTPUT->single_button(new moodle_url('/local/sis/index.php'), 'Return to SIS');

echo $OUTPUT->footer();