<?php
// local/sis/studentresults.php

require_once(__DIR__ . '/../../config.php');
require_login();

$context = context_system::instance();
require_capability('local/sis:viewresults', $context);

$PAGE->set_context($context);
$PAGE->set_url(new moodle_url('/local/sis/studentresults.php'));
$PAGE->set_title('My Results');
$PAGE->set_heading('My Results');

global $DB, $USER;

// Get current session and term (default ones).
$session = $DB->get_record('local_sis_sessions', ['isdefault' => 1]);
$term    = $DB->get_record('local_sis_terms', ['isdefault' => 1]);

if (!$session || !$term) {
    echo $OUTPUT->header();
    echo $OUTPUT->notification('No active session/term found.', 'error');
    echo $OUTPUT->footer();
    exit;
}

// Fetch results for the logged-in student.
$sql = "SELECT r.*, c.fullname AS coursename
        FROM {local_sis_result} r
        JOIN {course} c ON c.id = r.courseid
        WHERE r.userid = :userid AND r.sessionid = :sessionid AND r.termid = :termid
        ORDER BY c.fullname ASC";

$params = [
    'userid'    => $USER->id,
    'sessionid' => $session->id,
    'termid'    => $term->id
];

$results = $DB->get_records_sql($sql, $params);

// Output.
echo $OUTPUT->header();

// ================= HEADER SECTION =================
echo html_writer::start_div('report-header text-center mb-4');

// School logo (replace with your logo file or Moodle pix).
$logourl = $OUTPUT->image_url('logo', 'local_sis'); // Place logo in pix/logo.png
echo html_writer::empty_tag('img', [
    'src' => $logourl,
    'alt' => 'School Logo',
    'style' => 'height:80px; margin-bottom:10px;'
]);

// School name.
echo html_writer::tag('h2', 'My School Name');
echo html_writer::tag('h4', 'Student Academic Report');

// Student details.
echo html_writer::start_div('student-info text-left mt-3');
echo html_writer::tag('p', '<strong>Name:</strong> ' . fullname($USER));
echo html_writer::tag('p', '<strong>Reg No:</strong> ' . s($USER->username));
echo html_writer::tag('p', '<strong>Session:</strong> ' . format_string($session->sessionname));
echo html_writer::tag('p', '<strong>Term:</strong> ' . format_string($term->termname));
echo html_writer::end_div();

echo html_writer::end_div(); // report-header

// ================= RESULTS TABLE =================
if ($results) {
    $table = new html_table();
    $table->head = ['Course', '1st CA', '2nd CA', 'Exam', 'Total', 'Grade', 'Points'];

    $totalpoints = 0;
    $totalcourses = 0;

    foreach ($results as $r) {
        $row = [];
        $row[] = s($r->coursename);

        // Extract CA and Exam scores from `data` JSON.
        $cas = json_decode($r->data, true);
        if (is_array($cas)) {
            $row[] = $cas[0] ?? '-';
            $row[] = $cas[1] ?? '-';
            $row[] = $cas[2] ?? '-';
        } else {
            $row[] = $r->firstca ?? '-';
            $row[] = $r->secondca ?? '-';
            $row[] = $r->exam ?? '-';
        }

        $row[] = $r->total;
        $row[] = $r->grade;
        $row[] = $r->points;

        $table->data[] = $row;

        $totalpoints += $r->points;
        $totalcourses++;
    }

    echo html_writer::table($table);

    // GPA.
    $gpa = $totalcourses > 0 ? round($totalpoints / $totalcourses, 2) : 0;
    echo html_writer::div('<strong>GPA:</strong> ' . $gpa, 'alert alert-info mt-3');

    // Print button.
    $printbutton = html_writer::tag('button',
        '<i class="icon fa fa-print"></i> Print Results',
        [
            'class' => 'btn btn-primary mt-3 d-print-none',
            'onclick' => 'window.print();'
        ]
    );
    echo html_writer::div($printbutton, 'text-center');

} else {
    echo $OUTPUT->notification('No results found for this session/term.', 'info');
}

echo $OUTPUT->footer();