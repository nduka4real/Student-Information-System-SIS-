<?php
// This file is part of the Student Information System plugin for Moodle.
// this files is used for comments on results 
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version information for the Student Information System plugin
 *
 * @package    local_sis
 * @copyright  2025 NduksTech - https://facebook.com/ndukshub
 * @author     Nduka Akapti  (https://github.com/nduka4real)
 * @author     Ndukstech (https://www.youtube.com/@nduks-tech)
 * @author     https://www.linkedin.com/in/ndukaakpati/
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @details
 * Display Name: Student Information System
 * Description: A comprehensive system for managing student records, assessments, fees, and school operations.
 * Contact: https://github.com/nduka4real
 * Social: https://facebook.com/ndukshub
 */

// Moodle core file includes
require_once(__DIR__ . '/../../config.php');
require_login();
require_capability('moodle/site:config', context_system::instance());

global $DB, $USER, $PAGE, $OUTPUT;

// Get URL parameters
$categoryid = optional_param('categoryid', 0, PARAM_INT);
$sessionid  = optional_param('sessionid', 0, PARAM_INT);
$termid     = optional_param('termid', 0, PARAM_INT);
$save       = optional_param('save', 0, PARAM_INT);

// --- Handle saving comments (must be before any output) ---
if ($save && confirm_sesskey()) {
    // Debug: Log that save is triggered
    error_log("=== SAVE COMMENTS TRIGGERED ===");
    error_log("Category ID: $categoryid, Session ID: $sessionid, Term ID: $termid");
    
    // Use $_POST directly and clean each parameter individually
    $comments = isset($_POST['comments']) ? $_POST['comments'] : [];
    
    // Debug: Log comments data
    error_log("Comments data received: " . print_r($comments, true));
    
    foreach ($comments as $userid => $fields) {
        // Clean each comment individually
        $teacher_comment = clean_param($fields['teacher'] ?? '', PARAM_TEXT);
        $principal_comment = clean_param($fields['principal'] ?? '', PARAM_TEXT);
        
        // Debug: Log individual comment
        error_log("Processing user $userid - Teacher: '$teacher_comment', Principal: '$principal_comment'");
        
        // Check if we need to create the record or update it
        // Try to find existing comment with the correct parameters
        $existing_comments = $DB->get_records('local_sis_comments', [
            'userid' => $userid,
            'categoryid' => $categoryid
        ]);
        
        $rec = null;
        foreach ($existing_comments as $comment) {
            // Check if this comment matches our session/term using either new or old columns
            if (($comment->sessionid == $sessionid && $comment->termid == $termid) || 
                ($comment->session == $sessionid && $comment->term == $termid)) {
                $rec = $comment;
                break;
            }
        }
        
        if (!$rec) {
            // Create new record with ALL correct column names
            $rec = new stdClass();
            $rec->userid = $userid;
            $rec->categoryid = $categoryid;
            $rec->sessionid = $sessionid;       // New column name
            $rec->termid = $termid;             // New column name
            $rec->session = $sessionid;         // Old column name (for backward compatibility)
            $rec->term = $termid;               // Old column name (for backward compatibility)
            $rec->teachercomment = $teacher_comment;
            $rec->principalcomment = $principal_comment;
            $rec->timemodified = time();
            
            $result = $DB->insert_record('local_sis_comments', $rec);
            error_log("Inserted new comment record for user $userid, result ID: $result");
        } else {
            // Update existing record
            $rec->teachercomment = $teacher_comment;
            $rec->principalcomment = $principal_comment;
            $rec->sessionid = $sessionid;       // Ensure new columns are set
            $rec->termid = $termid;             // Ensure new columns are set
            $rec->session = $sessionid;         // Ensure old columns are set
            $rec->term = $termid;               // Ensure old columns are set
            $rec->timemodified = time();
            
            $result = $DB->update_record('local_sis_comments', $rec);
            error_log("Updated comment record for user $userid, result: $result");
        }
    }
    
    // Debug: Log before redirect
    error_log("Redirecting to managecomments.php with parameters");
    
    // Use redirect with proper notification
    redirect(
        new moodle_url('/local/sis/managecomments.php', [
            'categoryid' => $categoryid,
            'sessionid' => $sessionid,
            'termid' => $termid
        ]),
        'Comments saved successfully!',
        null,
        \core\output\notification::NOTIFY_SUCCESS
    );
    exit;
}

// --- Page setup ---
$context = context_system::instance();
$PAGE->set_context($context);
$PAGE->set_url(new moodle_url('/local/sis/managecomments.php'));
$PAGE->set_title('SIS - Manage Comments');

echo $OUTPUT->header();

// --- Dashboard Button Definition ---
// FIX: Removed get_string() which was causing the error due to missing language string.
$dashboard_button = html_writer::tag(
    'a', 
    'Back to Main Dashboard', 
    ['href' => new moodle_url('/local/sis/index.php'), 'class' => 'btn btn-info mb-4']
);

// --- Output Dashboard Button at Top ---
echo $dashboard_button;


// --- Fetch sessions and terms ---
$sessions = $DB->get_records('local_sis_sessions', null, 'sessionname ASC');

// **FIX: Only load terms if a session is selected and filter by that session**
$terms = [];
if ($sessionid > 0) {
    // NOTE: This assumes 'local_sis_terms' has a 'sessionid' column to filter
    $terms = $DB->get_records('local_sis_terms', ['sessionid' => $sessionid], 'termname ASC');
}

// --- Default session/term logic ---
if (!$sessionid && $sessions) {
    $default_session = $DB->get_record('local_sis_sessions', ['isdefault' => 1]);
    if ($default_session) {
        $sessionid = $default_session->id;
    } else {
        // Fallback to the first session if no default is set
        reset($sessions);
        $sessionid = key($sessions);
    }
    
    // Re-fetch terms based on the newly set default session ID
    if ($sessionid > 0) {
        $terms = $DB->get_records('local_sis_terms', ['sessionid' => $sessionid], 'termname ASC');
    }
}

// **FIX: Only select a default term if terms are available (i.e., a session is active)**
if (!$termid) {
    if ($sessionid > 0 && $terms) {
        // Try to find default term associated with the current session
        $default_term = $DB->get_record('local_sis_terms', ['isdefault' => 1, 'sessionid' => $sessionid]);
        if ($default_term) {
            $termid = $default_term->id;
        } else {
            // Fallback: use the first term in the filtered list
            reset($terms);
            $termid = key($terms);
        }
    } else {
        // If no session or no terms, ensure termid is 0
        $termid = 0;
    }
}


// --- Dropdown options ---
$categories = $DB->get_records_menu('course_categories', null, 'name', 'id, name');

$session_options = [0 => '-- Select Session --'];
foreach ($sessions as $s) {  
    $session_options[$s->id] = $s->sessionname;  
}

// **FIX: Change placeholder text if no session is selected**
$term_options = [0 => ($sessionid > 0 ? '-- Select Term --' : '-- Select Session First --')];
foreach ($terms as $t) {  
    $term_options[$t->id] = $t->termname;  
}

// --- Selection form ---
echo html_writer::start_tag('form', ['method' => 'get', 'class' => 'form-inline mb-4', 'id' => 'filter-form']);
echo html_writer::label('Class:', 'categoryid', false, ['class' => 'mr-2']);
// Added ID 'categoryid' for consistency and potential JS use
echo html_writer::select($categories, 'categoryid', $categoryid, false, ['class' => 'form-control mr-3', 'id' => 'categoryid']);

echo html_writer::label('Session:', 'sessionid', false, ['class' => 'mr-2']);
// **FIX: Added ID 'sessionid' to enable JavaScript auto-submit**
echo html_writer::select($session_options, 'sessionid', $sessionid, false, ['class' => 'form-control mr-3', 'id' => 'sessionid']);

echo html_writer::label('Term:', 'termid', false, ['class' => 'mr-2']);
// **FIX: Disabled term dropdown if no session is selected**
$term_attrs = ['class' => 'form-control mr-3', 'id' => 'termid'];
if ($sessionid == 0) {
    $term_attrs['disabled'] = 'disabled';
}
echo html_writer::select($term_options, 'termid', $termid, false, $term_attrs);

echo html_writer::empty_tag('input', ['type' => 'submit', 'value' => 'Go', 'class' => 'btn btn-primary']);
echo html_writer::end_tag('form');

// Stop if no category or term is selected (now terms depend on session)
if (!$categoryid || !$sessionid || !$termid) {
    echo $OUTPUT->notification("Please select a Class, a Session, and a Term to view and manage comments.", 'notifymessage');
    echo $OUTPUT->footer();
    exit;
}

// --- Fetch students with aggregated results ---
$students = $DB->get_records_sql("
    SELECT
        u.id,
        u.firstname,
        u.lastname,
        SUM(r.total) AS finaltotalscore,
        COUNT(c.id) AS coursecount
    FROM {user} u
    JOIN {local_sis_result} r ON r.userid = u.id
    JOIN {course} c ON r.courseid = c.id
    WHERE c.category = :catid
      AND r.sessionid = :sessionid
      AND r.termid = :termid
    GROUP BY u.id, u.firstname, u.lastname
    ORDER BY u.lastname, u.firstname
", [
    'catid' => $categoryid,
    'sessionid' => $sessionid,
    'termid' => $termid
]);

if (!$students) {
    echo $OUTPUT->notification("No students found for this class, session, and term.", 'notifymessage');
    echo $OUTPUT->footer();
    exit;
}

// Pre-fetch all comments for these students in one query for efficiency
$user_ids = array_keys($students);
if (!empty($user_ids)) {
    list($insql, $inparams) = $DB->get_in_or_equal($user_ids);
    
    // Get comments using BOTH new and old column structures to ensure we find them
    $comments_records = $DB->get_records_sql("
        SELECT * FROM {local_sis_comments} 
        WHERE userid $insql 
        AND categoryid = ?
        AND (
            (sessionid = ? AND termid = ?) OR 
            (session = ? AND term = ?)
        )
    ", array_merge($inparams, [$categoryid, $sessionid, $termid, $sessionid, $termid]));
} else {
    $comments_records = [];
}

// Debug: Log comments fetched from database
error_log("Fetched " . count($comments_records) . " comment records from database for category $categoryid, session $sessionid, term $termid");

// Create a map for quick access
$comments_map = [];
foreach ($comments_records as $rec) {
    $comments_map[$rec->userid] = $rec;
    error_log("Comment for user $rec->userid: Teacher='$rec->teachercomment', Principal='$rec->principalcomment'");
}

// --- Build comments form ---
echo html_writer::start_tag('form', ['method' => 'post', 'class' => 'mb-4', 'id' => 'comments-form']);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey()]);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'save', 'value' => '1']);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'categoryid', 'value' => $categoryid]);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sessionid', 'value' => $sessionid]);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'termid', 'value' => $termid]);

// --- Bulk buttons ---
echo html_writer::start_div('mb-3');
echo html_writer::tag('button', 'Auto Generate All Teacher Comments', [
    'type' => 'button',
    'class' => 'btn btn-sm btn-info mr-2',
    'onclick' => "autoGenerateAll('teacher')"
]);
echo html_writer::tag('button', 'Auto Generate All Principal Comments', [
    'type' => 'button',
    'class' => 'btn btn-sm btn-info mr-2',
    'onclick' => "autoGenerateAll('principal')"
]);
echo html_writer::tag('button', 'Clear All Comments', [
    'type' => 'button',
    'class' => 'btn btn-sm btn-danger mr-2',
    'onclick' => "clearAllComments()"
]);
echo html_writer::tag('button', 'Clear Teacher Comments', [
    'type' => 'button',
    'class' => 'btn btn-sm btn-warning mr-2',
    'onclick' => "clearCommentsByRole('teacher')"
]);
echo html_writer::tag('button', 'Clear Principal Comments', [
    'type' => 'button',
    'class' => 'btn btn-sm btn-warning',
    'onclick' => "clearCommentsByRole('principal')"
]);
echo html_writer::end_div();

$table = new html_table();
$table->head = ['Student ID', 'Name', 'Final Total Score', 'Final Average', 'Teacher Comment', 'Principal Comment'];

foreach ($students as $s) {
    // Get comments from our pre-fetched map
    $teacher_comment = '';
    $principal_comment = '';
    
    if (isset($comments_map[$s->id])) {
        $teacher_comment = $comments_map[$s->id]->teachercomment ?? '';
        $principal_comment = $comments_map[$s->id]->principalcomment ?? '';
        
        // Debug: Log found comments
        error_log("Found comments for user $s->id: Teacher='$teacher_comment', Principal='$principal_comment'");
    } else {
        error_log("No comments found for user $s->id in category $categoryid, session $sessionid, term $termid");
    }

    // Calculate scores
    $finaltotalscore = (float)($s->finaltotalscore ?? 0);
    $coursecount = (int)($s->coursecount ?? 0);
    
    // FIXED: Calculate average and round to one decimal place properly
    $finalaverage = ($coursecount > 0) ? ($finaltotalscore / $coursecount) : 0;
    
    // FIXED: Use proper rounding to one decimal place (rounds 74.45 to 74.5)
    $finalaverage_rounded = round($finalaverage, 1);
    
    // Format for display - use rounded value
    $finalaverage_display = number_format($finalaverage_rounded, 1);

    // Teacher auto-comment logic - use rounded average for consistency
    if ($finalaverage_rounded >= 80) {
        $auto_teacher = "Outstanding performance with a total of $finaltotalscore marks and an excellent average of " . $finalaverage_display . "%. Keep it up!";
    } elseif ($finalaverage_rounded >= 65) {
        $auto_teacher = "Good work with a total of $finaltotalscore marks and an average of " . $finalaverage_display . "%. With more effort, you can reach the top.";
    } elseif ($finalaverage_rounded >= 50) {
        $auto_teacher = "Fair performance (total marks: $finaltotalscore, average: " . $finalaverage_display . "%). More consistency and focus are needed.";
    } else {
        $auto_teacher = "Poor result (total marks: $finaltotalscore, average: " . $finalaverage_display . "%). Serious improvement and dedication are required.";
    }

    // Principal auto-comment logic - use rounded average for consistency
    if ($finalaverage_rounded >= 80) {
        $auto_principal = "Excellent achievement. Maintain this high standard across all subjects.";
    } elseif ($finalaverage_rounded >= 65) {
        $auto_principal = "A commendable effort. Strive for more consistency and aim higher.";
    } elseif ($finalaverage_rounded >= 50) {
        $auto_principal = "An average performance. More hard work and determination will bring better results.";
    } else {
        $auto_principal = "Performance is below expectation. Strong commitment is needed to improve.";
    }

    // Fix fullname() warnings
    $userforname = new stdClass();
    $userforname->id = $s->id;
    $userforname->firstname = $s->firstname;
    $userforname->lastname = $s->lastname;
    $userforname->firstnamephonetic = '';
    $userforname->lastnamephonetic = '';
    $userforname->middlename = '';
    $userforname->alternatename = '';

    $row = [];
    $row[] = s($s->id);
    $row[] = fullname($userforname);
    $row[] = number_format($finaltotalscore, 2) ?: '-';
    $row[] = $finalaverage_display ?: '-';

    // Teacher comment field + button
    $row[] = html_writer::tag('textarea', s($teacher_comment), [
        'id' => "teacher_{$s->id}",
        'name' => "comments[{$s->id}][teacher]",
        'rows' => 2,
        'cols' => 35,
        'class' => 'comment-field'
    ]) .
    html_writer::tag('button', 'Auto Generate', [
        'type' => 'button',
        'class' => 'btn btn-sm btn-secondary ml-2',
        'onclick' => "document.getElementById('teacher_{$s->id}').value = '".addslashes($auto_teacher)."'"
    ]);

    // Principal comment field + button
    $row[] = html_writer::tag('textarea', s($principal_comment), [
        'id' => "principal_{$s->id}",
        'name' => "comments[{$s->id}][principal]",
        'rows' => 2,
        'cols' => 35,
        'class' => 'comment-field'
    ]) .
    html_writer::tag('button', 'Auto Generate', [
        'type' => 'button',
        'class' => 'btn btn-sm btn-secondary ml-2',
        'onclick' => "document.getElementById('principal_{$s->id}').value = '".addslashes($auto_principal)."'"
    ]);

    $table->data[] = $row;
}

echo html_writer::table($table);
echo html_writer::empty_tag('input', [
    'type' => 'submit', 
    'value' => 'Save All Comments', 
    'class' => 'btn btn-primary'
]);
echo html_writer::end_tag('form');

// --- Output Dashboard Button at Bottom ---
echo html_writer::start_div('mt-4');
echo $dashboard_button;
echo html_writer::end_div();


// --- JS for bulk actions and auto-submit on session change ---
echo html_writer::script("
// **NEW: Auto-submit form when session changes to update term list**
document.getElementById('sessionid').addEventListener('change', function() {
    // We only need to check if a session is selected to submit and update the term list
    this.form.submit();
});

// Bulk auto-generate comments only if textareas are empty
function autoGenerateAll(role) {
    const textareas = document.querySelectorAll('textarea[id^=\"' + role + '_\"]');
    textareas.forEach(textarea => {
        if (textarea.value.trim() === '') {
            const btn = document.querySelector('button[onclick*=\"' + textarea.id + '\"]');
            if (btn) { btn.click(); }
        }
    });
}

// Clear ALL comments
function clearAllComments() {
    if (!confirm('Are you sure you want to clear ALL teacher and principal comments?')) return;
    document.querySelectorAll('textarea[id^=\"teacher_\"], textarea[id^=\"principal_\"]').forEach(t => t.value = '');
}

// Clear comments by role (teacher or principal only)
function clearCommentsByRole(role) {
    if (!confirm('Are you sure you want to clear all ' + role + ' comments?')) return;
    document.querySelectorAll('textarea[id^=\"' + role + '_\"]').forEach(t => t.value = '');
}
");

echo $OUTPUT->footer();