<?php
// This file is part of the Student Information System plugin for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//This file bulk uploads students primarily.
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version information for the Student Information System plugin
 *
 * @package    local_sis
 * @copyright  2025 NduksTech - https://facebook.com/ndukshub
 * @author     Nduka Akapti  (https://github.com/nduka4real)
 * @author     Ndukstech (https://www.youtube.com/@nduks-tech)
 * @author     https://www.linkedin.com/in/ndukaakpati/
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @details
 * Display Name: Student Information System
 * Description: A comprehensive system for managing student records, assessments, fees, and school operations.
 * Contact: https://github.com/nduka4real
 * Social: https://facebook.com/ndukshub
 */
require_once(__DIR__ . '/../../config.php');
require_login();
require_capability('moodle/site:config', context_system::instance());

global $DB, $PAGE, $OUTPUT, $CFG;

$PAGE->set_url(new moodle_url('/local/sis/bulk_upload_students.php'));
$PAGE->set_context(context_system::instance());
$PAGE->set_title("Bulk Upload Students");

require_once($CFG->libdir.'/formslib.php');

/**
 * Enforce course enrollment for students in all category courses
 * This function ensures students are registered even if exams exist
 */
function enforce_course_enrollment($userid, $courseid, $sessionid, $termid) {
    global $DB;
    
    // Check if enrollment already exists
    $enrol_instance = $DB->get_record('enrol', [
        'courseid' => $courseid,
        'enrol' => 'manual'
    ]);
    
    if (!$enrol_instance) {
        return false; // No manual enrollment method available
    }
    
    // Check if user is already enrolled
    $existing_enrollment = $DB->get_record('user_enrolments', [
        'userid' => $userid,
        'enrolid' => $enrol_instance->id
    ]);
    
    if (!$existing_enrollment) {
        // Create new enrollment
        $enrollment = new stdClass();
        $enrollment->userid = $userid;
        $enrollment->enrolid = $enrol_instance->id;
        $enrollment->timestart = time();
        $enrollment->timeend = 0; // No end date
        $enrollment->modifierid = 2; // Admin user
        $enrollment->timecreated = time();
        $enrollment->timemodified = time();
        
        $DB->insert_record('user_enrolments', $enrollment);
        
        // Record in SIS enrollment table if it exists
        if ($DB->get_manager()->table_exists('local_sis_enrollments')) {
            $sis_enrollment = new stdClass();
            $sis_enrollment->userid = $userid;
            $sis_enrollment->courseid = $courseid;
            $sis_enrollment->sessionid = $sessionid;
            $sis_enrollment->termid = $termid;
            $sis_enrollment->timecreated = time();
            $sis_enrollment->timemodified = time();
            
            $DB->insert_record('local_sis_enrollments', $sis_enrollment);
        }
        
        return true;
    }
    
    return false; // Enrollment already exists
}

/// ==== FORM ====
class bulk_upload_form extends moodleform {
    function definition() {
        global $DB;

        $mform = $this->_form;

        // Session select - Fetches from mdl_local_sis_sessions
        $sessions = $DB->get_records_menu('local_sis_sessions', null, '', 'id,name');
        $mform->addElement('select', 'sessionid', 'Select Session', $sessions);
        $mform->addRule('sessionid', null, 'required', null, 'client');

        // Term select - Fetches from mdl_local_sis_terms
        $terms = $DB->get_records_menu('local_sis_terms', null, '', 'id,name');
        $mform->addElement('select', 'termid', 'Select Term', $terms);
        $mform->addRule('termid', null, 'required', null, 'client');

        // Class select
        $categories = $DB->get_records_menu('course_categories', null, '', 'id,name');
        $mform->addElement('select', 'categoryid', 'Select Class/Category', $categories);
        $mform->addRule('categoryid', null, 'required', null, 'client');

        // CSV upload
        $mform->addElement('filepicker', 'csvfile', 'Upload CSV file', null, ['accepted_types' => ['.csv']]);
        $mform->addRule('csvfile', null, 'required');

        $mform->addElement('submit', 'previewbutton', 'Preview Import');
    }
}

// Form instance
$mform = new bulk_upload_form();

echo $OUTPUT->header();

if ($mform->is_cancelled()) {
    redirect(new moodle_url('/local/sis/index.php'));

} else if ($data = $mform->get_data()) {

    // Handle uploaded CSV
    $csvfile = $mform->get_new_filename('csvfile');
    $content = $mform->get_file_content('csvfile');

    if ($content) {
        $lines = explode("\n", trim($content));
        $header = str_getcsv(array_shift($lines));

        $rows = [];
        foreach ($lines as $line) {
            $row = array_combine($header, str_getcsv($line));
            if (!empty($row['username'])) {
                $rows[] = $row;
            }
        }

        // === PREVIEW TABLE ===
        echo $OUTPUT->heading("Preview Import");

        // Get courses in the selected category to show enrollment info
        $courses = $DB->get_records('course', ['category' => $data->categoryid], '', 'id, fullname, shortname');
        
        if ($courses) {
            echo $OUTPUT->heading("Students will be enrolled in these courses:", 4);
            $course_list = [];
            foreach ($courses as $course) {
                $course_list[] = $course->shortname;
            }
            echo "<p><strong>" . implode(', ', $course_list) . "</strong></p>";
        }

        $table = new html_table();
        $table->head = ['Firstname', 'Lastname', 'Username', 'Email', 'Password', 'Status'];

        foreach ($rows as $row) {
            $status = '';
            if ($DB->record_exists('user', ['username' => $row['username']])) {
                $status = '<span style="color:red">Username exists - will update enrollment</span>';
            } elseif ($DB->record_exists('user', ['email' => $row['email']])) {
                $status = '<span style="color:orange">Email exists - will update enrollment</span>';
            } else {
                $status = '<span style="color:green">New user - will create and enroll</span>';
            }

            $table->data[] = [
                $row['firstname'],
                $row['lastname'],
                $row['username'],
                $row['email'],
                $row['password'],
                $status
            ];
        }
        echo html_writer::table($table);

        // Hidden form for confirmation
        $confirmurl = new moodle_url('/local/sis/bulk_upload_students_confirm.php');
        $hiddenform = html_writer::start_tag('form', ['method' => 'post', 'action' => $confirmurl]);
        $hiddenform .= html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sessionid', 'value' => $data->sessionid]);
        $hiddenform .= html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'termid', 'value' => $data->termid]);
        $hiddenform .= html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'categoryid', 'value' => $data->categoryid]);
        $hiddenform .= html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'csvcontent', 'value' => base64_encode($content)]);
        $hiddenform .= html_writer::empty_tag('input', ['type' => 'submit', 'value' => 'Confirm Import']);
        $hiddenform .= html_writer::end_tag('form');

        echo $hiddenform;
    }
} else {
    // Show form
    $mform->display();

    // Download sample CSV
    echo html_writer::link(
        new moodle_url('/local/sis/sample_students.csv'),
        'Download Sample CSV'
    );
}

echo $OUTPUT->footer();