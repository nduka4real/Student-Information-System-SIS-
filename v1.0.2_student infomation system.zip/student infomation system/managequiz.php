<?php
// This file is part of the Student Information System plugin for Moodle.
// This file manages all quizzes

// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version information for the Student Information System plugin
 *
 * @package    local_sis
 * @copyright  2025 NduksTech - https://facebook.com/ndukshub
 * @author     Nduka Akapti  (https://github.com/nduka4real)
 * @author     Ndukstech (https://www.youtube.com/@nduks-tech)
 * @author     https://www.linkedin.com/in/ndukaakpati/
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @details
 * Display Name: Student Information System
 * Description: A comprehensive system for managing student records, assessments, fees, and school operations.
 * Contact: https://github.com/nduka4real
 * Social: https://facebook.com/ndukshub
 */

// local/sis/managequiz.php

require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/filelib.php');
require_once($CFG->dirroot . '/mod/quiz/lib.php');
require_once($CFG->dirroot . '/course/lib.php');
require_once($CFG->dirroot . '/question/editlib.php');
require_once(__DIR__ . '/aikenlib.php');

require_login();
global $DB, $PAGE, $OUTPUT, $USER;

// Parameters
$categoryid = optional_param('categoryid', 0, PARAM_INT);
$courseid   = optional_param('courseid', 0, PARAM_INT);
$action     = optional_param('action', '', PARAM_ALPHA);
$quizid     = optional_param('quizid', 0, PARAM_INT);

// Page setup
$context = context_system::instance();
$PAGE->set_context($context);
$PAGE->set_pagelayout('standard');
$PAGE->set_url(new moodle_url('/local/sis/managequiz.php', [
    'categoryid' => $categoryid,
    'courseid' => $courseid
]));
$PAGE->set_title("Manage Quizzes - Student Information System");
$PAGE->set_heading("Quiz Management Dashboard");

// Load SIS CSS styles directly - FIXED: No more deprecated before_footer callback
$PAGE->requires->css(new moodle_url('/local/sis/styles.css'));

echo $OUTPUT->header();

// ============================================
// ADD CSS WRAPPER HERE
// ============================================
echo html_writer::start_div('local-sis');

// ============================================
// HEADER SECTION WITH BREADCRUMB AND ACTIONS
// ============================================
echo html_writer::start_div('row mb-4');
echo html_writer::start_div('col-md-8');
echo html_writer::tag('h1', 'Quiz Management', ['class' => 'h2 mb-1 text-primary']);
echo html_writer::start_div('breadcrumb');
if ($categoryid) {
    $category = $DB->get_record('course_categories', ['id' => $categoryid]);
    echo html_writer::link(
        new moodle_url('/local/sis/managequiz.php'),
        'Categories',
        ['class' => 'text-muted']
    );
    if ($category) {
        echo ' <span class="text-muted mx-2">�</span> ' . format_string($category->name);
    }
    if ($courseid) {
        $course = $DB->get_record('course', ['id' => $courseid]);
        echo ' <span class="text-muted mx-2">�</span> ' . ($course ? format_string($course->fullname) : 'Course');
    }
}
echo html_writer::end_div();
echo html_writer::end_div(); // col-md-8

echo html_writer::start_div('col-md-4 text-right');
echo html_writer::link(
    new moodle_url('/local/sis/index.php'),
    '<i class="fa fa-arrow-left"></i> Back to Main Dashboard',
    ['class' => 'btn btn-outline-primary']
);
echo html_writer::end_div(); // col-md-4
echo html_writer::end_div(); // row

// ============================================
// STEP 1: SELECT CATEGORY
// ============================================
if (!$categoryid) {
    echo html_writer::start_div('card');
    echo html_writer::start_div('card-header bg-primary text-white');
    echo html_writer::tag('h4', '<i class="fa fa-folder-open"></i> Select Category / Class', ['class' => 'mb-0']);
    echo html_writer::end_div(); // card-header
    
    echo html_writer::start_div('card-body');
    $categories = $DB->get_records('course_categories', null, 'name ASC');
    
    if (empty($categories)) {
        echo $OUTPUT->notification("No course categories found.", 'notifyproblem');
    } else {
        echo html_writer::tag('p', 'Choose a category to manage quizzes:', ['class' => 'text-muted mb-3']);
        echo html_writer::start_div('row');
        foreach ($categories as $cat) {
            $url = new moodle_url($PAGE->url, ['categoryid' => $cat->id]);
            echo html_writer::start_div('col-md-6 col-lg-4 mb-3');
            echo html_writer::link(
                $url,
                '<div class="card category-card h-100">
                    <div class="card-body text-center">
                        <i class="fa fa-folder fa-2x text-warning mb-2"></i>
                        <h5 class="card-title">' . format_string($cat->name) . '</h5>
                        <small class="text-muted">Click to view courses</small>
                    </div>
                </div>',
                ['class' => 'text-decoration-none']
            );
            echo html_writer::end_div(); // col
        }
        echo html_writer::end_div(); // row
    }
    echo html_writer::end_div(); // card-body
    echo html_writer::end_div(); // card

    // ============================================
    // CLOSE CSS WRAPPER BEFORE FOOTER
    // ============================================
    echo html_writer::end_div(); // Close local-sis
    echo $OUTPUT->footer();
    exit;
}

// ============================================
// STEP 2: SELECT COURSE
// ============================================
if ($categoryid && !$courseid) {
    $category = $DB->get_record('course_categories', ['id' => $categoryid]);
    
    echo html_writer::start_div('card');
    echo html_writer::start_div('card-header bg-primary text-white');
    echo html_writer::tag('h4', '<i class="fa fa-book"></i> Select Course', ['class' => 'mb-0']);
    if ($category) {
        echo html_writer::tag('small', 'Category: ' . format_string($category->name), ['class' => 'float-right mt-1']);
    }
    echo html_writer::end_div(); // card-header
    
    echo html_writer::start_div('card-body');
    $courses = $DB->get_records('course', ['category' => $categoryid], 'fullname ASC');
    
    if (empty($courses)) {
        echo $OUTPUT->notification("No courses found in this category.", 'notifyproblem');
        echo html_writer::link(
            new moodle_url('/local/sis/managequiz.php'),
            '<i class="fa fa-arrow-left"></i> Back to Categories',
            ['class' => 'btn btn-outline-primary mt-3']
        );
    } else {
        echo html_writer::tag('p', 'Choose a course to manage quizzes:', ['class' => 'text-muted mb-3']);
        echo html_writer::start_div('row');
        foreach ($courses as $course) {
            $url = new moodle_url($PAGE->url, [
                'categoryid' => $categoryid,
                'courseid' => $course->id
            ]);
            echo html_writer::start_div('col-md-6 col-lg-4 mb-3');
            echo html_writer::link(
                $url,
                '<div class="card course-card h-100">
                    <div class="card-body text-center">
                        <i class="fa fa-graduation-cap fa-2x text-info mb-2"></i>
                        <h5 class="card-title">' . format_string($course->fullname) . '</h5>
                        <small class="text-muted">Click to manage quizzes</small>
                    </div>
                </div>',
                ['class' => 'text-decoration-none']
            );
            echo html_writer::end_div(); // col
        }
        echo html_writer::end_div(); // row
        
        echo html_writer::start_div('mt-4 text-center');
        echo html_writer::link(
            new moodle_url('/local/sis/managequiz.php'),
            '<i class="fa fa-arrow-left"></i> Back to Categories',
            ['class' => 'btn btn-outline-secondary']
        );
        echo html_writer::end_div();
    }
    echo html_writer::end_div(); // card-body
    echo html_writer::end_div(); // card

    // ============================================
    // CLOSE CSS WRAPPER BEFORE FOOTER
    // ============================================
    echo html_writer::end_div(); // Close local-sis
    echo $OUTPUT->footer();
    exit;
}

// ============================================
// STEP 3: MANAGE QUIZZES
// ============================================
$context = context_course::instance($courseid);
require_capability('moodle/course:manageactivities', $context);

$course = $DB->get_record('course', ['id' => $courseid]);
$category = $DB->get_record('course_categories', ['id' => $categoryid]);

// Course header with navigation
echo html_writer::start_div('card mb-4');
echo html_writer::start_div('card-body bg-light');
echo html_writer::start_div('row');
echo html_writer::start_div('col-md-8');
echo html_writer::tag('h3', '<i class="fa fa-tasks"></i> ' . format_string($course->fullname), ['class' => 'mb-1']);
echo html_writer::tag('p', 'Category: ' . ($category ? format_string($category->name) : 'Unknown'), ['class' => 'text-muted mb-0']);
echo html_writer::end_div(); // col-md-8
echo html_writer::start_div('col-md-4 text-right');
echo html_writer::link(
    new moodle_url('/local/sis/managequiz.php', ['categoryid' => $categoryid]),
    '<i class="fa fa-arrow-left"></i> Back to Courses',
    ['class' => 'btn btn-outline-secondary']
);
echo ' ';
echo html_writer::link(
    new moodle_url('/course/view.php', ['id' => $courseid]),
    '<i class="fa fa-external-link"></i> View Course',
    ['class' => 'btn btn-outline-info', 'target' => '_blank']
);
echo html_writer::end_div(); // col-md-4
echo html_writer::end_div(); // row
echo html_writer::end_div(); // card-body
echo html_writer::end_div(); // card

// ============================================
// DASHBOARD STATISTICS
// ============================================
$quizzes = $DB->get_records('quiz', ['course' => $courseid], 'timecreated DESC');
$total_quizzes = count($quizzes);
$total_questions = 0;

foreach ($quizzes as $quiz) {
    $question_count = $DB->count_records_sql("SELECT COUNT(*) FROM {quiz_slots} WHERE quizid = ?", [$quiz->id]);
    $total_questions += $question_count;
}

echo html_writer::start_div('row mb-4');
// Total Quizzes
echo html_writer::start_div('col-md-3 mb-3');
echo html_writer::start_div('card stat-card bg-primary text-white h-100');
echo html_writer::start_div('card-body text-center');
echo html_writer::tag('h2', $total_quizzes, ['class' => 'display-4 mb-0']);
echo html_writer::tag('p', 'Total Quizzes', ['class' => 'mb-0']);
echo html_writer::end_div(); // card-body
echo html_writer::end_div(); // card
echo html_writer::end_div(); // col

// Total Questions
echo html_writer::start_div('col-md-3 mb-3');
echo html_writer::start_div('card stat-card bg-success text-white h-100');
echo html_writer::start_div('card-body text-center');
echo html_writer::tag('h2', $total_questions, ['class' => 'display-4 mb-0']);
echo html_writer::tag('p', 'Total Questions', ['class' => 'mb-0']);
echo html_writer::end_div(); // card-body
echo html_writer::end_div(); // card
echo html_writer::end_div(); // col

// Quick Actions
echo html_writer::start_div('col-md-3 mb-3');
echo html_writer::start_div('card stat-card bg-info text-white h-100');
echo html_writer::start_div('card-body text-center');
echo html_writer::tag('h2', '<i class="fa fa-plus"></i>', ['class' => 'mb-0']);
echo html_writer::tag('p', 'Create New Quiz', ['class' => 'mb-0']);
echo html_writer::end_div(); // card-body
echo html_writer::end_div(); // card
echo html_writer::end_div(); // col

// Empty column for layout
echo html_writer::start_div('col-md-3 mb-3');
echo html_writer::start_div('card stat-card bg-light h-100');
echo html_writer::start_div('card-body text-center');
echo html_writer::tag('h2', '<i class="fa fa-cog"></i>', ['class' => 'mb-0 text-muted']);
echo html_writer::tag('p', 'Tools', ['class' => 'mb-0 text-muted']);
echo html_writer::end_div(); // card-body
echo html_writer::end_div(); // card
echo html_writer::end_div(); // col
echo html_writer::end_div(); // row

// ============================================
// ACTION HANDLERS
// ============================================

// Handle Actions
if ($action === 'delete' && confirm_sesskey() && $quizid) {
    $quiz = $DB->get_record('quiz', ['id' => $quizid]);
    if ($quiz) {
        $cm = get_coursemodule_from_instance('quiz', $quizid, $courseid);
        if ($cm) {
            course_delete_module($cm->id);
            echo $OUTPUT->notification("Quiz deleted successfully.", 'notifysuccess');
        } else {
            $DB->delete_records('quiz', ['id' => $quizid]);
            echo $OUTPUT->notification("Quiz deleted successfully.", 'notifysuccess');
        }
    }
}

if ($action === 'edit' && confirm_sesskey() && $quizid) {
    $newname = required_param('newname', PARAM_TEXT);
    $quiz = $DB->get_record('quiz', ['id' => $quizid]);
    if ($quiz) {
        $quiz->name = $newname;
        $DB->update_record('quiz', $quiz);
        echo $OUTPUT->notification("Quiz name updated.", 'notifysuccess');
    }
}

if ($action === 'create_simple' && confirm_sesskey()) {
    $quizname = required_param('quizname', PARAM_TEXT);
    
    $quiz = new stdClass();
    $quiz->course = $courseid;
    $quiz->name = $quizname;
    $quiz->intro = 'Auto-created quiz.';
    $quiz->introformat = FORMAT_HTML;
    $quiz->timeopen = 0;
    $quiz->timeclose = 0;
    $quiz->timelimit = 0;
    $quiz->overduehandling = 'autosubmit';
    $quiz->preferredbehaviour = 'deferredfeedback';
    $quiz->attempts = 0;
    $quiz->grade = 100;
    $quiz->questionsperpage = 1;
    $quiz->shuffleanswers = 1;
    $quiz->grade = 100;
    $quiz->sumgrades = 100;
    $quiz->timecreated = time();
    $quiz->timemodified = time();
    
    $quiz->password = '';
    $quiz->subnet = '';
    
    try {
        $quizid = $DB->insert_record('quiz', $quiz);
        
        if ($quizid) {
            $mod = new stdClass();
            $mod->course = $courseid;
            $mod->module = $DB->get_field('modules', 'id', ['name' => 'quiz']);
            $mod->instance = $quizid;
            $mod->section = 0;
            $mod->visible = 1;
            $mod->visibleoncoursepage = 1;
            $mod->groupmode = 0;
            $mod->groupingid = 0;
            
            if (!$cmid = add_course_module($mod)) {
                throw new Exception('Could not add course module');
            }
            
            course_add_cm_to_section($courseid, $cmid, 0);
            
            echo $OUTPUT->notification("Quiz '{$quizname}' created successfully.", 'notifysuccess');
        } else {
            echo $OUTPUT->notification("Failed to create quiz.", 'notifyproblem');
        }
    } catch (Exception $e) {
        echo $OUTPUT->notification("Error creating quiz: " . $e->getMessage(), 'notifyproblem');
    }
}

// Import to question bank handler
if ($action === 'import_to_bank' && confirm_sesskey() && !empty($_FILES['aikenfile']['tmp_name'])) {
    $tmp = $_FILES['aikenfile']['tmp_name'];
    
    // We need a context for the question bank - use course context
    $context = context_course::instance($courseid);
    
    // Use the existing function to import to question bank with proper context
    $count = import_aiken_to_question_bank($tmp, $courseid, $context);
    if ($count > 0) {
        echo $OUTPUT->notification("Imported {$count} question(s) into question bank successfully.", 'notifysuccess');
    } else {
        echo $OUTPUT->notification("No valid questions found in uploaded file or import failed.", 'notifyproblem');
    }
}

if ($action === 'import' && confirm_sesskey() && !empty($_FILES['aikenfile']['tmp_name'])) {
    $tmp = $_FILES['aikenfile']['tmp_name'];
    $target_quiz = required_param('target_quiz', PARAM_INT);
    
    $quiz = $DB->get_record('quiz', ['id' => $target_quiz]);
    if ($quiz) {
        $count = import_aiken_to_quiz($tmp, $courseid, $target_quiz);
        if ($count > 0) {
            echo $OUTPUT->notification("Imported {$count} question(s) into quiz successfully.", 'notifysuccess');
        } else {
            echo $OUTPUT->notification("No valid questions found in uploaded file.", 'notifyproblem');
        }
    } else {
        echo $OUTPUT->notification("Target quiz not found.", 'notifyproblem');
    }
}

// Handle add questions from bank
if ($action === 'add_questions_from_bank' && confirm_sesskey()) {
    $target_quiz = required_param('target_quiz', PARAM_INT);
    $quiz = $DB->get_record('quiz', ['id' => $target_quiz]);
    if ($quiz) {
        $cm = get_coursemodule_from_instance('quiz', $quiz->id, $courseid, false, IGNORE_MISSING);
        if ($cm) {
            $question_adder_url = new moodle_url('/mod/quiz/edit.php', [
                'cmid' => $cm->id
            ]);
            redirect($question_adder_url);
        } else {
            echo $OUTPUT->notification("Course module not found for this quiz.", 'notifyproblem');
        }
    } else {
        echo $OUTPUT->notification("Target quiz not found.", 'notifyproblem');
    }
}

// ============================================
// QUIZ LIST WITH COMPREHENSIVE MANAGEMENT
// ============================================
$quizzes = $DB->get_records('quiz', ['course' => $courseid], 'timecreated DESC');

if (empty($quizzes)) {
    echo $OUTPUT->notification("No quizzes created yet for this course.", 'notifyproblem');
} else {
    echo html_writer::tag('h4', 'Existing Quizzes');
    echo html_writer::start_tag('table', ['class' => 'generaltable table table-bordered table-striped']);
    echo html_writer::start_tag('thead');
    echo html_writer::start_tag('tr');
    echo html_writer::tag('th', 'Quiz Name');
    echo html_writer::tag('th', 'Questions');
    echo html_writer::tag('th', 'Timing');
    echo html_writer::tag('th', 'Attempts');
    echo html_writer::tag('th', 'Actions', ['width' => '300px']);
    echo html_writer::end_tag('tr');
    echo html_writer::end_tag('thead');
    echo html_writer::start_tag('tbody');

    foreach ($quizzes as $quiz) {
        $cm = get_coursemodule_from_instance('quiz', $quiz->id, $courseid);
        
        // Count questions in this quiz
        $question_count = $DB->count_records_sql("
            SELECT COUNT(*) 
            FROM {quiz_slots} 
            WHERE quizid = ?", [$quiz->id]);

        if ($cm) {
            $viewurl = new moodle_url('/mod/quiz/view.php', ['id' => $cm->id]);
            $editurl = new moodle_url('/course/modedit.php', ['update' => $cm->id]);
            $questionsurl = new moodle_url('/mod/quiz/edit.php', ['cmid' => $cm->id]);
            $reportsurl = new moodle_url('/mod/quiz/report.php', ['id' => $cm->id]);
            
            $viewlink = html_writer::link($viewurl, format_string($quiz->name), ['class' => 'font-weight-bold']);
        } else {
            $viewlink = format_string($quiz->name) . ' <span class="badge badge-warning">No course module</span>';
            $editurl = '';
            $questionsurl = '';
            $reportsurl = '';
        }

        // Timing info
        $timing = '';
        if ($quiz->timeopen && $quiz->timeclose) {
            $timing = userdate($quiz->timeopen, '%d/%m %H:%M') . '<br>to<br>' . userdate($quiz->timeclose, '%d/%m %H:%M');
        } elseif ($quiz->timeopen) {
            $timing = 'From: ' . userdate($quiz->timeopen, '%d/%m %H:%M');
        } elseif ($quiz->timeclose) {
            $timing = 'Until: ' . userdate($quiz->timeclose, '%d/%m %H:%M');
        } else {
            $timing = 'No restrictions';
        }

        // Attempts info
        $attempts_info = $quiz->attempts == 0 ? 'Unlimited' : $quiz->attempts . ' attempts';

        $deleteurl = new moodle_url($PAGE->url, [
            'categoryid' => $categoryid,
            'courseid' => $courseid,
            'quizid' => $quiz->id,
            'action' => 'delete',
            'sesskey' => sesskey()
        ]);

        echo html_writer::start_tag('tr');
        echo html_writer::tag('td', $viewlink);
        
        // Questions count
        echo html_writer::start_tag('td', ['class' => 'text-center']);
        echo $question_count . ' questions';
        echo html_writer::end_tag('td');
        
        echo html_writer::tag('td', $timing, ['style' => 'font-size: 0.8em;', 'class' => 'text-center']);
        echo html_writer::tag('td', $attempts_info, ['class' => 'text-center']);
        echo html_writer::start_tag('td');
        
        // Action buttons
        if ($cm) {
            echo html_writer::link($viewurl, ' View', ['class' => 'btn btn-sm btn-outline-primary mr-1']);
            echo html_writer::link($editurl, ' Settings', ['class' => 'btn btn-sm btn-outline-secondary mr-1']);
            echo html_writer::link($questionsurl, ' Questions', ['class' => 'btn btn-sm btn-outline-info mr-1']);
            echo html_writer::link($reportsurl, ' Reports', ['class' => 'btn btn-sm btn-outline-success mr-1']);
        }
        
        // Quick edit form
        echo '<form method="post" style="display:inline;">
            <input type="hidden" name="categoryid" value="'.$categoryid.'">
            <input type="hidden" name="courseid" value="'.$courseid.'">
            <input type="hidden" name="quizid" value="'.$quiz->id.'">
            <input type="hidden" name="action" value="edit">
            <input type="hidden" name="sesskey" value="'.sesskey().'">
            <input type="text" name="newname" value="'.s($quiz->name).'" style="width:120px; display:inline;" class="form-control form-control-sm d-inline-block">
            <button type="submit" class="btn btn-sm btn-warning">Update</button>
        </form>';
        
        echo html_writer::link($deleteurl, 'Delete', [
            'class' => 'btn btn-sm btn-danger ml-1',
            'onclick' => "return confirm('Are you sure you want to delete this quiz?');",
            'title' => 'Delete Quiz'
        ]);
        
        echo html_writer::end_tag('td');
        echo html_writer::end_tag('tr');
    }

    echo html_writer::end_tag('tbody');
    echo html_writer::end_tag('table');
}

// ============================================
// CREATE QUIZ OPTIONS
// ============================================
echo html_writer::tag('h4', 'Create New Quiz');

// Option 1: Use Moodle's built-in quiz creation
echo '<div class="card mb-4">';
echo '<div class="card-header bg-primary text-white">';
echo '<h5 class="mb-0">Option 1: Use Moodle\'s Built-in Quiz Creator (Recommended)</h5>';
echo '</div>';
echo '<div class="card-body">';
echo '<p>This will open Moodle\'s standard quiz creation form with all the advanced settings:</p>';
$moodle_quiz_url = new moodle_url('/course/modedit.php', [
    'add' => 'quiz',
    'course' => $courseid,
    'section' => 0
]);
echo html_writer::link($moodle_quiz_url, 'Open Moodle Quiz Creator', [
    'class' => 'btn btn-success btn-lg',
    'target' => '_blank'
]);
echo '</div>';
echo '</div>';

// Option 2: Simple quick creation
echo '<div class="card mb-4">';
echo '<div class="card-header bg-secondary text-white">';
echo '<h5 class="mb-0">Option 2: Quick Create Simple Quiz</h5>';
echo '</div>';
echo '<div class="card-body">';
echo '<p>Create a basic quiz quickly (limited settings):</p>';
echo '<form method="post">';
echo '<input type="hidden" name="action" value="create_simple">';
echo '<input type="hidden" name="sesskey" value="'.sesskey().'">';
echo '<input type="hidden" name="categoryid" value="'.$categoryid.'">';
echo '<input type="hidden" name="courseid" value="'.$courseid.'">';

echo '<div class="form-group">';
echo '<label for="quizname">Quiz Name *</label>';
echo '<input type="text" id="quizname" name="quizname" class="form-control" required placeholder="Enter quiz name">';
echo '</div>';

echo '<button type="submit" class="btn btn-primary">Create Simple Quiz</button>';
echo '</form>';
echo '</div>';
echo '</div>';

// ============================================
// QUESTION BANK MANAGEMENT
// ============================================
echo html_writer::tag('h4', 'Question Bank Management');

echo '<div class="card mb-4">';
echo '<div class="card-header bg-info text-white">';
echo '<h5 class="mb-0">Question Bank Tools</h5>';
echo '</div>';
echo '<div class="card-body">';

$question_bank_url = new moodle_url('/question/bank/managecategories/category.php', [
    'courseid' => $courseid
]);

echo '<div class="row">';

// Option 1: Direct course question bank
echo '<div class="col-md-6">';
echo '<div class="card">';
echo '<div class="card-header">Course Question Bank</div>';
echo '<div class="card-body">';
echo '<p class="small">Access the question bank for this course:</p>';
echo html_writer::link($question_bank_url, 'Open Course Question Bank', [
    'class' => 'btn btn-info btn-sm',
    'target' => '_blank'
]);
echo '</div>';
echo '</div>';
echo '</div>';

// Option 2: Use quiz-specific question bank
echo '<div class="col-md-6">';
echo '<div class="card">';
echo '<div class="card-header">Quiz Question Bank</div>';
echo '<div class="card-body">';
if (!empty($quizzes)) {
    $first_quiz = reset($quizzes);
    $cm = get_coursemodule_from_instance('quiz', $first_quiz->id, $courseid);
    if ($cm) {
        $quiz_question_bank_url = new moodle_url('/question/bank/managecategories/category.php', [
            'cmid' => $cm->id
        ]);
        echo '<p class="small">Access question bank via quiz context:</p>';
        echo html_writer::link($quiz_question_bank_url, 'Open Quiz Question Bank', [
            'class' => 'btn btn-info btn-sm',
            'target' => '_blank'
        ]);
    } else {
        echo '<p class="text-muted small">No valid course modules found for quizzes.</p>';
    }
} else {
    echo '<p class="text-muted small">Create a quiz first to access question bank.</p>';
}
echo '</div>';
echo '</div>';
echo '</div>';

echo '</div>'; // end row

// Alternative: Use the standard question edit interface
echo '<div class="mt-3">';
echo '<h6>Alternative Access Methods:</h6>';
echo '<div class="row">';

// Method 1: Standard question edit interface
echo '<div class="col-md-4">';
$question_edit_url = new moodle_url('/question/edit.php', [
    'courseid' => $courseid
]);
echo html_writer::link($question_edit_url, 'Question Edit Interface', [
    'class' => 'btn btn-outline-primary btn-sm',
    'target' => '_blank'
]);
echo '</div>';

// Method 2: Import questions directly
echo '<div class="col-md-4">';
$question_import_url = new moodle_url('/question/import.php', [
    'courseid' => $courseid
]);
echo html_writer::link($question_import_url, 'Import Questions', [
    'class' => 'btn btn-outline-success btn-sm',
    'target' => '_blank'
]);
echo '</div>';

// Method 3: Export questions
echo '<div class="col-md-4">';
$question_export_url = new moodle_url('/question/export.php', [
    'courseid' => $courseid
]);
echo html_writer::link($question_export_url, 'Export Questions', [
    'class' => 'btn btn-outline-warning btn-sm',
    'target' => '_blank'
]);
echo '</div>';

echo '</div>'; // end row
echo '</div>';

echo '</div>'; // end card-body
echo '</div>'; // end card

// ============================================
// QUESTION IMPORT/EXPORT SECTION
// ============================================
echo html_writer::tag('h4', 'Question Import/Export');

echo '<div class="card mb-4">';
echo '<div class="card-header bg-success text-white">';
echo '<h5 class="mb-0">Import Questions to Question Bank</h5>';
echo '</div>';
echo '<div class="card-body">';

echo '<div class="row">';

// Import questions to question bank
echo '<div class="col-md-6">';
echo '<div class="card">';
echo '<div class="card-header">Import Questions to Question Bank</div>';
echo '<div class="card-body">';
echo '<form method="post" enctype="multipart/form-data">';
echo '<input type="hidden" name="action" value="import_to_bank">';
echo '<input type="hidden" name="sesskey" value="'.sesskey().'">';
echo '<input type="hidden" name="categoryid" value="'.$categoryid.'">';
echo '<input type="hidden" name="courseid" value="'.$courseid.'">';

echo '<div class="form-group">';
echo '<label>Upload AIKEN Format File (.txt):</label>';
echo '<input type="file" name="aikenfile" accept=".txt" class="form-control-file" required>';
echo '<small class="form-text text-muted">Upload a .txt file in AIKEN format to add questions to the question bank.</small>';
echo '</div>';

echo '<button type="submit" class="btn btn-success">Import to Question Bank</button>';
echo '</form>';
echo '</div>';
echo '</div>';
echo '</div>';

// Add questions from question bank to quiz
echo '<div class="col-md-6">';
echo '<div class="card">';
echo '<div class="card-header">Add Questions from Bank to Quiz</div>';
echo '<div class="card-body">';
if (!empty($quizzes)) {
    echo '<form method="post">';
    echo '<input type="hidden" name="action" value="add_questions_from_bank">';
    echo '<input type="hidden" name="sesskey" value="'.sesskey().'">';
    echo '<input type="hidden" name="categoryid" value="'.$categoryid.'">';
    echo '<input type="hidden" name="courseid" value="'.$courseid.'">';
    
    echo '<div class="form-group">';
    echo '<label>Select Quiz:</label>';
    echo '<select name="target_quiz" class="form-control" required>';
    foreach ($quizzes as $quiz) {
        $cm = get_coursemodule_from_instance('quiz', $quiz->id, $courseid, false, IGNORE_MISSING);
        if ($cm || $quiz->course == $courseid) {
            echo '<option value="'.$quiz->id.'">'.format_string($quiz->name);
            if (!$cm) {
                echo ' (will fix CM)';
            }
            echo '</option>';
        }
    }
    echo '</select>';
    echo '</div>';
    
    echo '<button type="submit" class="btn btn-warning">Open Question Adder</button>';
    echo '<small class="form-text text-muted">This will open the quiz question editor where you can add questions from the bank.</small>';
    echo '</form>';
} else {
    echo '<p class="text-muted">Create a quiz first to add questions.</p>';
}
echo '</div>';
echo '</div>';
echo '</div>';

echo '</div>'; // end row
echo '</div>'; // end card-body
echo '</div>'; // end card

// ============================================
// CALENDAR VIEW FOR QUIZ SCHEDULES
// ============================================
echo html_writer::tag('h4', 'Quiz Schedule Calendar');

// Get upcoming quizzes with due dates
$upcoming_quizzes = $DB->get_records_sql("
    SELECT q.*, cm.id as cmid
    FROM {quiz} q
    JOIN {course_modules} cm ON cm.instance = q.id AND cm.module = (
        SELECT id FROM {modules} WHERE name = 'quiz'
    )
    WHERE q.course = ? AND q.timeclose > ? AND q.timeclose < ?
    ORDER BY q.timeclose ASC
", [$courseid, time(), time() + (30 * 24 * 60 * 60)]); // Next 30 days

if (!empty($upcoming_quizzes)) {
    echo '<div class="card">';
    echo '<div class="card-header">Upcoming Quizzes (Next 30 Days)</div>';
    echo '<div class="card-body">';
    echo '<ul class="list-group">';
    
    foreach ($upcoming_quizzes as $quiz) {
        $cm = get_coursemodule_from_instance('quiz', $quiz->id, $courseid);
        $quizurl = new moodle_url('/mod/quiz/view.php', ['id' => $cm->id]);
        
        echo '<li class="list-group-item d-flex justify-content-between align-items-center">';
        echo '<div>';
        echo '<strong>' . html_writer::link($quizurl, format_string($quiz->name)) . '</strong><br>';
        echo '<small class="text-muted">Due: ' . userdate($quiz->timeclose, '%A, %B %d, %Y at %I:%M %p') . '</small>';
        echo '</div>';
        echo '<span class="badge badge-primary badge-pill">';
        echo format_time($quiz->timeclose - time());
        echo ' left</span>';
        echo '</li>';
    }
    
    echo '</ul>';
    echo '</div>';
    echo '</div>';
} else {
    echo '<div class="alert alert-info">No upcoming quizzes scheduled in the next 30 days.</div>';
}

// ============================================
// IMPORT AIKEN TO QUIZ
// ============================================
if (!empty($quizzes)) {
    echo html_writer::tag('h4', 'Import Questions Directly to Quiz (AIKEN .txt)');
    echo '<div class="card">';
    echo '<div class="card-body">';
    echo '<form method="post" enctype="multipart/form-data">';
    echo '<input type="hidden" name="action" value="import">';
    echo '<input type="hidden" name="sesskey" value="'.sesskey().'">';
    echo '<input type="hidden" name="categoryid" value="'.$categoryid.'">';
    echo '<input type="hidden" name="courseid" value="'.$courseid.'">';
    
    echo '<div class="form-group">';
    echo '<label>Select Target Quiz:</label>';
    echo '<select name="target_quiz" class="form-control">';
    foreach ($quizzes as $quiz) {
        echo '<option value="'.$quiz->id.'">'.format_string($quiz->name).'</option>';
    }
    echo '</select>';
    echo '</div>';
    
    echo '<div class="form-group">';
    echo '<label>Upload AIKEN Format File (.txt):</label>';
    echo '<input type="file" name="aikenfile" accept=".txt" class="form-control-file" required>';
    echo '<small class="form-text text-muted">Upload a .txt file in AIKEN format containing your questions.</small>';
    echo '</div>';
    
    echo '<button type="submit" class="btn btn-success">Import Questions to Quiz</button>';
    echo '</form>';
    echo '</div>';
    echo '</div>';
} else {
    echo html_writer::tag('p', 'Create a quiz first to import questions.', ['class' => 'alert alert-info']);
}

// Refresh button to see newly created quizzes
echo '<div class="mt-4 text-center">';
$refresh_url = new moodle_url($PAGE->url, ['categoryid' => $categoryid, 'courseid' => $courseid]);
echo html_writer::link($refresh_url, 'Refresh Page', ['class' => 'btn btn-outline-secondary btn-lg']);
echo '</div>';

// ============================================
// CLOSE CSS WRAPPER BEFORE FOOTER
// ============================================
echo html_writer::end_div(); // Close local-sis

echo $OUTPUT->footer();