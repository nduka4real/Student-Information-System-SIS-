<?php
// This file is part of the Student Information System plugin for Moodle.
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version information for the Student Information System plugin
 *
 * @package    local_sis
 * @copyright  2025 NduksTech - https://facebook.com/ndukshub
 * @author     Nduka Akapti  (https://github.com/nduka4real)
 * @author     Ndukstech (https://www.youtube.com/@nduks-tech)
 * @author     https://www.linkedin.com/in/ndukaakpati/
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @details
 * Display Name: Student Information System
 * Description: A comprehensive system for managing student records, assessments, fees, and school operations.
 * Contact: https://github.com/nduka4real
 * Social: https://facebook.com/ndukshub
 */
// This file is responsible for generating and downloading a sample CSV file
// with student details for bulk Continuous Assessment (CA) score uploads.

// Core Moodle includes
require_once(__DIR__ . '/../../config.php');
require_login();

// Get the course ID from the request
$courseid = required_param('courseid', PARAM_INT);
$course = get_course($courseid);
$context = context_course::instance($course->id);

// Ensure the user has the required capability to access this page
require_login($course);
require_capability('moodle/course:update', $context);

global $DB;

// Fetch the CA configuration to get the component names
$ca_config = $DB->get_record('local_sis_ca_config', ['courseid' => $courseid]);
if (!$ca_config) {
    // If no config exists, redirect with an error message
    redirect(new moodle_url('/local/sis/enterca.php', ['courseid' => $courseid]), 'CA configuration not found. Please configure it first.', 3);
}
$components = json_decode($ca_config->components, true);

// Get the list of enrolled students
$students = get_enrolled_users($context, 'mod/assign:submit');
if (empty($students)) {
    // If no students are enrolled, redirect with an error message
    redirect(new moodle_url('/local/sis/enterca.php', ['courseid' => $courseid]), 'No students enrolled in this course.', 3);
}

// Set up the CSV file name for download
$filename = 'CA_Template_' . preg_replace('/[^a-z0-9]+/i', '_', $course->fullname) . '.csv';

// Set HTTP headers for a file download
header('Content-Type: text/csv');
header('Content-Disposition: attachment;filename="' . $filename . '"');
header('Cache-Control: max-age=0');

// Open a file handle to the output stream
$output = fopen('php://output', 'w');

// Create the header row for the CSV file
$header = ['ID Number', 'Username', 'Full Name'];
foreach ($components as $component) {
    $header[] = $component['name'] . ' (Max: ' . $component['max'] . ')';
}

// Write the header row to the CSV file
fputcsv($output, $header);

// Populate the CSV with student data
foreach ($students as $student) {
    $data = [
        $student->idnumber,
        $student->username,
        fullname($student),
    ];
    // Add an empty value for each component to serve as a placeholder for scores
    foreach ($components as $component) {
        $data[] = '';
    }
    // Write the student's data row to the CSV file
    fputcsv($output, $data);
}

// Close the file handle
fclose($output);

// Terminate the script to prevent any further output
exit;